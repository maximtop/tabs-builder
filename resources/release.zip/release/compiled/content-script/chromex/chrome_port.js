// Compiled by ClojureScript 1.10.439 {:static-fns true, :optimize-constants true, :elide-asserts true}
goog.provide('chromex.chrome_port');
goog.require('cljs.core');
goog.require('cljs.core.constants');
goog.require('oops.core');
goog.require('chromex.support');
goog.require('chromex.protocols.chrome_port');
goog.require('chromex.protocols.chrome_port_state');
goog.require('cljs.core.async.impl.protocols');
goog.require('cljs.core.async');

/**
* @constructor
 * @implements {chromex.protocols.chrome_port.IChromePort}
 * @implements {chromex.protocols.chrome_port_state.IChromePortState}
 * @implements {cljs.core.async.impl.protocols.Channel}
 * @implements {cljs.core.async.impl.protocols.ReadPort}
*/
chromex.chrome_port.ChromePort = (function (config,native_chrome_port,channel,connected_QMARK_){
this.config = config;
this.native_chrome_port = native_chrome_port;
this.channel = channel;
this.connected_QMARK_ = connected_QMARK_;
});
chromex.chrome_port.ChromePort.prototype.chromex$protocols$chrome_port$IChromePort$ = cljs.core.PROTOCOL_SENTINEL;

chromex.chrome_port.ChromePort.prototype.chromex$protocols$chrome_port$IChromePort$get_native_port$arity$1 = (function (_this){
var self__ = this;
var _this__$1 = this;
return self__.native_chrome_port;
});

chromex.chrome_port.ChromePort.prototype.chromex$protocols$chrome_port$IChromePort$get_name$arity$1 = (function (_this){
var self__ = this;
var _this__$1 = this;
var target_obj_31164 = self__.native_chrome_port;
var next_obj_31165 = (target_obj_31164["name"]);
return next_obj_31165;
});

chromex.chrome_port.ChromePort.prototype.chromex$protocols$chrome_port$IChromePort$get_sender$arity$1 = (function (_this){
var self__ = this;
var _this__$1 = this;
var target_obj_31166 = self__.native_chrome_port;
var next_obj_31167 = (target_obj_31166["sender"]);
return next_obj_31167;
});

chromex.chrome_port.ChromePort.prototype.chromex$protocols$chrome_port$IChromePort$post_message_BANG_$arity$2 = (function (this$,message){
var self__ = this;
var this$__$1 = this;
if((message == null)){
var config__6143__auto__ = self__.config;
var handler_key__6144__auto__ = cljs.core.cst$kw$chrome_DASH_port_DASH_post_DASH_message_DASH_called_DASH_with_DASH_nil;
var handler__6145__auto__ = handler_key__6144__auto__.cljs$core$IFn$_invoke$arity$1(config__6143__auto__);

return (handler__6145__auto__.cljs$core$IFn$_invoke$arity$2 ? handler__6145__auto__.cljs$core$IFn$_invoke$arity$2(config__6143__auto__,this$__$1) : handler__6145__auto__.call(null,config__6143__auto__,this$__$1));
} else {
if(cljs.core.truth_(self__.connected_QMARK_)){
var target_obj_31168 = self__.native_chrome_port;
var call_info_31170 = [target_obj_31168,(function (){var next_obj_31171 = (target_obj_31168["postMessage"]);
return next_obj_31171;
})()];
var fn_31169 = (call_info_31170[(1)]);
if((!((fn_31169 == null)))){
return fn_31169.call((call_info_31170[(0)]),message);
} else {
return null;
}
} else {
var config__6143__auto__ = self__.config;
var handler_key__6144__auto__ = cljs.core.cst$kw$chrome_DASH_port_DASH_post_DASH_message_DASH_called_DASH_on_DASH_disconnected_DASH_port;
var handler__6145__auto__ = handler_key__6144__auto__.cljs$core$IFn$_invoke$arity$1(config__6143__auto__);

return (handler__6145__auto__.cljs$core$IFn$_invoke$arity$2 ? handler__6145__auto__.cljs$core$IFn$_invoke$arity$2(config__6143__auto__,this$__$1) : handler__6145__auto__.call(null,config__6143__auto__,this$__$1));
}
}
});

chromex.chrome_port.ChromePort.prototype.chromex$protocols$chrome_port$IChromePort$disconnect_BANG_$arity$1 = (function (this$){
var self__ = this;
var this$__$1 = this;
if(cljs.core.truth_(self__.connected_QMARK_)){
var target_obj_31172 = self__.native_chrome_port;
var call_info_31174 = [target_obj_31172,(function (){var next_obj_31175 = (target_obj_31172["disconnect"]);
return next_obj_31175;
})()];
var fn_31173 = (call_info_31174[(1)]);
if((!((fn_31173 == null)))){
return fn_31173.call((call_info_31174[(0)]));
} else {
return null;
}
} else {
var config__6143__auto__ = self__.config;
var handler_key__6144__auto__ = cljs.core.cst$kw$chrome_DASH_port_DASH_disconnect_DASH_called_DASH_on_DASH_disconnected_DASH_port;
var handler__6145__auto__ = handler_key__6144__auto__.cljs$core$IFn$_invoke$arity$1(config__6143__auto__);

return (handler__6145__auto__.cljs$core$IFn$_invoke$arity$2 ? handler__6145__auto__.cljs$core$IFn$_invoke$arity$2(config__6143__auto__,this$__$1) : handler__6145__auto__.call(null,config__6143__auto__,this$__$1));
}
});

chromex.chrome_port.ChromePort.prototype.chromex$protocols$chrome_port$IChromePort$on_disconnect_BANG_$arity$2 = (function (this$,callback){
var self__ = this;
var this$__$1 = this;
if(cljs.core.truth_(self__.connected_QMARK_)){
var target_obj_31176 = self__.native_chrome_port;
var call_info_31178 = (function (){var target_obj_31179 = (function (){var next_obj_31180 = (target_obj_31176["onDisconnect"]);
return next_obj_31180;
})();
return [target_obj_31179,(function (){var next_obj_31181 = (target_obj_31179["addListener"]);
return next_obj_31181;
})()];
})();
var fn_31177 = (call_info_31178[(1)]);
if((!((fn_31177 == null)))){
return fn_31177.call((call_info_31178[(0)]),callback);
} else {
return null;
}
} else {
var config__6143__auto__ = self__.config;
var handler_key__6144__auto__ = cljs.core.cst$kw$chrome_DASH_port_DASH_on_DASH_disconnect_DASH_called_DASH_on_DASH_disconnected_DASH_port;
var handler__6145__auto__ = handler_key__6144__auto__.cljs$core$IFn$_invoke$arity$1(config__6143__auto__);

return (handler__6145__auto__.cljs$core$IFn$_invoke$arity$2 ? handler__6145__auto__.cljs$core$IFn$_invoke$arity$2(config__6143__auto__,this$__$1) : handler__6145__auto__.call(null,config__6143__auto__,this$__$1));
}
});

chromex.chrome_port.ChromePort.prototype.chromex$protocols$chrome_port$IChromePort$on_message_BANG_$arity$2 = (function (this$,callback){
var self__ = this;
var this$__$1 = this;
if(cljs.core.truth_(self__.connected_QMARK_)){
var target_obj_31182 = self__.native_chrome_port;
var call_info_31184 = (function (){var target_obj_31185 = (function (){var next_obj_31186 = (target_obj_31182["onMessage"]);
return next_obj_31186;
})();
return [target_obj_31185,(function (){var next_obj_31187 = (target_obj_31185["addListener"]);
return next_obj_31187;
})()];
})();
var fn_31183 = (call_info_31184[(1)]);
if((!((fn_31183 == null)))){
return fn_31183.call((call_info_31184[(0)]),callback);
} else {
return null;
}
} else {
var config__6143__auto__ = self__.config;
var handler_key__6144__auto__ = cljs.core.cst$kw$chrome_DASH_port_DASH_on_DASH_message_DASH_called_DASH_on_DASH_disconnected_DASH_port;
var handler__6145__auto__ = handler_key__6144__auto__.cljs$core$IFn$_invoke$arity$1(config__6143__auto__);

return (handler__6145__auto__.cljs$core$IFn$_invoke$arity$2 ? handler__6145__auto__.cljs$core$IFn$_invoke$arity$2(config__6143__auto__,this$__$1) : handler__6145__auto__.call(null,config__6143__auto__,this$__$1));
}
});

chromex.chrome_port.ChromePort.prototype.chromex$protocols$chrome_port_state$IChromePortState$ = cljs.core.PROTOCOL_SENTINEL;

chromex.chrome_port.ChromePort.prototype.chromex$protocols$chrome_port_state$IChromePortState$set_connected_BANG_$arity$2 = (function (_this,val){
var self__ = this;
var _this__$1 = this;
return self__.connected_QMARK_ = val;
});

chromex.chrome_port.ChromePort.prototype.chromex$protocols$chrome_port_state$IChromePortState$put_message_BANG_$arity$2 = (function (this$,message){
var self__ = this;
var this$__$1 = this;
if(cljs.core.truth_(self__.connected_QMARK_)){
return cljs.core.async.put_BANG_.cljs$core$IFn$_invoke$arity$2(self__.channel,message);
} else {
var config__6143__auto__ = self__.config;
var handler_key__6144__auto__ = cljs.core.cst$kw$chrome_DASH_port_DASH_put_DASH_message_DASH_called_DASH_on_DASH_disconnected_DASH_port;
var handler__6145__auto__ = handler_key__6144__auto__.cljs$core$IFn$_invoke$arity$1(config__6143__auto__);

return (handler__6145__auto__.cljs$core$IFn$_invoke$arity$3 ? handler__6145__auto__.cljs$core$IFn$_invoke$arity$3(config__6143__auto__,this$__$1,message) : handler__6145__auto__.call(null,config__6143__auto__,this$__$1,message));
}
});

chromex.chrome_port.ChromePort.prototype.chromex$protocols$chrome_port_state$IChromePortState$close_resources_BANG_$arity$1 = (function (_this){
var self__ = this;
var _this__$1 = this;
return cljs.core.async.impl.protocols.close_BANG_(self__.channel);
});

chromex.chrome_port.ChromePort.prototype.cljs$core$async$impl$protocols$ReadPort$ = cljs.core.PROTOCOL_SENTINEL;

chromex.chrome_port.ChromePort.prototype.cljs$core$async$impl$protocols$ReadPort$take_BANG_$arity$2 = (function (_this,handler){
var self__ = this;
var _this__$1 = this;
return cljs.core.async.impl.protocols.take_BANG_(self__.channel,handler);
});

chromex.chrome_port.ChromePort.prototype.cljs$core$async$impl$protocols$Channel$ = cljs.core.PROTOCOL_SENTINEL;

chromex.chrome_port.ChromePort.prototype.cljs$core$async$impl$protocols$Channel$closed_QMARK_$arity$1 = (function (_this){
var self__ = this;
var _this__$1 = this;
return cljs.core.async.impl.protocols.closed_QMARK_(self__.channel);
});

chromex.chrome_port.ChromePort.prototype.cljs$core$async$impl$protocols$Channel$close_BANG_$arity$1 = (function (this$){
var self__ = this;
var this$__$1 = this;
return this$__$1.chromex$protocols$chrome_port$IChromePort$disconnect_BANG_$arity$1(null);
});

chromex.chrome_port.ChromePort.getBasis = (function (){
return new cljs.core.PersistentVector(null, 4, 5, cljs.core.PersistentVector.EMPTY_NODE, [cljs.core.cst$sym$config,cljs.core.cst$sym$native_DASH_chrome_DASH_port,cljs.core.cst$sym$channel,cljs.core.with_meta(cljs.core.cst$sym$connected_QMARK_,new cljs.core.PersistentArrayMap(null, 1, [cljs.core.cst$kw$mutable,true], null))], null);
});

chromex.chrome_port.ChromePort.cljs$lang$type = true;

chromex.chrome_port.ChromePort.cljs$lang$ctorStr = "chromex.chrome-port/ChromePort";

chromex.chrome_port.ChromePort.cljs$lang$ctorPrWriter = (function (this__4290__auto__,writer__4291__auto__,opt__4292__auto__){
return cljs.core._write(writer__4291__auto__,"chromex.chrome-port/ChromePort");
});

/**
 * Positional factory function for chromex.chrome-port/ChromePort.
 */
chromex.chrome_port.__GT_ChromePort = (function chromex$chrome_port$__GT_ChromePort(config,native_chrome_port,channel,connected_QMARK_){
return (new chromex.chrome_port.ChromePort(config,native_chrome_port,channel,connected_QMARK_));
});

chromex.chrome_port.make_chrome_port = (function chromex$chrome_port$make_chrome_port(config,native_chrome_port){

var channel = (function (){var config__6143__auto__ = config;
var handler_key__6144__auto__ = cljs.core.cst$kw$chrome_DASH_port_DASH_channel_DASH_factory;
var handler__6145__auto__ = handler_key__6144__auto__.cljs$core$IFn$_invoke$arity$1(config__6143__auto__);

return (handler__6145__auto__.cljs$core$IFn$_invoke$arity$1 ? handler__6145__auto__.cljs$core$IFn$_invoke$arity$1(config__6143__auto__) : handler__6145__auto__.call(null,config__6143__auto__));
})();
var chrome_port = (new chromex.chrome_port.ChromePort(config,native_chrome_port,channel,true));
var on_message_fn_factory = (function (){var config__6143__auto__ = config;
var handler_key__6144__auto__ = cljs.core.cst$kw$chrome_DASH_port_DASH_on_DASH_message_DASH_fn_DASH_factory;
var handler__6145__auto__ = handler_key__6144__auto__.cljs$core$IFn$_invoke$arity$1(config__6143__auto__);

return (handler__6145__auto__.cljs$core$IFn$_invoke$arity$2 ? handler__6145__auto__.cljs$core$IFn$_invoke$arity$2(config__6143__auto__,chrome_port) : handler__6145__auto__.call(null,config__6143__auto__,chrome_port));
})();
var on_disconnect_fn_factory = (function (){var config__6143__auto__ = config;
var handler_key__6144__auto__ = cljs.core.cst$kw$chrome_DASH_port_DASH_on_DASH_disconnect_DASH_fn_DASH_factory;
var handler__6145__auto__ = handler_key__6144__auto__.cljs$core$IFn$_invoke$arity$1(config__6143__auto__);

return (handler__6145__auto__.cljs$core$IFn$_invoke$arity$2 ? handler__6145__auto__.cljs$core$IFn$_invoke$arity$2(config__6143__auto__,chrome_port) : handler__6145__auto__.call(null,config__6143__auto__,chrome_port));
})();
chrome_port.chromex$protocols$chrome_port$IChromePort$on_message_BANG_$arity$2(null,on_message_fn_factory);

chrome_port.chromex$protocols$chrome_port$IChromePort$on_disconnect_BANG_$arity$2(null,on_disconnect_fn_factory);

return chrome_port;
});
