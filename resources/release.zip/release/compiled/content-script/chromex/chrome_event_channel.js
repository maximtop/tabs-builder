// Compiled by ClojureScript 1.10.439 {:static-fns true, :optimize-constants true, :elide-asserts true}
goog.provide('chromex.chrome_event_channel');
goog.require('cljs.core');
goog.require('cljs.core.constants');
goog.require('cljs.core.async.impl.protocols');
goog.require('chromex.protocols.chrome_event_subscription');
goog.require('chromex.protocols.chrome_event_channel');

/**
* @constructor
 * @implements {cljs.core.async.impl.protocols.Channel}
 * @implements {cljs.core.async.impl.protocols.WritePort}
 * @implements {cljs.core.async.impl.protocols.ReadPort}
 * @implements {chromex.protocols.chrome_event_channel.IChromeEventChannel}
*/
chromex.chrome_event_channel.ChromeEventChannel = (function (chan,subscriptions){
this.chan = chan;
this.subscriptions = subscriptions;
});
chromex.chrome_event_channel.ChromeEventChannel.prototype.chromex$protocols$chrome_event_channel$IChromeEventChannel$ = cljs.core.PROTOCOL_SENTINEL;

chromex.chrome_event_channel.ChromeEventChannel.prototype.chromex$protocols$chrome_event_channel$IChromeEventChannel$register_BANG_$arity$2 = (function (_this,subscription){
var self__ = this;
var _this__$1 = this;
return self__.subscriptions = cljs.core.conj.cljs$core$IFn$_invoke$arity$2(self__.subscriptions,subscription);
});

chromex.chrome_event_channel.ChromeEventChannel.prototype.chromex$protocols$chrome_event_channel$IChromeEventChannel$unregister_BANG_$arity$2 = (function (_this,subscription){
var self__ = this;
var _this__$1 = this;
return self__.subscriptions = cljs.core.disj.cljs$core$IFn$_invoke$arity$2(self__.subscriptions,subscription);
});

chromex.chrome_event_channel.ChromeEventChannel.prototype.chromex$protocols$chrome_event_channel$IChromeEventChannel$unsubscribe_all_BANG_$arity$1 = (function (_this){
var self__ = this;
var _this__$1 = this;
var seq__31197_31201 = cljs.core.seq(self__.subscriptions);
var chunk__31198_31202 = null;
var count__31199_31203 = (0);
var i__31200_31204 = (0);
while(true){
if((i__31200_31204 < count__31199_31203)){
var subscription_31205 = chunk__31198_31202.cljs$core$IIndexed$_nth$arity$2(null,i__31200_31204);
chromex.protocols.chrome_event_subscription.unsubscribe_BANG_(subscription_31205);


var G__31206 = seq__31197_31201;
var G__31207 = chunk__31198_31202;
var G__31208 = count__31199_31203;
var G__31209 = (i__31200_31204 + (1));
seq__31197_31201 = G__31206;
chunk__31198_31202 = G__31207;
count__31199_31203 = G__31208;
i__31200_31204 = G__31209;
continue;
} else {
var temp__5457__auto___31210 = cljs.core.seq(seq__31197_31201);
if(temp__5457__auto___31210){
var seq__31197_31211__$1 = temp__5457__auto___31210;
if(cljs.core.chunked_seq_QMARK_(seq__31197_31211__$1)){
var c__4461__auto___31212 = cljs.core.chunk_first(seq__31197_31211__$1);
var G__31213 = cljs.core.chunk_rest(seq__31197_31211__$1);
var G__31214 = c__4461__auto___31212;
var G__31215 = cljs.core.count(c__4461__auto___31212);
var G__31216 = (0);
seq__31197_31201 = G__31213;
chunk__31198_31202 = G__31214;
count__31199_31203 = G__31215;
i__31200_31204 = G__31216;
continue;
} else {
var subscription_31217 = cljs.core.first(seq__31197_31211__$1);
chromex.protocols.chrome_event_subscription.unsubscribe_BANG_(subscription_31217);


var G__31218 = cljs.core.next(seq__31197_31211__$1);
var G__31219 = null;
var G__31220 = (0);
var G__31221 = (0);
seq__31197_31201 = G__31218;
chunk__31198_31202 = G__31219;
count__31199_31203 = G__31220;
i__31200_31204 = G__31221;
continue;
}
} else {
}
}
break;
}

return self__.subscriptions = cljs.core.PersistentHashSet.EMPTY;
});

chromex.chrome_event_channel.ChromeEventChannel.prototype.cljs$core$async$impl$protocols$WritePort$ = cljs.core.PROTOCOL_SENTINEL;

chromex.chrome_event_channel.ChromeEventChannel.prototype.cljs$core$async$impl$protocols$WritePort$put_BANG_$arity$3 = (function (_this,val,handler){
var self__ = this;
var _this__$1 = this;
return cljs.core.async.impl.protocols.put_BANG_(self__.chan,val,handler);
});

chromex.chrome_event_channel.ChromeEventChannel.prototype.cljs$core$async$impl$protocols$ReadPort$ = cljs.core.PROTOCOL_SENTINEL;

chromex.chrome_event_channel.ChromeEventChannel.prototype.cljs$core$async$impl$protocols$ReadPort$take_BANG_$arity$2 = (function (_this,handler){
var self__ = this;
var _this__$1 = this;
return cljs.core.async.impl.protocols.take_BANG_(self__.chan,handler);
});

chromex.chrome_event_channel.ChromeEventChannel.prototype.cljs$core$async$impl$protocols$Channel$ = cljs.core.PROTOCOL_SENTINEL;

chromex.chrome_event_channel.ChromeEventChannel.prototype.cljs$core$async$impl$protocols$Channel$closed_QMARK_$arity$1 = (function (_this){
var self__ = this;
var _this__$1 = this;
return cljs.core.async.impl.protocols.closed_QMARK_(self__.chan);
});

chromex.chrome_event_channel.ChromeEventChannel.prototype.cljs$core$async$impl$protocols$Channel$close_BANG_$arity$1 = (function (this$){
var self__ = this;
var this$__$1 = this;
this$__$1.chromex$protocols$chrome_event_channel$IChromeEventChannel$unsubscribe_all_BANG_$arity$1(null);

return cljs.core.async.impl.protocols.close_BANG_(self__.chan);
});

chromex.chrome_event_channel.ChromeEventChannel.getBasis = (function (){
return new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [cljs.core.cst$sym$chan,cljs.core.with_meta(cljs.core.cst$sym$subscriptions,new cljs.core.PersistentArrayMap(null, 1, [cljs.core.cst$kw$mutable,true], null))], null);
});

chromex.chrome_event_channel.ChromeEventChannel.cljs$lang$type = true;

chromex.chrome_event_channel.ChromeEventChannel.cljs$lang$ctorStr = "chromex.chrome-event-channel/ChromeEventChannel";

chromex.chrome_event_channel.ChromeEventChannel.cljs$lang$ctorPrWriter = (function (this__4290__auto__,writer__4291__auto__,opt__4292__auto__){
return cljs.core._write(writer__4291__auto__,"chromex.chrome-event-channel/ChromeEventChannel");
});

/**
 * Positional factory function for chromex.chrome-event-channel/ChromeEventChannel.
 */
chromex.chrome_event_channel.__GT_ChromeEventChannel = (function chromex$chrome_event_channel$__GT_ChromeEventChannel(chan,subscriptions){
return (new chromex.chrome_event_channel.ChromeEventChannel(chan,subscriptions));
});

chromex.chrome_event_channel.make_chrome_event_channel = (function chromex$chrome_event_channel$make_chrome_event_channel(chan){
return (new chromex.chrome_event_channel.ChromeEventChannel(chan,cljs.core.PersistentHashSet.EMPTY));
});
