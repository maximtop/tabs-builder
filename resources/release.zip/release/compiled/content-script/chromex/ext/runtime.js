// Compiled by ClojureScript 1.10.439 {:static-fns true, :optimize-constants true, :elide-asserts true}
goog.provide('chromex.ext.runtime');
goog.require('cljs.core');
goog.require('cljs.core.constants');
goog.require('chromex.core');
chromex.ext.runtime.last_error_STAR_ = (function chromex$ext$runtime$last_error_STAR_(config){
var result_31368 = (function (){var final_args_array_31369 = chromex.support.prepare_final_args_array(cljs.core.PersistentVector.EMPTY,"chrome.runtime.lastError");
var ns_31370 = (function (){var target_obj_31372 = cljs.core.cst$kw$root.cljs$core$IFn$_invoke$arity$1(config);
var next_obj_31373 = (target_obj_31372["chrome"]);
var next_obj_31374 = (next_obj_31373["runtime"]);
return next_obj_31374;
})();


var target_31371 = (function (){var target_obj_31375 = ns_31370;
var next_obj_31376 = (target_obj_31375["lastError"]);
if((!((next_obj_31376 == null)))){
return next_obj_31376;
} else {
return null;
}
})();
return target_31371;
})();
return result_31368;
});
chromex.ext.runtime.id_STAR_ = (function chromex$ext$runtime$id_STAR_(config){
var result_31377 = (function (){var final_args_array_31378 = chromex.support.prepare_final_args_array(cljs.core.PersistentVector.EMPTY,"chrome.runtime.id");
var ns_31379 = (function (){var target_obj_31381 = cljs.core.cst$kw$root.cljs$core$IFn$_invoke$arity$1(config);
var next_obj_31382 = (target_obj_31381["chrome"]);
var next_obj_31383 = (next_obj_31382["runtime"]);
return next_obj_31383;
})();


var target_31380 = (function (){var target_obj_31384 = ns_31379;
var next_obj_31385 = (target_obj_31384["id"]);
if((!((next_obj_31385 == null)))){
return next_obj_31385;
} else {
return null;
}
})();
return target_31380;
})();
return result_31377;
});
chromex.ext.runtime.get_background_page_STAR_ = (function chromex$ext$runtime$get_background_page_STAR_(config){
var callback_chan_31386 = (function (){var config__6143__auto__ = config;
var handler_key__6144__auto__ = cljs.core.cst$kw$callback_DASH_channel_DASH_factory;
var handler__6145__auto__ = handler_key__6144__auto__.cljs$core$IFn$_invoke$arity$1(config__6143__auto__);

return (handler__6145__auto__.cljs$core$IFn$_invoke$arity$1 ? handler__6145__auto__.cljs$core$IFn$_invoke$arity$1(config__6143__auto__) : handler__6145__auto__.call(null,config__6143__auto__));
})();
var marshalled_callback_31388_31405 = ((function (callback_chan_31386){
return (function (cb_background_page_31392){
var fexpr__31396 = (function (){var config__6143__auto__ = config;
var handler_key__6144__auto__ = cljs.core.cst$kw$callback_DASH_fn_DASH_factory;
var handler__6145__auto__ = handler_key__6144__auto__.cljs$core$IFn$_invoke$arity$1(config__6143__auto__);

var G__31397 = config__6143__auto__;
var G__31398 = new cljs.core.PersistentArrayMap(null, 5, [cljs.core.cst$kw$id,cljs.core.cst$kw$chromex$ext$runtime_SLASH_get_DASH_background_DASH_page,cljs.core.cst$kw$name,"getBackgroundPage",cljs.core.cst$kw$callback_QMARK_,true,cljs.core.cst$kw$params,new cljs.core.PersistentVector(null, 1, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentArrayMap(null, 3, [cljs.core.cst$kw$name,"callback",cljs.core.cst$kw$type,cljs.core.cst$kw$callback,cljs.core.cst$kw$callback,new cljs.core.PersistentArrayMap(null, 1, [cljs.core.cst$kw$params,new cljs.core.PersistentVector(null, 1, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentArrayMap(null, 3, [cljs.core.cst$kw$name,"background-page",cljs.core.cst$kw$optional_QMARK_,true,cljs.core.cst$kw$type,"Window"], null)], null)], null)], null)], null),cljs.core.cst$kw$function_QMARK_,true], null);
var G__31399 = callback_chan_31386;
return (handler__6145__auto__.cljs$core$IFn$_invoke$arity$3 ? handler__6145__auto__.cljs$core$IFn$_invoke$arity$3(G__31397,G__31398,G__31399) : handler__6145__auto__.call(null,G__31397,G__31398,G__31399));
})();
return (fexpr__31396.cljs$core$IFn$_invoke$arity$1 ? fexpr__31396.cljs$core$IFn$_invoke$arity$1(cb_background_page_31392) : fexpr__31396.call(null,cb_background_page_31392));
});})(callback_chan_31386))
;
var result_31387_31406 = (function (){var final_args_array_31389 = chromex.support.prepare_final_args_array(new cljs.core.PersistentVector(null, 1, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_callback_31388_31405,"callback",null], null)], null),"chrome.runtime.getBackgroundPage");
var ns_31390 = (function (){var target_obj_31400 = cljs.core.cst$kw$root.cljs$core$IFn$_invoke$arity$1(config);
var next_obj_31401 = (target_obj_31400["chrome"]);
var next_obj_31402 = (next_obj_31401["runtime"]);
return next_obj_31402;
})();
var config__6181__auto___31407 = config;
var api_check_fn__6182__auto___31408 = cljs.core.cst$kw$missing_DASH_api_DASH_check_DASH_fn.cljs$core$IFn$_invoke$arity$1(config__6181__auto___31407);

(api_check_fn__6182__auto___31408.cljs$core$IFn$_invoke$arity$3 ? api_check_fn__6182__auto___31408.cljs$core$IFn$_invoke$arity$3("chrome.runtime.getBackgroundPage",ns_31390,"getBackgroundPage") : api_check_fn__6182__auto___31408.call(null,"chrome.runtime.getBackgroundPage",ns_31390,"getBackgroundPage"));


var target_31391 = (function (){var target_obj_31403 = ns_31390;
var next_obj_31404 = (target_obj_31403["getBackgroundPage"]);
if((!((next_obj_31404 == null)))){
return next_obj_31404;
} else {
return null;
}
})();
return target_31391.apply(ns_31390,final_args_array_31389);
})();

return callback_chan_31386;
});
chromex.ext.runtime.open_options_page_STAR_ = (function chromex$ext$runtime$open_options_page_STAR_(config){
var callback_chan_31409 = (function (){var config__6143__auto__ = config;
var handler_key__6144__auto__ = cljs.core.cst$kw$callback_DASH_channel_DASH_factory;
var handler__6145__auto__ = handler_key__6144__auto__.cljs$core$IFn$_invoke$arity$1(config__6143__auto__);

return (handler__6145__auto__.cljs$core$IFn$_invoke$arity$1 ? handler__6145__auto__.cljs$core$IFn$_invoke$arity$1(config__6143__auto__) : handler__6145__auto__.call(null,config__6143__auto__));
})();
var marshalled_callback_31411_31423 = (function (){var config__6143__auto__ = config;
var handler_key__6144__auto__ = cljs.core.cst$kw$callback_DASH_fn_DASH_factory;
var handler__6145__auto__ = handler_key__6144__auto__.cljs$core$IFn$_invoke$arity$1(config__6143__auto__);

var G__31415 = config__6143__auto__;
var G__31416 = new cljs.core.PersistentArrayMap(null, 6, [cljs.core.cst$kw$id,cljs.core.cst$kw$chromex$ext$runtime_SLASH_open_DASH_options_DASH_page,cljs.core.cst$kw$name,"openOptionsPage",cljs.core.cst$kw$since,"42",cljs.core.cst$kw$callback_QMARK_,true,cljs.core.cst$kw$params,new cljs.core.PersistentVector(null, 1, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentArrayMap(null, 3, [cljs.core.cst$kw$name,"callback",cljs.core.cst$kw$optional_QMARK_,true,cljs.core.cst$kw$type,cljs.core.cst$kw$callback], null)], null),cljs.core.cst$kw$function_QMARK_,true], null);
var G__31417 = callback_chan_31409;
return (handler__6145__auto__.cljs$core$IFn$_invoke$arity$3 ? handler__6145__auto__.cljs$core$IFn$_invoke$arity$3(G__31415,G__31416,G__31417) : handler__6145__auto__.call(null,G__31415,G__31416,G__31417));
})();
var result_31410_31424 = (function (){var final_args_array_31412 = chromex.support.prepare_final_args_array(new cljs.core.PersistentVector(null, 1, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_callback_31411_31423,"callback",true], null)], null),"chrome.runtime.openOptionsPage");
var ns_31413 = (function (){var target_obj_31418 = cljs.core.cst$kw$root.cljs$core$IFn$_invoke$arity$1(config);
var next_obj_31419 = (target_obj_31418["chrome"]);
var next_obj_31420 = (next_obj_31419["runtime"]);
return next_obj_31420;
})();
var config__6181__auto___31425 = config;
var api_check_fn__6182__auto___31426 = cljs.core.cst$kw$missing_DASH_api_DASH_check_DASH_fn.cljs$core$IFn$_invoke$arity$1(config__6181__auto___31425);

(api_check_fn__6182__auto___31426.cljs$core$IFn$_invoke$arity$3 ? api_check_fn__6182__auto___31426.cljs$core$IFn$_invoke$arity$3("chrome.runtime.openOptionsPage",ns_31413,"openOptionsPage") : api_check_fn__6182__auto___31426.call(null,"chrome.runtime.openOptionsPage",ns_31413,"openOptionsPage"));


var target_31414 = (function (){var target_obj_31421 = ns_31413;
var next_obj_31422 = (target_obj_31421["openOptionsPage"]);
if((!((next_obj_31422 == null)))){
return next_obj_31422;
} else {
return null;
}
})();
return target_31414.apply(ns_31413,final_args_array_31412);
})();

return callback_chan_31409;
});
chromex.ext.runtime.get_manifest_STAR_ = (function chromex$ext$runtime$get_manifest_STAR_(config){
var result_31427 = (function (){var final_args_array_31428 = chromex.support.prepare_final_args_array(cljs.core.PersistentVector.EMPTY,"chrome.runtime.getManifest");
var ns_31429 = (function (){var target_obj_31431 = cljs.core.cst$kw$root.cljs$core$IFn$_invoke$arity$1(config);
var next_obj_31432 = (target_obj_31431["chrome"]);
var next_obj_31433 = (next_obj_31432["runtime"]);
return next_obj_31433;
})();
var config__6181__auto___31436 = config;
var api_check_fn__6182__auto___31437 = cljs.core.cst$kw$missing_DASH_api_DASH_check_DASH_fn.cljs$core$IFn$_invoke$arity$1(config__6181__auto___31436);

(api_check_fn__6182__auto___31437.cljs$core$IFn$_invoke$arity$3 ? api_check_fn__6182__auto___31437.cljs$core$IFn$_invoke$arity$3("chrome.runtime.getManifest",ns_31429,"getManifest") : api_check_fn__6182__auto___31437.call(null,"chrome.runtime.getManifest",ns_31429,"getManifest"));


var target_31430 = (function (){var target_obj_31434 = ns_31429;
var next_obj_31435 = (target_obj_31434["getManifest"]);
if((!((next_obj_31435 == null)))){
return next_obj_31435;
} else {
return null;
}
})();
return target_31430.apply(ns_31429,final_args_array_31428);
})();
return result_31427;
});
chromex.ext.runtime.get_url_STAR_ = (function chromex$ext$runtime$get_url_STAR_(config,path){
var marshalled_path_31439 = (function (){var omit_test_31443 = path;
if(cljs.core.keyword_identical_QMARK_(omit_test_31443,cljs.core.cst$kw$omit)){
return cljs.core.cst$kw$omit;
} else {
return omit_test_31443;
}
})();
var result_31438 = (function (){var final_args_array_31440 = chromex.support.prepare_final_args_array(new cljs.core.PersistentVector(null, 1, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_path_31439,"path",null], null)], null),"chrome.runtime.getURL");
var ns_31441 = (function (){var target_obj_31444 = cljs.core.cst$kw$root.cljs$core$IFn$_invoke$arity$1(config);
var next_obj_31445 = (target_obj_31444["chrome"]);
var next_obj_31446 = (next_obj_31445["runtime"]);
return next_obj_31446;
})();
var config__6181__auto___31449 = config;
var api_check_fn__6182__auto___31450 = cljs.core.cst$kw$missing_DASH_api_DASH_check_DASH_fn.cljs$core$IFn$_invoke$arity$1(config__6181__auto___31449);

(api_check_fn__6182__auto___31450.cljs$core$IFn$_invoke$arity$3 ? api_check_fn__6182__auto___31450.cljs$core$IFn$_invoke$arity$3("chrome.runtime.getURL",ns_31441,"getURL") : api_check_fn__6182__auto___31450.call(null,"chrome.runtime.getURL",ns_31441,"getURL"));


var target_31442 = (function (){var target_obj_31447 = ns_31441;
var next_obj_31448 = (target_obj_31447["getURL"]);
if((!((next_obj_31448 == null)))){
return next_obj_31448;
} else {
return null;
}
})();
return target_31442.apply(ns_31441,final_args_array_31440);
})();
return result_31438;
});
chromex.ext.runtime.set_uninstall_url_STAR_ = (function chromex$ext$runtime$set_uninstall_url_STAR_(config,url){
var callback_chan_31451 = (function (){var config__6143__auto__ = config;
var handler_key__6144__auto__ = cljs.core.cst$kw$callback_DASH_channel_DASH_factory;
var handler__6145__auto__ = handler_key__6144__auto__.cljs$core$IFn$_invoke$arity$1(config__6143__auto__);

return (handler__6145__auto__.cljs$core$IFn$_invoke$arity$1 ? handler__6145__auto__.cljs$core$IFn$_invoke$arity$1(config__6143__auto__) : handler__6145__auto__.call(null,config__6143__auto__));
})();
var marshalled_url_31453_31467 = (function (){var omit_test_31458 = url;
if(cljs.core.keyword_identical_QMARK_(omit_test_31458,cljs.core.cst$kw$omit)){
return cljs.core.cst$kw$omit;
} else {
return omit_test_31458;
}
})();
var marshalled_callback_31454_31468 = (function (){var config__6143__auto__ = config;
var handler_key__6144__auto__ = cljs.core.cst$kw$callback_DASH_fn_DASH_factory;
var handler__6145__auto__ = handler_key__6144__auto__.cljs$core$IFn$_invoke$arity$1(config__6143__auto__);

var G__31459 = config__6143__auto__;
var G__31460 = new cljs.core.PersistentArrayMap(null, 6, [cljs.core.cst$kw$id,cljs.core.cst$kw$chromex$ext$runtime_SLASH_set_DASH_uninstall_DASH_url,cljs.core.cst$kw$name,"setUninstallURL",cljs.core.cst$kw$since,"41",cljs.core.cst$kw$callback_QMARK_,true,cljs.core.cst$kw$params,new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentArrayMap(null, 2, [cljs.core.cst$kw$name,"url",cljs.core.cst$kw$type,"string"], null),new cljs.core.PersistentArrayMap(null, 3, [cljs.core.cst$kw$name,"callback",cljs.core.cst$kw$optional_QMARK_,true,cljs.core.cst$kw$type,cljs.core.cst$kw$callback], null)], null),cljs.core.cst$kw$function_QMARK_,true], null);
var G__31461 = callback_chan_31451;
return (handler__6145__auto__.cljs$core$IFn$_invoke$arity$3 ? handler__6145__auto__.cljs$core$IFn$_invoke$arity$3(G__31459,G__31460,G__31461) : handler__6145__auto__.call(null,G__31459,G__31460,G__31461));
})();
var result_31452_31469 = (function (){var final_args_array_31455 = chromex.support.prepare_final_args_array(new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_url_31453_31467,"url",null], null),new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_callback_31454_31468,"callback",true], null)], null),"chrome.runtime.setUninstallURL");
var ns_31456 = (function (){var target_obj_31462 = cljs.core.cst$kw$root.cljs$core$IFn$_invoke$arity$1(config);
var next_obj_31463 = (target_obj_31462["chrome"]);
var next_obj_31464 = (next_obj_31463["runtime"]);
return next_obj_31464;
})();
var config__6181__auto___31470 = config;
var api_check_fn__6182__auto___31471 = cljs.core.cst$kw$missing_DASH_api_DASH_check_DASH_fn.cljs$core$IFn$_invoke$arity$1(config__6181__auto___31470);

(api_check_fn__6182__auto___31471.cljs$core$IFn$_invoke$arity$3 ? api_check_fn__6182__auto___31471.cljs$core$IFn$_invoke$arity$3("chrome.runtime.setUninstallURL",ns_31456,"setUninstallURL") : api_check_fn__6182__auto___31471.call(null,"chrome.runtime.setUninstallURL",ns_31456,"setUninstallURL"));


var target_31457 = (function (){var target_obj_31465 = ns_31456;
var next_obj_31466 = (target_obj_31465["setUninstallURL"]);
if((!((next_obj_31466 == null)))){
return next_obj_31466;
} else {
return null;
}
})();
return target_31457.apply(ns_31456,final_args_array_31455);
})();

return callback_chan_31451;
});
chromex.ext.runtime.reload_STAR_ = (function chromex$ext$runtime$reload_STAR_(config){
var result_31472 = (function (){var final_args_array_31473 = chromex.support.prepare_final_args_array(cljs.core.PersistentVector.EMPTY,"chrome.runtime.reload");
var ns_31474 = (function (){var target_obj_31476 = cljs.core.cst$kw$root.cljs$core$IFn$_invoke$arity$1(config);
var next_obj_31477 = (target_obj_31476["chrome"]);
var next_obj_31478 = (next_obj_31477["runtime"]);
return next_obj_31478;
})();
var config__6181__auto___31481 = config;
var api_check_fn__6182__auto___31482 = cljs.core.cst$kw$missing_DASH_api_DASH_check_DASH_fn.cljs$core$IFn$_invoke$arity$1(config__6181__auto___31481);

(api_check_fn__6182__auto___31482.cljs$core$IFn$_invoke$arity$3 ? api_check_fn__6182__auto___31482.cljs$core$IFn$_invoke$arity$3("chrome.runtime.reload",ns_31474,"reload") : api_check_fn__6182__auto___31482.call(null,"chrome.runtime.reload",ns_31474,"reload"));


var target_31475 = (function (){var target_obj_31479 = ns_31474;
var next_obj_31480 = (target_obj_31479["reload"]);
if((!((next_obj_31480 == null)))){
return next_obj_31480;
} else {
return null;
}
})();
return target_31475.apply(ns_31474,final_args_array_31473);
})();
return result_31472;
});
chromex.ext.runtime.request_update_check_STAR_ = (function chromex$ext$runtime$request_update_check_STAR_(config){
var callback_chan_31483 = (function (){var config__6143__auto__ = config;
var handler_key__6144__auto__ = cljs.core.cst$kw$callback_DASH_channel_DASH_factory;
var handler__6145__auto__ = handler_key__6144__auto__.cljs$core$IFn$_invoke$arity$1(config__6143__auto__);

return (handler__6145__auto__.cljs$core$IFn$_invoke$arity$1 ? handler__6145__auto__.cljs$core$IFn$_invoke$arity$1(config__6143__auto__) : handler__6145__auto__.call(null,config__6143__auto__));
})();
var marshalled_callback_31485_31503 = ((function (callback_chan_31483){
return (function (cb_status_31489,cb_details_31490){
var fexpr__31494 = (function (){var config__6143__auto__ = config;
var handler_key__6144__auto__ = cljs.core.cst$kw$callback_DASH_fn_DASH_factory;
var handler__6145__auto__ = handler_key__6144__auto__.cljs$core$IFn$_invoke$arity$1(config__6143__auto__);

var G__31495 = config__6143__auto__;
var G__31496 = new cljs.core.PersistentArrayMap(null, 5, [cljs.core.cst$kw$id,cljs.core.cst$kw$chromex$ext$runtime_SLASH_request_DASH_update_DASH_check,cljs.core.cst$kw$name,"requestUpdateCheck",cljs.core.cst$kw$callback_QMARK_,true,cljs.core.cst$kw$params,new cljs.core.PersistentVector(null, 1, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentArrayMap(null, 3, [cljs.core.cst$kw$name,"callback",cljs.core.cst$kw$type,cljs.core.cst$kw$callback,cljs.core.cst$kw$callback,new cljs.core.PersistentArrayMap(null, 1, [cljs.core.cst$kw$params,new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentArrayMap(null, 2, [cljs.core.cst$kw$name,"status",cljs.core.cst$kw$type,"runtime.RequestUpdateCheckStatus"], null),new cljs.core.PersistentArrayMap(null, 3, [cljs.core.cst$kw$name,"details",cljs.core.cst$kw$optional_QMARK_,true,cljs.core.cst$kw$type,"object"], null)], null)], null)], null)], null),cljs.core.cst$kw$function_QMARK_,true], null);
var G__31497 = callback_chan_31483;
return (handler__6145__auto__.cljs$core$IFn$_invoke$arity$3 ? handler__6145__auto__.cljs$core$IFn$_invoke$arity$3(G__31495,G__31496,G__31497) : handler__6145__auto__.call(null,G__31495,G__31496,G__31497));
})();
return (fexpr__31494.cljs$core$IFn$_invoke$arity$2 ? fexpr__31494.cljs$core$IFn$_invoke$arity$2(cb_status_31489,cb_details_31490) : fexpr__31494.call(null,cb_status_31489,cb_details_31490));
});})(callback_chan_31483))
;
var result_31484_31504 = (function (){var final_args_array_31486 = chromex.support.prepare_final_args_array(new cljs.core.PersistentVector(null, 1, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_callback_31485_31503,"callback",null], null)], null),"chrome.runtime.requestUpdateCheck");
var ns_31487 = (function (){var target_obj_31498 = cljs.core.cst$kw$root.cljs$core$IFn$_invoke$arity$1(config);
var next_obj_31499 = (target_obj_31498["chrome"]);
var next_obj_31500 = (next_obj_31499["runtime"]);
return next_obj_31500;
})();
var config__6181__auto___31505 = config;
var api_check_fn__6182__auto___31506 = cljs.core.cst$kw$missing_DASH_api_DASH_check_DASH_fn.cljs$core$IFn$_invoke$arity$1(config__6181__auto___31505);

(api_check_fn__6182__auto___31506.cljs$core$IFn$_invoke$arity$3 ? api_check_fn__6182__auto___31506.cljs$core$IFn$_invoke$arity$3("chrome.runtime.requestUpdateCheck",ns_31487,"requestUpdateCheck") : api_check_fn__6182__auto___31506.call(null,"chrome.runtime.requestUpdateCheck",ns_31487,"requestUpdateCheck"));


var target_31488 = (function (){var target_obj_31501 = ns_31487;
var next_obj_31502 = (target_obj_31501["requestUpdateCheck"]);
if((!((next_obj_31502 == null)))){
return next_obj_31502;
} else {
return null;
}
})();
return target_31488.apply(ns_31487,final_args_array_31486);
})();

return callback_chan_31483;
});
chromex.ext.runtime.restart_STAR_ = (function chromex$ext$runtime$restart_STAR_(config){
var result_31507 = (function (){var final_args_array_31508 = chromex.support.prepare_final_args_array(cljs.core.PersistentVector.EMPTY,"chrome.runtime.restart");
var ns_31509 = (function (){var target_obj_31511 = cljs.core.cst$kw$root.cljs$core$IFn$_invoke$arity$1(config);
var next_obj_31512 = (target_obj_31511["chrome"]);
var next_obj_31513 = (next_obj_31512["runtime"]);
return next_obj_31513;
})();
var config__6181__auto___31516 = config;
var api_check_fn__6182__auto___31517 = cljs.core.cst$kw$missing_DASH_api_DASH_check_DASH_fn.cljs$core$IFn$_invoke$arity$1(config__6181__auto___31516);

(api_check_fn__6182__auto___31517.cljs$core$IFn$_invoke$arity$3 ? api_check_fn__6182__auto___31517.cljs$core$IFn$_invoke$arity$3("chrome.runtime.restart",ns_31509,"restart") : api_check_fn__6182__auto___31517.call(null,"chrome.runtime.restart",ns_31509,"restart"));


var target_31510 = (function (){var target_obj_31514 = ns_31509;
var next_obj_31515 = (target_obj_31514["restart"]);
if((!((next_obj_31515 == null)))){
return next_obj_31515;
} else {
return null;
}
})();
return target_31510.apply(ns_31509,final_args_array_31508);
})();
return result_31507;
});
chromex.ext.runtime.restart_after_delay_STAR_ = (function chromex$ext$runtime$restart_after_delay_STAR_(config,seconds){
var callback_chan_31518 = (function (){var config__6143__auto__ = config;
var handler_key__6144__auto__ = cljs.core.cst$kw$callback_DASH_channel_DASH_factory;
var handler__6145__auto__ = handler_key__6144__auto__.cljs$core$IFn$_invoke$arity$1(config__6143__auto__);

return (handler__6145__auto__.cljs$core$IFn$_invoke$arity$1 ? handler__6145__auto__.cljs$core$IFn$_invoke$arity$1(config__6143__auto__) : handler__6145__auto__.call(null,config__6143__auto__));
})();
var marshalled_seconds_31520_31534 = (function (){var omit_test_31525 = seconds;
if(cljs.core.keyword_identical_QMARK_(omit_test_31525,cljs.core.cst$kw$omit)){
return cljs.core.cst$kw$omit;
} else {
return omit_test_31525;
}
})();
var marshalled_callback_31521_31535 = (function (){var config__6143__auto__ = config;
var handler_key__6144__auto__ = cljs.core.cst$kw$callback_DASH_fn_DASH_factory;
var handler__6145__auto__ = handler_key__6144__auto__.cljs$core$IFn$_invoke$arity$1(config__6143__auto__);

var G__31526 = config__6143__auto__;
var G__31527 = new cljs.core.PersistentArrayMap(null, 6, [cljs.core.cst$kw$id,cljs.core.cst$kw$chromex$ext$runtime_SLASH_restart_DASH_after_DASH_delay,cljs.core.cst$kw$name,"restartAfterDelay",cljs.core.cst$kw$since,"53",cljs.core.cst$kw$callback_QMARK_,true,cljs.core.cst$kw$params,new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentArrayMap(null, 2, [cljs.core.cst$kw$name,"seconds",cljs.core.cst$kw$type,"integer"], null),new cljs.core.PersistentArrayMap(null, 3, [cljs.core.cst$kw$name,"callback",cljs.core.cst$kw$optional_QMARK_,true,cljs.core.cst$kw$type,cljs.core.cst$kw$callback], null)], null),cljs.core.cst$kw$function_QMARK_,true], null);
var G__31528 = callback_chan_31518;
return (handler__6145__auto__.cljs$core$IFn$_invoke$arity$3 ? handler__6145__auto__.cljs$core$IFn$_invoke$arity$3(G__31526,G__31527,G__31528) : handler__6145__auto__.call(null,G__31526,G__31527,G__31528));
})();
var result_31519_31536 = (function (){var final_args_array_31522 = chromex.support.prepare_final_args_array(new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_seconds_31520_31534,"seconds",null], null),new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_callback_31521_31535,"callback",true], null)], null),"chrome.runtime.restartAfterDelay");
var ns_31523 = (function (){var target_obj_31529 = cljs.core.cst$kw$root.cljs$core$IFn$_invoke$arity$1(config);
var next_obj_31530 = (target_obj_31529["chrome"]);
var next_obj_31531 = (next_obj_31530["runtime"]);
return next_obj_31531;
})();
var config__6181__auto___31537 = config;
var api_check_fn__6182__auto___31538 = cljs.core.cst$kw$missing_DASH_api_DASH_check_DASH_fn.cljs$core$IFn$_invoke$arity$1(config__6181__auto___31537);

(api_check_fn__6182__auto___31538.cljs$core$IFn$_invoke$arity$3 ? api_check_fn__6182__auto___31538.cljs$core$IFn$_invoke$arity$3("chrome.runtime.restartAfterDelay",ns_31523,"restartAfterDelay") : api_check_fn__6182__auto___31538.call(null,"chrome.runtime.restartAfterDelay",ns_31523,"restartAfterDelay"));


var target_31524 = (function (){var target_obj_31532 = ns_31523;
var next_obj_31533 = (target_obj_31532["restartAfterDelay"]);
if((!((next_obj_31533 == null)))){
return next_obj_31533;
} else {
return null;
}
})();
return target_31524.apply(ns_31523,final_args_array_31522);
})();

return callback_chan_31518;
});
chromex.ext.runtime.connect_STAR_ = (function chromex$ext$runtime$connect_STAR_(config,extension_id,connect_info){
var marshalled_extension_id_31540 = (function (){var omit_test_31545 = extension_id;
if(cljs.core.keyword_identical_QMARK_(omit_test_31545,cljs.core.cst$kw$omit)){
return cljs.core.cst$kw$omit;
} else {
return omit_test_31545;
}
})();
var marshalled_connect_info_31541 = (function (){var omit_test_31546 = connect_info;
if(cljs.core.keyword_identical_QMARK_(omit_test_31546,cljs.core.cst$kw$omit)){
return cljs.core.cst$kw$omit;
} else {
return omit_test_31546;
}
})();
var result_31539 = (function (){var final_args_array_31542 = chromex.support.prepare_final_args_array(new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_extension_id_31540,"extension-id",true], null),new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_connect_info_31541,"connect-info",true], null)], null),"chrome.runtime.connect");
var ns_31543 = (function (){var target_obj_31547 = cljs.core.cst$kw$root.cljs$core$IFn$_invoke$arity$1(config);
var next_obj_31548 = (target_obj_31547["chrome"]);
var next_obj_31549 = (next_obj_31548["runtime"]);
return next_obj_31549;
})();
var config__6181__auto___31552 = config;
var api_check_fn__6182__auto___31553 = cljs.core.cst$kw$missing_DASH_api_DASH_check_DASH_fn.cljs$core$IFn$_invoke$arity$1(config__6181__auto___31552);

(api_check_fn__6182__auto___31553.cljs$core$IFn$_invoke$arity$3 ? api_check_fn__6182__auto___31553.cljs$core$IFn$_invoke$arity$3("chrome.runtime.connect",ns_31543,"connect") : api_check_fn__6182__auto___31553.call(null,"chrome.runtime.connect",ns_31543,"connect"));


var target_31544 = (function (){var target_obj_31550 = ns_31543;
var next_obj_31551 = (target_obj_31550["connect"]);
if((!((next_obj_31551 == null)))){
return next_obj_31551;
} else {
return null;
}
})();
return target_31544.apply(ns_31543,final_args_array_31542);
})();
return chromex.marshalling.from_native_chrome_port(config,result_31539);
});
chromex.ext.runtime.connect_native_STAR_ = (function chromex$ext$runtime$connect_native_STAR_(config,application){
var marshalled_application_31555 = (function (){var omit_test_31559 = application;
if(cljs.core.keyword_identical_QMARK_(omit_test_31559,cljs.core.cst$kw$omit)){
return cljs.core.cst$kw$omit;
} else {
return omit_test_31559;
}
})();
var result_31554 = (function (){var final_args_array_31556 = chromex.support.prepare_final_args_array(new cljs.core.PersistentVector(null, 1, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_application_31555,"application",null], null)], null),"chrome.runtime.connectNative");
var ns_31557 = (function (){var target_obj_31560 = cljs.core.cst$kw$root.cljs$core$IFn$_invoke$arity$1(config);
var next_obj_31561 = (target_obj_31560["chrome"]);
var next_obj_31562 = (next_obj_31561["runtime"]);
return next_obj_31562;
})();
var config__6181__auto___31565 = config;
var api_check_fn__6182__auto___31566 = cljs.core.cst$kw$missing_DASH_api_DASH_check_DASH_fn.cljs$core$IFn$_invoke$arity$1(config__6181__auto___31565);

(api_check_fn__6182__auto___31566.cljs$core$IFn$_invoke$arity$3 ? api_check_fn__6182__auto___31566.cljs$core$IFn$_invoke$arity$3("chrome.runtime.connectNative",ns_31557,"connectNative") : api_check_fn__6182__auto___31566.call(null,"chrome.runtime.connectNative",ns_31557,"connectNative"));


var target_31558 = (function (){var target_obj_31563 = ns_31557;
var next_obj_31564 = (target_obj_31563["connectNative"]);
if((!((next_obj_31564 == null)))){
return next_obj_31564;
} else {
return null;
}
})();
return target_31558.apply(ns_31557,final_args_array_31556);
})();
return chromex.marshalling.from_native_chrome_port(config,result_31554);
});
chromex.ext.runtime.send_message_STAR_ = (function chromex$ext$runtime$send_message_STAR_(config,extension_id,message,options){
var callback_chan_31567 = (function (){var config__6143__auto__ = config;
var handler_key__6144__auto__ = cljs.core.cst$kw$callback_DASH_channel_DASH_factory;
var handler__6145__auto__ = handler_key__6144__auto__.cljs$core$IFn$_invoke$arity$1(config__6143__auto__);

return (handler__6145__auto__.cljs$core$IFn$_invoke$arity$1 ? handler__6145__auto__.cljs$core$IFn$_invoke$arity$1(config__6143__auto__) : handler__6145__auto__.call(null,config__6143__auto__));
})();
var marshalled_extension_id_31569_31592 = (function (){var omit_test_31576 = extension_id;
if(cljs.core.keyword_identical_QMARK_(omit_test_31576,cljs.core.cst$kw$omit)){
return cljs.core.cst$kw$omit;
} else {
return omit_test_31576;
}
})();
var marshalled_message_31570_31593 = (function (){var omit_test_31577 = message;
if(cljs.core.keyword_identical_QMARK_(omit_test_31577,cljs.core.cst$kw$omit)){
return cljs.core.cst$kw$omit;
} else {
return omit_test_31577;
}
})();
var marshalled_options_31571_31594 = (function (){var omit_test_31578 = options;
if(cljs.core.keyword_identical_QMARK_(omit_test_31578,cljs.core.cst$kw$omit)){
return cljs.core.cst$kw$omit;
} else {
return omit_test_31578;
}
})();
var marshalled_response_callback_31572_31595 = ((function (marshalled_extension_id_31569_31592,marshalled_message_31570_31593,marshalled_options_31571_31594,callback_chan_31567){
return (function (cb_response_31579){
var fexpr__31583 = (function (){var config__6143__auto__ = config;
var handler_key__6144__auto__ = cljs.core.cst$kw$callback_DASH_fn_DASH_factory;
var handler__6145__auto__ = handler_key__6144__auto__.cljs$core$IFn$_invoke$arity$1(config__6143__auto__);

var G__31584 = config__6143__auto__;
var G__31585 = new cljs.core.PersistentArrayMap(null, 5, [cljs.core.cst$kw$id,cljs.core.cst$kw$chromex$ext$runtime_SLASH_send_DASH_message,cljs.core.cst$kw$name,"sendMessage",cljs.core.cst$kw$callback_QMARK_,true,cljs.core.cst$kw$params,new cljs.core.PersistentVector(null, 4, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentArrayMap(null, 3, [cljs.core.cst$kw$name,"extension-id",cljs.core.cst$kw$optional_QMARK_,true,cljs.core.cst$kw$type,"string"], null),new cljs.core.PersistentArrayMap(null, 2, [cljs.core.cst$kw$name,"message",cljs.core.cst$kw$type,"any"], null),new cljs.core.PersistentArrayMap(null, 3, [cljs.core.cst$kw$name,"options",cljs.core.cst$kw$optional_QMARK_,true,cljs.core.cst$kw$type,"object"], null),new cljs.core.PersistentArrayMap(null, 4, [cljs.core.cst$kw$name,"response-callback",cljs.core.cst$kw$optional_QMARK_,true,cljs.core.cst$kw$type,cljs.core.cst$kw$callback,cljs.core.cst$kw$callback,new cljs.core.PersistentArrayMap(null, 1, [cljs.core.cst$kw$params,new cljs.core.PersistentVector(null, 1, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentArrayMap(null, 2, [cljs.core.cst$kw$name,"response",cljs.core.cst$kw$type,"any"], null)], null)], null)], null)], null),cljs.core.cst$kw$function_QMARK_,true], null);
var G__31586 = callback_chan_31567;
return (handler__6145__auto__.cljs$core$IFn$_invoke$arity$3 ? handler__6145__auto__.cljs$core$IFn$_invoke$arity$3(G__31584,G__31585,G__31586) : handler__6145__auto__.call(null,G__31584,G__31585,G__31586));
})();
return (fexpr__31583.cljs$core$IFn$_invoke$arity$1 ? fexpr__31583.cljs$core$IFn$_invoke$arity$1(cb_response_31579) : fexpr__31583.call(null,cb_response_31579));
});})(marshalled_extension_id_31569_31592,marshalled_message_31570_31593,marshalled_options_31571_31594,callback_chan_31567))
;
var result_31568_31596 = (function (){var final_args_array_31573 = chromex.support.prepare_final_args_array(new cljs.core.PersistentVector(null, 4, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_extension_id_31569_31592,"extension-id",true], null),new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_message_31570_31593,"message",null], null),new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_options_31571_31594,"options",true], null),new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_response_callback_31572_31595,"response-callback",true], null)], null),"chrome.runtime.sendMessage");
var ns_31574 = (function (){var target_obj_31587 = cljs.core.cst$kw$root.cljs$core$IFn$_invoke$arity$1(config);
var next_obj_31588 = (target_obj_31587["chrome"]);
var next_obj_31589 = (next_obj_31588["runtime"]);
return next_obj_31589;
})();
var config__6181__auto___31597 = config;
var api_check_fn__6182__auto___31598 = cljs.core.cst$kw$missing_DASH_api_DASH_check_DASH_fn.cljs$core$IFn$_invoke$arity$1(config__6181__auto___31597);

(api_check_fn__6182__auto___31598.cljs$core$IFn$_invoke$arity$3 ? api_check_fn__6182__auto___31598.cljs$core$IFn$_invoke$arity$3("chrome.runtime.sendMessage",ns_31574,"sendMessage") : api_check_fn__6182__auto___31598.call(null,"chrome.runtime.sendMessage",ns_31574,"sendMessage"));


var target_31575 = (function (){var target_obj_31590 = ns_31574;
var next_obj_31591 = (target_obj_31590["sendMessage"]);
if((!((next_obj_31591 == null)))){
return next_obj_31591;
} else {
return null;
}
})();
return target_31575.apply(ns_31574,final_args_array_31573);
})();

return callback_chan_31567;
});
chromex.ext.runtime.send_native_message_STAR_ = (function chromex$ext$runtime$send_native_message_STAR_(config,application,message){
var callback_chan_31599 = (function (){var config__6143__auto__ = config;
var handler_key__6144__auto__ = cljs.core.cst$kw$callback_DASH_channel_DASH_factory;
var handler__6145__auto__ = handler_key__6144__auto__.cljs$core$IFn$_invoke$arity$1(config__6143__auto__);

return (handler__6145__auto__.cljs$core$IFn$_invoke$arity$1 ? handler__6145__auto__.cljs$core$IFn$_invoke$arity$1(config__6143__auto__) : handler__6145__auto__.call(null,config__6143__auto__));
})();
var marshalled_application_31601_31622 = (function (){var omit_test_31607 = application;
if(cljs.core.keyword_identical_QMARK_(omit_test_31607,cljs.core.cst$kw$omit)){
return cljs.core.cst$kw$omit;
} else {
return omit_test_31607;
}
})();
var marshalled_message_31602_31623 = (function (){var omit_test_31608 = message;
if(cljs.core.keyword_identical_QMARK_(omit_test_31608,cljs.core.cst$kw$omit)){
return cljs.core.cst$kw$omit;
} else {
return omit_test_31608;
}
})();
var marshalled_response_callback_31603_31624 = ((function (marshalled_application_31601_31622,marshalled_message_31602_31623,callback_chan_31599){
return (function (cb_response_31609){
var fexpr__31613 = (function (){var config__6143__auto__ = config;
var handler_key__6144__auto__ = cljs.core.cst$kw$callback_DASH_fn_DASH_factory;
var handler__6145__auto__ = handler_key__6144__auto__.cljs$core$IFn$_invoke$arity$1(config__6143__auto__);

var G__31614 = config__6143__auto__;
var G__31615 = new cljs.core.PersistentArrayMap(null, 6, [cljs.core.cst$kw$id,cljs.core.cst$kw$chromex$ext$runtime_SLASH_send_DASH_native_DASH_message,cljs.core.cst$kw$name,"sendNativeMessage",cljs.core.cst$kw$since,"28",cljs.core.cst$kw$callback_QMARK_,true,cljs.core.cst$kw$params,new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentArrayMap(null, 2, [cljs.core.cst$kw$name,"application",cljs.core.cst$kw$type,"string"], null),new cljs.core.PersistentArrayMap(null, 2, [cljs.core.cst$kw$name,"message",cljs.core.cst$kw$type,"object"], null),new cljs.core.PersistentArrayMap(null, 4, [cljs.core.cst$kw$name,"response-callback",cljs.core.cst$kw$optional_QMARK_,true,cljs.core.cst$kw$type,cljs.core.cst$kw$callback,cljs.core.cst$kw$callback,new cljs.core.PersistentArrayMap(null, 1, [cljs.core.cst$kw$params,new cljs.core.PersistentVector(null, 1, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentArrayMap(null, 2, [cljs.core.cst$kw$name,"response",cljs.core.cst$kw$type,"any"], null)], null)], null)], null)], null),cljs.core.cst$kw$function_QMARK_,true], null);
var G__31616 = callback_chan_31599;
return (handler__6145__auto__.cljs$core$IFn$_invoke$arity$3 ? handler__6145__auto__.cljs$core$IFn$_invoke$arity$3(G__31614,G__31615,G__31616) : handler__6145__auto__.call(null,G__31614,G__31615,G__31616));
})();
return (fexpr__31613.cljs$core$IFn$_invoke$arity$1 ? fexpr__31613.cljs$core$IFn$_invoke$arity$1(cb_response_31609) : fexpr__31613.call(null,cb_response_31609));
});})(marshalled_application_31601_31622,marshalled_message_31602_31623,callback_chan_31599))
;
var result_31600_31625 = (function (){var final_args_array_31604 = chromex.support.prepare_final_args_array(new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_application_31601_31622,"application",null], null),new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_message_31602_31623,"message",null], null),new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_response_callback_31603_31624,"response-callback",true], null)], null),"chrome.runtime.sendNativeMessage");
var ns_31605 = (function (){var target_obj_31617 = cljs.core.cst$kw$root.cljs$core$IFn$_invoke$arity$1(config);
var next_obj_31618 = (target_obj_31617["chrome"]);
var next_obj_31619 = (next_obj_31618["runtime"]);
return next_obj_31619;
})();
var config__6181__auto___31626 = config;
var api_check_fn__6182__auto___31627 = cljs.core.cst$kw$missing_DASH_api_DASH_check_DASH_fn.cljs$core$IFn$_invoke$arity$1(config__6181__auto___31626);

(api_check_fn__6182__auto___31627.cljs$core$IFn$_invoke$arity$3 ? api_check_fn__6182__auto___31627.cljs$core$IFn$_invoke$arity$3("chrome.runtime.sendNativeMessage",ns_31605,"sendNativeMessage") : api_check_fn__6182__auto___31627.call(null,"chrome.runtime.sendNativeMessage",ns_31605,"sendNativeMessage"));


var target_31606 = (function (){var target_obj_31620 = ns_31605;
var next_obj_31621 = (target_obj_31620["sendNativeMessage"]);
if((!((next_obj_31621 == null)))){
return next_obj_31621;
} else {
return null;
}
})();
return target_31606.apply(ns_31605,final_args_array_31604);
})();

return callback_chan_31599;
});
chromex.ext.runtime.get_platform_info_STAR_ = (function chromex$ext$runtime$get_platform_info_STAR_(config){
var callback_chan_31628 = (function (){var config__6143__auto__ = config;
var handler_key__6144__auto__ = cljs.core.cst$kw$callback_DASH_channel_DASH_factory;
var handler__6145__auto__ = handler_key__6144__auto__.cljs$core$IFn$_invoke$arity$1(config__6143__auto__);

return (handler__6145__auto__.cljs$core$IFn$_invoke$arity$1 ? handler__6145__auto__.cljs$core$IFn$_invoke$arity$1(config__6143__auto__) : handler__6145__auto__.call(null,config__6143__auto__));
})();
var marshalled_callback_31630_31647 = ((function (callback_chan_31628){
return (function (cb_platform_info_31634){
var fexpr__31638 = (function (){var config__6143__auto__ = config;
var handler_key__6144__auto__ = cljs.core.cst$kw$callback_DASH_fn_DASH_factory;
var handler__6145__auto__ = handler_key__6144__auto__.cljs$core$IFn$_invoke$arity$1(config__6143__auto__);

var G__31639 = config__6143__auto__;
var G__31640 = new cljs.core.PersistentArrayMap(null, 6, [cljs.core.cst$kw$id,cljs.core.cst$kw$chromex$ext$runtime_SLASH_get_DASH_platform_DASH_info,cljs.core.cst$kw$name,"getPlatformInfo",cljs.core.cst$kw$since,"29",cljs.core.cst$kw$callback_QMARK_,true,cljs.core.cst$kw$params,new cljs.core.PersistentVector(null, 1, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentArrayMap(null, 3, [cljs.core.cst$kw$name,"callback",cljs.core.cst$kw$type,cljs.core.cst$kw$callback,cljs.core.cst$kw$callback,new cljs.core.PersistentArrayMap(null, 1, [cljs.core.cst$kw$params,new cljs.core.PersistentVector(null, 1, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentArrayMap(null, 2, [cljs.core.cst$kw$name,"platform-info",cljs.core.cst$kw$type,"runtime.PlatformInfo"], null)], null)], null)], null)], null),cljs.core.cst$kw$function_QMARK_,true], null);
var G__31641 = callback_chan_31628;
return (handler__6145__auto__.cljs$core$IFn$_invoke$arity$3 ? handler__6145__auto__.cljs$core$IFn$_invoke$arity$3(G__31639,G__31640,G__31641) : handler__6145__auto__.call(null,G__31639,G__31640,G__31641));
})();
return (fexpr__31638.cljs$core$IFn$_invoke$arity$1 ? fexpr__31638.cljs$core$IFn$_invoke$arity$1(cb_platform_info_31634) : fexpr__31638.call(null,cb_platform_info_31634));
});})(callback_chan_31628))
;
var result_31629_31648 = (function (){var final_args_array_31631 = chromex.support.prepare_final_args_array(new cljs.core.PersistentVector(null, 1, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_callback_31630_31647,"callback",null], null)], null),"chrome.runtime.getPlatformInfo");
var ns_31632 = (function (){var target_obj_31642 = cljs.core.cst$kw$root.cljs$core$IFn$_invoke$arity$1(config);
var next_obj_31643 = (target_obj_31642["chrome"]);
var next_obj_31644 = (next_obj_31643["runtime"]);
return next_obj_31644;
})();
var config__6181__auto___31649 = config;
var api_check_fn__6182__auto___31650 = cljs.core.cst$kw$missing_DASH_api_DASH_check_DASH_fn.cljs$core$IFn$_invoke$arity$1(config__6181__auto___31649);

(api_check_fn__6182__auto___31650.cljs$core$IFn$_invoke$arity$3 ? api_check_fn__6182__auto___31650.cljs$core$IFn$_invoke$arity$3("chrome.runtime.getPlatformInfo",ns_31632,"getPlatformInfo") : api_check_fn__6182__auto___31650.call(null,"chrome.runtime.getPlatformInfo",ns_31632,"getPlatformInfo"));


var target_31633 = (function (){var target_obj_31645 = ns_31632;
var next_obj_31646 = (target_obj_31645["getPlatformInfo"]);
if((!((next_obj_31646 == null)))){
return next_obj_31646;
} else {
return null;
}
})();
return target_31633.apply(ns_31632,final_args_array_31631);
})();

return callback_chan_31628;
});
chromex.ext.runtime.get_package_directory_entry_STAR_ = (function chromex$ext$runtime$get_package_directory_entry_STAR_(config){
var callback_chan_31651 = (function (){var config__6143__auto__ = config;
var handler_key__6144__auto__ = cljs.core.cst$kw$callback_DASH_channel_DASH_factory;
var handler__6145__auto__ = handler_key__6144__auto__.cljs$core$IFn$_invoke$arity$1(config__6143__auto__);

return (handler__6145__auto__.cljs$core$IFn$_invoke$arity$1 ? handler__6145__auto__.cljs$core$IFn$_invoke$arity$1(config__6143__auto__) : handler__6145__auto__.call(null,config__6143__auto__));
})();
var marshalled_callback_31653_31670 = ((function (callback_chan_31651){
return (function (cb_directory_entry_31657){
var fexpr__31661 = (function (){var config__6143__auto__ = config;
var handler_key__6144__auto__ = cljs.core.cst$kw$callback_DASH_fn_DASH_factory;
var handler__6145__auto__ = handler_key__6144__auto__.cljs$core$IFn$_invoke$arity$1(config__6143__auto__);

var G__31662 = config__6143__auto__;
var G__31663 = new cljs.core.PersistentArrayMap(null, 6, [cljs.core.cst$kw$id,cljs.core.cst$kw$chromex$ext$runtime_SLASH_get_DASH_package_DASH_directory_DASH_entry,cljs.core.cst$kw$name,"getPackageDirectoryEntry",cljs.core.cst$kw$since,"29",cljs.core.cst$kw$callback_QMARK_,true,cljs.core.cst$kw$params,new cljs.core.PersistentVector(null, 1, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentArrayMap(null, 3, [cljs.core.cst$kw$name,"callback",cljs.core.cst$kw$type,cljs.core.cst$kw$callback,cljs.core.cst$kw$callback,new cljs.core.PersistentArrayMap(null, 1, [cljs.core.cst$kw$params,new cljs.core.PersistentVector(null, 1, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentArrayMap(null, 2, [cljs.core.cst$kw$name,"directory-entry",cljs.core.cst$kw$type,"DirectoryEntry"], null)], null)], null)], null)], null),cljs.core.cst$kw$function_QMARK_,true], null);
var G__31664 = callback_chan_31651;
return (handler__6145__auto__.cljs$core$IFn$_invoke$arity$3 ? handler__6145__auto__.cljs$core$IFn$_invoke$arity$3(G__31662,G__31663,G__31664) : handler__6145__auto__.call(null,G__31662,G__31663,G__31664));
})();
return (fexpr__31661.cljs$core$IFn$_invoke$arity$1 ? fexpr__31661.cljs$core$IFn$_invoke$arity$1(cb_directory_entry_31657) : fexpr__31661.call(null,cb_directory_entry_31657));
});})(callback_chan_31651))
;
var result_31652_31671 = (function (){var final_args_array_31654 = chromex.support.prepare_final_args_array(new cljs.core.PersistentVector(null, 1, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_callback_31653_31670,"callback",null], null)], null),"chrome.runtime.getPackageDirectoryEntry");
var ns_31655 = (function (){var target_obj_31665 = cljs.core.cst$kw$root.cljs$core$IFn$_invoke$arity$1(config);
var next_obj_31666 = (target_obj_31665["chrome"]);
var next_obj_31667 = (next_obj_31666["runtime"]);
return next_obj_31667;
})();
var config__6181__auto___31672 = config;
var api_check_fn__6182__auto___31673 = cljs.core.cst$kw$missing_DASH_api_DASH_check_DASH_fn.cljs$core$IFn$_invoke$arity$1(config__6181__auto___31672);

(api_check_fn__6182__auto___31673.cljs$core$IFn$_invoke$arity$3 ? api_check_fn__6182__auto___31673.cljs$core$IFn$_invoke$arity$3("chrome.runtime.getPackageDirectoryEntry",ns_31655,"getPackageDirectoryEntry") : api_check_fn__6182__auto___31673.call(null,"chrome.runtime.getPackageDirectoryEntry",ns_31655,"getPackageDirectoryEntry"));


var target_31656 = (function (){var target_obj_31668 = ns_31655;
var next_obj_31669 = (target_obj_31668["getPackageDirectoryEntry"]);
if((!((next_obj_31669 == null)))){
return next_obj_31669;
} else {
return null;
}
})();
return target_31656.apply(ns_31655,final_args_array_31654);
})();

return callback_chan_31651;
});
chromex.ext.runtime.on_startup_STAR_ = (function chromex$ext$runtime$on_startup_STAR_(var_args){
var args__4647__auto__ = [];
var len__4641__auto___31691 = arguments.length;
var i__4642__auto___31692 = (0);
while(true){
if((i__4642__auto___31692 < len__4641__auto___31691)){
args__4647__auto__.push((arguments[i__4642__auto___31692]));

var G__31693 = (i__4642__auto___31692 + (1));
i__4642__auto___31692 = G__31693;
continue;
} else {
}
break;
}

var argseq__4648__auto__ = ((((2) < args__4647__auto__.length))?(new cljs.core.IndexedSeq(args__4647__auto__.slice((2)),(0),null)):null);
return chromex.ext.runtime.on_startup_STAR_.cljs$core$IFn$_invoke$arity$variadic((arguments[(0)]),(arguments[(1)]),argseq__4648__auto__);
});

chromex.ext.runtime.on_startup_STAR_.cljs$core$IFn$_invoke$arity$variadic = (function (config,channel,args){
var event_fn_31677 = (function (){var config__6143__auto__ = config;
var handler_key__6144__auto__ = cljs.core.cst$kw$event_DASH_listener_DASH_factory;
var handler__6145__auto__ = handler_key__6144__auto__.cljs$core$IFn$_invoke$arity$1(config__6143__auto__);

var G__31683 = config__6143__auto__;
var G__31684 = cljs.core.cst$kw$chromex$ext$runtime_SLASH_on_DASH_startup;
var G__31685 = channel;
return (handler__6145__auto__.cljs$core$IFn$_invoke$arity$3 ? handler__6145__auto__.cljs$core$IFn$_invoke$arity$3(G__31683,G__31684,G__31685) : handler__6145__auto__.call(null,G__31683,G__31684,G__31685));
})();
var handler_fn_31678 = event_fn_31677;
var logging_fn_31679 = ((function (event_fn_31677,handler_fn_31678){
return (function (){

return (handler_fn_31678.cljs$core$IFn$_invoke$arity$0 ? handler_fn_31678.cljs$core$IFn$_invoke$arity$0() : handler_fn_31678.call(null));
});})(event_fn_31677,handler_fn_31678))
;
var ns_obj_31682 = (function (){var target_obj_31686 = cljs.core.cst$kw$root.cljs$core$IFn$_invoke$arity$1(config);
var next_obj_31687 = (target_obj_31686["chrome"]);
var next_obj_31688 = (next_obj_31687["runtime"]);
return next_obj_31688;
})();
var config__6181__auto___31694 = config;
var api_check_fn__6182__auto___31695 = cljs.core.cst$kw$missing_DASH_api_DASH_check_DASH_fn.cljs$core$IFn$_invoke$arity$1(config__6181__auto___31694);

(api_check_fn__6182__auto___31695.cljs$core$IFn$_invoke$arity$3 ? api_check_fn__6182__auto___31695.cljs$core$IFn$_invoke$arity$3("chrome.runtime.onStartup",ns_obj_31682,"onStartup") : api_check_fn__6182__auto___31695.call(null,"chrome.runtime.onStartup",ns_obj_31682,"onStartup"));

var event_obj_31680 = (function (){var target_obj_31689 = ns_obj_31682;
var next_obj_31690 = (target_obj_31689["onStartup"]);
return next_obj_31690;
})();
var result_31681 = chromex.chrome_event_subscription.make_chrome_event_subscription(event_obj_31680,logging_fn_31679,channel);
result_31681.chromex$protocols$chrome_event_subscription$IChromeEventSubscription$subscribe_BANG_$arity$2(null,args);

return result_31681;
});

chromex.ext.runtime.on_startup_STAR_.cljs$lang$maxFixedArity = (2);

/** @this {Function} */
chromex.ext.runtime.on_startup_STAR_.cljs$lang$applyTo = (function (seq31674){
var G__31675 = cljs.core.first(seq31674);
var seq31674__$1 = cljs.core.next(seq31674);
var G__31676 = cljs.core.first(seq31674__$1);
var seq31674__$2 = cljs.core.next(seq31674__$1);
var self__4628__auto__ = this;
return self__4628__auto__.cljs$core$IFn$_invoke$arity$variadic(G__31675,G__31676,seq31674__$2);
});

chromex.ext.runtime.on_installed_STAR_ = (function chromex$ext$runtime$on_installed_STAR_(var_args){
var args__4647__auto__ = [];
var len__4641__auto___31715 = arguments.length;
var i__4642__auto___31716 = (0);
while(true){
if((i__4642__auto___31716 < len__4641__auto___31715)){
args__4647__auto__.push((arguments[i__4642__auto___31716]));

var G__31717 = (i__4642__auto___31716 + (1));
i__4642__auto___31716 = G__31717;
continue;
} else {
}
break;
}

var argseq__4648__auto__ = ((((2) < args__4647__auto__.length))?(new cljs.core.IndexedSeq(args__4647__auto__.slice((2)),(0),null)):null);
return chromex.ext.runtime.on_installed_STAR_.cljs$core$IFn$_invoke$arity$variadic((arguments[(0)]),(arguments[(1)]),argseq__4648__auto__);
});

chromex.ext.runtime.on_installed_STAR_.cljs$core$IFn$_invoke$arity$variadic = (function (config,channel,args){
var event_fn_31699 = (function (){var config__6143__auto__ = config;
var handler_key__6144__auto__ = cljs.core.cst$kw$event_DASH_listener_DASH_factory;
var handler__6145__auto__ = handler_key__6144__auto__.cljs$core$IFn$_invoke$arity$1(config__6143__auto__);

var G__31707 = config__6143__auto__;
var G__31708 = cljs.core.cst$kw$chromex$ext$runtime_SLASH_on_DASH_installed;
var G__31709 = channel;
return (handler__6145__auto__.cljs$core$IFn$_invoke$arity$3 ? handler__6145__auto__.cljs$core$IFn$_invoke$arity$3(G__31707,G__31708,G__31709) : handler__6145__auto__.call(null,G__31707,G__31708,G__31709));
})();
var handler_fn_31700 = ((function (event_fn_31699){
return (function (cb_details_31705){
return (event_fn_31699.cljs$core$IFn$_invoke$arity$1 ? event_fn_31699.cljs$core$IFn$_invoke$arity$1(cb_details_31705) : event_fn_31699.call(null,cb_details_31705));
});})(event_fn_31699))
;
var logging_fn_31701 = ((function (event_fn_31699,handler_fn_31700){
return (function (cb_param_details_31706){

return handler_fn_31700(cb_param_details_31706);
});})(event_fn_31699,handler_fn_31700))
;
var ns_obj_31704 = (function (){var target_obj_31710 = cljs.core.cst$kw$root.cljs$core$IFn$_invoke$arity$1(config);
var next_obj_31711 = (target_obj_31710["chrome"]);
var next_obj_31712 = (next_obj_31711["runtime"]);
return next_obj_31712;
})();
var config__6181__auto___31718 = config;
var api_check_fn__6182__auto___31719 = cljs.core.cst$kw$missing_DASH_api_DASH_check_DASH_fn.cljs$core$IFn$_invoke$arity$1(config__6181__auto___31718);

(api_check_fn__6182__auto___31719.cljs$core$IFn$_invoke$arity$3 ? api_check_fn__6182__auto___31719.cljs$core$IFn$_invoke$arity$3("chrome.runtime.onInstalled",ns_obj_31704,"onInstalled") : api_check_fn__6182__auto___31719.call(null,"chrome.runtime.onInstalled",ns_obj_31704,"onInstalled"));

var event_obj_31702 = (function (){var target_obj_31713 = ns_obj_31704;
var next_obj_31714 = (target_obj_31713["onInstalled"]);
return next_obj_31714;
})();
var result_31703 = chromex.chrome_event_subscription.make_chrome_event_subscription(event_obj_31702,logging_fn_31701,channel);
result_31703.chromex$protocols$chrome_event_subscription$IChromeEventSubscription$subscribe_BANG_$arity$2(null,args);

return result_31703;
});

chromex.ext.runtime.on_installed_STAR_.cljs$lang$maxFixedArity = (2);

/** @this {Function} */
chromex.ext.runtime.on_installed_STAR_.cljs$lang$applyTo = (function (seq31696){
var G__31697 = cljs.core.first(seq31696);
var seq31696__$1 = cljs.core.next(seq31696);
var G__31698 = cljs.core.first(seq31696__$1);
var seq31696__$2 = cljs.core.next(seq31696__$1);
var self__4628__auto__ = this;
return self__4628__auto__.cljs$core$IFn$_invoke$arity$variadic(G__31697,G__31698,seq31696__$2);
});

chromex.ext.runtime.on_suspend_STAR_ = (function chromex$ext$runtime$on_suspend_STAR_(var_args){
var args__4647__auto__ = [];
var len__4641__auto___31737 = arguments.length;
var i__4642__auto___31738 = (0);
while(true){
if((i__4642__auto___31738 < len__4641__auto___31737)){
args__4647__auto__.push((arguments[i__4642__auto___31738]));

var G__31739 = (i__4642__auto___31738 + (1));
i__4642__auto___31738 = G__31739;
continue;
} else {
}
break;
}

var argseq__4648__auto__ = ((((2) < args__4647__auto__.length))?(new cljs.core.IndexedSeq(args__4647__auto__.slice((2)),(0),null)):null);
return chromex.ext.runtime.on_suspend_STAR_.cljs$core$IFn$_invoke$arity$variadic((arguments[(0)]),(arguments[(1)]),argseq__4648__auto__);
});

chromex.ext.runtime.on_suspend_STAR_.cljs$core$IFn$_invoke$arity$variadic = (function (config,channel,args){
var event_fn_31723 = (function (){var config__6143__auto__ = config;
var handler_key__6144__auto__ = cljs.core.cst$kw$event_DASH_listener_DASH_factory;
var handler__6145__auto__ = handler_key__6144__auto__.cljs$core$IFn$_invoke$arity$1(config__6143__auto__);

var G__31729 = config__6143__auto__;
var G__31730 = cljs.core.cst$kw$chromex$ext$runtime_SLASH_on_DASH_suspend;
var G__31731 = channel;
return (handler__6145__auto__.cljs$core$IFn$_invoke$arity$3 ? handler__6145__auto__.cljs$core$IFn$_invoke$arity$3(G__31729,G__31730,G__31731) : handler__6145__auto__.call(null,G__31729,G__31730,G__31731));
})();
var handler_fn_31724 = event_fn_31723;
var logging_fn_31725 = ((function (event_fn_31723,handler_fn_31724){
return (function (){

return (handler_fn_31724.cljs$core$IFn$_invoke$arity$0 ? handler_fn_31724.cljs$core$IFn$_invoke$arity$0() : handler_fn_31724.call(null));
});})(event_fn_31723,handler_fn_31724))
;
var ns_obj_31728 = (function (){var target_obj_31732 = cljs.core.cst$kw$root.cljs$core$IFn$_invoke$arity$1(config);
var next_obj_31733 = (target_obj_31732["chrome"]);
var next_obj_31734 = (next_obj_31733["runtime"]);
return next_obj_31734;
})();
var config__6181__auto___31740 = config;
var api_check_fn__6182__auto___31741 = cljs.core.cst$kw$missing_DASH_api_DASH_check_DASH_fn.cljs$core$IFn$_invoke$arity$1(config__6181__auto___31740);

(api_check_fn__6182__auto___31741.cljs$core$IFn$_invoke$arity$3 ? api_check_fn__6182__auto___31741.cljs$core$IFn$_invoke$arity$3("chrome.runtime.onSuspend",ns_obj_31728,"onSuspend") : api_check_fn__6182__auto___31741.call(null,"chrome.runtime.onSuspend",ns_obj_31728,"onSuspend"));

var event_obj_31726 = (function (){var target_obj_31735 = ns_obj_31728;
var next_obj_31736 = (target_obj_31735["onSuspend"]);
return next_obj_31736;
})();
var result_31727 = chromex.chrome_event_subscription.make_chrome_event_subscription(event_obj_31726,logging_fn_31725,channel);
result_31727.chromex$protocols$chrome_event_subscription$IChromeEventSubscription$subscribe_BANG_$arity$2(null,args);

return result_31727;
});

chromex.ext.runtime.on_suspend_STAR_.cljs$lang$maxFixedArity = (2);

/** @this {Function} */
chromex.ext.runtime.on_suspend_STAR_.cljs$lang$applyTo = (function (seq31720){
var G__31721 = cljs.core.first(seq31720);
var seq31720__$1 = cljs.core.next(seq31720);
var G__31722 = cljs.core.first(seq31720__$1);
var seq31720__$2 = cljs.core.next(seq31720__$1);
var self__4628__auto__ = this;
return self__4628__auto__.cljs$core$IFn$_invoke$arity$variadic(G__31721,G__31722,seq31720__$2);
});

chromex.ext.runtime.on_suspend_canceled_STAR_ = (function chromex$ext$runtime$on_suspend_canceled_STAR_(var_args){
var args__4647__auto__ = [];
var len__4641__auto___31759 = arguments.length;
var i__4642__auto___31760 = (0);
while(true){
if((i__4642__auto___31760 < len__4641__auto___31759)){
args__4647__auto__.push((arguments[i__4642__auto___31760]));

var G__31761 = (i__4642__auto___31760 + (1));
i__4642__auto___31760 = G__31761;
continue;
} else {
}
break;
}

var argseq__4648__auto__ = ((((2) < args__4647__auto__.length))?(new cljs.core.IndexedSeq(args__4647__auto__.slice((2)),(0),null)):null);
return chromex.ext.runtime.on_suspend_canceled_STAR_.cljs$core$IFn$_invoke$arity$variadic((arguments[(0)]),(arguments[(1)]),argseq__4648__auto__);
});

chromex.ext.runtime.on_suspend_canceled_STAR_.cljs$core$IFn$_invoke$arity$variadic = (function (config,channel,args){
var event_fn_31745 = (function (){var config__6143__auto__ = config;
var handler_key__6144__auto__ = cljs.core.cst$kw$event_DASH_listener_DASH_factory;
var handler__6145__auto__ = handler_key__6144__auto__.cljs$core$IFn$_invoke$arity$1(config__6143__auto__);

var G__31751 = config__6143__auto__;
var G__31752 = cljs.core.cst$kw$chromex$ext$runtime_SLASH_on_DASH_suspend_DASH_canceled;
var G__31753 = channel;
return (handler__6145__auto__.cljs$core$IFn$_invoke$arity$3 ? handler__6145__auto__.cljs$core$IFn$_invoke$arity$3(G__31751,G__31752,G__31753) : handler__6145__auto__.call(null,G__31751,G__31752,G__31753));
})();
var handler_fn_31746 = event_fn_31745;
var logging_fn_31747 = ((function (event_fn_31745,handler_fn_31746){
return (function (){

return (handler_fn_31746.cljs$core$IFn$_invoke$arity$0 ? handler_fn_31746.cljs$core$IFn$_invoke$arity$0() : handler_fn_31746.call(null));
});})(event_fn_31745,handler_fn_31746))
;
var ns_obj_31750 = (function (){var target_obj_31754 = cljs.core.cst$kw$root.cljs$core$IFn$_invoke$arity$1(config);
var next_obj_31755 = (target_obj_31754["chrome"]);
var next_obj_31756 = (next_obj_31755["runtime"]);
return next_obj_31756;
})();
var config__6181__auto___31762 = config;
var api_check_fn__6182__auto___31763 = cljs.core.cst$kw$missing_DASH_api_DASH_check_DASH_fn.cljs$core$IFn$_invoke$arity$1(config__6181__auto___31762);

(api_check_fn__6182__auto___31763.cljs$core$IFn$_invoke$arity$3 ? api_check_fn__6182__auto___31763.cljs$core$IFn$_invoke$arity$3("chrome.runtime.onSuspendCanceled",ns_obj_31750,"onSuspendCanceled") : api_check_fn__6182__auto___31763.call(null,"chrome.runtime.onSuspendCanceled",ns_obj_31750,"onSuspendCanceled"));

var event_obj_31748 = (function (){var target_obj_31757 = ns_obj_31750;
var next_obj_31758 = (target_obj_31757["onSuspendCanceled"]);
return next_obj_31758;
})();
var result_31749 = chromex.chrome_event_subscription.make_chrome_event_subscription(event_obj_31748,logging_fn_31747,channel);
result_31749.chromex$protocols$chrome_event_subscription$IChromeEventSubscription$subscribe_BANG_$arity$2(null,args);

return result_31749;
});

chromex.ext.runtime.on_suspend_canceled_STAR_.cljs$lang$maxFixedArity = (2);

/** @this {Function} */
chromex.ext.runtime.on_suspend_canceled_STAR_.cljs$lang$applyTo = (function (seq31742){
var G__31743 = cljs.core.first(seq31742);
var seq31742__$1 = cljs.core.next(seq31742);
var G__31744 = cljs.core.first(seq31742__$1);
var seq31742__$2 = cljs.core.next(seq31742__$1);
var self__4628__auto__ = this;
return self__4628__auto__.cljs$core$IFn$_invoke$arity$variadic(G__31743,G__31744,seq31742__$2);
});

chromex.ext.runtime.on_update_available_STAR_ = (function chromex$ext$runtime$on_update_available_STAR_(var_args){
var args__4647__auto__ = [];
var len__4641__auto___31783 = arguments.length;
var i__4642__auto___31784 = (0);
while(true){
if((i__4642__auto___31784 < len__4641__auto___31783)){
args__4647__auto__.push((arguments[i__4642__auto___31784]));

var G__31785 = (i__4642__auto___31784 + (1));
i__4642__auto___31784 = G__31785;
continue;
} else {
}
break;
}

var argseq__4648__auto__ = ((((2) < args__4647__auto__.length))?(new cljs.core.IndexedSeq(args__4647__auto__.slice((2)),(0),null)):null);
return chromex.ext.runtime.on_update_available_STAR_.cljs$core$IFn$_invoke$arity$variadic((arguments[(0)]),(arguments[(1)]),argseq__4648__auto__);
});

chromex.ext.runtime.on_update_available_STAR_.cljs$core$IFn$_invoke$arity$variadic = (function (config,channel,args){
var event_fn_31767 = (function (){var config__6143__auto__ = config;
var handler_key__6144__auto__ = cljs.core.cst$kw$event_DASH_listener_DASH_factory;
var handler__6145__auto__ = handler_key__6144__auto__.cljs$core$IFn$_invoke$arity$1(config__6143__auto__);

var G__31775 = config__6143__auto__;
var G__31776 = cljs.core.cst$kw$chromex$ext$runtime_SLASH_on_DASH_update_DASH_available;
var G__31777 = channel;
return (handler__6145__auto__.cljs$core$IFn$_invoke$arity$3 ? handler__6145__auto__.cljs$core$IFn$_invoke$arity$3(G__31775,G__31776,G__31777) : handler__6145__auto__.call(null,G__31775,G__31776,G__31777));
})();
var handler_fn_31768 = ((function (event_fn_31767){
return (function (cb_details_31773){
return (event_fn_31767.cljs$core$IFn$_invoke$arity$1 ? event_fn_31767.cljs$core$IFn$_invoke$arity$1(cb_details_31773) : event_fn_31767.call(null,cb_details_31773));
});})(event_fn_31767))
;
var logging_fn_31769 = ((function (event_fn_31767,handler_fn_31768){
return (function (cb_param_details_31774){

return handler_fn_31768(cb_param_details_31774);
});})(event_fn_31767,handler_fn_31768))
;
var ns_obj_31772 = (function (){var target_obj_31778 = cljs.core.cst$kw$root.cljs$core$IFn$_invoke$arity$1(config);
var next_obj_31779 = (target_obj_31778["chrome"]);
var next_obj_31780 = (next_obj_31779["runtime"]);
return next_obj_31780;
})();
var config__6181__auto___31786 = config;
var api_check_fn__6182__auto___31787 = cljs.core.cst$kw$missing_DASH_api_DASH_check_DASH_fn.cljs$core$IFn$_invoke$arity$1(config__6181__auto___31786);

(api_check_fn__6182__auto___31787.cljs$core$IFn$_invoke$arity$3 ? api_check_fn__6182__auto___31787.cljs$core$IFn$_invoke$arity$3("chrome.runtime.onUpdateAvailable",ns_obj_31772,"onUpdateAvailable") : api_check_fn__6182__auto___31787.call(null,"chrome.runtime.onUpdateAvailable",ns_obj_31772,"onUpdateAvailable"));

var event_obj_31770 = (function (){var target_obj_31781 = ns_obj_31772;
var next_obj_31782 = (target_obj_31781["onUpdateAvailable"]);
return next_obj_31782;
})();
var result_31771 = chromex.chrome_event_subscription.make_chrome_event_subscription(event_obj_31770,logging_fn_31769,channel);
result_31771.chromex$protocols$chrome_event_subscription$IChromeEventSubscription$subscribe_BANG_$arity$2(null,args);

return result_31771;
});

chromex.ext.runtime.on_update_available_STAR_.cljs$lang$maxFixedArity = (2);

/** @this {Function} */
chromex.ext.runtime.on_update_available_STAR_.cljs$lang$applyTo = (function (seq31764){
var G__31765 = cljs.core.first(seq31764);
var seq31764__$1 = cljs.core.next(seq31764);
var G__31766 = cljs.core.first(seq31764__$1);
var seq31764__$2 = cljs.core.next(seq31764__$1);
var self__4628__auto__ = this;
return self__4628__auto__.cljs$core$IFn$_invoke$arity$variadic(G__31765,G__31766,seq31764__$2);
});

chromex.ext.runtime.on_browser_update_available_STAR_ = (function chromex$ext$runtime$on_browser_update_available_STAR_(var_args){
var args__4647__auto__ = [];
var len__4641__auto___31805 = arguments.length;
var i__4642__auto___31806 = (0);
while(true){
if((i__4642__auto___31806 < len__4641__auto___31805)){
args__4647__auto__.push((arguments[i__4642__auto___31806]));

var G__31807 = (i__4642__auto___31806 + (1));
i__4642__auto___31806 = G__31807;
continue;
} else {
}
break;
}

var argseq__4648__auto__ = ((((2) < args__4647__auto__.length))?(new cljs.core.IndexedSeq(args__4647__auto__.slice((2)),(0),null)):null);
return chromex.ext.runtime.on_browser_update_available_STAR_.cljs$core$IFn$_invoke$arity$variadic((arguments[(0)]),(arguments[(1)]),argseq__4648__auto__);
});

chromex.ext.runtime.on_browser_update_available_STAR_.cljs$core$IFn$_invoke$arity$variadic = (function (config,channel,args){
var event_fn_31791 = (function (){var config__6143__auto__ = config;
var handler_key__6144__auto__ = cljs.core.cst$kw$event_DASH_listener_DASH_factory;
var handler__6145__auto__ = handler_key__6144__auto__.cljs$core$IFn$_invoke$arity$1(config__6143__auto__);

var G__31797 = config__6143__auto__;
var G__31798 = cljs.core.cst$kw$chromex$ext$runtime_SLASH_on_DASH_browser_DASH_update_DASH_available;
var G__31799 = channel;
return (handler__6145__auto__.cljs$core$IFn$_invoke$arity$3 ? handler__6145__auto__.cljs$core$IFn$_invoke$arity$3(G__31797,G__31798,G__31799) : handler__6145__auto__.call(null,G__31797,G__31798,G__31799));
})();
var handler_fn_31792 = event_fn_31791;
var logging_fn_31793 = ((function (event_fn_31791,handler_fn_31792){
return (function (){

return (handler_fn_31792.cljs$core$IFn$_invoke$arity$0 ? handler_fn_31792.cljs$core$IFn$_invoke$arity$0() : handler_fn_31792.call(null));
});})(event_fn_31791,handler_fn_31792))
;
var ns_obj_31796 = (function (){var target_obj_31800 = cljs.core.cst$kw$root.cljs$core$IFn$_invoke$arity$1(config);
var next_obj_31801 = (target_obj_31800["chrome"]);
var next_obj_31802 = (next_obj_31801["runtime"]);
return next_obj_31802;
})();
var config__6181__auto___31808 = config;
var api_check_fn__6182__auto___31809 = cljs.core.cst$kw$missing_DASH_api_DASH_check_DASH_fn.cljs$core$IFn$_invoke$arity$1(config__6181__auto___31808);

(api_check_fn__6182__auto___31809.cljs$core$IFn$_invoke$arity$3 ? api_check_fn__6182__auto___31809.cljs$core$IFn$_invoke$arity$3("chrome.runtime.onBrowserUpdateAvailable",ns_obj_31796,"onBrowserUpdateAvailable") : api_check_fn__6182__auto___31809.call(null,"chrome.runtime.onBrowserUpdateAvailable",ns_obj_31796,"onBrowserUpdateAvailable"));

var event_obj_31794 = (function (){var target_obj_31803 = ns_obj_31796;
var next_obj_31804 = (target_obj_31803["onBrowserUpdateAvailable"]);
return next_obj_31804;
})();
var result_31795 = chromex.chrome_event_subscription.make_chrome_event_subscription(event_obj_31794,logging_fn_31793,channel);
result_31795.chromex$protocols$chrome_event_subscription$IChromeEventSubscription$subscribe_BANG_$arity$2(null,args);

return result_31795;
});

chromex.ext.runtime.on_browser_update_available_STAR_.cljs$lang$maxFixedArity = (2);

/** @this {Function} */
chromex.ext.runtime.on_browser_update_available_STAR_.cljs$lang$applyTo = (function (seq31788){
var G__31789 = cljs.core.first(seq31788);
var seq31788__$1 = cljs.core.next(seq31788);
var G__31790 = cljs.core.first(seq31788__$1);
var seq31788__$2 = cljs.core.next(seq31788__$1);
var self__4628__auto__ = this;
return self__4628__auto__.cljs$core$IFn$_invoke$arity$variadic(G__31789,G__31790,seq31788__$2);
});

chromex.ext.runtime.on_connect_STAR_ = (function chromex$ext$runtime$on_connect_STAR_(var_args){
var args__4647__auto__ = [];
var len__4641__auto___31830 = arguments.length;
var i__4642__auto___31831 = (0);
while(true){
if((i__4642__auto___31831 < len__4641__auto___31830)){
args__4647__auto__.push((arguments[i__4642__auto___31831]));

var G__31832 = (i__4642__auto___31831 + (1));
i__4642__auto___31831 = G__31832;
continue;
} else {
}
break;
}

var argseq__4648__auto__ = ((((2) < args__4647__auto__.length))?(new cljs.core.IndexedSeq(args__4647__auto__.slice((2)),(0),null)):null);
return chromex.ext.runtime.on_connect_STAR_.cljs$core$IFn$_invoke$arity$variadic((arguments[(0)]),(arguments[(1)]),argseq__4648__auto__);
});

chromex.ext.runtime.on_connect_STAR_.cljs$core$IFn$_invoke$arity$variadic = (function (config,channel,args){
var event_fn_31813 = (function (){var config__6143__auto__ = config;
var handler_key__6144__auto__ = cljs.core.cst$kw$event_DASH_listener_DASH_factory;
var handler__6145__auto__ = handler_key__6144__auto__.cljs$core$IFn$_invoke$arity$1(config__6143__auto__);

var G__31821 = config__6143__auto__;
var G__31822 = cljs.core.cst$kw$chromex$ext$runtime_SLASH_on_DASH_connect;
var G__31823 = channel;
return (handler__6145__auto__.cljs$core$IFn$_invoke$arity$3 ? handler__6145__auto__.cljs$core$IFn$_invoke$arity$3(G__31821,G__31822,G__31823) : handler__6145__auto__.call(null,G__31821,G__31822,G__31823));
})();
var handler_fn_31814 = ((function (event_fn_31813){
return (function (cb_port_31819){
var G__31824 = chromex.marshalling.from_native_chrome_port(config,cb_port_31819);
return (event_fn_31813.cljs$core$IFn$_invoke$arity$1 ? event_fn_31813.cljs$core$IFn$_invoke$arity$1(G__31824) : event_fn_31813.call(null,G__31824));
});})(event_fn_31813))
;
var logging_fn_31815 = ((function (event_fn_31813,handler_fn_31814){
return (function (cb_param_port_31820){

return handler_fn_31814(cb_param_port_31820);
});})(event_fn_31813,handler_fn_31814))
;
var ns_obj_31818 = (function (){var target_obj_31825 = cljs.core.cst$kw$root.cljs$core$IFn$_invoke$arity$1(config);
var next_obj_31826 = (target_obj_31825["chrome"]);
var next_obj_31827 = (next_obj_31826["runtime"]);
return next_obj_31827;
})();
var config__6181__auto___31833 = config;
var api_check_fn__6182__auto___31834 = cljs.core.cst$kw$missing_DASH_api_DASH_check_DASH_fn.cljs$core$IFn$_invoke$arity$1(config__6181__auto___31833);

(api_check_fn__6182__auto___31834.cljs$core$IFn$_invoke$arity$3 ? api_check_fn__6182__auto___31834.cljs$core$IFn$_invoke$arity$3("chrome.runtime.onConnect",ns_obj_31818,"onConnect") : api_check_fn__6182__auto___31834.call(null,"chrome.runtime.onConnect",ns_obj_31818,"onConnect"));

var event_obj_31816 = (function (){var target_obj_31828 = ns_obj_31818;
var next_obj_31829 = (target_obj_31828["onConnect"]);
return next_obj_31829;
})();
var result_31817 = chromex.chrome_event_subscription.make_chrome_event_subscription(event_obj_31816,logging_fn_31815,channel);
result_31817.chromex$protocols$chrome_event_subscription$IChromeEventSubscription$subscribe_BANG_$arity$2(null,args);

return result_31817;
});

chromex.ext.runtime.on_connect_STAR_.cljs$lang$maxFixedArity = (2);

/** @this {Function} */
chromex.ext.runtime.on_connect_STAR_.cljs$lang$applyTo = (function (seq31810){
var G__31811 = cljs.core.first(seq31810);
var seq31810__$1 = cljs.core.next(seq31810);
var G__31812 = cljs.core.first(seq31810__$1);
var seq31810__$2 = cljs.core.next(seq31810__$1);
var self__4628__auto__ = this;
return self__4628__auto__.cljs$core$IFn$_invoke$arity$variadic(G__31811,G__31812,seq31810__$2);
});

chromex.ext.runtime.on_connect_external_STAR_ = (function chromex$ext$runtime$on_connect_external_STAR_(var_args){
var args__4647__auto__ = [];
var len__4641__auto___31855 = arguments.length;
var i__4642__auto___31856 = (0);
while(true){
if((i__4642__auto___31856 < len__4641__auto___31855)){
args__4647__auto__.push((arguments[i__4642__auto___31856]));

var G__31857 = (i__4642__auto___31856 + (1));
i__4642__auto___31856 = G__31857;
continue;
} else {
}
break;
}

var argseq__4648__auto__ = ((((2) < args__4647__auto__.length))?(new cljs.core.IndexedSeq(args__4647__auto__.slice((2)),(0),null)):null);
return chromex.ext.runtime.on_connect_external_STAR_.cljs$core$IFn$_invoke$arity$variadic((arguments[(0)]),(arguments[(1)]),argseq__4648__auto__);
});

chromex.ext.runtime.on_connect_external_STAR_.cljs$core$IFn$_invoke$arity$variadic = (function (config,channel,args){
var event_fn_31838 = (function (){var config__6143__auto__ = config;
var handler_key__6144__auto__ = cljs.core.cst$kw$event_DASH_listener_DASH_factory;
var handler__6145__auto__ = handler_key__6144__auto__.cljs$core$IFn$_invoke$arity$1(config__6143__auto__);

var G__31846 = config__6143__auto__;
var G__31847 = cljs.core.cst$kw$chromex$ext$runtime_SLASH_on_DASH_connect_DASH_external;
var G__31848 = channel;
return (handler__6145__auto__.cljs$core$IFn$_invoke$arity$3 ? handler__6145__auto__.cljs$core$IFn$_invoke$arity$3(G__31846,G__31847,G__31848) : handler__6145__auto__.call(null,G__31846,G__31847,G__31848));
})();
var handler_fn_31839 = ((function (event_fn_31838){
return (function (cb_port_31844){
var G__31849 = chromex.marshalling.from_native_chrome_port(config,cb_port_31844);
return (event_fn_31838.cljs$core$IFn$_invoke$arity$1 ? event_fn_31838.cljs$core$IFn$_invoke$arity$1(G__31849) : event_fn_31838.call(null,G__31849));
});})(event_fn_31838))
;
var logging_fn_31840 = ((function (event_fn_31838,handler_fn_31839){
return (function (cb_param_port_31845){

return handler_fn_31839(cb_param_port_31845);
});})(event_fn_31838,handler_fn_31839))
;
var ns_obj_31843 = (function (){var target_obj_31850 = cljs.core.cst$kw$root.cljs$core$IFn$_invoke$arity$1(config);
var next_obj_31851 = (target_obj_31850["chrome"]);
var next_obj_31852 = (next_obj_31851["runtime"]);
return next_obj_31852;
})();
var config__6181__auto___31858 = config;
var api_check_fn__6182__auto___31859 = cljs.core.cst$kw$missing_DASH_api_DASH_check_DASH_fn.cljs$core$IFn$_invoke$arity$1(config__6181__auto___31858);

(api_check_fn__6182__auto___31859.cljs$core$IFn$_invoke$arity$3 ? api_check_fn__6182__auto___31859.cljs$core$IFn$_invoke$arity$3("chrome.runtime.onConnectExternal",ns_obj_31843,"onConnectExternal") : api_check_fn__6182__auto___31859.call(null,"chrome.runtime.onConnectExternal",ns_obj_31843,"onConnectExternal"));

var event_obj_31841 = (function (){var target_obj_31853 = ns_obj_31843;
var next_obj_31854 = (target_obj_31853["onConnectExternal"]);
return next_obj_31854;
})();
var result_31842 = chromex.chrome_event_subscription.make_chrome_event_subscription(event_obj_31841,logging_fn_31840,channel);
result_31842.chromex$protocols$chrome_event_subscription$IChromeEventSubscription$subscribe_BANG_$arity$2(null,args);

return result_31842;
});

chromex.ext.runtime.on_connect_external_STAR_.cljs$lang$maxFixedArity = (2);

/** @this {Function} */
chromex.ext.runtime.on_connect_external_STAR_.cljs$lang$applyTo = (function (seq31835){
var G__31836 = cljs.core.first(seq31835);
var seq31835__$1 = cljs.core.next(seq31835);
var G__31837 = cljs.core.first(seq31835__$1);
var seq31835__$2 = cljs.core.next(seq31835__$1);
var self__4628__auto__ = this;
return self__4628__auto__.cljs$core$IFn$_invoke$arity$variadic(G__31836,G__31837,seq31835__$2);
});

chromex.ext.runtime.on_message_STAR_ = (function chromex$ext$runtime$on_message_STAR_(var_args){
var args__4647__auto__ = [];
var len__4641__auto___31883 = arguments.length;
var i__4642__auto___31884 = (0);
while(true){
if((i__4642__auto___31884 < len__4641__auto___31883)){
args__4647__auto__.push((arguments[i__4642__auto___31884]));

var G__31885 = (i__4642__auto___31884 + (1));
i__4642__auto___31884 = G__31885;
continue;
} else {
}
break;
}

var argseq__4648__auto__ = ((((2) < args__4647__auto__.length))?(new cljs.core.IndexedSeq(args__4647__auto__.slice((2)),(0),null)):null);
return chromex.ext.runtime.on_message_STAR_.cljs$core$IFn$_invoke$arity$variadic((arguments[(0)]),(arguments[(1)]),argseq__4648__auto__);
});

chromex.ext.runtime.on_message_STAR_.cljs$core$IFn$_invoke$arity$variadic = (function (config,channel,args){
var event_fn_31863 = (function (){var config__6143__auto__ = config;
var handler_key__6144__auto__ = cljs.core.cst$kw$event_DASH_listener_DASH_factory;
var handler__6145__auto__ = handler_key__6144__auto__.cljs$core$IFn$_invoke$arity$1(config__6143__auto__);

var G__31875 = config__6143__auto__;
var G__31876 = cljs.core.cst$kw$chromex$ext$runtime_SLASH_on_DASH_message;
var G__31877 = channel;
return (handler__6145__auto__.cljs$core$IFn$_invoke$arity$3 ? handler__6145__auto__.cljs$core$IFn$_invoke$arity$3(G__31875,G__31876,G__31877) : handler__6145__auto__.call(null,G__31875,G__31876,G__31877));
})();
var handler_fn_31864 = ((function (event_fn_31863){
return (function (cb_message_31869,cb_sender_31870,cb_send_response_31871){
return (event_fn_31863.cljs$core$IFn$_invoke$arity$3 ? event_fn_31863.cljs$core$IFn$_invoke$arity$3(cb_message_31869,cb_sender_31870,cb_send_response_31871) : event_fn_31863.call(null,cb_message_31869,cb_sender_31870,cb_send_response_31871));
});})(event_fn_31863))
;
var logging_fn_31865 = ((function (event_fn_31863,handler_fn_31864){
return (function (cb_param_message_31872,cb_param_sender_31873,cb_param_send_response_31874){

return handler_fn_31864(cb_param_message_31872,cb_param_sender_31873,cb_param_send_response_31874);
});})(event_fn_31863,handler_fn_31864))
;
var ns_obj_31868 = (function (){var target_obj_31878 = cljs.core.cst$kw$root.cljs$core$IFn$_invoke$arity$1(config);
var next_obj_31879 = (target_obj_31878["chrome"]);
var next_obj_31880 = (next_obj_31879["runtime"]);
return next_obj_31880;
})();
var config__6181__auto___31886 = config;
var api_check_fn__6182__auto___31887 = cljs.core.cst$kw$missing_DASH_api_DASH_check_DASH_fn.cljs$core$IFn$_invoke$arity$1(config__6181__auto___31886);

(api_check_fn__6182__auto___31887.cljs$core$IFn$_invoke$arity$3 ? api_check_fn__6182__auto___31887.cljs$core$IFn$_invoke$arity$3("chrome.runtime.onMessage",ns_obj_31868,"onMessage") : api_check_fn__6182__auto___31887.call(null,"chrome.runtime.onMessage",ns_obj_31868,"onMessage"));

var event_obj_31866 = (function (){var target_obj_31881 = ns_obj_31868;
var next_obj_31882 = (target_obj_31881["onMessage"]);
return next_obj_31882;
})();
var result_31867 = chromex.chrome_event_subscription.make_chrome_event_subscription(event_obj_31866,logging_fn_31865,channel);
result_31867.chromex$protocols$chrome_event_subscription$IChromeEventSubscription$subscribe_BANG_$arity$2(null,args);

return result_31867;
});

chromex.ext.runtime.on_message_STAR_.cljs$lang$maxFixedArity = (2);

/** @this {Function} */
chromex.ext.runtime.on_message_STAR_.cljs$lang$applyTo = (function (seq31860){
var G__31861 = cljs.core.first(seq31860);
var seq31860__$1 = cljs.core.next(seq31860);
var G__31862 = cljs.core.first(seq31860__$1);
var seq31860__$2 = cljs.core.next(seq31860__$1);
var self__4628__auto__ = this;
return self__4628__auto__.cljs$core$IFn$_invoke$arity$variadic(G__31861,G__31862,seq31860__$2);
});

chromex.ext.runtime.on_message_external_STAR_ = (function chromex$ext$runtime$on_message_external_STAR_(var_args){
var args__4647__auto__ = [];
var len__4641__auto___31911 = arguments.length;
var i__4642__auto___31912 = (0);
while(true){
if((i__4642__auto___31912 < len__4641__auto___31911)){
args__4647__auto__.push((arguments[i__4642__auto___31912]));

var G__31913 = (i__4642__auto___31912 + (1));
i__4642__auto___31912 = G__31913;
continue;
} else {
}
break;
}

var argseq__4648__auto__ = ((((2) < args__4647__auto__.length))?(new cljs.core.IndexedSeq(args__4647__auto__.slice((2)),(0),null)):null);
return chromex.ext.runtime.on_message_external_STAR_.cljs$core$IFn$_invoke$arity$variadic((arguments[(0)]),(arguments[(1)]),argseq__4648__auto__);
});

chromex.ext.runtime.on_message_external_STAR_.cljs$core$IFn$_invoke$arity$variadic = (function (config,channel,args){
var event_fn_31891 = (function (){var config__6143__auto__ = config;
var handler_key__6144__auto__ = cljs.core.cst$kw$event_DASH_listener_DASH_factory;
var handler__6145__auto__ = handler_key__6144__auto__.cljs$core$IFn$_invoke$arity$1(config__6143__auto__);

var G__31903 = config__6143__auto__;
var G__31904 = cljs.core.cst$kw$chromex$ext$runtime_SLASH_on_DASH_message_DASH_external;
var G__31905 = channel;
return (handler__6145__auto__.cljs$core$IFn$_invoke$arity$3 ? handler__6145__auto__.cljs$core$IFn$_invoke$arity$3(G__31903,G__31904,G__31905) : handler__6145__auto__.call(null,G__31903,G__31904,G__31905));
})();
var handler_fn_31892 = ((function (event_fn_31891){
return (function (cb_message_31897,cb_sender_31898,cb_send_response_31899){
return (event_fn_31891.cljs$core$IFn$_invoke$arity$3 ? event_fn_31891.cljs$core$IFn$_invoke$arity$3(cb_message_31897,cb_sender_31898,cb_send_response_31899) : event_fn_31891.call(null,cb_message_31897,cb_sender_31898,cb_send_response_31899));
});})(event_fn_31891))
;
var logging_fn_31893 = ((function (event_fn_31891,handler_fn_31892){
return (function (cb_param_message_31900,cb_param_sender_31901,cb_param_send_response_31902){

return handler_fn_31892(cb_param_message_31900,cb_param_sender_31901,cb_param_send_response_31902);
});})(event_fn_31891,handler_fn_31892))
;
var ns_obj_31896 = (function (){var target_obj_31906 = cljs.core.cst$kw$root.cljs$core$IFn$_invoke$arity$1(config);
var next_obj_31907 = (target_obj_31906["chrome"]);
var next_obj_31908 = (next_obj_31907["runtime"]);
return next_obj_31908;
})();
var config__6181__auto___31914 = config;
var api_check_fn__6182__auto___31915 = cljs.core.cst$kw$missing_DASH_api_DASH_check_DASH_fn.cljs$core$IFn$_invoke$arity$1(config__6181__auto___31914);

(api_check_fn__6182__auto___31915.cljs$core$IFn$_invoke$arity$3 ? api_check_fn__6182__auto___31915.cljs$core$IFn$_invoke$arity$3("chrome.runtime.onMessageExternal",ns_obj_31896,"onMessageExternal") : api_check_fn__6182__auto___31915.call(null,"chrome.runtime.onMessageExternal",ns_obj_31896,"onMessageExternal"));

var event_obj_31894 = (function (){var target_obj_31909 = ns_obj_31896;
var next_obj_31910 = (target_obj_31909["onMessageExternal"]);
return next_obj_31910;
})();
var result_31895 = chromex.chrome_event_subscription.make_chrome_event_subscription(event_obj_31894,logging_fn_31893,channel);
result_31895.chromex$protocols$chrome_event_subscription$IChromeEventSubscription$subscribe_BANG_$arity$2(null,args);

return result_31895;
});

chromex.ext.runtime.on_message_external_STAR_.cljs$lang$maxFixedArity = (2);

/** @this {Function} */
chromex.ext.runtime.on_message_external_STAR_.cljs$lang$applyTo = (function (seq31888){
var G__31889 = cljs.core.first(seq31888);
var seq31888__$1 = cljs.core.next(seq31888);
var G__31890 = cljs.core.first(seq31888__$1);
var seq31888__$2 = cljs.core.next(seq31888__$1);
var self__4628__auto__ = this;
return self__4628__auto__.cljs$core$IFn$_invoke$arity$variadic(G__31889,G__31890,seq31888__$2);
});

chromex.ext.runtime.on_restart_required_STAR_ = (function chromex$ext$runtime$on_restart_required_STAR_(var_args){
var args__4647__auto__ = [];
var len__4641__auto___31935 = arguments.length;
var i__4642__auto___31936 = (0);
while(true){
if((i__4642__auto___31936 < len__4641__auto___31935)){
args__4647__auto__.push((arguments[i__4642__auto___31936]));

var G__31937 = (i__4642__auto___31936 + (1));
i__4642__auto___31936 = G__31937;
continue;
} else {
}
break;
}

var argseq__4648__auto__ = ((((2) < args__4647__auto__.length))?(new cljs.core.IndexedSeq(args__4647__auto__.slice((2)),(0),null)):null);
return chromex.ext.runtime.on_restart_required_STAR_.cljs$core$IFn$_invoke$arity$variadic((arguments[(0)]),(arguments[(1)]),argseq__4648__auto__);
});

chromex.ext.runtime.on_restart_required_STAR_.cljs$core$IFn$_invoke$arity$variadic = (function (config,channel,args){
var event_fn_31919 = (function (){var config__6143__auto__ = config;
var handler_key__6144__auto__ = cljs.core.cst$kw$event_DASH_listener_DASH_factory;
var handler__6145__auto__ = handler_key__6144__auto__.cljs$core$IFn$_invoke$arity$1(config__6143__auto__);

var G__31927 = config__6143__auto__;
var G__31928 = cljs.core.cst$kw$chromex$ext$runtime_SLASH_on_DASH_restart_DASH_required;
var G__31929 = channel;
return (handler__6145__auto__.cljs$core$IFn$_invoke$arity$3 ? handler__6145__auto__.cljs$core$IFn$_invoke$arity$3(G__31927,G__31928,G__31929) : handler__6145__auto__.call(null,G__31927,G__31928,G__31929));
})();
var handler_fn_31920 = ((function (event_fn_31919){
return (function (cb_reason_31925){
return (event_fn_31919.cljs$core$IFn$_invoke$arity$1 ? event_fn_31919.cljs$core$IFn$_invoke$arity$1(cb_reason_31925) : event_fn_31919.call(null,cb_reason_31925));
});})(event_fn_31919))
;
var logging_fn_31921 = ((function (event_fn_31919,handler_fn_31920){
return (function (cb_param_reason_31926){

return handler_fn_31920(cb_param_reason_31926);
});})(event_fn_31919,handler_fn_31920))
;
var ns_obj_31924 = (function (){var target_obj_31930 = cljs.core.cst$kw$root.cljs$core$IFn$_invoke$arity$1(config);
var next_obj_31931 = (target_obj_31930["chrome"]);
var next_obj_31932 = (next_obj_31931["runtime"]);
return next_obj_31932;
})();
var config__6181__auto___31938 = config;
var api_check_fn__6182__auto___31939 = cljs.core.cst$kw$missing_DASH_api_DASH_check_DASH_fn.cljs$core$IFn$_invoke$arity$1(config__6181__auto___31938);

(api_check_fn__6182__auto___31939.cljs$core$IFn$_invoke$arity$3 ? api_check_fn__6182__auto___31939.cljs$core$IFn$_invoke$arity$3("chrome.runtime.onRestartRequired",ns_obj_31924,"onRestartRequired") : api_check_fn__6182__auto___31939.call(null,"chrome.runtime.onRestartRequired",ns_obj_31924,"onRestartRequired"));

var event_obj_31922 = (function (){var target_obj_31933 = ns_obj_31924;
var next_obj_31934 = (target_obj_31933["onRestartRequired"]);
return next_obj_31934;
})();
var result_31923 = chromex.chrome_event_subscription.make_chrome_event_subscription(event_obj_31922,logging_fn_31921,channel);
result_31923.chromex$protocols$chrome_event_subscription$IChromeEventSubscription$subscribe_BANG_$arity$2(null,args);

return result_31923;
});

chromex.ext.runtime.on_restart_required_STAR_.cljs$lang$maxFixedArity = (2);

/** @this {Function} */
chromex.ext.runtime.on_restart_required_STAR_.cljs$lang$applyTo = (function (seq31916){
var G__31917 = cljs.core.first(seq31916);
var seq31916__$1 = cljs.core.next(seq31916);
var G__31918 = cljs.core.first(seq31916__$1);
var seq31916__$2 = cljs.core.next(seq31916__$1);
var self__4628__auto__ = this;
return self__4628__auto__.cljs$core$IFn$_invoke$arity$variadic(G__31917,G__31918,seq31916__$2);
});

