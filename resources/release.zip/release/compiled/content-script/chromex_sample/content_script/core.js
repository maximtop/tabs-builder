// Compiled by ClojureScript 1.10.439 {:static-fns true, :optimize-constants true, :elide-asserts true}
goog.provide('chromex_sample.content_script.core');
goog.require('cljs.core');
goog.require('cljs.core.constants');
goog.require('cljs.core.async');
goog.require('chromex.logging');
goog.require('chromex.protocols.chrome_port');
goog.require('chromex.ext.runtime');
chromex_sample.content_script.core.process_message_BANG_ = (function chromex_sample$content_script$core$process_message_BANG_(message){
console.log("CONTENT SCRIPT: got message:",message);

return null;
});
chromex_sample.content_script.core.run_message_loop_BANG_ = (function chromex_sample$content_script$core$run_message_loop_BANG_(message_channel){
console.log("CONTENT SCRIPT: starting message loop...");


var c__7992__auto__ = cljs.core.async.chan.cljs$core$IFn$_invoke$arity$1((1));
cljs.core.async.impl.dispatch.run(((function (c__7992__auto__){
return (function (){
var f__7993__auto__ = (function (){var switch__7885__auto__ = ((function (c__7992__auto__){
return (function (state_31958){
var state_val_31959 = (state_31958[(1)]);
if((state_val_31959 === (1))){
var state_31958__$1 = state_31958;
var statearr_31960_31973 = state_31958__$1;
(statearr_31960_31973[(2)] = null);

(statearr_31960_31973[(1)] = (2));


return cljs.core.cst$kw$recur;
} else {
if((state_val_31959 === (2))){
var state_31958__$1 = state_31958;
return cljs.core.async.impl.ioc_helpers.take_BANG_(state_31958__$1,(4),message_channel);
} else {
if((state_val_31959 === (3))){
var inst_31956 = (state_31958[(2)]);
var state_31958__$1 = state_31958;
return cljs.core.async.impl.ioc_helpers.return_chan(state_31958__$1,inst_31956);
} else {
if((state_val_31959 === (4))){
var inst_31946 = (state_31958[(7)]);
var inst_31946__$1 = (state_31958[(2)]);
var inst_31947 = (inst_31946__$1 == null);
var state_31958__$1 = (function (){var statearr_31961 = state_31958;
(statearr_31961[(7)] = inst_31946__$1);

return statearr_31961;
})();
if(cljs.core.truth_(inst_31947)){
var statearr_31962_31974 = state_31958__$1;
(statearr_31962_31974[(1)] = (5));

} else {
var statearr_31963_31975 = state_31958__$1;
(statearr_31963_31975[(1)] = (6));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_31959 === (5))){
var state_31958__$1 = state_31958;
var statearr_31964_31976 = state_31958__$1;
(statearr_31964_31976[(2)] = null);

(statearr_31964_31976[(1)] = (7));


return cljs.core.cst$kw$recur;
} else {
if((state_val_31959 === (6))){
var inst_31946 = (state_31958[(7)]);
var inst_31950 = chromex_sample.content_script.core.process_message_BANG_(inst_31946);
var state_31958__$1 = (function (){var statearr_31965 = state_31958;
(statearr_31965[(8)] = inst_31950);

return statearr_31965;
})();
var statearr_31966_31977 = state_31958__$1;
(statearr_31966_31977[(2)] = null);

(statearr_31966_31977[(1)] = (2));


return cljs.core.cst$kw$recur;
} else {
if((state_val_31959 === (7))){
var inst_31953 = (state_31958[(2)]);
var inst_31954 = console.log("CONTENT SCRIPT: leaving message loop");
var state_31958__$1 = (function (){var statearr_31967 = state_31958;
(statearr_31967[(9)] = inst_31954);

(statearr_31967[(10)] = inst_31953);

return statearr_31967;
})();
var statearr_31968_31978 = state_31958__$1;
(statearr_31968_31978[(2)] = null);

(statearr_31968_31978[(1)] = (3));


return cljs.core.cst$kw$recur;
} else {
return null;
}
}
}
}
}
}
}
});})(c__7992__auto__))
;
return ((function (switch__7885__auto__,c__7992__auto__){
return (function() {
var chromex_sample$content_script$core$run_message_loop_BANG__$_state_machine__7886__auto__ = null;
var chromex_sample$content_script$core$run_message_loop_BANG__$_state_machine__7886__auto____0 = (function (){
var statearr_31969 = [null,null,null,null,null,null,null,null,null,null,null];
(statearr_31969[(0)] = chromex_sample$content_script$core$run_message_loop_BANG__$_state_machine__7886__auto__);

(statearr_31969[(1)] = (1));

return statearr_31969;
});
var chromex_sample$content_script$core$run_message_loop_BANG__$_state_machine__7886__auto____1 = (function (state_31958){
while(true){
var ret_value__7887__auto__ = (function (){try{while(true){
var result__7888__auto__ = switch__7885__auto__(state_31958);
if(cljs.core.keyword_identical_QMARK_(result__7888__auto__,cljs.core.cst$kw$recur)){
continue;
} else {
return result__7888__auto__;
}
break;
}
}catch (e31970){if((e31970 instanceof Object)){
var ex__7889__auto__ = e31970;
var statearr_31971_31979 = state_31958;
(statearr_31971_31979[(5)] = ex__7889__auto__);


cljs.core.async.impl.ioc_helpers.process_exception(state_31958);

return cljs.core.cst$kw$recur;
} else {
throw e31970;

}
}})();
if(cljs.core.keyword_identical_QMARK_(ret_value__7887__auto__,cljs.core.cst$kw$recur)){
var G__31980 = state_31958;
state_31958 = G__31980;
continue;
} else {
return ret_value__7887__auto__;
}
break;
}
});
chromex_sample$content_script$core$run_message_loop_BANG__$_state_machine__7886__auto__ = function(state_31958){
switch(arguments.length){
case 0:
return chromex_sample$content_script$core$run_message_loop_BANG__$_state_machine__7886__auto____0.call(this);
case 1:
return chromex_sample$content_script$core$run_message_loop_BANG__$_state_machine__7886__auto____1.call(this,state_31958);
}
throw(new Error('Invalid arity: ' + arguments.length));
};
chromex_sample$content_script$core$run_message_loop_BANG__$_state_machine__7886__auto__.cljs$core$IFn$_invoke$arity$0 = chromex_sample$content_script$core$run_message_loop_BANG__$_state_machine__7886__auto____0;
chromex_sample$content_script$core$run_message_loop_BANG__$_state_machine__7886__auto__.cljs$core$IFn$_invoke$arity$1 = chromex_sample$content_script$core$run_message_loop_BANG__$_state_machine__7886__auto____1;
return chromex_sample$content_script$core$run_message_loop_BANG__$_state_machine__7886__auto__;
})()
;})(switch__7885__auto__,c__7992__auto__))
})();
var state__7994__auto__ = (function (){var statearr_31972 = (f__7993__auto__.cljs$core$IFn$_invoke$arity$0 ? f__7993__auto__.cljs$core$IFn$_invoke$arity$0() : f__7993__auto__.call(null));
(statearr_31972[(6)] = c__7992__auto__);

return statearr_31972;
})();
return cljs.core.async.impl.ioc_helpers.run_state_machine_wrapped(state__7994__auto__);
});})(c__7992__auto__))
);

return c__7992__auto__;
});
chromex_sample.content_script.core.do_page_analysis_BANG_ = (function chromex_sample$content_script$core$do_page_analysis_BANG_(background_port){
var script_elements = document.getElementsByTagName("script");
var script_count = script_elements.length;
var title = document.title;
var msg = ["CONTENT SCRIPT: document '",cljs.core.str.cljs$core$IFn$_invoke$arity$1(title),"' contains ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(script_count)," script tags."].join('');
console.log(msg);


return chromex.protocols.chrome_port.post_message_BANG_(background_port,msg);
});
chromex_sample.content_script.core.connect_to_background_page_BANG_ = (function chromex_sample$content_script$core$connect_to_background_page_BANG_(){
var background_port = chromex.ext.runtime.connect_STAR_(chromex.config.get_active_config(),cljs.core.cst$kw$omit,cljs.core.cst$kw$omit);
chromex.protocols.chrome_port.post_message_BANG_(background_port,"hello from CONTENT SCRIPT!");

chromex_sample.content_script.core.run_message_loop_BANG_(background_port);

return chromex_sample.content_script.core.do_page_analysis_BANG_(background_port);
});
chromex_sample.content_script.core.init_BANG_ = (function chromex_sample$content_script$core$init_BANG_(){
console.log("CONTENT SCRIPT: init");


return chromex_sample.content_script.core.connect_to_background_page_BANG_();
});
