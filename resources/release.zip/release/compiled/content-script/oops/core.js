// Compiled by ClojureScript 1.10.439 {:static-fns true, :optimize-constants true, :elide-asserts true}
goog.provide('oops.core');
goog.require('cljs.core');
goog.require('cljs.core.constants');
goog.require('cljs.spec.alpha');
goog.require('goog.object');
goog.require('oops.sdefs');
goog.require('oops.state');
goog.require('oops.config');
goog.require('oops.messages');
goog.require('oops.helpers');
goog.require('oops.schema');
oops.core.report_error_dynamically = (function oops$core$report_error_dynamically(msg,data){
if(oops.state.was_error_reported_QMARK_()){
return null;
} else {
oops.state.mark_error_reported_BANG_();

var G__31035 = oops.config.get_error_reporting();
if(cljs.core._EQ_.cljs$core$IFn$_invoke$arity$2(cljs.core.cst$kw$throw,G__31035)){
throw oops.state.prepare_error_from_call_site(msg,oops.helpers.wrap_data_in_enveloper_if_possible(oops.config.use_envelope_QMARK_(),data));
} else {
if(cljs.core._EQ_.cljs$core$IFn$_invoke$arity$2(cljs.core.cst$kw$console,G__31035)){
var G__31037 = (console["error"]);
var G__31038 = msg;
var G__31039 = oops.helpers.wrap_data_in_enveloper_if_possible(oops.config.use_envelope_QMARK_(),data);
var fexpr__31036 = oops.state.get_console_reporter();
return (fexpr__31036.cljs$core$IFn$_invoke$arity$3 ? fexpr__31036.cljs$core$IFn$_invoke$arity$3(G__31037,G__31038,G__31039) : fexpr__31036.call(null,G__31037,G__31038,G__31039));
} else {
if(cljs.core._EQ_.cljs$core$IFn$_invoke$arity$2(false,G__31035)){
return null;
} else {
throw (new Error(["No matching clause: ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(G__31035)].join('')));

}
}
}
}
});
oops.core.report_warning_dynamically = (function oops$core$report_warning_dynamically(msg,data){
var G__31040 = oops.config.get_warning_reporting();
if(cljs.core._EQ_.cljs$core$IFn$_invoke$arity$2(cljs.core.cst$kw$throw,G__31040)){
throw oops.state.prepare_error_from_call_site(msg,oops.helpers.wrap_data_in_enveloper_if_possible(oops.config.use_envelope_QMARK_(),data));
} else {
if(cljs.core._EQ_.cljs$core$IFn$_invoke$arity$2(cljs.core.cst$kw$console,G__31040)){
var G__31042 = (console["warn"]);
var G__31043 = msg;
var G__31044 = oops.helpers.wrap_data_in_enveloper_if_possible(oops.config.use_envelope_QMARK_(),data);
var fexpr__31041 = oops.state.get_console_reporter();
return (fexpr__31041.cljs$core$IFn$_invoke$arity$3 ? fexpr__31041.cljs$core$IFn$_invoke$arity$3(G__31042,G__31043,G__31044) : fexpr__31041.call(null,G__31042,G__31043,G__31044));
} else {
if(cljs.core._EQ_.cljs$core$IFn$_invoke$arity$2(false,G__31040)){
return null;
} else {
throw (new Error(["No matching clause: ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(G__31040)].join('')));

}
}
}
});
oops.core.report_if_needed_dynamically = (function oops$core$report_if_needed_dynamically(var_args){
var args__4647__auto__ = [];
var len__4641__auto___31051 = arguments.length;
var i__4642__auto___31052 = (0);
while(true){
if((i__4642__auto___31052 < len__4641__auto___31051)){
args__4647__auto__.push((arguments[i__4642__auto___31052]));

var G__31053 = (i__4642__auto___31052 + (1));
i__4642__auto___31052 = G__31053;
continue;
} else {
}
break;
}

var argseq__4648__auto__ = ((((1) < args__4647__auto__.length))?(new cljs.core.IndexedSeq(args__4647__auto__.slice((1)),(0),null)):null);
return oops.core.report_if_needed_dynamically.cljs$core$IFn$_invoke$arity$variadic((arguments[(0)]),argseq__4648__auto__);
});

oops.core.report_if_needed_dynamically.cljs$core$IFn$_invoke$arity$variadic = (function (msg_id,p__31047){
var vec__31048 = p__31047;
var info = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(vec__31048,(0),null);
return null;
});

oops.core.report_if_needed_dynamically.cljs$lang$maxFixedArity = (1);

/** @this {Function} */
oops.core.report_if_needed_dynamically.cljs$lang$applyTo = (function (seq31045){
var G__31046 = cljs.core.first(seq31045);
var seq31045__$1 = cljs.core.next(seq31045);
var self__4628__auto__ = this;
return self__4628__auto__.cljs$core$IFn$_invoke$arity$variadic(G__31046,seq31045__$1);
});

oops.core.validate_object_access_dynamically = (function oops$core$validate_object_access_dynamically(obj,mode,key,push_QMARK_,check_key_read_QMARK_,check_key_write_QMARK_){
if(((((cljs.core._EQ_.cljs$core$IFn$_invoke$arity$2(mode,(0))) && ((void 0 === obj))))?((cljs.core.contains_QMARK_(oops.config.get_suppress_reporting(),cljs.core.cst$kw$unexpected_DASH_object_DASH_value))?true:(function (){
(oops.core.report_if_needed_dynamically.cljs$core$IFn$_invoke$arity$2 ? oops.core.report_if_needed_dynamically.cljs$core$IFn$_invoke$arity$2(cljs.core.cst$kw$unexpected_DASH_object_DASH_value,new cljs.core.PersistentArrayMap(null, 3, [cljs.core.cst$kw$path,oops.state.get_key_path_str(),cljs.core.cst$kw$flavor,"undefined",cljs.core.cst$kw$obj,oops.state.get_target_object()], null)) : oops.core.report_if_needed_dynamically.call(null,cljs.core.cst$kw$unexpected_DASH_object_DASH_value,new cljs.core.PersistentArrayMap(null, 3, [cljs.core.cst$kw$path,oops.state.get_key_path_str(),cljs.core.cst$kw$flavor,"undefined",cljs.core.cst$kw$obj,oops.state.get_target_object()], null)));

return false;
})()
):((((cljs.core._EQ_.cljs$core$IFn$_invoke$arity$2(mode,(0))) && ((obj == null))))?((cljs.core.contains_QMARK_(oops.config.get_suppress_reporting(),cljs.core.cst$kw$unexpected_DASH_object_DASH_value))?true:(function (){
(oops.core.report_if_needed_dynamically.cljs$core$IFn$_invoke$arity$2 ? oops.core.report_if_needed_dynamically.cljs$core$IFn$_invoke$arity$2(cljs.core.cst$kw$unexpected_DASH_object_DASH_value,new cljs.core.PersistentArrayMap(null, 3, [cljs.core.cst$kw$path,oops.state.get_key_path_str(),cljs.core.cst$kw$flavor,"nil",cljs.core.cst$kw$obj,oops.state.get_target_object()], null)) : oops.core.report_if_needed_dynamically.call(null,cljs.core.cst$kw$unexpected_DASH_object_DASH_value,new cljs.core.PersistentArrayMap(null, 3, [cljs.core.cst$kw$path,oops.state.get_key_path_str(),cljs.core.cst$kw$flavor,"nil",cljs.core.cst$kw$obj,oops.state.get_target_object()], null)));

return false;
})()
):(cljs.core.truth_(goog.isBoolean(obj))?((cljs.core.contains_QMARK_(oops.config.get_suppress_reporting(),cljs.core.cst$kw$unexpected_DASH_object_DASH_value))?true:(function (){
(oops.core.report_if_needed_dynamically.cljs$core$IFn$_invoke$arity$2 ? oops.core.report_if_needed_dynamically.cljs$core$IFn$_invoke$arity$2(cljs.core.cst$kw$unexpected_DASH_object_DASH_value,new cljs.core.PersistentArrayMap(null, 3, [cljs.core.cst$kw$path,oops.state.get_key_path_str(),cljs.core.cst$kw$flavor,"boolean",cljs.core.cst$kw$obj,oops.state.get_target_object()], null)) : oops.core.report_if_needed_dynamically.call(null,cljs.core.cst$kw$unexpected_DASH_object_DASH_value,new cljs.core.PersistentArrayMap(null, 3, [cljs.core.cst$kw$path,oops.state.get_key_path_str(),cljs.core.cst$kw$flavor,"boolean",cljs.core.cst$kw$obj,oops.state.get_target_object()], null)));

return false;
})()
):(cljs.core.truth_(goog.isNumber(obj))?((cljs.core.contains_QMARK_(oops.config.get_suppress_reporting(),cljs.core.cst$kw$unexpected_DASH_object_DASH_value))?true:(function (){
(oops.core.report_if_needed_dynamically.cljs$core$IFn$_invoke$arity$2 ? oops.core.report_if_needed_dynamically.cljs$core$IFn$_invoke$arity$2(cljs.core.cst$kw$unexpected_DASH_object_DASH_value,new cljs.core.PersistentArrayMap(null, 3, [cljs.core.cst$kw$path,oops.state.get_key_path_str(),cljs.core.cst$kw$flavor,"number",cljs.core.cst$kw$obj,oops.state.get_target_object()], null)) : oops.core.report_if_needed_dynamically.call(null,cljs.core.cst$kw$unexpected_DASH_object_DASH_value,new cljs.core.PersistentArrayMap(null, 3, [cljs.core.cst$kw$path,oops.state.get_key_path_str(),cljs.core.cst$kw$flavor,"number",cljs.core.cst$kw$obj,oops.state.get_target_object()], null)));

return false;
})()
):(cljs.core.truth_(goog.isString(obj))?((cljs.core.contains_QMARK_(oops.config.get_suppress_reporting(),cljs.core.cst$kw$unexpected_DASH_object_DASH_value))?true:(function (){
(oops.core.report_if_needed_dynamically.cljs$core$IFn$_invoke$arity$2 ? oops.core.report_if_needed_dynamically.cljs$core$IFn$_invoke$arity$2(cljs.core.cst$kw$unexpected_DASH_object_DASH_value,new cljs.core.PersistentArrayMap(null, 3, [cljs.core.cst$kw$path,oops.state.get_key_path_str(),cljs.core.cst$kw$flavor,"string",cljs.core.cst$kw$obj,oops.state.get_target_object()], null)) : oops.core.report_if_needed_dynamically.call(null,cljs.core.cst$kw$unexpected_DASH_object_DASH_value,new cljs.core.PersistentArrayMap(null, 3, [cljs.core.cst$kw$path,oops.state.get_key_path_str(),cljs.core.cst$kw$flavor,"string",cljs.core.cst$kw$obj,oops.state.get_target_object()], null)));

return false;
})()
):((cljs.core.not(goog.isObject(obj)))?((cljs.core.contains_QMARK_(oops.config.get_suppress_reporting(),cljs.core.cst$kw$unexpected_DASH_object_DASH_value))?true:(function (){
(oops.core.report_if_needed_dynamically.cljs$core$IFn$_invoke$arity$2 ? oops.core.report_if_needed_dynamically.cljs$core$IFn$_invoke$arity$2(cljs.core.cst$kw$unexpected_DASH_object_DASH_value,new cljs.core.PersistentArrayMap(null, 3, [cljs.core.cst$kw$path,oops.state.get_key_path_str(),cljs.core.cst$kw$flavor,"non-object",cljs.core.cst$kw$obj,oops.state.get_target_object()], null)) : oops.core.report_if_needed_dynamically.call(null,cljs.core.cst$kw$unexpected_DASH_object_DASH_value,new cljs.core.PersistentArrayMap(null, 3, [cljs.core.cst$kw$path,oops.state.get_key_path_str(),cljs.core.cst$kw$flavor,"non-object",cljs.core.cst$kw$obj,oops.state.get_target_object()], null)));

return false;
})()
):(cljs.core.truth_(goog.isDateLike(obj))?((cljs.core.contains_QMARK_(oops.config.get_suppress_reporting(),cljs.core.cst$kw$unexpected_DASH_object_DASH_value))?true:(function (){
(oops.core.report_if_needed_dynamically.cljs$core$IFn$_invoke$arity$2 ? oops.core.report_if_needed_dynamically.cljs$core$IFn$_invoke$arity$2(cljs.core.cst$kw$unexpected_DASH_object_DASH_value,new cljs.core.PersistentArrayMap(null, 3, [cljs.core.cst$kw$path,oops.state.get_key_path_str(),cljs.core.cst$kw$flavor,"date-like",cljs.core.cst$kw$obj,oops.state.get_target_object()], null)) : oops.core.report_if_needed_dynamically.call(null,cljs.core.cst$kw$unexpected_DASH_object_DASH_value,new cljs.core.PersistentArrayMap(null, 3, [cljs.core.cst$kw$path,oops.state.get_key_path_str(),cljs.core.cst$kw$flavor,"date-like",cljs.core.cst$kw$obj,oops.state.get_target_object()], null)));

return true;
})()
):(cljs.core.truth_(oops.helpers.cljs_type_QMARK_(obj))?((cljs.core.contains_QMARK_(oops.config.get_suppress_reporting(),cljs.core.cst$kw$unexpected_DASH_object_DASH_value))?true:(function (){
(oops.core.report_if_needed_dynamically.cljs$core$IFn$_invoke$arity$2 ? oops.core.report_if_needed_dynamically.cljs$core$IFn$_invoke$arity$2(cljs.core.cst$kw$unexpected_DASH_object_DASH_value,new cljs.core.PersistentArrayMap(null, 3, [cljs.core.cst$kw$path,oops.state.get_key_path_str(),cljs.core.cst$kw$flavor,"cljs type",cljs.core.cst$kw$obj,oops.state.get_target_object()], null)) : oops.core.report_if_needed_dynamically.call(null,cljs.core.cst$kw$unexpected_DASH_object_DASH_value,new cljs.core.PersistentArrayMap(null, 3, [cljs.core.cst$kw$path,oops.state.get_key_path_str(),cljs.core.cst$kw$flavor,"cljs type",cljs.core.cst$kw$obj,oops.state.get_target_object()], null)));

return true;
})()
):(cljs.core.truth_(oops.helpers.cljs_instance_QMARK_(obj))?((cljs.core.contains_QMARK_(oops.config.get_suppress_reporting(),cljs.core.cst$kw$unexpected_DASH_object_DASH_value))?true:(function (){
(oops.core.report_if_needed_dynamically.cljs$core$IFn$_invoke$arity$2 ? oops.core.report_if_needed_dynamically.cljs$core$IFn$_invoke$arity$2(cljs.core.cst$kw$unexpected_DASH_object_DASH_value,new cljs.core.PersistentArrayMap(null, 3, [cljs.core.cst$kw$path,oops.state.get_key_path_str(),cljs.core.cst$kw$flavor,"cljs instance",cljs.core.cst$kw$obj,oops.state.get_target_object()], null)) : oops.core.report_if_needed_dynamically.call(null,cljs.core.cst$kw$unexpected_DASH_object_DASH_value,new cljs.core.PersistentArrayMap(null, 3, [cljs.core.cst$kw$path,oops.state.get_key_path_str(),cljs.core.cst$kw$flavor,"cljs instance",cljs.core.cst$kw$obj,oops.state.get_target_object()], null)));

return true;
})()
):true
)))))))))){
if(cljs.core.truth_(push_QMARK_)){
oops.state.add_key_to_current_path_BANG_(key);

oops.state.set_last_access_modifier_BANG_(mode);
} else {
}

var and__4036__auto__ = (cljs.core.truth_(check_key_read_QMARK_)?((((cljs.core._EQ_.cljs$core$IFn$_invoke$arity$2(mode,(0))) && (cljs.core.not(goog.object.containsKey(obj,key)))))?(oops.core.report_if_needed_dynamically.cljs$core$IFn$_invoke$arity$2 ? oops.core.report_if_needed_dynamically.cljs$core$IFn$_invoke$arity$2(cljs.core.cst$kw$missing_DASH_object_DASH_key,new cljs.core.PersistentArrayMap(null, 3, [cljs.core.cst$kw$path,oops.state.get_key_path_str(),cljs.core.cst$kw$key,key,cljs.core.cst$kw$obj,oops.state.get_target_object()], null)) : oops.core.report_if_needed_dynamically.call(null,cljs.core.cst$kw$missing_DASH_object_DASH_key,new cljs.core.PersistentArrayMap(null, 3, [cljs.core.cst$kw$path,oops.state.get_key_path_str(),cljs.core.cst$kw$key,key,cljs.core.cst$kw$obj,oops.state.get_target_object()], null))):true):true);
if(cljs.core.truth_(and__4036__auto__)){
if(cljs.core.truth_(check_key_write_QMARK_)){
var temp__5459__auto__ = oops.helpers.get_property_descriptor(obj,key);
if((temp__5459__auto__ == null)){
if(cljs.core.truth_(oops.helpers.is_object_frozen_QMARK_(obj))){
return (oops.core.report_if_needed_dynamically.cljs$core$IFn$_invoke$arity$2 ? oops.core.report_if_needed_dynamically.cljs$core$IFn$_invoke$arity$2(cljs.core.cst$kw$object_DASH_is_DASH_frozen,new cljs.core.PersistentArrayMap(null, 3, [cljs.core.cst$kw$path,oops.state.get_key_path_str(),cljs.core.cst$kw$key,key,cljs.core.cst$kw$obj,oops.state.get_target_object()], null)) : oops.core.report_if_needed_dynamically.call(null,cljs.core.cst$kw$object_DASH_is_DASH_frozen,new cljs.core.PersistentArrayMap(null, 3, [cljs.core.cst$kw$path,oops.state.get_key_path_str(),cljs.core.cst$kw$key,key,cljs.core.cst$kw$obj,oops.state.get_target_object()], null)));
} else {
if(cljs.core.truth_(oops.helpers.is_object_sealed_QMARK_(obj))){
return (oops.core.report_if_needed_dynamically.cljs$core$IFn$_invoke$arity$2 ? oops.core.report_if_needed_dynamically.cljs$core$IFn$_invoke$arity$2(cljs.core.cst$kw$object_DASH_is_DASH_sealed,new cljs.core.PersistentArrayMap(null, 3, [cljs.core.cst$kw$path,oops.state.get_key_path_str(),cljs.core.cst$kw$key,key,cljs.core.cst$kw$obj,oops.state.get_target_object()], null)) : oops.core.report_if_needed_dynamically.call(null,cljs.core.cst$kw$object_DASH_is_DASH_sealed,new cljs.core.PersistentArrayMap(null, 3, [cljs.core.cst$kw$path,oops.state.get_key_path_str(),cljs.core.cst$kw$key,key,cljs.core.cst$kw$obj,oops.state.get_target_object()], null)));
} else {
return true;

}
}
} else {
var descriptor_31054 = temp__5459__auto__;
var temp__5459__auto____$1 = oops.helpers.determine_property_non_writable_reason(descriptor_31054);
if((temp__5459__auto____$1 == null)){
return true;
} else {
var reason_31055 = temp__5459__auto____$1;
return (oops.core.report_if_needed_dynamically.cljs$core$IFn$_invoke$arity$2 ? oops.core.report_if_needed_dynamically.cljs$core$IFn$_invoke$arity$2(cljs.core.cst$kw$object_DASH_key_DASH_not_DASH_writable,new cljs.core.PersistentArrayMap(null, 5, [cljs.core.cst$kw$path,oops.state.get_key_path_str(),cljs.core.cst$kw$key,key,cljs.core.cst$kw$frozen_QMARK_,oops.helpers.is_object_frozen_QMARK_(obj),cljs.core.cst$kw$reason,reason_31055,cljs.core.cst$kw$obj,oops.state.get_target_object()], null)) : oops.core.report_if_needed_dynamically.call(null,cljs.core.cst$kw$object_DASH_key_DASH_not_DASH_writable,new cljs.core.PersistentArrayMap(null, 5, [cljs.core.cst$kw$path,oops.state.get_key_path_str(),cljs.core.cst$kw$key,key,cljs.core.cst$kw$frozen_QMARK_,oops.helpers.is_object_frozen_QMARK_(obj),cljs.core.cst$kw$reason,reason_31055,cljs.core.cst$kw$obj,oops.state.get_target_object()], null)));
}
}
} else {
return true;
}
} else {
return and__4036__auto__;
}
} else {
return null;
}
});
oops.core.validate_fn_call_dynamically = (function oops$core$validate_fn_call_dynamically(fn,mode){
if(((cljs.core._EQ_.cljs$core$IFn$_invoke$arity$2(mode,(1))) && ((fn == null)))){
return true;
} else {
if(cljs.core.truth_(goog.isFunction(fn))){
return true;
} else {
return (oops.core.report_if_needed_dynamically.cljs$core$IFn$_invoke$arity$2 ? oops.core.report_if_needed_dynamically.cljs$core$IFn$_invoke$arity$2(cljs.core.cst$kw$expected_DASH_function_DASH_value,new cljs.core.PersistentArrayMap(null, 4, [cljs.core.cst$kw$path,oops.state.get_key_path_str(),cljs.core.cst$kw$soft_QMARK_,cljs.core._EQ_.cljs$core$IFn$_invoke$arity$2(mode,(1)),cljs.core.cst$kw$fn,fn,cljs.core.cst$kw$obj,oops.state.get_target_object()], null)) : oops.core.report_if_needed_dynamically.call(null,cljs.core.cst$kw$expected_DASH_function_DASH_value,new cljs.core.PersistentArrayMap(null, 4, [cljs.core.cst$kw$path,oops.state.get_key_path_str(),cljs.core.cst$kw$soft_QMARK_,cljs.core._EQ_.cljs$core$IFn$_invoke$arity$2(mode,(1)),cljs.core.cst$kw$fn,fn,cljs.core.cst$kw$obj,oops.state.get_target_object()], null)));

}
}
});
oops.core.punch_key_dynamically_BANG_ = (function oops$core$punch_key_dynamically_BANG_(obj,key){
var child_factory_31057 = oops.config.get_child_factory();
var child_factory_31057__$1 = (function (){var G__31058 = child_factory_31057;
var G__31058__$1 = (((G__31058 instanceof cljs.core.Keyword))?G__31058.fqn:null);
switch (G__31058__$1) {
case "js-obj":
return ((function (G__31058,G__31058__$1,child_factory_31057){
return (function (){
return {};
});
;})(G__31058,G__31058__$1,child_factory_31057))

break;
case "js-array":
return ((function (G__31058,G__31058__$1,child_factory_31057){
return (function (){
return [];
});
;})(G__31058,G__31058__$1,child_factory_31057))

break;
default:
return child_factory_31057;

}
})();

var child_obj_31056 = (child_factory_31057__$1.cljs$core$IFn$_invoke$arity$2 ? child_factory_31057__$1.cljs$core$IFn$_invoke$arity$2(obj,key) : child_factory_31057__$1.call(null,obj,key));
(obj[key] = child_obj_31056);

return child_obj_31056;
});
oops.core.build_path_dynamically = (function oops$core$build_path_dynamically(selector){
if(((typeof selector === 'string') || ((selector instanceof cljs.core.Keyword)))){
var selector_path_31062 = [];
oops.schema.prepare_simple_path_BANG_(selector,selector_path_31062);

return selector_path_31062;
} else {
var selector_path_31063 = [];
oops.schema.prepare_path_BANG_(selector,selector_path_31063);

return selector_path_31063;

}
});
oops.core.check_path_dynamically = (function oops$core$check_path_dynamically(path,op){
var temp__5461__auto__ = oops.schema.check_dynamic_path_BANG_(path,op);
if((temp__5461__auto__ == null)){
return null;
} else {
var issue_31064 = temp__5461__auto__;
return cljs.core.apply.cljs$core$IFn$_invoke$arity$2(oops.core.report_if_needed_dynamically,issue_31064);
}
});
oops.core.get_key_dynamically = (function oops$core$get_key_dynamically(obj,key,mode){
return (obj[key]);
});
oops.core.set_key_dynamically = (function oops$core$set_key_dynamically(obj,key,val,mode){
return (obj[key] = val);
});
oops.core.get_selector_dynamically = (function oops$core$get_selector_dynamically(obj,selector){
var path_31066 = (function (){var path_31065 = oops.core.build_path_dynamically(selector);

return path_31065;
})();
var len_31067 = path_31066.length;
var i_31068 = (0);
var obj_31069 = obj;
while(true){
if((i_31068 < len_31067)){
var mode_31070 = (path_31066[i_31068]);
var key_31071 = (path_31066[(i_31068 + (1))]);
var next_obj_31072 = oops.core.get_key_dynamically(obj_31069,key_31071,mode_31070);
var G__31073 = mode_31070;
switch (G__31073) {
case (0):
var G__31075 = (i_31068 + (2));
var G__31076 = next_obj_31072;
i_31068 = G__31075;
obj_31069 = G__31076;
continue;

break;
case (1):
if((!((next_obj_31072 == null)))){
var G__31077 = (i_31068 + (2));
var G__31078 = next_obj_31072;
i_31068 = G__31077;
obj_31069 = G__31078;
continue;
} else {
return null;
}

break;
case (2):
if((!((next_obj_31072 == null)))){
var G__31079 = (i_31068 + (2));
var G__31080 = next_obj_31072;
i_31068 = G__31079;
obj_31069 = G__31080;
continue;
} else {
var G__31081 = (i_31068 + (2));
var G__31082 = (oops.core.punch_key_dynamically_BANG_.cljs$core$IFn$_invoke$arity$2 ? oops.core.punch_key_dynamically_BANG_.cljs$core$IFn$_invoke$arity$2(obj_31069,key_31071) : oops.core.punch_key_dynamically_BANG_.call(null,obj_31069,key_31071));
i_31068 = G__31081;
obj_31069 = G__31082;
continue;
}

break;
default:
throw (new Error(["No matching clause: ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(G__31073)].join('')));

}
} else {
return obj_31069;
}
break;
}
});
oops.core.get_selector_call_info_dynamically = (function oops$core$get_selector_call_info_dynamically(obj,selector){
var path_31084 = (function (){var path_31083 = oops.core.build_path_dynamically(selector);

return path_31083;
})();
var len_31085 = path_31084.length;
if((len_31085 < (4))){
return [obj,(function (){var path_31087 = path_31084;
var len_31088 = path_31087.length;
var i_31089 = (0);
var obj_31090 = obj;
while(true){
if((i_31089 < len_31088)){
var mode_31091 = (path_31087[i_31089]);
var key_31092 = (path_31087[(i_31089 + (1))]);
var next_obj_31093 = oops.core.get_key_dynamically(obj_31090,key_31092,mode_31091);
var G__31108 = mode_31091;
switch (G__31108) {
case (0):
var G__31112 = (i_31089 + (2));
var G__31113 = next_obj_31093;
i_31089 = G__31112;
obj_31090 = G__31113;
continue;

break;
case (1):
if((!((next_obj_31093 == null)))){
var G__31114 = (i_31089 + (2));
var G__31115 = next_obj_31093;
i_31089 = G__31114;
obj_31090 = G__31115;
continue;
} else {
return null;
}

break;
case (2):
if((!((next_obj_31093 == null)))){
var G__31116 = (i_31089 + (2));
var G__31117 = next_obj_31093;
i_31089 = G__31116;
obj_31090 = G__31117;
continue;
} else {
var G__31118 = (i_31089 + (2));
var G__31119 = (oops.core.punch_key_dynamically_BANG_.cljs$core$IFn$_invoke$arity$2 ? oops.core.punch_key_dynamically_BANG_.cljs$core$IFn$_invoke$arity$2(obj_31090,key_31092) : oops.core.punch_key_dynamically_BANG_.call(null,obj_31090,key_31092));
i_31089 = G__31118;
obj_31090 = G__31119;
continue;
}

break;
default:
throw (new Error(["No matching clause: ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(G__31108)].join('')));

}
} else {
return obj_31090;
}
break;
}
})()];
} else {
var target_obj_31086 = (function (){var path_31094 = path_31084.slice((0),(len_31085 - (2)));
var len_31095 = path_31094.length;
var i_31096 = (0);
var obj_31097 = obj;
while(true){
if((i_31096 < len_31095)){
var mode_31098 = (path_31094[i_31096]);
var key_31099 = (path_31094[(i_31096 + (1))]);
var next_obj_31100 = oops.core.get_key_dynamically(obj_31097,key_31099,mode_31098);
var G__31109 = mode_31098;
switch (G__31109) {
case (0):
var G__31121 = (i_31096 + (2));
var G__31122 = next_obj_31100;
i_31096 = G__31121;
obj_31097 = G__31122;
continue;

break;
case (1):
if((!((next_obj_31100 == null)))){
var G__31123 = (i_31096 + (2));
var G__31124 = next_obj_31100;
i_31096 = G__31123;
obj_31097 = G__31124;
continue;
} else {
return null;
}

break;
case (2):
if((!((next_obj_31100 == null)))){
var G__31125 = (i_31096 + (2));
var G__31126 = next_obj_31100;
i_31096 = G__31125;
obj_31097 = G__31126;
continue;
} else {
var G__31127 = (i_31096 + (2));
var G__31128 = (oops.core.punch_key_dynamically_BANG_.cljs$core$IFn$_invoke$arity$2 ? oops.core.punch_key_dynamically_BANG_.cljs$core$IFn$_invoke$arity$2(obj_31097,key_31099) : oops.core.punch_key_dynamically_BANG_.call(null,obj_31097,key_31099));
i_31096 = G__31127;
obj_31097 = G__31128;
continue;
}

break;
default:
throw (new Error(["No matching clause: ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(G__31109)].join('')));

}
} else {
return obj_31097;
}
break;
}
})();
return [target_obj_31086,(function (){var path_31101 = [(path_31084[(len_31085 - (2))]),(path_31084[(len_31085 - (1))])];
var len_31102 = path_31101.length;
var i_31103 = (0);
var obj_31104 = target_obj_31086;
while(true){
if((i_31103 < len_31102)){
var mode_31105 = (path_31101[i_31103]);
var key_31106 = (path_31101[(i_31103 + (1))]);
var next_obj_31107 = oops.core.get_key_dynamically(obj_31104,key_31106,mode_31105);
var G__31110 = mode_31105;
switch (G__31110) {
case (0):
var G__31130 = (i_31103 + (2));
var G__31131 = next_obj_31107;
i_31103 = G__31130;
obj_31104 = G__31131;
continue;

break;
case (1):
if((!((next_obj_31107 == null)))){
var G__31132 = (i_31103 + (2));
var G__31133 = next_obj_31107;
i_31103 = G__31132;
obj_31104 = G__31133;
continue;
} else {
return null;
}

break;
case (2):
if((!((next_obj_31107 == null)))){
var G__31134 = (i_31103 + (2));
var G__31135 = next_obj_31107;
i_31103 = G__31134;
obj_31104 = G__31135;
continue;
} else {
var G__31136 = (i_31103 + (2));
var G__31137 = (oops.core.punch_key_dynamically_BANG_.cljs$core$IFn$_invoke$arity$2 ? oops.core.punch_key_dynamically_BANG_.cljs$core$IFn$_invoke$arity$2(obj_31104,key_31106) : oops.core.punch_key_dynamically_BANG_.call(null,obj_31104,key_31106));
i_31103 = G__31136;
obj_31104 = G__31137;
continue;
}

break;
default:
throw (new Error(["No matching clause: ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(G__31110)].join('')));

}
} else {
return obj_31104;
}
break;
}
})()];
}
});
oops.core.set_selector_dynamically = (function oops$core$set_selector_dynamically(obj,selector,val){
var path_31139 = (function (){var path_31138 = oops.core.build_path_dynamically(selector);

return path_31138;
})();
var len_31142 = path_31139.length;
var parent_obj_path_31143 = path_31139.slice((0),(len_31142 - (2)));
var key_31140 = (path_31139[(len_31142 - (1))]);
var mode_31141 = (path_31139[(len_31142 - (2))]);
var parent_obj_31144 = (function (){var path_31145 = parent_obj_path_31143;
var len_31146 = path_31145.length;
var i_31147 = (0);
var obj_31148 = obj;
while(true){
if((i_31147 < len_31146)){
var mode_31149 = (path_31145[i_31147]);
var key_31150 = (path_31145[(i_31147 + (1))]);
var next_obj_31151 = oops.core.get_key_dynamically(obj_31148,key_31150,mode_31149);
var G__31152 = mode_31149;
switch (G__31152) {
case (0):
var G__31154 = (i_31147 + (2));
var G__31155 = next_obj_31151;
i_31147 = G__31154;
obj_31148 = G__31155;
continue;

break;
case (1):
if((!((next_obj_31151 == null)))){
var G__31156 = (i_31147 + (2));
var G__31157 = next_obj_31151;
i_31147 = G__31156;
obj_31148 = G__31157;
continue;
} else {
return null;
}

break;
case (2):
if((!((next_obj_31151 == null)))){
var G__31158 = (i_31147 + (2));
var G__31159 = next_obj_31151;
i_31147 = G__31158;
obj_31148 = G__31159;
continue;
} else {
var G__31160 = (i_31147 + (2));
var G__31161 = (oops.core.punch_key_dynamically_BANG_.cljs$core$IFn$_invoke$arity$2 ? oops.core.punch_key_dynamically_BANG_.cljs$core$IFn$_invoke$arity$2(obj_31148,key_31150) : oops.core.punch_key_dynamically_BANG_.call(null,obj_31148,key_31150));
i_31147 = G__31160;
obj_31148 = G__31161;
continue;
}

break;
default:
throw (new Error(["No matching clause: ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(G__31152)].join('')));

}
} else {
return obj_31148;
}
break;
}
})();
return oops.core.set_key_dynamically(parent_obj_31144,key_31140,val,mode_31141);
});
