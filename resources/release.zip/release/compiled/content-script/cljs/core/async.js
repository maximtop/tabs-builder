// Compiled by ClojureScript 1.10.439 {:static-fns true, :optimize-constants true, :elide-asserts true}
goog.provide('cljs.core.async');
goog.require('cljs.core');
goog.require('cljs.core.constants');
goog.require('cljs.core.async.impl.protocols');
goog.require('cljs.core.async.impl.channels');
goog.require('cljs.core.async.impl.buffers');
goog.require('cljs.core.async.impl.timers');
goog.require('cljs.core.async.impl.dispatch');
goog.require('cljs.core.async.impl.ioc_helpers');
cljs.core.async.fn_handler = (function cljs$core$async$fn_handler(var_args){
var G__28207 = arguments.length;
switch (G__28207) {
case 1:
return cljs.core.async.fn_handler.cljs$core$IFn$_invoke$arity$1((arguments[(0)]));

break;
case 2:
return cljs.core.async.fn_handler.cljs$core$IFn$_invoke$arity$2((arguments[(0)]),(arguments[(1)]));

break;
default:
throw (new Error(["Invalid arity: ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(arguments.length)].join('')));

}
});

cljs.core.async.fn_handler.cljs$core$IFn$_invoke$arity$1 = (function (f){
return cljs.core.async.fn_handler.cljs$core$IFn$_invoke$arity$2(f,true);
});

cljs.core.async.fn_handler.cljs$core$IFn$_invoke$arity$2 = (function (f,blockable){
if((typeof cljs !== 'undefined') && (typeof cljs.core !== 'undefined') && (typeof cljs.core.async !== 'undefined') && (typeof cljs.core.async.t_cljs$core$async28208 !== 'undefined')){
} else {

/**
* @constructor
 * @implements {cljs.core.async.impl.protocols.Handler}
 * @implements {cljs.core.IMeta}
 * @implements {cljs.core.IWithMeta}
*/
cljs.core.async.t_cljs$core$async28208 = (function (f,blockable,meta28209){
this.f = f;
this.blockable = blockable;
this.meta28209 = meta28209;
this.cljs$lang$protocol_mask$partition0$ = 393216;
this.cljs$lang$protocol_mask$partition1$ = 0;
});
cljs.core.async.t_cljs$core$async28208.prototype.cljs$core$IWithMeta$_with_meta$arity$2 = (function (_28210,meta28209__$1){
var self__ = this;
var _28210__$1 = this;
return (new cljs.core.async.t_cljs$core$async28208(self__.f,self__.blockable,meta28209__$1));
});

cljs.core.async.t_cljs$core$async28208.prototype.cljs$core$IMeta$_meta$arity$1 = (function (_28210){
var self__ = this;
var _28210__$1 = this;
return self__.meta28209;
});

cljs.core.async.t_cljs$core$async28208.prototype.cljs$core$async$impl$protocols$Handler$ = cljs.core.PROTOCOL_SENTINEL;

cljs.core.async.t_cljs$core$async28208.prototype.cljs$core$async$impl$protocols$Handler$active_QMARK_$arity$1 = (function (_){
var self__ = this;
var ___$1 = this;
return true;
});

cljs.core.async.t_cljs$core$async28208.prototype.cljs$core$async$impl$protocols$Handler$blockable_QMARK_$arity$1 = (function (_){
var self__ = this;
var ___$1 = this;
return self__.blockable;
});

cljs.core.async.t_cljs$core$async28208.prototype.cljs$core$async$impl$protocols$Handler$commit$arity$1 = (function (_){
var self__ = this;
var ___$1 = this;
return self__.f;
});

cljs.core.async.t_cljs$core$async28208.getBasis = (function (){
return new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [cljs.core.cst$sym$f,cljs.core.cst$sym$blockable,cljs.core.cst$sym$meta28209], null);
});

cljs.core.async.t_cljs$core$async28208.cljs$lang$type = true;

cljs.core.async.t_cljs$core$async28208.cljs$lang$ctorStr = "cljs.core.async/t_cljs$core$async28208";

cljs.core.async.t_cljs$core$async28208.cljs$lang$ctorPrWriter = (function (this__4290__auto__,writer__4291__auto__,opt__4292__auto__){
return cljs.core._write(writer__4291__auto__,"cljs.core.async/t_cljs$core$async28208");
});

/**
 * Positional factory function for cljs.core.async/t_cljs$core$async28208.
 */
cljs.core.async.__GT_t_cljs$core$async28208 = (function cljs$core$async$__GT_t_cljs$core$async28208(f__$1,blockable__$1,meta28209){
return (new cljs.core.async.t_cljs$core$async28208(f__$1,blockable__$1,meta28209));
});

}

return (new cljs.core.async.t_cljs$core$async28208(f,blockable,cljs.core.PersistentArrayMap.EMPTY));
});

cljs.core.async.fn_handler.cljs$lang$maxFixedArity = 2;

/**
 * Returns a fixed buffer of size n. When full, puts will block/park.
 */
cljs.core.async.buffer = (function cljs$core$async$buffer(n){
return cljs.core.async.impl.buffers.fixed_buffer(n);
});
/**
 * Returns a buffer of size n. When full, puts will complete but
 *   val will be dropped (no transfer).
 */
cljs.core.async.dropping_buffer = (function cljs$core$async$dropping_buffer(n){
return cljs.core.async.impl.buffers.dropping_buffer(n);
});
/**
 * Returns a buffer of size n. When full, puts will complete, and be
 *   buffered, but oldest elements in buffer will be dropped (not
 *   transferred).
 */
cljs.core.async.sliding_buffer = (function cljs$core$async$sliding_buffer(n){
return cljs.core.async.impl.buffers.sliding_buffer(n);
});
/**
 * Returns true if a channel created with buff will never block. That is to say,
 * puts into this buffer will never cause the buffer to be full. 
 */
cljs.core.async.unblocking_buffer_QMARK_ = (function cljs$core$async$unblocking_buffer_QMARK_(buff){
if((!((buff == null)))){
if(((false) || ((cljs.core.PROTOCOL_SENTINEL === buff.cljs$core$async$impl$protocols$UnblockingBuffer$)))){
return true;
} else {
if((!buff.cljs$lang$protocol_mask$partition$)){
return cljs.core.native_satisfies_QMARK_(cljs.core.async.impl.protocols.UnblockingBuffer,buff);
} else {
return false;
}
}
} else {
return cljs.core.native_satisfies_QMARK_(cljs.core.async.impl.protocols.UnblockingBuffer,buff);
}
});
/**
 * Creates a channel with an optional buffer, an optional transducer (like (map f),
 *   (filter p) etc or a composition thereof), and an optional exception handler.
 *   If buf-or-n is a number, will create and use a fixed buffer of that size. If a
 *   transducer is supplied a buffer must be specified. ex-handler must be a
 *   fn of one argument - if an exception occurs during transformation it will be called
 *   with the thrown value as an argument, and any non-nil return value will be placed
 *   in the channel.
 */
cljs.core.async.chan = (function cljs$core$async$chan(var_args){
var G__28214 = arguments.length;
switch (G__28214) {
case 0:
return cljs.core.async.chan.cljs$core$IFn$_invoke$arity$0();

break;
case 1:
return cljs.core.async.chan.cljs$core$IFn$_invoke$arity$1((arguments[(0)]));

break;
case 2:
return cljs.core.async.chan.cljs$core$IFn$_invoke$arity$2((arguments[(0)]),(arguments[(1)]));

break;
case 3:
return cljs.core.async.chan.cljs$core$IFn$_invoke$arity$3((arguments[(0)]),(arguments[(1)]),(arguments[(2)]));

break;
default:
throw (new Error(["Invalid arity: ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(arguments.length)].join('')));

}
});

cljs.core.async.chan.cljs$core$IFn$_invoke$arity$0 = (function (){
return cljs.core.async.chan.cljs$core$IFn$_invoke$arity$1(null);
});

cljs.core.async.chan.cljs$core$IFn$_invoke$arity$1 = (function (buf_or_n){
return cljs.core.async.chan.cljs$core$IFn$_invoke$arity$3(buf_or_n,null,null);
});

cljs.core.async.chan.cljs$core$IFn$_invoke$arity$2 = (function (buf_or_n,xform){
return cljs.core.async.chan.cljs$core$IFn$_invoke$arity$3(buf_or_n,xform,null);
});

cljs.core.async.chan.cljs$core$IFn$_invoke$arity$3 = (function (buf_or_n,xform,ex_handler){
var buf_or_n__$1 = ((cljs.core._EQ_.cljs$core$IFn$_invoke$arity$2(buf_or_n,(0)))?null:buf_or_n);
if(cljs.core.truth_(xform)){
} else {
}

return cljs.core.async.impl.channels.chan.cljs$core$IFn$_invoke$arity$3(((typeof buf_or_n__$1 === 'number')?cljs.core.async.buffer(buf_or_n__$1):buf_or_n__$1),xform,ex_handler);
});

cljs.core.async.chan.cljs$lang$maxFixedArity = 3;

/**
 * Creates a promise channel with an optional transducer, and an optional
 *   exception-handler. A promise channel can take exactly one value that consumers
 *   will receive. Once full, puts complete but val is dropped (no transfer).
 *   Consumers will block until either a value is placed in the channel or the
 *   channel is closed. See chan for the semantics of xform and ex-handler.
 */
cljs.core.async.promise_chan = (function cljs$core$async$promise_chan(var_args){
var G__28217 = arguments.length;
switch (G__28217) {
case 0:
return cljs.core.async.promise_chan.cljs$core$IFn$_invoke$arity$0();

break;
case 1:
return cljs.core.async.promise_chan.cljs$core$IFn$_invoke$arity$1((arguments[(0)]));

break;
case 2:
return cljs.core.async.promise_chan.cljs$core$IFn$_invoke$arity$2((arguments[(0)]),(arguments[(1)]));

break;
default:
throw (new Error(["Invalid arity: ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(arguments.length)].join('')));

}
});

cljs.core.async.promise_chan.cljs$core$IFn$_invoke$arity$0 = (function (){
return cljs.core.async.promise_chan.cljs$core$IFn$_invoke$arity$1(null);
});

cljs.core.async.promise_chan.cljs$core$IFn$_invoke$arity$1 = (function (xform){
return cljs.core.async.promise_chan.cljs$core$IFn$_invoke$arity$2(xform,null);
});

cljs.core.async.promise_chan.cljs$core$IFn$_invoke$arity$2 = (function (xform,ex_handler){
return cljs.core.async.chan.cljs$core$IFn$_invoke$arity$3(cljs.core.async.impl.buffers.promise_buffer(),xform,ex_handler);
});

cljs.core.async.promise_chan.cljs$lang$maxFixedArity = 2;

/**
 * Returns a channel that will close after msecs
 */
cljs.core.async.timeout = (function cljs$core$async$timeout(msecs){
return cljs.core.async.impl.timers.timeout(msecs);
});
/**
 * takes a val from port. Must be called inside a (go ...) block. Will
 *   return nil if closed. Will park if nothing is available.
 *   Returns true unless port is already closed
 */
cljs.core.async._LT__BANG_ = (function cljs$core$async$_LT__BANG_(port){
throw (new Error("<! used not in (go ...) block"));
});
/**
 * Asynchronously takes a val from port, passing to fn1. Will pass nil
 * if closed. If on-caller? (default true) is true, and value is
 * immediately available, will call fn1 on calling thread.
 * Returns nil.
 */
cljs.core.async.take_BANG_ = (function cljs$core$async$take_BANG_(var_args){
var G__28220 = arguments.length;
switch (G__28220) {
case 2:
return cljs.core.async.take_BANG_.cljs$core$IFn$_invoke$arity$2((arguments[(0)]),(arguments[(1)]));

break;
case 3:
return cljs.core.async.take_BANG_.cljs$core$IFn$_invoke$arity$3((arguments[(0)]),(arguments[(1)]),(arguments[(2)]));

break;
default:
throw (new Error(["Invalid arity: ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(arguments.length)].join('')));

}
});

cljs.core.async.take_BANG_.cljs$core$IFn$_invoke$arity$2 = (function (port,fn1){
return cljs.core.async.take_BANG_.cljs$core$IFn$_invoke$arity$3(port,fn1,true);
});

cljs.core.async.take_BANG_.cljs$core$IFn$_invoke$arity$3 = (function (port,fn1,on_caller_QMARK_){
var ret = cljs.core.async.impl.protocols.take_BANG_(port,cljs.core.async.fn_handler.cljs$core$IFn$_invoke$arity$1(fn1));
if(cljs.core.truth_(ret)){
var val_28222 = cljs.core.deref(ret);
if(cljs.core.truth_(on_caller_QMARK_)){
(fn1.cljs$core$IFn$_invoke$arity$1 ? fn1.cljs$core$IFn$_invoke$arity$1(val_28222) : fn1.call(null,val_28222));
} else {
cljs.core.async.impl.dispatch.run(((function (val_28222,ret){
return (function (){
return (fn1.cljs$core$IFn$_invoke$arity$1 ? fn1.cljs$core$IFn$_invoke$arity$1(val_28222) : fn1.call(null,val_28222));
});})(val_28222,ret))
);
}
} else {
}

return null;
});

cljs.core.async.take_BANG_.cljs$lang$maxFixedArity = 3;

cljs.core.async.nop = (function cljs$core$async$nop(_){
return null;
});
cljs.core.async.fhnop = cljs.core.async.fn_handler.cljs$core$IFn$_invoke$arity$1(cljs.core.async.nop);
/**
 * puts a val into port. nil values are not allowed. Must be called
 *   inside a (go ...) block. Will park if no buffer space is available.
 *   Returns true unless port is already closed.
 */
cljs.core.async._GT__BANG_ = (function cljs$core$async$_GT__BANG_(port,val){
throw (new Error(">! used not in (go ...) block"));
});
/**
 * Asynchronously puts a val into port, calling fn1 (if supplied) when
 * complete. nil values are not allowed. Will throw if closed. If
 * on-caller? (default true) is true, and the put is immediately
 * accepted, will call fn1 on calling thread.  Returns nil.
 */
cljs.core.async.put_BANG_ = (function cljs$core$async$put_BANG_(var_args){
var G__28224 = arguments.length;
switch (G__28224) {
case 2:
return cljs.core.async.put_BANG_.cljs$core$IFn$_invoke$arity$2((arguments[(0)]),(arguments[(1)]));

break;
case 3:
return cljs.core.async.put_BANG_.cljs$core$IFn$_invoke$arity$3((arguments[(0)]),(arguments[(1)]),(arguments[(2)]));

break;
case 4:
return cljs.core.async.put_BANG_.cljs$core$IFn$_invoke$arity$4((arguments[(0)]),(arguments[(1)]),(arguments[(2)]),(arguments[(3)]));

break;
default:
throw (new Error(["Invalid arity: ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(arguments.length)].join('')));

}
});

cljs.core.async.put_BANG_.cljs$core$IFn$_invoke$arity$2 = (function (port,val){
var temp__5455__auto__ = cljs.core.async.impl.protocols.put_BANG_(port,val,cljs.core.async.fhnop);
if(cljs.core.truth_(temp__5455__auto__)){
var ret = temp__5455__auto__;
return cljs.core.deref(ret);
} else {
return true;
}
});

cljs.core.async.put_BANG_.cljs$core$IFn$_invoke$arity$3 = (function (port,val,fn1){
return cljs.core.async.put_BANG_.cljs$core$IFn$_invoke$arity$4(port,val,fn1,true);
});

cljs.core.async.put_BANG_.cljs$core$IFn$_invoke$arity$4 = (function (port,val,fn1,on_caller_QMARK_){
var temp__5455__auto__ = cljs.core.async.impl.protocols.put_BANG_(port,val,cljs.core.async.fn_handler.cljs$core$IFn$_invoke$arity$1(fn1));
if(cljs.core.truth_(temp__5455__auto__)){
var retb = temp__5455__auto__;
var ret = cljs.core.deref(retb);
if(cljs.core.truth_(on_caller_QMARK_)){
(fn1.cljs$core$IFn$_invoke$arity$1 ? fn1.cljs$core$IFn$_invoke$arity$1(ret) : fn1.call(null,ret));
} else {
cljs.core.async.impl.dispatch.run(((function (ret,retb,temp__5455__auto__){
return (function (){
return (fn1.cljs$core$IFn$_invoke$arity$1 ? fn1.cljs$core$IFn$_invoke$arity$1(ret) : fn1.call(null,ret));
});})(ret,retb,temp__5455__auto__))
);
}

return ret;
} else {
return true;
}
});

cljs.core.async.put_BANG_.cljs$lang$maxFixedArity = 4;

cljs.core.async.close_BANG_ = (function cljs$core$async$close_BANG_(port){
return cljs.core.async.impl.protocols.close_BANG_(port);
});
cljs.core.async.random_array = (function cljs$core$async$random_array(n){
var a = (new Array(n));
var n__4518__auto___28226 = n;
var x_28227 = (0);
while(true){
if((x_28227 < n__4518__auto___28226)){
(a[x_28227] = (0));

var G__28228 = (x_28227 + (1));
x_28227 = G__28228;
continue;
} else {
}
break;
}

var i = (1);
while(true){
if(cljs.core._EQ_.cljs$core$IFn$_invoke$arity$2(i,n)){
return a;
} else {
var j = cljs.core.rand_int(i);
(a[i] = (a[j]));

(a[j] = i);

var G__28229 = (i + (1));
i = G__28229;
continue;
}
break;
}
});
cljs.core.async.alt_flag = (function cljs$core$async$alt_flag(){
var flag = cljs.core.atom.cljs$core$IFn$_invoke$arity$1(true);
if((typeof cljs !== 'undefined') && (typeof cljs.core !== 'undefined') && (typeof cljs.core.async !== 'undefined') && (typeof cljs.core.async.t_cljs$core$async28230 !== 'undefined')){
} else {

/**
* @constructor
 * @implements {cljs.core.async.impl.protocols.Handler}
 * @implements {cljs.core.IMeta}
 * @implements {cljs.core.IWithMeta}
*/
cljs.core.async.t_cljs$core$async28230 = (function (flag,meta28231){
this.flag = flag;
this.meta28231 = meta28231;
this.cljs$lang$protocol_mask$partition0$ = 393216;
this.cljs$lang$protocol_mask$partition1$ = 0;
});
cljs.core.async.t_cljs$core$async28230.prototype.cljs$core$IWithMeta$_with_meta$arity$2 = ((function (flag){
return (function (_28232,meta28231__$1){
var self__ = this;
var _28232__$1 = this;
return (new cljs.core.async.t_cljs$core$async28230(self__.flag,meta28231__$1));
});})(flag))
;

cljs.core.async.t_cljs$core$async28230.prototype.cljs$core$IMeta$_meta$arity$1 = ((function (flag){
return (function (_28232){
var self__ = this;
var _28232__$1 = this;
return self__.meta28231;
});})(flag))
;

cljs.core.async.t_cljs$core$async28230.prototype.cljs$core$async$impl$protocols$Handler$ = cljs.core.PROTOCOL_SENTINEL;

cljs.core.async.t_cljs$core$async28230.prototype.cljs$core$async$impl$protocols$Handler$active_QMARK_$arity$1 = ((function (flag){
return (function (_){
var self__ = this;
var ___$1 = this;
return cljs.core.deref(self__.flag);
});})(flag))
;

cljs.core.async.t_cljs$core$async28230.prototype.cljs$core$async$impl$protocols$Handler$blockable_QMARK_$arity$1 = ((function (flag){
return (function (_){
var self__ = this;
var ___$1 = this;
return true;
});})(flag))
;

cljs.core.async.t_cljs$core$async28230.prototype.cljs$core$async$impl$protocols$Handler$commit$arity$1 = ((function (flag){
return (function (_){
var self__ = this;
var ___$1 = this;
cljs.core.reset_BANG_(self__.flag,null);

return true;
});})(flag))
;

cljs.core.async.t_cljs$core$async28230.getBasis = ((function (flag){
return (function (){
return new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [cljs.core.cst$sym$flag,cljs.core.cst$sym$meta28231], null);
});})(flag))
;

cljs.core.async.t_cljs$core$async28230.cljs$lang$type = true;

cljs.core.async.t_cljs$core$async28230.cljs$lang$ctorStr = "cljs.core.async/t_cljs$core$async28230";

cljs.core.async.t_cljs$core$async28230.cljs$lang$ctorPrWriter = ((function (flag){
return (function (this__4290__auto__,writer__4291__auto__,opt__4292__auto__){
return cljs.core._write(writer__4291__auto__,"cljs.core.async/t_cljs$core$async28230");
});})(flag))
;

/**
 * Positional factory function for cljs.core.async/t_cljs$core$async28230.
 */
cljs.core.async.__GT_t_cljs$core$async28230 = ((function (flag){
return (function cljs$core$async$alt_flag_$___GT_t_cljs$core$async28230(flag__$1,meta28231){
return (new cljs.core.async.t_cljs$core$async28230(flag__$1,meta28231));
});})(flag))
;

}

return (new cljs.core.async.t_cljs$core$async28230(flag,cljs.core.PersistentArrayMap.EMPTY));
});
cljs.core.async.alt_handler = (function cljs$core$async$alt_handler(flag,cb){
if((typeof cljs !== 'undefined') && (typeof cljs.core !== 'undefined') && (typeof cljs.core.async !== 'undefined') && (typeof cljs.core.async.t_cljs$core$async28233 !== 'undefined')){
} else {

/**
* @constructor
 * @implements {cljs.core.async.impl.protocols.Handler}
 * @implements {cljs.core.IMeta}
 * @implements {cljs.core.IWithMeta}
*/
cljs.core.async.t_cljs$core$async28233 = (function (flag,cb,meta28234){
this.flag = flag;
this.cb = cb;
this.meta28234 = meta28234;
this.cljs$lang$protocol_mask$partition0$ = 393216;
this.cljs$lang$protocol_mask$partition1$ = 0;
});
cljs.core.async.t_cljs$core$async28233.prototype.cljs$core$IWithMeta$_with_meta$arity$2 = (function (_28235,meta28234__$1){
var self__ = this;
var _28235__$1 = this;
return (new cljs.core.async.t_cljs$core$async28233(self__.flag,self__.cb,meta28234__$1));
});

cljs.core.async.t_cljs$core$async28233.prototype.cljs$core$IMeta$_meta$arity$1 = (function (_28235){
var self__ = this;
var _28235__$1 = this;
return self__.meta28234;
});

cljs.core.async.t_cljs$core$async28233.prototype.cljs$core$async$impl$protocols$Handler$ = cljs.core.PROTOCOL_SENTINEL;

cljs.core.async.t_cljs$core$async28233.prototype.cljs$core$async$impl$protocols$Handler$active_QMARK_$arity$1 = (function (_){
var self__ = this;
var ___$1 = this;
return cljs.core.async.impl.protocols.active_QMARK_(self__.flag);
});

cljs.core.async.t_cljs$core$async28233.prototype.cljs$core$async$impl$protocols$Handler$blockable_QMARK_$arity$1 = (function (_){
var self__ = this;
var ___$1 = this;
return true;
});

cljs.core.async.t_cljs$core$async28233.prototype.cljs$core$async$impl$protocols$Handler$commit$arity$1 = (function (_){
var self__ = this;
var ___$1 = this;
cljs.core.async.impl.protocols.commit(self__.flag);

return self__.cb;
});

cljs.core.async.t_cljs$core$async28233.getBasis = (function (){
return new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [cljs.core.cst$sym$flag,cljs.core.cst$sym$cb,cljs.core.cst$sym$meta28234], null);
});

cljs.core.async.t_cljs$core$async28233.cljs$lang$type = true;

cljs.core.async.t_cljs$core$async28233.cljs$lang$ctorStr = "cljs.core.async/t_cljs$core$async28233";

cljs.core.async.t_cljs$core$async28233.cljs$lang$ctorPrWriter = (function (this__4290__auto__,writer__4291__auto__,opt__4292__auto__){
return cljs.core._write(writer__4291__auto__,"cljs.core.async/t_cljs$core$async28233");
});

/**
 * Positional factory function for cljs.core.async/t_cljs$core$async28233.
 */
cljs.core.async.__GT_t_cljs$core$async28233 = (function cljs$core$async$alt_handler_$___GT_t_cljs$core$async28233(flag__$1,cb__$1,meta28234){
return (new cljs.core.async.t_cljs$core$async28233(flag__$1,cb__$1,meta28234));
});

}

return (new cljs.core.async.t_cljs$core$async28233(flag,cb,cljs.core.PersistentArrayMap.EMPTY));
});
/**
 * returns derefable [val port] if immediate, nil if enqueued
 */
cljs.core.async.do_alts = (function cljs$core$async$do_alts(fret,ports,opts){
var flag = cljs.core.async.alt_flag();
var n = cljs.core.count(ports);
var idxs = cljs.core.async.random_array(n);
var priority = cljs.core.cst$kw$priority.cljs$core$IFn$_invoke$arity$1(opts);
var ret = (function (){var i = (0);
while(true){
if((i < n)){
var idx = (cljs.core.truth_(priority)?i:(idxs[i]));
var port = cljs.core.nth.cljs$core$IFn$_invoke$arity$2(ports,idx);
var wport = ((cljs.core.vector_QMARK_(port))?(port.cljs$core$IFn$_invoke$arity$1 ? port.cljs$core$IFn$_invoke$arity$1((0)) : port.call(null,(0))):null);
var vbox = (cljs.core.truth_(wport)?(function (){var val = (port.cljs$core$IFn$_invoke$arity$1 ? port.cljs$core$IFn$_invoke$arity$1((1)) : port.call(null,(1)));
return cljs.core.async.impl.protocols.put_BANG_(wport,val,cljs.core.async.alt_handler(flag,((function (i,val,idx,port,wport,flag,n,idxs,priority){
return (function (p1__28236_SHARP_){
var G__28238 = new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [p1__28236_SHARP_,wport], null);
return (fret.cljs$core$IFn$_invoke$arity$1 ? fret.cljs$core$IFn$_invoke$arity$1(G__28238) : fret.call(null,G__28238));
});})(i,val,idx,port,wport,flag,n,idxs,priority))
));
})():cljs.core.async.impl.protocols.take_BANG_(port,cljs.core.async.alt_handler(flag,((function (i,idx,port,wport,flag,n,idxs,priority){
return (function (p1__28237_SHARP_){
var G__28239 = new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [p1__28237_SHARP_,port], null);
return (fret.cljs$core$IFn$_invoke$arity$1 ? fret.cljs$core$IFn$_invoke$arity$1(G__28239) : fret.call(null,G__28239));
});})(i,idx,port,wport,flag,n,idxs,priority))
)));
if(cljs.core.truth_(vbox)){
return cljs.core.async.impl.channels.box(new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [cljs.core.deref(vbox),(function (){var or__4047__auto__ = wport;
if(cljs.core.truth_(or__4047__auto__)){
return or__4047__auto__;
} else {
return port;
}
})()], null));
} else {
var G__28240 = (i + (1));
i = G__28240;
continue;
}
} else {
return null;
}
break;
}
})();
var or__4047__auto__ = ret;
if(cljs.core.truth_(or__4047__auto__)){
return or__4047__auto__;
} else {
if(cljs.core.contains_QMARK_(opts,cljs.core.cst$kw$default)){
var temp__5457__auto__ = (function (){var and__4036__auto__ = flag.cljs$core$async$impl$protocols$Handler$active_QMARK_$arity$1(null);
if(cljs.core.truth_(and__4036__auto__)){
return flag.cljs$core$async$impl$protocols$Handler$commit$arity$1(null);
} else {
return and__4036__auto__;
}
})();
if(cljs.core.truth_(temp__5457__auto__)){
var got = temp__5457__auto__;
return cljs.core.async.impl.channels.box(new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [cljs.core.cst$kw$default.cljs$core$IFn$_invoke$arity$1(opts),cljs.core.cst$kw$default], null));
} else {
return null;
}
} else {
return null;
}
}
});
/**
 * Completes at most one of several channel operations. Must be called
 * inside a (go ...) block. ports is a vector of channel endpoints,
 * which can be either a channel to take from or a vector of
 *   [channel-to-put-to val-to-put], in any combination. Takes will be
 *   made as if by <!, and puts will be made as if by >!. Unless
 *   the :priority option is true, if more than one port operation is
 *   ready a non-deterministic choice will be made. If no operation is
 *   ready and a :default value is supplied, [default-val :default] will
 *   be returned, otherwise alts! will park until the first operation to
 *   become ready completes. Returns [val port] of the completed
 *   operation, where val is the value taken for takes, and a
 *   boolean (true unless already closed, as per put!) for puts.
 * 
 *   opts are passed as :key val ... Supported options:
 * 
 *   :default val - the value to use if none of the operations are immediately ready
 *   :priority true - (default nil) when true, the operations will be tried in order.
 * 
 *   Note: there is no guarantee that the port exps or val exprs will be
 *   used, nor in what order should they be, so they should not be
 *   depended upon for side effects.
 */
cljs.core.async.alts_BANG_ = (function cljs$core$async$alts_BANG_(var_args){
var args__4647__auto__ = [];
var len__4641__auto___28246 = arguments.length;
var i__4642__auto___28247 = (0);
while(true){
if((i__4642__auto___28247 < len__4641__auto___28246)){
args__4647__auto__.push((arguments[i__4642__auto___28247]));

var G__28248 = (i__4642__auto___28247 + (1));
i__4642__auto___28247 = G__28248;
continue;
} else {
}
break;
}

var argseq__4648__auto__ = ((((1) < args__4647__auto__.length))?(new cljs.core.IndexedSeq(args__4647__auto__.slice((1)),(0),null)):null);
return cljs.core.async.alts_BANG_.cljs$core$IFn$_invoke$arity$variadic((arguments[(0)]),argseq__4648__auto__);
});

cljs.core.async.alts_BANG_.cljs$core$IFn$_invoke$arity$variadic = (function (ports,p__28243){
var map__28244 = p__28243;
var map__28244__$1 = (((((!((map__28244 == null))))?(((((map__28244.cljs$lang$protocol_mask$partition0$ & (64))) || ((cljs.core.PROTOCOL_SENTINEL === map__28244.cljs$core$ISeq$))))?true:false):false))?cljs.core.apply.cljs$core$IFn$_invoke$arity$2(cljs.core.hash_map,map__28244):map__28244);
var opts = map__28244__$1;
throw (new Error("alts! used not in (go ...) block"));
});

cljs.core.async.alts_BANG_.cljs$lang$maxFixedArity = (1);

/** @this {Function} */
cljs.core.async.alts_BANG_.cljs$lang$applyTo = (function (seq28241){
var G__28242 = cljs.core.first(seq28241);
var seq28241__$1 = cljs.core.next(seq28241);
var self__4628__auto__ = this;
return self__4628__auto__.cljs$core$IFn$_invoke$arity$variadic(G__28242,seq28241__$1);
});

/**
 * Puts a val into port if it's possible to do so immediately.
 *   nil values are not allowed. Never blocks. Returns true if offer succeeds.
 */
cljs.core.async.offer_BANG_ = (function cljs$core$async$offer_BANG_(port,val){
var ret = cljs.core.async.impl.protocols.put_BANG_(port,val,cljs.core.async.fn_handler.cljs$core$IFn$_invoke$arity$2(cljs.core.async.nop,false));
if(cljs.core.truth_(ret)){
return cljs.core.deref(ret);
} else {
return null;
}
});
/**
 * Takes a val from port if it's possible to do so immediately.
 *   Never blocks. Returns value if successful, nil otherwise.
 */
cljs.core.async.poll_BANG_ = (function cljs$core$async$poll_BANG_(port){
var ret = cljs.core.async.impl.protocols.take_BANG_(port,cljs.core.async.fn_handler.cljs$core$IFn$_invoke$arity$2(cljs.core.async.nop,false));
if(cljs.core.truth_(ret)){
return cljs.core.deref(ret);
} else {
return null;
}
});
/**
 * Takes elements from the from channel and supplies them to the to
 * channel. By default, the to channel will be closed when the from
 * channel closes, but can be determined by the close?  parameter. Will
 * stop consuming the from channel if the to channel closes
 */
cljs.core.async.pipe = (function cljs$core$async$pipe(var_args){
var G__28250 = arguments.length;
switch (G__28250) {
case 2:
return cljs.core.async.pipe.cljs$core$IFn$_invoke$arity$2((arguments[(0)]),(arguments[(1)]));

break;
case 3:
return cljs.core.async.pipe.cljs$core$IFn$_invoke$arity$3((arguments[(0)]),(arguments[(1)]),(arguments[(2)]));

break;
default:
throw (new Error(["Invalid arity: ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(arguments.length)].join('')));

}
});

cljs.core.async.pipe.cljs$core$IFn$_invoke$arity$2 = (function (from,to){
return cljs.core.async.pipe.cljs$core$IFn$_invoke$arity$3(from,to,true);
});

cljs.core.async.pipe.cljs$core$IFn$_invoke$arity$3 = (function (from,to,close_QMARK_){
var c__7992__auto___28296 = cljs.core.async.chan.cljs$core$IFn$_invoke$arity$1((1));
cljs.core.async.impl.dispatch.run(((function (c__7992__auto___28296){
return (function (){
var f__7993__auto__ = (function (){var switch__7885__auto__ = ((function (c__7992__auto___28296){
return (function (state_28274){
var state_val_28275 = (state_28274[(1)]);
if((state_val_28275 === (7))){
var inst_28270 = (state_28274[(2)]);
var state_28274__$1 = state_28274;
var statearr_28276_28297 = state_28274__$1;
(statearr_28276_28297[(2)] = inst_28270);

(statearr_28276_28297[(1)] = (3));


return cljs.core.cst$kw$recur;
} else {
if((state_val_28275 === (1))){
var state_28274__$1 = state_28274;
var statearr_28277_28298 = state_28274__$1;
(statearr_28277_28298[(2)] = null);

(statearr_28277_28298[(1)] = (2));


return cljs.core.cst$kw$recur;
} else {
if((state_val_28275 === (4))){
var inst_28253 = (state_28274[(7)]);
var inst_28253__$1 = (state_28274[(2)]);
var inst_28254 = (inst_28253__$1 == null);
var state_28274__$1 = (function (){var statearr_28278 = state_28274;
(statearr_28278[(7)] = inst_28253__$1);

return statearr_28278;
})();
if(cljs.core.truth_(inst_28254)){
var statearr_28279_28299 = state_28274__$1;
(statearr_28279_28299[(1)] = (5));

} else {
var statearr_28280_28300 = state_28274__$1;
(statearr_28280_28300[(1)] = (6));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_28275 === (13))){
var state_28274__$1 = state_28274;
var statearr_28281_28301 = state_28274__$1;
(statearr_28281_28301[(2)] = null);

(statearr_28281_28301[(1)] = (14));


return cljs.core.cst$kw$recur;
} else {
if((state_val_28275 === (6))){
var inst_28253 = (state_28274[(7)]);
var state_28274__$1 = state_28274;
return cljs.core.async.impl.ioc_helpers.put_BANG_(state_28274__$1,(11),to,inst_28253);
} else {
if((state_val_28275 === (3))){
var inst_28272 = (state_28274[(2)]);
var state_28274__$1 = state_28274;
return cljs.core.async.impl.ioc_helpers.return_chan(state_28274__$1,inst_28272);
} else {
if((state_val_28275 === (12))){
var state_28274__$1 = state_28274;
var statearr_28282_28302 = state_28274__$1;
(statearr_28282_28302[(2)] = null);

(statearr_28282_28302[(1)] = (2));


return cljs.core.cst$kw$recur;
} else {
if((state_val_28275 === (2))){
var state_28274__$1 = state_28274;
return cljs.core.async.impl.ioc_helpers.take_BANG_(state_28274__$1,(4),from);
} else {
if((state_val_28275 === (11))){
var inst_28263 = (state_28274[(2)]);
var state_28274__$1 = state_28274;
if(cljs.core.truth_(inst_28263)){
var statearr_28283_28303 = state_28274__$1;
(statearr_28283_28303[(1)] = (12));

} else {
var statearr_28284_28304 = state_28274__$1;
(statearr_28284_28304[(1)] = (13));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_28275 === (9))){
var state_28274__$1 = state_28274;
var statearr_28285_28305 = state_28274__$1;
(statearr_28285_28305[(2)] = null);

(statearr_28285_28305[(1)] = (10));


return cljs.core.cst$kw$recur;
} else {
if((state_val_28275 === (5))){
var state_28274__$1 = state_28274;
if(cljs.core.truth_(close_QMARK_)){
var statearr_28286_28306 = state_28274__$1;
(statearr_28286_28306[(1)] = (8));

} else {
var statearr_28287_28307 = state_28274__$1;
(statearr_28287_28307[(1)] = (9));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_28275 === (14))){
var inst_28268 = (state_28274[(2)]);
var state_28274__$1 = state_28274;
var statearr_28288_28308 = state_28274__$1;
(statearr_28288_28308[(2)] = inst_28268);

(statearr_28288_28308[(1)] = (7));


return cljs.core.cst$kw$recur;
} else {
if((state_val_28275 === (10))){
var inst_28260 = (state_28274[(2)]);
var state_28274__$1 = state_28274;
var statearr_28289_28309 = state_28274__$1;
(statearr_28289_28309[(2)] = inst_28260);

(statearr_28289_28309[(1)] = (7));


return cljs.core.cst$kw$recur;
} else {
if((state_val_28275 === (8))){
var inst_28257 = cljs.core.async.close_BANG_(to);
var state_28274__$1 = state_28274;
var statearr_28290_28310 = state_28274__$1;
(statearr_28290_28310[(2)] = inst_28257);

(statearr_28290_28310[(1)] = (10));


return cljs.core.cst$kw$recur;
} else {
return null;
}
}
}
}
}
}
}
}
}
}
}
}
}
}
});})(c__7992__auto___28296))
;
return ((function (switch__7885__auto__,c__7992__auto___28296){
return (function() {
var cljs$core$async$state_machine__7886__auto__ = null;
var cljs$core$async$state_machine__7886__auto____0 = (function (){
var statearr_28291 = [null,null,null,null,null,null,null,null];
(statearr_28291[(0)] = cljs$core$async$state_machine__7886__auto__);

(statearr_28291[(1)] = (1));

return statearr_28291;
});
var cljs$core$async$state_machine__7886__auto____1 = (function (state_28274){
while(true){
var ret_value__7887__auto__ = (function (){try{while(true){
var result__7888__auto__ = switch__7885__auto__(state_28274);
if(cljs.core.keyword_identical_QMARK_(result__7888__auto__,cljs.core.cst$kw$recur)){
continue;
} else {
return result__7888__auto__;
}
break;
}
}catch (e28292){if((e28292 instanceof Object)){
var ex__7889__auto__ = e28292;
var statearr_28293_28311 = state_28274;
(statearr_28293_28311[(5)] = ex__7889__auto__);


cljs.core.async.impl.ioc_helpers.process_exception(state_28274);

return cljs.core.cst$kw$recur;
} else {
throw e28292;

}
}})();
if(cljs.core.keyword_identical_QMARK_(ret_value__7887__auto__,cljs.core.cst$kw$recur)){
var G__28312 = state_28274;
state_28274 = G__28312;
continue;
} else {
return ret_value__7887__auto__;
}
break;
}
});
cljs$core$async$state_machine__7886__auto__ = function(state_28274){
switch(arguments.length){
case 0:
return cljs$core$async$state_machine__7886__auto____0.call(this);
case 1:
return cljs$core$async$state_machine__7886__auto____1.call(this,state_28274);
}
throw(new Error('Invalid arity: ' + arguments.length));
};
cljs$core$async$state_machine__7886__auto__.cljs$core$IFn$_invoke$arity$0 = cljs$core$async$state_machine__7886__auto____0;
cljs$core$async$state_machine__7886__auto__.cljs$core$IFn$_invoke$arity$1 = cljs$core$async$state_machine__7886__auto____1;
return cljs$core$async$state_machine__7886__auto__;
})()
;})(switch__7885__auto__,c__7992__auto___28296))
})();
var state__7994__auto__ = (function (){var statearr_28294 = (f__7993__auto__.cljs$core$IFn$_invoke$arity$0 ? f__7993__auto__.cljs$core$IFn$_invoke$arity$0() : f__7993__auto__.call(null));
(statearr_28294[(6)] = c__7992__auto___28296);

return statearr_28294;
})();
return cljs.core.async.impl.ioc_helpers.run_state_machine_wrapped(state__7994__auto__);
});})(c__7992__auto___28296))
);


return to;
});

cljs.core.async.pipe.cljs$lang$maxFixedArity = 3;

cljs.core.async.pipeline_STAR_ = (function cljs$core$async$pipeline_STAR_(n,to,xf,from,close_QMARK_,ex_handler,type){

var jobs = cljs.core.async.chan.cljs$core$IFn$_invoke$arity$1(n);
var results = cljs.core.async.chan.cljs$core$IFn$_invoke$arity$1(n);
var process = ((function (jobs,results){
return (function (p__28313){
var vec__28314 = p__28313;
var v = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(vec__28314,(0),null);
var p = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(vec__28314,(1),null);
var job = vec__28314;
if((job == null)){
cljs.core.async.close_BANG_(results);

return null;
} else {
var res = cljs.core.async.chan.cljs$core$IFn$_invoke$arity$3((1),xf,ex_handler);
var c__7992__auto___28485 = cljs.core.async.chan.cljs$core$IFn$_invoke$arity$1((1));
cljs.core.async.impl.dispatch.run(((function (c__7992__auto___28485,res,vec__28314,v,p,job,jobs,results){
return (function (){
var f__7993__auto__ = (function (){var switch__7885__auto__ = ((function (c__7992__auto___28485,res,vec__28314,v,p,job,jobs,results){
return (function (state_28321){
var state_val_28322 = (state_28321[(1)]);
if((state_val_28322 === (1))){
var state_28321__$1 = state_28321;
return cljs.core.async.impl.ioc_helpers.put_BANG_(state_28321__$1,(2),res,v);
} else {
if((state_val_28322 === (2))){
var inst_28318 = (state_28321[(2)]);
var inst_28319 = cljs.core.async.close_BANG_(res);
var state_28321__$1 = (function (){var statearr_28323 = state_28321;
(statearr_28323[(7)] = inst_28318);

return statearr_28323;
})();
return cljs.core.async.impl.ioc_helpers.return_chan(state_28321__$1,inst_28319);
} else {
return null;
}
}
});})(c__7992__auto___28485,res,vec__28314,v,p,job,jobs,results))
;
return ((function (switch__7885__auto__,c__7992__auto___28485,res,vec__28314,v,p,job,jobs,results){
return (function() {
var cljs$core$async$pipeline_STAR__$_state_machine__7886__auto__ = null;
var cljs$core$async$pipeline_STAR__$_state_machine__7886__auto____0 = (function (){
var statearr_28324 = [null,null,null,null,null,null,null,null];
(statearr_28324[(0)] = cljs$core$async$pipeline_STAR__$_state_machine__7886__auto__);

(statearr_28324[(1)] = (1));

return statearr_28324;
});
var cljs$core$async$pipeline_STAR__$_state_machine__7886__auto____1 = (function (state_28321){
while(true){
var ret_value__7887__auto__ = (function (){try{while(true){
var result__7888__auto__ = switch__7885__auto__(state_28321);
if(cljs.core.keyword_identical_QMARK_(result__7888__auto__,cljs.core.cst$kw$recur)){
continue;
} else {
return result__7888__auto__;
}
break;
}
}catch (e28325){if((e28325 instanceof Object)){
var ex__7889__auto__ = e28325;
var statearr_28326_28486 = state_28321;
(statearr_28326_28486[(5)] = ex__7889__auto__);


cljs.core.async.impl.ioc_helpers.process_exception(state_28321);

return cljs.core.cst$kw$recur;
} else {
throw e28325;

}
}})();
if(cljs.core.keyword_identical_QMARK_(ret_value__7887__auto__,cljs.core.cst$kw$recur)){
var G__28487 = state_28321;
state_28321 = G__28487;
continue;
} else {
return ret_value__7887__auto__;
}
break;
}
});
cljs$core$async$pipeline_STAR__$_state_machine__7886__auto__ = function(state_28321){
switch(arguments.length){
case 0:
return cljs$core$async$pipeline_STAR__$_state_machine__7886__auto____0.call(this);
case 1:
return cljs$core$async$pipeline_STAR__$_state_machine__7886__auto____1.call(this,state_28321);
}
throw(new Error('Invalid arity: ' + arguments.length));
};
cljs$core$async$pipeline_STAR__$_state_machine__7886__auto__.cljs$core$IFn$_invoke$arity$0 = cljs$core$async$pipeline_STAR__$_state_machine__7886__auto____0;
cljs$core$async$pipeline_STAR__$_state_machine__7886__auto__.cljs$core$IFn$_invoke$arity$1 = cljs$core$async$pipeline_STAR__$_state_machine__7886__auto____1;
return cljs$core$async$pipeline_STAR__$_state_machine__7886__auto__;
})()
;})(switch__7885__auto__,c__7992__auto___28485,res,vec__28314,v,p,job,jobs,results))
})();
var state__7994__auto__ = (function (){var statearr_28327 = (f__7993__auto__.cljs$core$IFn$_invoke$arity$0 ? f__7993__auto__.cljs$core$IFn$_invoke$arity$0() : f__7993__auto__.call(null));
(statearr_28327[(6)] = c__7992__auto___28485);

return statearr_28327;
})();
return cljs.core.async.impl.ioc_helpers.run_state_machine_wrapped(state__7994__auto__);
});})(c__7992__auto___28485,res,vec__28314,v,p,job,jobs,results))
);


cljs.core.async.put_BANG_.cljs$core$IFn$_invoke$arity$2(p,res);

return true;
}
});})(jobs,results))
;
var async = ((function (jobs,results,process){
return (function (p__28328){
var vec__28329 = p__28328;
var v = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(vec__28329,(0),null);
var p = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(vec__28329,(1),null);
var job = vec__28329;
if((job == null)){
cljs.core.async.close_BANG_(results);

return null;
} else {
var res = cljs.core.async.chan.cljs$core$IFn$_invoke$arity$1((1));
(xf.cljs$core$IFn$_invoke$arity$2 ? xf.cljs$core$IFn$_invoke$arity$2(v,res) : xf.call(null,v,res));

cljs.core.async.put_BANG_.cljs$core$IFn$_invoke$arity$2(p,res);

return true;
}
});})(jobs,results,process))
;
var n__4518__auto___28488 = n;
var __28489 = (0);
while(true){
if((__28489 < n__4518__auto___28488)){
var G__28332_28490 = type;
var G__28332_28491__$1 = (((G__28332_28490 instanceof cljs.core.Keyword))?G__28332_28490.fqn:null);
switch (G__28332_28491__$1) {
case "compute":
var c__7992__auto___28493 = cljs.core.async.chan.cljs$core$IFn$_invoke$arity$1((1));
cljs.core.async.impl.dispatch.run(((function (__28489,c__7992__auto___28493,G__28332_28490,G__28332_28491__$1,n__4518__auto___28488,jobs,results,process,async){
return (function (){
var f__7993__auto__ = (function (){var switch__7885__auto__ = ((function (__28489,c__7992__auto___28493,G__28332_28490,G__28332_28491__$1,n__4518__auto___28488,jobs,results,process,async){
return (function (state_28345){
var state_val_28346 = (state_28345[(1)]);
if((state_val_28346 === (1))){
var state_28345__$1 = state_28345;
var statearr_28347_28494 = state_28345__$1;
(statearr_28347_28494[(2)] = null);

(statearr_28347_28494[(1)] = (2));


return cljs.core.cst$kw$recur;
} else {
if((state_val_28346 === (2))){
var state_28345__$1 = state_28345;
return cljs.core.async.impl.ioc_helpers.take_BANG_(state_28345__$1,(4),jobs);
} else {
if((state_val_28346 === (3))){
var inst_28343 = (state_28345[(2)]);
var state_28345__$1 = state_28345;
return cljs.core.async.impl.ioc_helpers.return_chan(state_28345__$1,inst_28343);
} else {
if((state_val_28346 === (4))){
var inst_28335 = (state_28345[(2)]);
var inst_28336 = process(inst_28335);
var state_28345__$1 = state_28345;
if(cljs.core.truth_(inst_28336)){
var statearr_28348_28495 = state_28345__$1;
(statearr_28348_28495[(1)] = (5));

} else {
var statearr_28349_28496 = state_28345__$1;
(statearr_28349_28496[(1)] = (6));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_28346 === (5))){
var state_28345__$1 = state_28345;
var statearr_28350_28497 = state_28345__$1;
(statearr_28350_28497[(2)] = null);

(statearr_28350_28497[(1)] = (2));


return cljs.core.cst$kw$recur;
} else {
if((state_val_28346 === (6))){
var state_28345__$1 = state_28345;
var statearr_28351_28498 = state_28345__$1;
(statearr_28351_28498[(2)] = null);

(statearr_28351_28498[(1)] = (7));


return cljs.core.cst$kw$recur;
} else {
if((state_val_28346 === (7))){
var inst_28341 = (state_28345[(2)]);
var state_28345__$1 = state_28345;
var statearr_28352_28499 = state_28345__$1;
(statearr_28352_28499[(2)] = inst_28341);

(statearr_28352_28499[(1)] = (3));


return cljs.core.cst$kw$recur;
} else {
return null;
}
}
}
}
}
}
}
});})(__28489,c__7992__auto___28493,G__28332_28490,G__28332_28491__$1,n__4518__auto___28488,jobs,results,process,async))
;
return ((function (__28489,switch__7885__auto__,c__7992__auto___28493,G__28332_28490,G__28332_28491__$1,n__4518__auto___28488,jobs,results,process,async){
return (function() {
var cljs$core$async$pipeline_STAR__$_state_machine__7886__auto__ = null;
var cljs$core$async$pipeline_STAR__$_state_machine__7886__auto____0 = (function (){
var statearr_28353 = [null,null,null,null,null,null,null];
(statearr_28353[(0)] = cljs$core$async$pipeline_STAR__$_state_machine__7886__auto__);

(statearr_28353[(1)] = (1));

return statearr_28353;
});
var cljs$core$async$pipeline_STAR__$_state_machine__7886__auto____1 = (function (state_28345){
while(true){
var ret_value__7887__auto__ = (function (){try{while(true){
var result__7888__auto__ = switch__7885__auto__(state_28345);
if(cljs.core.keyword_identical_QMARK_(result__7888__auto__,cljs.core.cst$kw$recur)){
continue;
} else {
return result__7888__auto__;
}
break;
}
}catch (e28354){if((e28354 instanceof Object)){
var ex__7889__auto__ = e28354;
var statearr_28355_28500 = state_28345;
(statearr_28355_28500[(5)] = ex__7889__auto__);


cljs.core.async.impl.ioc_helpers.process_exception(state_28345);

return cljs.core.cst$kw$recur;
} else {
throw e28354;

}
}})();
if(cljs.core.keyword_identical_QMARK_(ret_value__7887__auto__,cljs.core.cst$kw$recur)){
var G__28501 = state_28345;
state_28345 = G__28501;
continue;
} else {
return ret_value__7887__auto__;
}
break;
}
});
cljs$core$async$pipeline_STAR__$_state_machine__7886__auto__ = function(state_28345){
switch(arguments.length){
case 0:
return cljs$core$async$pipeline_STAR__$_state_machine__7886__auto____0.call(this);
case 1:
return cljs$core$async$pipeline_STAR__$_state_machine__7886__auto____1.call(this,state_28345);
}
throw(new Error('Invalid arity: ' + arguments.length));
};
cljs$core$async$pipeline_STAR__$_state_machine__7886__auto__.cljs$core$IFn$_invoke$arity$0 = cljs$core$async$pipeline_STAR__$_state_machine__7886__auto____0;
cljs$core$async$pipeline_STAR__$_state_machine__7886__auto__.cljs$core$IFn$_invoke$arity$1 = cljs$core$async$pipeline_STAR__$_state_machine__7886__auto____1;
return cljs$core$async$pipeline_STAR__$_state_machine__7886__auto__;
})()
;})(__28489,switch__7885__auto__,c__7992__auto___28493,G__28332_28490,G__28332_28491__$1,n__4518__auto___28488,jobs,results,process,async))
})();
var state__7994__auto__ = (function (){var statearr_28356 = (f__7993__auto__.cljs$core$IFn$_invoke$arity$0 ? f__7993__auto__.cljs$core$IFn$_invoke$arity$0() : f__7993__auto__.call(null));
(statearr_28356[(6)] = c__7992__auto___28493);

return statearr_28356;
})();
return cljs.core.async.impl.ioc_helpers.run_state_machine_wrapped(state__7994__auto__);
});})(__28489,c__7992__auto___28493,G__28332_28490,G__28332_28491__$1,n__4518__auto___28488,jobs,results,process,async))
);


break;
case "async":
var c__7992__auto___28502 = cljs.core.async.chan.cljs$core$IFn$_invoke$arity$1((1));
cljs.core.async.impl.dispatch.run(((function (__28489,c__7992__auto___28502,G__28332_28490,G__28332_28491__$1,n__4518__auto___28488,jobs,results,process,async){
return (function (){
var f__7993__auto__ = (function (){var switch__7885__auto__ = ((function (__28489,c__7992__auto___28502,G__28332_28490,G__28332_28491__$1,n__4518__auto___28488,jobs,results,process,async){
return (function (state_28369){
var state_val_28370 = (state_28369[(1)]);
if((state_val_28370 === (1))){
var state_28369__$1 = state_28369;
var statearr_28371_28503 = state_28369__$1;
(statearr_28371_28503[(2)] = null);

(statearr_28371_28503[(1)] = (2));


return cljs.core.cst$kw$recur;
} else {
if((state_val_28370 === (2))){
var state_28369__$1 = state_28369;
return cljs.core.async.impl.ioc_helpers.take_BANG_(state_28369__$1,(4),jobs);
} else {
if((state_val_28370 === (3))){
var inst_28367 = (state_28369[(2)]);
var state_28369__$1 = state_28369;
return cljs.core.async.impl.ioc_helpers.return_chan(state_28369__$1,inst_28367);
} else {
if((state_val_28370 === (4))){
var inst_28359 = (state_28369[(2)]);
var inst_28360 = async(inst_28359);
var state_28369__$1 = state_28369;
if(cljs.core.truth_(inst_28360)){
var statearr_28372_28504 = state_28369__$1;
(statearr_28372_28504[(1)] = (5));

} else {
var statearr_28373_28505 = state_28369__$1;
(statearr_28373_28505[(1)] = (6));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_28370 === (5))){
var state_28369__$1 = state_28369;
var statearr_28374_28506 = state_28369__$1;
(statearr_28374_28506[(2)] = null);

(statearr_28374_28506[(1)] = (2));


return cljs.core.cst$kw$recur;
} else {
if((state_val_28370 === (6))){
var state_28369__$1 = state_28369;
var statearr_28375_28507 = state_28369__$1;
(statearr_28375_28507[(2)] = null);

(statearr_28375_28507[(1)] = (7));


return cljs.core.cst$kw$recur;
} else {
if((state_val_28370 === (7))){
var inst_28365 = (state_28369[(2)]);
var state_28369__$1 = state_28369;
var statearr_28376_28508 = state_28369__$1;
(statearr_28376_28508[(2)] = inst_28365);

(statearr_28376_28508[(1)] = (3));


return cljs.core.cst$kw$recur;
} else {
return null;
}
}
}
}
}
}
}
});})(__28489,c__7992__auto___28502,G__28332_28490,G__28332_28491__$1,n__4518__auto___28488,jobs,results,process,async))
;
return ((function (__28489,switch__7885__auto__,c__7992__auto___28502,G__28332_28490,G__28332_28491__$1,n__4518__auto___28488,jobs,results,process,async){
return (function() {
var cljs$core$async$pipeline_STAR__$_state_machine__7886__auto__ = null;
var cljs$core$async$pipeline_STAR__$_state_machine__7886__auto____0 = (function (){
var statearr_28377 = [null,null,null,null,null,null,null];
(statearr_28377[(0)] = cljs$core$async$pipeline_STAR__$_state_machine__7886__auto__);

(statearr_28377[(1)] = (1));

return statearr_28377;
});
var cljs$core$async$pipeline_STAR__$_state_machine__7886__auto____1 = (function (state_28369){
while(true){
var ret_value__7887__auto__ = (function (){try{while(true){
var result__7888__auto__ = switch__7885__auto__(state_28369);
if(cljs.core.keyword_identical_QMARK_(result__7888__auto__,cljs.core.cst$kw$recur)){
continue;
} else {
return result__7888__auto__;
}
break;
}
}catch (e28378){if((e28378 instanceof Object)){
var ex__7889__auto__ = e28378;
var statearr_28379_28509 = state_28369;
(statearr_28379_28509[(5)] = ex__7889__auto__);


cljs.core.async.impl.ioc_helpers.process_exception(state_28369);

return cljs.core.cst$kw$recur;
} else {
throw e28378;

}
}})();
if(cljs.core.keyword_identical_QMARK_(ret_value__7887__auto__,cljs.core.cst$kw$recur)){
var G__28510 = state_28369;
state_28369 = G__28510;
continue;
} else {
return ret_value__7887__auto__;
}
break;
}
});
cljs$core$async$pipeline_STAR__$_state_machine__7886__auto__ = function(state_28369){
switch(arguments.length){
case 0:
return cljs$core$async$pipeline_STAR__$_state_machine__7886__auto____0.call(this);
case 1:
return cljs$core$async$pipeline_STAR__$_state_machine__7886__auto____1.call(this,state_28369);
}
throw(new Error('Invalid arity: ' + arguments.length));
};
cljs$core$async$pipeline_STAR__$_state_machine__7886__auto__.cljs$core$IFn$_invoke$arity$0 = cljs$core$async$pipeline_STAR__$_state_machine__7886__auto____0;
cljs$core$async$pipeline_STAR__$_state_machine__7886__auto__.cljs$core$IFn$_invoke$arity$1 = cljs$core$async$pipeline_STAR__$_state_machine__7886__auto____1;
return cljs$core$async$pipeline_STAR__$_state_machine__7886__auto__;
})()
;})(__28489,switch__7885__auto__,c__7992__auto___28502,G__28332_28490,G__28332_28491__$1,n__4518__auto___28488,jobs,results,process,async))
})();
var state__7994__auto__ = (function (){var statearr_28380 = (f__7993__auto__.cljs$core$IFn$_invoke$arity$0 ? f__7993__auto__.cljs$core$IFn$_invoke$arity$0() : f__7993__auto__.call(null));
(statearr_28380[(6)] = c__7992__auto___28502);

return statearr_28380;
})();
return cljs.core.async.impl.ioc_helpers.run_state_machine_wrapped(state__7994__auto__);
});})(__28489,c__7992__auto___28502,G__28332_28490,G__28332_28491__$1,n__4518__auto___28488,jobs,results,process,async))
);


break;
default:
throw (new Error(["No matching clause: ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(G__28332_28491__$1)].join('')));

}

var G__28511 = (__28489 + (1));
__28489 = G__28511;
continue;
} else {
}
break;
}

var c__7992__auto___28512 = cljs.core.async.chan.cljs$core$IFn$_invoke$arity$1((1));
cljs.core.async.impl.dispatch.run(((function (c__7992__auto___28512,jobs,results,process,async){
return (function (){
var f__7993__auto__ = (function (){var switch__7885__auto__ = ((function (c__7992__auto___28512,jobs,results,process,async){
return (function (state_28402){
var state_val_28403 = (state_28402[(1)]);
if((state_val_28403 === (1))){
var state_28402__$1 = state_28402;
var statearr_28404_28513 = state_28402__$1;
(statearr_28404_28513[(2)] = null);

(statearr_28404_28513[(1)] = (2));


return cljs.core.cst$kw$recur;
} else {
if((state_val_28403 === (2))){
var state_28402__$1 = state_28402;
return cljs.core.async.impl.ioc_helpers.take_BANG_(state_28402__$1,(4),from);
} else {
if((state_val_28403 === (3))){
var inst_28400 = (state_28402[(2)]);
var state_28402__$1 = state_28402;
return cljs.core.async.impl.ioc_helpers.return_chan(state_28402__$1,inst_28400);
} else {
if((state_val_28403 === (4))){
var inst_28383 = (state_28402[(7)]);
var inst_28383__$1 = (state_28402[(2)]);
var inst_28384 = (inst_28383__$1 == null);
var state_28402__$1 = (function (){var statearr_28405 = state_28402;
(statearr_28405[(7)] = inst_28383__$1);

return statearr_28405;
})();
if(cljs.core.truth_(inst_28384)){
var statearr_28406_28514 = state_28402__$1;
(statearr_28406_28514[(1)] = (5));

} else {
var statearr_28407_28515 = state_28402__$1;
(statearr_28407_28515[(1)] = (6));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_28403 === (5))){
var inst_28386 = cljs.core.async.close_BANG_(jobs);
var state_28402__$1 = state_28402;
var statearr_28408_28516 = state_28402__$1;
(statearr_28408_28516[(2)] = inst_28386);

(statearr_28408_28516[(1)] = (7));


return cljs.core.cst$kw$recur;
} else {
if((state_val_28403 === (6))){
var inst_28388 = (state_28402[(8)]);
var inst_28383 = (state_28402[(7)]);
var inst_28388__$1 = cljs.core.async.chan.cljs$core$IFn$_invoke$arity$1((1));
var inst_28389 = cljs.core.PersistentVector.EMPTY_NODE;
var inst_28390 = [inst_28383,inst_28388__$1];
var inst_28391 = (new cljs.core.PersistentVector(null,2,(5),inst_28389,inst_28390,null));
var state_28402__$1 = (function (){var statearr_28409 = state_28402;
(statearr_28409[(8)] = inst_28388__$1);

return statearr_28409;
})();
return cljs.core.async.impl.ioc_helpers.put_BANG_(state_28402__$1,(8),jobs,inst_28391);
} else {
if((state_val_28403 === (7))){
var inst_28398 = (state_28402[(2)]);
var state_28402__$1 = state_28402;
var statearr_28410_28517 = state_28402__$1;
(statearr_28410_28517[(2)] = inst_28398);

(statearr_28410_28517[(1)] = (3));


return cljs.core.cst$kw$recur;
} else {
if((state_val_28403 === (8))){
var inst_28388 = (state_28402[(8)]);
var inst_28393 = (state_28402[(2)]);
var state_28402__$1 = (function (){var statearr_28411 = state_28402;
(statearr_28411[(9)] = inst_28393);

return statearr_28411;
})();
return cljs.core.async.impl.ioc_helpers.put_BANG_(state_28402__$1,(9),results,inst_28388);
} else {
if((state_val_28403 === (9))){
var inst_28395 = (state_28402[(2)]);
var state_28402__$1 = (function (){var statearr_28412 = state_28402;
(statearr_28412[(10)] = inst_28395);

return statearr_28412;
})();
var statearr_28413_28518 = state_28402__$1;
(statearr_28413_28518[(2)] = null);

(statearr_28413_28518[(1)] = (2));


return cljs.core.cst$kw$recur;
} else {
return null;
}
}
}
}
}
}
}
}
}
});})(c__7992__auto___28512,jobs,results,process,async))
;
return ((function (switch__7885__auto__,c__7992__auto___28512,jobs,results,process,async){
return (function() {
var cljs$core$async$pipeline_STAR__$_state_machine__7886__auto__ = null;
var cljs$core$async$pipeline_STAR__$_state_machine__7886__auto____0 = (function (){
var statearr_28414 = [null,null,null,null,null,null,null,null,null,null,null];
(statearr_28414[(0)] = cljs$core$async$pipeline_STAR__$_state_machine__7886__auto__);

(statearr_28414[(1)] = (1));

return statearr_28414;
});
var cljs$core$async$pipeline_STAR__$_state_machine__7886__auto____1 = (function (state_28402){
while(true){
var ret_value__7887__auto__ = (function (){try{while(true){
var result__7888__auto__ = switch__7885__auto__(state_28402);
if(cljs.core.keyword_identical_QMARK_(result__7888__auto__,cljs.core.cst$kw$recur)){
continue;
} else {
return result__7888__auto__;
}
break;
}
}catch (e28415){if((e28415 instanceof Object)){
var ex__7889__auto__ = e28415;
var statearr_28416_28519 = state_28402;
(statearr_28416_28519[(5)] = ex__7889__auto__);


cljs.core.async.impl.ioc_helpers.process_exception(state_28402);

return cljs.core.cst$kw$recur;
} else {
throw e28415;

}
}})();
if(cljs.core.keyword_identical_QMARK_(ret_value__7887__auto__,cljs.core.cst$kw$recur)){
var G__28520 = state_28402;
state_28402 = G__28520;
continue;
} else {
return ret_value__7887__auto__;
}
break;
}
});
cljs$core$async$pipeline_STAR__$_state_machine__7886__auto__ = function(state_28402){
switch(arguments.length){
case 0:
return cljs$core$async$pipeline_STAR__$_state_machine__7886__auto____0.call(this);
case 1:
return cljs$core$async$pipeline_STAR__$_state_machine__7886__auto____1.call(this,state_28402);
}
throw(new Error('Invalid arity: ' + arguments.length));
};
cljs$core$async$pipeline_STAR__$_state_machine__7886__auto__.cljs$core$IFn$_invoke$arity$0 = cljs$core$async$pipeline_STAR__$_state_machine__7886__auto____0;
cljs$core$async$pipeline_STAR__$_state_machine__7886__auto__.cljs$core$IFn$_invoke$arity$1 = cljs$core$async$pipeline_STAR__$_state_machine__7886__auto____1;
return cljs$core$async$pipeline_STAR__$_state_machine__7886__auto__;
})()
;})(switch__7885__auto__,c__7992__auto___28512,jobs,results,process,async))
})();
var state__7994__auto__ = (function (){var statearr_28417 = (f__7993__auto__.cljs$core$IFn$_invoke$arity$0 ? f__7993__auto__.cljs$core$IFn$_invoke$arity$0() : f__7993__auto__.call(null));
(statearr_28417[(6)] = c__7992__auto___28512);

return statearr_28417;
})();
return cljs.core.async.impl.ioc_helpers.run_state_machine_wrapped(state__7994__auto__);
});})(c__7992__auto___28512,jobs,results,process,async))
);


var c__7992__auto__ = cljs.core.async.chan.cljs$core$IFn$_invoke$arity$1((1));
cljs.core.async.impl.dispatch.run(((function (c__7992__auto__,jobs,results,process,async){
return (function (){
var f__7993__auto__ = (function (){var switch__7885__auto__ = ((function (c__7992__auto__,jobs,results,process,async){
return (function (state_28455){
var state_val_28456 = (state_28455[(1)]);
if((state_val_28456 === (7))){
var inst_28451 = (state_28455[(2)]);
var state_28455__$1 = state_28455;
var statearr_28457_28521 = state_28455__$1;
(statearr_28457_28521[(2)] = inst_28451);

(statearr_28457_28521[(1)] = (3));


return cljs.core.cst$kw$recur;
} else {
if((state_val_28456 === (20))){
var state_28455__$1 = state_28455;
var statearr_28458_28522 = state_28455__$1;
(statearr_28458_28522[(2)] = null);

(statearr_28458_28522[(1)] = (21));


return cljs.core.cst$kw$recur;
} else {
if((state_val_28456 === (1))){
var state_28455__$1 = state_28455;
var statearr_28459_28523 = state_28455__$1;
(statearr_28459_28523[(2)] = null);

(statearr_28459_28523[(1)] = (2));


return cljs.core.cst$kw$recur;
} else {
if((state_val_28456 === (4))){
var inst_28420 = (state_28455[(7)]);
var inst_28420__$1 = (state_28455[(2)]);
var inst_28421 = (inst_28420__$1 == null);
var state_28455__$1 = (function (){var statearr_28460 = state_28455;
(statearr_28460[(7)] = inst_28420__$1);

return statearr_28460;
})();
if(cljs.core.truth_(inst_28421)){
var statearr_28461_28524 = state_28455__$1;
(statearr_28461_28524[(1)] = (5));

} else {
var statearr_28462_28525 = state_28455__$1;
(statearr_28462_28525[(1)] = (6));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_28456 === (15))){
var inst_28433 = (state_28455[(8)]);
var state_28455__$1 = state_28455;
return cljs.core.async.impl.ioc_helpers.put_BANG_(state_28455__$1,(18),to,inst_28433);
} else {
if((state_val_28456 === (21))){
var inst_28446 = (state_28455[(2)]);
var state_28455__$1 = state_28455;
var statearr_28463_28526 = state_28455__$1;
(statearr_28463_28526[(2)] = inst_28446);

(statearr_28463_28526[(1)] = (13));


return cljs.core.cst$kw$recur;
} else {
if((state_val_28456 === (13))){
var inst_28448 = (state_28455[(2)]);
var state_28455__$1 = (function (){var statearr_28464 = state_28455;
(statearr_28464[(9)] = inst_28448);

return statearr_28464;
})();
var statearr_28465_28527 = state_28455__$1;
(statearr_28465_28527[(2)] = null);

(statearr_28465_28527[(1)] = (2));


return cljs.core.cst$kw$recur;
} else {
if((state_val_28456 === (6))){
var inst_28420 = (state_28455[(7)]);
var state_28455__$1 = state_28455;
return cljs.core.async.impl.ioc_helpers.take_BANG_(state_28455__$1,(11),inst_28420);
} else {
if((state_val_28456 === (17))){
var inst_28441 = (state_28455[(2)]);
var state_28455__$1 = state_28455;
if(cljs.core.truth_(inst_28441)){
var statearr_28466_28528 = state_28455__$1;
(statearr_28466_28528[(1)] = (19));

} else {
var statearr_28467_28529 = state_28455__$1;
(statearr_28467_28529[(1)] = (20));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_28456 === (3))){
var inst_28453 = (state_28455[(2)]);
var state_28455__$1 = state_28455;
return cljs.core.async.impl.ioc_helpers.return_chan(state_28455__$1,inst_28453);
} else {
if((state_val_28456 === (12))){
var inst_28430 = (state_28455[(10)]);
var state_28455__$1 = state_28455;
return cljs.core.async.impl.ioc_helpers.take_BANG_(state_28455__$1,(14),inst_28430);
} else {
if((state_val_28456 === (2))){
var state_28455__$1 = state_28455;
return cljs.core.async.impl.ioc_helpers.take_BANG_(state_28455__$1,(4),results);
} else {
if((state_val_28456 === (19))){
var state_28455__$1 = state_28455;
var statearr_28468_28530 = state_28455__$1;
(statearr_28468_28530[(2)] = null);

(statearr_28468_28530[(1)] = (12));


return cljs.core.cst$kw$recur;
} else {
if((state_val_28456 === (11))){
var inst_28430 = (state_28455[(2)]);
var state_28455__$1 = (function (){var statearr_28469 = state_28455;
(statearr_28469[(10)] = inst_28430);

return statearr_28469;
})();
var statearr_28470_28531 = state_28455__$1;
(statearr_28470_28531[(2)] = null);

(statearr_28470_28531[(1)] = (12));


return cljs.core.cst$kw$recur;
} else {
if((state_val_28456 === (9))){
var state_28455__$1 = state_28455;
var statearr_28471_28532 = state_28455__$1;
(statearr_28471_28532[(2)] = null);

(statearr_28471_28532[(1)] = (10));


return cljs.core.cst$kw$recur;
} else {
if((state_val_28456 === (5))){
var state_28455__$1 = state_28455;
if(cljs.core.truth_(close_QMARK_)){
var statearr_28472_28533 = state_28455__$1;
(statearr_28472_28533[(1)] = (8));

} else {
var statearr_28473_28534 = state_28455__$1;
(statearr_28473_28534[(1)] = (9));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_28456 === (14))){
var inst_28433 = (state_28455[(8)]);
var inst_28435 = (state_28455[(11)]);
var inst_28433__$1 = (state_28455[(2)]);
var inst_28434 = (inst_28433__$1 == null);
var inst_28435__$1 = cljs.core.not(inst_28434);
var state_28455__$1 = (function (){var statearr_28474 = state_28455;
(statearr_28474[(8)] = inst_28433__$1);

(statearr_28474[(11)] = inst_28435__$1);

return statearr_28474;
})();
if(inst_28435__$1){
var statearr_28475_28535 = state_28455__$1;
(statearr_28475_28535[(1)] = (15));

} else {
var statearr_28476_28536 = state_28455__$1;
(statearr_28476_28536[(1)] = (16));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_28456 === (16))){
var inst_28435 = (state_28455[(11)]);
var state_28455__$1 = state_28455;
var statearr_28477_28537 = state_28455__$1;
(statearr_28477_28537[(2)] = inst_28435);

(statearr_28477_28537[(1)] = (17));


return cljs.core.cst$kw$recur;
} else {
if((state_val_28456 === (10))){
var inst_28427 = (state_28455[(2)]);
var state_28455__$1 = state_28455;
var statearr_28478_28538 = state_28455__$1;
(statearr_28478_28538[(2)] = inst_28427);

(statearr_28478_28538[(1)] = (7));


return cljs.core.cst$kw$recur;
} else {
if((state_val_28456 === (18))){
var inst_28438 = (state_28455[(2)]);
var state_28455__$1 = state_28455;
var statearr_28479_28539 = state_28455__$1;
(statearr_28479_28539[(2)] = inst_28438);

(statearr_28479_28539[(1)] = (17));


return cljs.core.cst$kw$recur;
} else {
if((state_val_28456 === (8))){
var inst_28424 = cljs.core.async.close_BANG_(to);
var state_28455__$1 = state_28455;
var statearr_28480_28540 = state_28455__$1;
(statearr_28480_28540[(2)] = inst_28424);

(statearr_28480_28540[(1)] = (10));


return cljs.core.cst$kw$recur;
} else {
return null;
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
});})(c__7992__auto__,jobs,results,process,async))
;
return ((function (switch__7885__auto__,c__7992__auto__,jobs,results,process,async){
return (function() {
var cljs$core$async$pipeline_STAR__$_state_machine__7886__auto__ = null;
var cljs$core$async$pipeline_STAR__$_state_machine__7886__auto____0 = (function (){
var statearr_28481 = [null,null,null,null,null,null,null,null,null,null,null,null];
(statearr_28481[(0)] = cljs$core$async$pipeline_STAR__$_state_machine__7886__auto__);

(statearr_28481[(1)] = (1));

return statearr_28481;
});
var cljs$core$async$pipeline_STAR__$_state_machine__7886__auto____1 = (function (state_28455){
while(true){
var ret_value__7887__auto__ = (function (){try{while(true){
var result__7888__auto__ = switch__7885__auto__(state_28455);
if(cljs.core.keyword_identical_QMARK_(result__7888__auto__,cljs.core.cst$kw$recur)){
continue;
} else {
return result__7888__auto__;
}
break;
}
}catch (e28482){if((e28482 instanceof Object)){
var ex__7889__auto__ = e28482;
var statearr_28483_28541 = state_28455;
(statearr_28483_28541[(5)] = ex__7889__auto__);


cljs.core.async.impl.ioc_helpers.process_exception(state_28455);

return cljs.core.cst$kw$recur;
} else {
throw e28482;

}
}})();
if(cljs.core.keyword_identical_QMARK_(ret_value__7887__auto__,cljs.core.cst$kw$recur)){
var G__28542 = state_28455;
state_28455 = G__28542;
continue;
} else {
return ret_value__7887__auto__;
}
break;
}
});
cljs$core$async$pipeline_STAR__$_state_machine__7886__auto__ = function(state_28455){
switch(arguments.length){
case 0:
return cljs$core$async$pipeline_STAR__$_state_machine__7886__auto____0.call(this);
case 1:
return cljs$core$async$pipeline_STAR__$_state_machine__7886__auto____1.call(this,state_28455);
}
throw(new Error('Invalid arity: ' + arguments.length));
};
cljs$core$async$pipeline_STAR__$_state_machine__7886__auto__.cljs$core$IFn$_invoke$arity$0 = cljs$core$async$pipeline_STAR__$_state_machine__7886__auto____0;
cljs$core$async$pipeline_STAR__$_state_machine__7886__auto__.cljs$core$IFn$_invoke$arity$1 = cljs$core$async$pipeline_STAR__$_state_machine__7886__auto____1;
return cljs$core$async$pipeline_STAR__$_state_machine__7886__auto__;
})()
;})(switch__7885__auto__,c__7992__auto__,jobs,results,process,async))
})();
var state__7994__auto__ = (function (){var statearr_28484 = (f__7993__auto__.cljs$core$IFn$_invoke$arity$0 ? f__7993__auto__.cljs$core$IFn$_invoke$arity$0() : f__7993__auto__.call(null));
(statearr_28484[(6)] = c__7992__auto__);

return statearr_28484;
})();
return cljs.core.async.impl.ioc_helpers.run_state_machine_wrapped(state__7994__auto__);
});})(c__7992__auto__,jobs,results,process,async))
);

return c__7992__auto__;
});
/**
 * Takes elements from the from channel and supplies them to the to
 *   channel, subject to the async function af, with parallelism n. af
 *   must be a function of two arguments, the first an input value and
 *   the second a channel on which to place the result(s). af must close!
 *   the channel before returning.  The presumption is that af will
 *   return immediately, having launched some asynchronous operation
 *   whose completion/callback will manipulate the result channel. Outputs
 *   will be returned in order relative to  the inputs. By default, the to
 *   channel will be closed when the from channel closes, but can be
 *   determined by the close?  parameter. Will stop consuming the from
 *   channel if the to channel closes.
 */
cljs.core.async.pipeline_async = (function cljs$core$async$pipeline_async(var_args){
var G__28544 = arguments.length;
switch (G__28544) {
case 4:
return cljs.core.async.pipeline_async.cljs$core$IFn$_invoke$arity$4((arguments[(0)]),(arguments[(1)]),(arguments[(2)]),(arguments[(3)]));

break;
case 5:
return cljs.core.async.pipeline_async.cljs$core$IFn$_invoke$arity$5((arguments[(0)]),(arguments[(1)]),(arguments[(2)]),(arguments[(3)]),(arguments[(4)]));

break;
default:
throw (new Error(["Invalid arity: ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(arguments.length)].join('')));

}
});

cljs.core.async.pipeline_async.cljs$core$IFn$_invoke$arity$4 = (function (n,to,af,from){
return cljs.core.async.pipeline_async.cljs$core$IFn$_invoke$arity$5(n,to,af,from,true);
});

cljs.core.async.pipeline_async.cljs$core$IFn$_invoke$arity$5 = (function (n,to,af,from,close_QMARK_){
return cljs.core.async.pipeline_STAR_(n,to,af,from,close_QMARK_,null,cljs.core.cst$kw$async);
});

cljs.core.async.pipeline_async.cljs$lang$maxFixedArity = 5;

/**
 * Takes elements from the from channel and supplies them to the to
 *   channel, subject to the transducer xf, with parallelism n. Because
 *   it is parallel, the transducer will be applied independently to each
 *   element, not across elements, and may produce zero or more outputs
 *   per input.  Outputs will be returned in order relative to the
 *   inputs. By default, the to channel will be closed when the from
 *   channel closes, but can be determined by the close?  parameter. Will
 *   stop consuming the from channel if the to channel closes.
 * 
 *   Note this is supplied for API compatibility with the Clojure version.
 *   Values of N > 1 will not result in actual concurrency in a
 *   single-threaded runtime.
 */
cljs.core.async.pipeline = (function cljs$core$async$pipeline(var_args){
var G__28547 = arguments.length;
switch (G__28547) {
case 4:
return cljs.core.async.pipeline.cljs$core$IFn$_invoke$arity$4((arguments[(0)]),(arguments[(1)]),(arguments[(2)]),(arguments[(3)]));

break;
case 5:
return cljs.core.async.pipeline.cljs$core$IFn$_invoke$arity$5((arguments[(0)]),(arguments[(1)]),(arguments[(2)]),(arguments[(3)]),(arguments[(4)]));

break;
case 6:
return cljs.core.async.pipeline.cljs$core$IFn$_invoke$arity$6((arguments[(0)]),(arguments[(1)]),(arguments[(2)]),(arguments[(3)]),(arguments[(4)]),(arguments[(5)]));

break;
default:
throw (new Error(["Invalid arity: ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(arguments.length)].join('')));

}
});

cljs.core.async.pipeline.cljs$core$IFn$_invoke$arity$4 = (function (n,to,xf,from){
return cljs.core.async.pipeline.cljs$core$IFn$_invoke$arity$5(n,to,xf,from,true);
});

cljs.core.async.pipeline.cljs$core$IFn$_invoke$arity$5 = (function (n,to,xf,from,close_QMARK_){
return cljs.core.async.pipeline.cljs$core$IFn$_invoke$arity$6(n,to,xf,from,close_QMARK_,null);
});

cljs.core.async.pipeline.cljs$core$IFn$_invoke$arity$6 = (function (n,to,xf,from,close_QMARK_,ex_handler){
return cljs.core.async.pipeline_STAR_(n,to,xf,from,close_QMARK_,ex_handler,cljs.core.cst$kw$compute);
});

cljs.core.async.pipeline.cljs$lang$maxFixedArity = 6;

/**
 * Takes a predicate and a source channel and returns a vector of two
 *   channels, the first of which will contain the values for which the
 *   predicate returned true, the second those for which it returned
 *   false.
 * 
 *   The out channels will be unbuffered by default, or two buf-or-ns can
 *   be supplied. The channels will close after the source channel has
 *   closed.
 */
cljs.core.async.split = (function cljs$core$async$split(var_args){
var G__28550 = arguments.length;
switch (G__28550) {
case 2:
return cljs.core.async.split.cljs$core$IFn$_invoke$arity$2((arguments[(0)]),(arguments[(1)]));

break;
case 4:
return cljs.core.async.split.cljs$core$IFn$_invoke$arity$4((arguments[(0)]),(arguments[(1)]),(arguments[(2)]),(arguments[(3)]));

break;
default:
throw (new Error(["Invalid arity: ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(arguments.length)].join('')));

}
});

cljs.core.async.split.cljs$core$IFn$_invoke$arity$2 = (function (p,ch){
return cljs.core.async.split.cljs$core$IFn$_invoke$arity$4(p,ch,null,null);
});

cljs.core.async.split.cljs$core$IFn$_invoke$arity$4 = (function (p,ch,t_buf_or_n,f_buf_or_n){
var tc = cljs.core.async.chan.cljs$core$IFn$_invoke$arity$1(t_buf_or_n);
var fc = cljs.core.async.chan.cljs$core$IFn$_invoke$arity$1(f_buf_or_n);
var c__7992__auto___28599 = cljs.core.async.chan.cljs$core$IFn$_invoke$arity$1((1));
cljs.core.async.impl.dispatch.run(((function (c__7992__auto___28599,tc,fc){
return (function (){
var f__7993__auto__ = (function (){var switch__7885__auto__ = ((function (c__7992__auto___28599,tc,fc){
return (function (state_28576){
var state_val_28577 = (state_28576[(1)]);
if((state_val_28577 === (7))){
var inst_28572 = (state_28576[(2)]);
var state_28576__$1 = state_28576;
var statearr_28578_28600 = state_28576__$1;
(statearr_28578_28600[(2)] = inst_28572);

(statearr_28578_28600[(1)] = (3));


return cljs.core.cst$kw$recur;
} else {
if((state_val_28577 === (1))){
var state_28576__$1 = state_28576;
var statearr_28579_28601 = state_28576__$1;
(statearr_28579_28601[(2)] = null);

(statearr_28579_28601[(1)] = (2));


return cljs.core.cst$kw$recur;
} else {
if((state_val_28577 === (4))){
var inst_28553 = (state_28576[(7)]);
var inst_28553__$1 = (state_28576[(2)]);
var inst_28554 = (inst_28553__$1 == null);
var state_28576__$1 = (function (){var statearr_28580 = state_28576;
(statearr_28580[(7)] = inst_28553__$1);

return statearr_28580;
})();
if(cljs.core.truth_(inst_28554)){
var statearr_28581_28602 = state_28576__$1;
(statearr_28581_28602[(1)] = (5));

} else {
var statearr_28582_28603 = state_28576__$1;
(statearr_28582_28603[(1)] = (6));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_28577 === (13))){
var state_28576__$1 = state_28576;
var statearr_28583_28604 = state_28576__$1;
(statearr_28583_28604[(2)] = null);

(statearr_28583_28604[(1)] = (14));


return cljs.core.cst$kw$recur;
} else {
if((state_val_28577 === (6))){
var inst_28553 = (state_28576[(7)]);
var inst_28559 = (p.cljs$core$IFn$_invoke$arity$1 ? p.cljs$core$IFn$_invoke$arity$1(inst_28553) : p.call(null,inst_28553));
var state_28576__$1 = state_28576;
if(cljs.core.truth_(inst_28559)){
var statearr_28584_28605 = state_28576__$1;
(statearr_28584_28605[(1)] = (9));

} else {
var statearr_28585_28606 = state_28576__$1;
(statearr_28585_28606[(1)] = (10));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_28577 === (3))){
var inst_28574 = (state_28576[(2)]);
var state_28576__$1 = state_28576;
return cljs.core.async.impl.ioc_helpers.return_chan(state_28576__$1,inst_28574);
} else {
if((state_val_28577 === (12))){
var state_28576__$1 = state_28576;
var statearr_28586_28607 = state_28576__$1;
(statearr_28586_28607[(2)] = null);

(statearr_28586_28607[(1)] = (2));


return cljs.core.cst$kw$recur;
} else {
if((state_val_28577 === (2))){
var state_28576__$1 = state_28576;
return cljs.core.async.impl.ioc_helpers.take_BANG_(state_28576__$1,(4),ch);
} else {
if((state_val_28577 === (11))){
var inst_28553 = (state_28576[(7)]);
var inst_28563 = (state_28576[(2)]);
var state_28576__$1 = state_28576;
return cljs.core.async.impl.ioc_helpers.put_BANG_(state_28576__$1,(8),inst_28563,inst_28553);
} else {
if((state_val_28577 === (9))){
var state_28576__$1 = state_28576;
var statearr_28587_28608 = state_28576__$1;
(statearr_28587_28608[(2)] = tc);

(statearr_28587_28608[(1)] = (11));


return cljs.core.cst$kw$recur;
} else {
if((state_val_28577 === (5))){
var inst_28556 = cljs.core.async.close_BANG_(tc);
var inst_28557 = cljs.core.async.close_BANG_(fc);
var state_28576__$1 = (function (){var statearr_28588 = state_28576;
(statearr_28588[(8)] = inst_28556);

return statearr_28588;
})();
var statearr_28589_28609 = state_28576__$1;
(statearr_28589_28609[(2)] = inst_28557);

(statearr_28589_28609[(1)] = (7));


return cljs.core.cst$kw$recur;
} else {
if((state_val_28577 === (14))){
var inst_28570 = (state_28576[(2)]);
var state_28576__$1 = state_28576;
var statearr_28590_28610 = state_28576__$1;
(statearr_28590_28610[(2)] = inst_28570);

(statearr_28590_28610[(1)] = (7));


return cljs.core.cst$kw$recur;
} else {
if((state_val_28577 === (10))){
var state_28576__$1 = state_28576;
var statearr_28591_28611 = state_28576__$1;
(statearr_28591_28611[(2)] = fc);

(statearr_28591_28611[(1)] = (11));


return cljs.core.cst$kw$recur;
} else {
if((state_val_28577 === (8))){
var inst_28565 = (state_28576[(2)]);
var state_28576__$1 = state_28576;
if(cljs.core.truth_(inst_28565)){
var statearr_28592_28612 = state_28576__$1;
(statearr_28592_28612[(1)] = (12));

} else {
var statearr_28593_28613 = state_28576__$1;
(statearr_28593_28613[(1)] = (13));

}

return cljs.core.cst$kw$recur;
} else {
return null;
}
}
}
}
}
}
}
}
}
}
}
}
}
}
});})(c__7992__auto___28599,tc,fc))
;
return ((function (switch__7885__auto__,c__7992__auto___28599,tc,fc){
return (function() {
var cljs$core$async$state_machine__7886__auto__ = null;
var cljs$core$async$state_machine__7886__auto____0 = (function (){
var statearr_28594 = [null,null,null,null,null,null,null,null,null];
(statearr_28594[(0)] = cljs$core$async$state_machine__7886__auto__);

(statearr_28594[(1)] = (1));

return statearr_28594;
});
var cljs$core$async$state_machine__7886__auto____1 = (function (state_28576){
while(true){
var ret_value__7887__auto__ = (function (){try{while(true){
var result__7888__auto__ = switch__7885__auto__(state_28576);
if(cljs.core.keyword_identical_QMARK_(result__7888__auto__,cljs.core.cst$kw$recur)){
continue;
} else {
return result__7888__auto__;
}
break;
}
}catch (e28595){if((e28595 instanceof Object)){
var ex__7889__auto__ = e28595;
var statearr_28596_28614 = state_28576;
(statearr_28596_28614[(5)] = ex__7889__auto__);


cljs.core.async.impl.ioc_helpers.process_exception(state_28576);

return cljs.core.cst$kw$recur;
} else {
throw e28595;

}
}})();
if(cljs.core.keyword_identical_QMARK_(ret_value__7887__auto__,cljs.core.cst$kw$recur)){
var G__28615 = state_28576;
state_28576 = G__28615;
continue;
} else {
return ret_value__7887__auto__;
}
break;
}
});
cljs$core$async$state_machine__7886__auto__ = function(state_28576){
switch(arguments.length){
case 0:
return cljs$core$async$state_machine__7886__auto____0.call(this);
case 1:
return cljs$core$async$state_machine__7886__auto____1.call(this,state_28576);
}
throw(new Error('Invalid arity: ' + arguments.length));
};
cljs$core$async$state_machine__7886__auto__.cljs$core$IFn$_invoke$arity$0 = cljs$core$async$state_machine__7886__auto____0;
cljs$core$async$state_machine__7886__auto__.cljs$core$IFn$_invoke$arity$1 = cljs$core$async$state_machine__7886__auto____1;
return cljs$core$async$state_machine__7886__auto__;
})()
;})(switch__7885__auto__,c__7992__auto___28599,tc,fc))
})();
var state__7994__auto__ = (function (){var statearr_28597 = (f__7993__auto__.cljs$core$IFn$_invoke$arity$0 ? f__7993__auto__.cljs$core$IFn$_invoke$arity$0() : f__7993__auto__.call(null));
(statearr_28597[(6)] = c__7992__auto___28599);

return statearr_28597;
})();
return cljs.core.async.impl.ioc_helpers.run_state_machine_wrapped(state__7994__auto__);
});})(c__7992__auto___28599,tc,fc))
);


return new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [tc,fc], null);
});

cljs.core.async.split.cljs$lang$maxFixedArity = 4;

/**
 * f should be a function of 2 arguments. Returns a channel containing
 *   the single result of applying f to init and the first item from the
 *   channel, then applying f to that result and the 2nd item, etc. If
 *   the channel closes without yielding items, returns init and f is not
 *   called. ch must close before reduce produces a result.
 */
cljs.core.async.reduce = (function cljs$core$async$reduce(f,init,ch){
var c__7992__auto__ = cljs.core.async.chan.cljs$core$IFn$_invoke$arity$1((1));
cljs.core.async.impl.dispatch.run(((function (c__7992__auto__){
return (function (){
var f__7993__auto__ = (function (){var switch__7885__auto__ = ((function (c__7992__auto__){
return (function (state_28636){
var state_val_28637 = (state_28636[(1)]);
if((state_val_28637 === (7))){
var inst_28632 = (state_28636[(2)]);
var state_28636__$1 = state_28636;
var statearr_28638_28656 = state_28636__$1;
(statearr_28638_28656[(2)] = inst_28632);

(statearr_28638_28656[(1)] = (3));


return cljs.core.cst$kw$recur;
} else {
if((state_val_28637 === (1))){
var inst_28616 = init;
var state_28636__$1 = (function (){var statearr_28639 = state_28636;
(statearr_28639[(7)] = inst_28616);

return statearr_28639;
})();
var statearr_28640_28657 = state_28636__$1;
(statearr_28640_28657[(2)] = null);

(statearr_28640_28657[(1)] = (2));


return cljs.core.cst$kw$recur;
} else {
if((state_val_28637 === (4))){
var inst_28619 = (state_28636[(8)]);
var inst_28619__$1 = (state_28636[(2)]);
var inst_28620 = (inst_28619__$1 == null);
var state_28636__$1 = (function (){var statearr_28641 = state_28636;
(statearr_28641[(8)] = inst_28619__$1);

return statearr_28641;
})();
if(cljs.core.truth_(inst_28620)){
var statearr_28642_28658 = state_28636__$1;
(statearr_28642_28658[(1)] = (5));

} else {
var statearr_28643_28659 = state_28636__$1;
(statearr_28643_28659[(1)] = (6));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_28637 === (6))){
var inst_28616 = (state_28636[(7)]);
var inst_28619 = (state_28636[(8)]);
var inst_28623 = (state_28636[(9)]);
var inst_28623__$1 = (f.cljs$core$IFn$_invoke$arity$2 ? f.cljs$core$IFn$_invoke$arity$2(inst_28616,inst_28619) : f.call(null,inst_28616,inst_28619));
var inst_28624 = cljs.core.reduced_QMARK_(inst_28623__$1);
var state_28636__$1 = (function (){var statearr_28644 = state_28636;
(statearr_28644[(9)] = inst_28623__$1);

return statearr_28644;
})();
if(inst_28624){
var statearr_28645_28660 = state_28636__$1;
(statearr_28645_28660[(1)] = (8));

} else {
var statearr_28646_28661 = state_28636__$1;
(statearr_28646_28661[(1)] = (9));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_28637 === (3))){
var inst_28634 = (state_28636[(2)]);
var state_28636__$1 = state_28636;
return cljs.core.async.impl.ioc_helpers.return_chan(state_28636__$1,inst_28634);
} else {
if((state_val_28637 === (2))){
var state_28636__$1 = state_28636;
return cljs.core.async.impl.ioc_helpers.take_BANG_(state_28636__$1,(4),ch);
} else {
if((state_val_28637 === (9))){
var inst_28623 = (state_28636[(9)]);
var inst_28616 = inst_28623;
var state_28636__$1 = (function (){var statearr_28647 = state_28636;
(statearr_28647[(7)] = inst_28616);

return statearr_28647;
})();
var statearr_28648_28662 = state_28636__$1;
(statearr_28648_28662[(2)] = null);

(statearr_28648_28662[(1)] = (2));


return cljs.core.cst$kw$recur;
} else {
if((state_val_28637 === (5))){
var inst_28616 = (state_28636[(7)]);
var state_28636__$1 = state_28636;
var statearr_28649_28663 = state_28636__$1;
(statearr_28649_28663[(2)] = inst_28616);

(statearr_28649_28663[(1)] = (7));


return cljs.core.cst$kw$recur;
} else {
if((state_val_28637 === (10))){
var inst_28630 = (state_28636[(2)]);
var state_28636__$1 = state_28636;
var statearr_28650_28664 = state_28636__$1;
(statearr_28650_28664[(2)] = inst_28630);

(statearr_28650_28664[(1)] = (7));


return cljs.core.cst$kw$recur;
} else {
if((state_val_28637 === (8))){
var inst_28623 = (state_28636[(9)]);
var inst_28626 = cljs.core.deref(inst_28623);
var state_28636__$1 = state_28636;
var statearr_28651_28665 = state_28636__$1;
(statearr_28651_28665[(2)] = inst_28626);

(statearr_28651_28665[(1)] = (10));


return cljs.core.cst$kw$recur;
} else {
return null;
}
}
}
}
}
}
}
}
}
}
});})(c__7992__auto__))
;
return ((function (switch__7885__auto__,c__7992__auto__){
return (function() {
var cljs$core$async$reduce_$_state_machine__7886__auto__ = null;
var cljs$core$async$reduce_$_state_machine__7886__auto____0 = (function (){
var statearr_28652 = [null,null,null,null,null,null,null,null,null,null];
(statearr_28652[(0)] = cljs$core$async$reduce_$_state_machine__7886__auto__);

(statearr_28652[(1)] = (1));

return statearr_28652;
});
var cljs$core$async$reduce_$_state_machine__7886__auto____1 = (function (state_28636){
while(true){
var ret_value__7887__auto__ = (function (){try{while(true){
var result__7888__auto__ = switch__7885__auto__(state_28636);
if(cljs.core.keyword_identical_QMARK_(result__7888__auto__,cljs.core.cst$kw$recur)){
continue;
} else {
return result__7888__auto__;
}
break;
}
}catch (e28653){if((e28653 instanceof Object)){
var ex__7889__auto__ = e28653;
var statearr_28654_28666 = state_28636;
(statearr_28654_28666[(5)] = ex__7889__auto__);


cljs.core.async.impl.ioc_helpers.process_exception(state_28636);

return cljs.core.cst$kw$recur;
} else {
throw e28653;

}
}})();
if(cljs.core.keyword_identical_QMARK_(ret_value__7887__auto__,cljs.core.cst$kw$recur)){
var G__28667 = state_28636;
state_28636 = G__28667;
continue;
} else {
return ret_value__7887__auto__;
}
break;
}
});
cljs$core$async$reduce_$_state_machine__7886__auto__ = function(state_28636){
switch(arguments.length){
case 0:
return cljs$core$async$reduce_$_state_machine__7886__auto____0.call(this);
case 1:
return cljs$core$async$reduce_$_state_machine__7886__auto____1.call(this,state_28636);
}
throw(new Error('Invalid arity: ' + arguments.length));
};
cljs$core$async$reduce_$_state_machine__7886__auto__.cljs$core$IFn$_invoke$arity$0 = cljs$core$async$reduce_$_state_machine__7886__auto____0;
cljs$core$async$reduce_$_state_machine__7886__auto__.cljs$core$IFn$_invoke$arity$1 = cljs$core$async$reduce_$_state_machine__7886__auto____1;
return cljs$core$async$reduce_$_state_machine__7886__auto__;
})()
;})(switch__7885__auto__,c__7992__auto__))
})();
var state__7994__auto__ = (function (){var statearr_28655 = (f__7993__auto__.cljs$core$IFn$_invoke$arity$0 ? f__7993__auto__.cljs$core$IFn$_invoke$arity$0() : f__7993__auto__.call(null));
(statearr_28655[(6)] = c__7992__auto__);

return statearr_28655;
})();
return cljs.core.async.impl.ioc_helpers.run_state_machine_wrapped(state__7994__auto__);
});})(c__7992__auto__))
);

return c__7992__auto__;
});
/**
 * async/reduces a channel with a transformation (xform f).
 *   Returns a channel containing the result.  ch must close before
 *   transduce produces a result.
 */
cljs.core.async.transduce = (function cljs$core$async$transduce(xform,f,init,ch){
var f__$1 = (xform.cljs$core$IFn$_invoke$arity$1 ? xform.cljs$core$IFn$_invoke$arity$1(f) : xform.call(null,f));
var c__7992__auto__ = cljs.core.async.chan.cljs$core$IFn$_invoke$arity$1((1));
cljs.core.async.impl.dispatch.run(((function (c__7992__auto__,f__$1){
return (function (){
var f__7993__auto__ = (function (){var switch__7885__auto__ = ((function (c__7992__auto__,f__$1){
return (function (state_28673){
var state_val_28674 = (state_28673[(1)]);
if((state_val_28674 === (1))){
var inst_28668 = cljs.core.async.reduce(f__$1,init,ch);
var state_28673__$1 = state_28673;
return cljs.core.async.impl.ioc_helpers.take_BANG_(state_28673__$1,(2),inst_28668);
} else {
if((state_val_28674 === (2))){
var inst_28670 = (state_28673[(2)]);
var inst_28671 = (f__$1.cljs$core$IFn$_invoke$arity$1 ? f__$1.cljs$core$IFn$_invoke$arity$1(inst_28670) : f__$1.call(null,inst_28670));
var state_28673__$1 = state_28673;
return cljs.core.async.impl.ioc_helpers.return_chan(state_28673__$1,inst_28671);
} else {
return null;
}
}
});})(c__7992__auto__,f__$1))
;
return ((function (switch__7885__auto__,c__7992__auto__,f__$1){
return (function() {
var cljs$core$async$transduce_$_state_machine__7886__auto__ = null;
var cljs$core$async$transduce_$_state_machine__7886__auto____0 = (function (){
var statearr_28675 = [null,null,null,null,null,null,null];
(statearr_28675[(0)] = cljs$core$async$transduce_$_state_machine__7886__auto__);

(statearr_28675[(1)] = (1));

return statearr_28675;
});
var cljs$core$async$transduce_$_state_machine__7886__auto____1 = (function (state_28673){
while(true){
var ret_value__7887__auto__ = (function (){try{while(true){
var result__7888__auto__ = switch__7885__auto__(state_28673);
if(cljs.core.keyword_identical_QMARK_(result__7888__auto__,cljs.core.cst$kw$recur)){
continue;
} else {
return result__7888__auto__;
}
break;
}
}catch (e28676){if((e28676 instanceof Object)){
var ex__7889__auto__ = e28676;
var statearr_28677_28679 = state_28673;
(statearr_28677_28679[(5)] = ex__7889__auto__);


cljs.core.async.impl.ioc_helpers.process_exception(state_28673);

return cljs.core.cst$kw$recur;
} else {
throw e28676;

}
}})();
if(cljs.core.keyword_identical_QMARK_(ret_value__7887__auto__,cljs.core.cst$kw$recur)){
var G__28680 = state_28673;
state_28673 = G__28680;
continue;
} else {
return ret_value__7887__auto__;
}
break;
}
});
cljs$core$async$transduce_$_state_machine__7886__auto__ = function(state_28673){
switch(arguments.length){
case 0:
return cljs$core$async$transduce_$_state_machine__7886__auto____0.call(this);
case 1:
return cljs$core$async$transduce_$_state_machine__7886__auto____1.call(this,state_28673);
}
throw(new Error('Invalid arity: ' + arguments.length));
};
cljs$core$async$transduce_$_state_machine__7886__auto__.cljs$core$IFn$_invoke$arity$0 = cljs$core$async$transduce_$_state_machine__7886__auto____0;
cljs$core$async$transduce_$_state_machine__7886__auto__.cljs$core$IFn$_invoke$arity$1 = cljs$core$async$transduce_$_state_machine__7886__auto____1;
return cljs$core$async$transduce_$_state_machine__7886__auto__;
})()
;})(switch__7885__auto__,c__7992__auto__,f__$1))
})();
var state__7994__auto__ = (function (){var statearr_28678 = (f__7993__auto__.cljs$core$IFn$_invoke$arity$0 ? f__7993__auto__.cljs$core$IFn$_invoke$arity$0() : f__7993__auto__.call(null));
(statearr_28678[(6)] = c__7992__auto__);

return statearr_28678;
})();
return cljs.core.async.impl.ioc_helpers.run_state_machine_wrapped(state__7994__auto__);
});})(c__7992__auto__,f__$1))
);

return c__7992__auto__;
});
/**
 * Puts the contents of coll into the supplied channel.
 * 
 *   By default the channel will be closed after the items are copied,
 *   but can be determined by the close? parameter.
 * 
 *   Returns a channel which will close after the items are copied.
 */
cljs.core.async.onto_chan = (function cljs$core$async$onto_chan(var_args){
var G__28682 = arguments.length;
switch (G__28682) {
case 2:
return cljs.core.async.onto_chan.cljs$core$IFn$_invoke$arity$2((arguments[(0)]),(arguments[(1)]));

break;
case 3:
return cljs.core.async.onto_chan.cljs$core$IFn$_invoke$arity$3((arguments[(0)]),(arguments[(1)]),(arguments[(2)]));

break;
default:
throw (new Error(["Invalid arity: ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(arguments.length)].join('')));

}
});

cljs.core.async.onto_chan.cljs$core$IFn$_invoke$arity$2 = (function (ch,coll){
return cljs.core.async.onto_chan.cljs$core$IFn$_invoke$arity$3(ch,coll,true);
});

cljs.core.async.onto_chan.cljs$core$IFn$_invoke$arity$3 = (function (ch,coll,close_QMARK_){
var c__7992__auto__ = cljs.core.async.chan.cljs$core$IFn$_invoke$arity$1((1));
cljs.core.async.impl.dispatch.run(((function (c__7992__auto__){
return (function (){
var f__7993__auto__ = (function (){var switch__7885__auto__ = ((function (c__7992__auto__){
return (function (state_28707){
var state_val_28708 = (state_28707[(1)]);
if((state_val_28708 === (7))){
var inst_28689 = (state_28707[(2)]);
var state_28707__$1 = state_28707;
var statearr_28709_28730 = state_28707__$1;
(statearr_28709_28730[(2)] = inst_28689);

(statearr_28709_28730[(1)] = (6));


return cljs.core.cst$kw$recur;
} else {
if((state_val_28708 === (1))){
var inst_28683 = cljs.core.seq(coll);
var inst_28684 = inst_28683;
var state_28707__$1 = (function (){var statearr_28710 = state_28707;
(statearr_28710[(7)] = inst_28684);

return statearr_28710;
})();
var statearr_28711_28731 = state_28707__$1;
(statearr_28711_28731[(2)] = null);

(statearr_28711_28731[(1)] = (2));


return cljs.core.cst$kw$recur;
} else {
if((state_val_28708 === (4))){
var inst_28684 = (state_28707[(7)]);
var inst_28687 = cljs.core.first(inst_28684);
var state_28707__$1 = state_28707;
return cljs.core.async.impl.ioc_helpers.put_BANG_(state_28707__$1,(7),ch,inst_28687);
} else {
if((state_val_28708 === (13))){
var inst_28701 = (state_28707[(2)]);
var state_28707__$1 = state_28707;
var statearr_28712_28732 = state_28707__$1;
(statearr_28712_28732[(2)] = inst_28701);

(statearr_28712_28732[(1)] = (10));


return cljs.core.cst$kw$recur;
} else {
if((state_val_28708 === (6))){
var inst_28692 = (state_28707[(2)]);
var state_28707__$1 = state_28707;
if(cljs.core.truth_(inst_28692)){
var statearr_28713_28733 = state_28707__$1;
(statearr_28713_28733[(1)] = (8));

} else {
var statearr_28714_28734 = state_28707__$1;
(statearr_28714_28734[(1)] = (9));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_28708 === (3))){
var inst_28705 = (state_28707[(2)]);
var state_28707__$1 = state_28707;
return cljs.core.async.impl.ioc_helpers.return_chan(state_28707__$1,inst_28705);
} else {
if((state_val_28708 === (12))){
var state_28707__$1 = state_28707;
var statearr_28715_28735 = state_28707__$1;
(statearr_28715_28735[(2)] = null);

(statearr_28715_28735[(1)] = (13));


return cljs.core.cst$kw$recur;
} else {
if((state_val_28708 === (2))){
var inst_28684 = (state_28707[(7)]);
var state_28707__$1 = state_28707;
if(cljs.core.truth_(inst_28684)){
var statearr_28716_28736 = state_28707__$1;
(statearr_28716_28736[(1)] = (4));

} else {
var statearr_28717_28737 = state_28707__$1;
(statearr_28717_28737[(1)] = (5));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_28708 === (11))){
var inst_28698 = cljs.core.async.close_BANG_(ch);
var state_28707__$1 = state_28707;
var statearr_28718_28738 = state_28707__$1;
(statearr_28718_28738[(2)] = inst_28698);

(statearr_28718_28738[(1)] = (13));


return cljs.core.cst$kw$recur;
} else {
if((state_val_28708 === (9))){
var state_28707__$1 = state_28707;
if(cljs.core.truth_(close_QMARK_)){
var statearr_28719_28739 = state_28707__$1;
(statearr_28719_28739[(1)] = (11));

} else {
var statearr_28720_28740 = state_28707__$1;
(statearr_28720_28740[(1)] = (12));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_28708 === (5))){
var inst_28684 = (state_28707[(7)]);
var state_28707__$1 = state_28707;
var statearr_28721_28741 = state_28707__$1;
(statearr_28721_28741[(2)] = inst_28684);

(statearr_28721_28741[(1)] = (6));


return cljs.core.cst$kw$recur;
} else {
if((state_val_28708 === (10))){
var inst_28703 = (state_28707[(2)]);
var state_28707__$1 = state_28707;
var statearr_28722_28742 = state_28707__$1;
(statearr_28722_28742[(2)] = inst_28703);

(statearr_28722_28742[(1)] = (3));


return cljs.core.cst$kw$recur;
} else {
if((state_val_28708 === (8))){
var inst_28684 = (state_28707[(7)]);
var inst_28694 = cljs.core.next(inst_28684);
var inst_28684__$1 = inst_28694;
var state_28707__$1 = (function (){var statearr_28723 = state_28707;
(statearr_28723[(7)] = inst_28684__$1);

return statearr_28723;
})();
var statearr_28724_28743 = state_28707__$1;
(statearr_28724_28743[(2)] = null);

(statearr_28724_28743[(1)] = (2));


return cljs.core.cst$kw$recur;
} else {
return null;
}
}
}
}
}
}
}
}
}
}
}
}
}
});})(c__7992__auto__))
;
return ((function (switch__7885__auto__,c__7992__auto__){
return (function() {
var cljs$core$async$state_machine__7886__auto__ = null;
var cljs$core$async$state_machine__7886__auto____0 = (function (){
var statearr_28725 = [null,null,null,null,null,null,null,null];
(statearr_28725[(0)] = cljs$core$async$state_machine__7886__auto__);

(statearr_28725[(1)] = (1));

return statearr_28725;
});
var cljs$core$async$state_machine__7886__auto____1 = (function (state_28707){
while(true){
var ret_value__7887__auto__ = (function (){try{while(true){
var result__7888__auto__ = switch__7885__auto__(state_28707);
if(cljs.core.keyword_identical_QMARK_(result__7888__auto__,cljs.core.cst$kw$recur)){
continue;
} else {
return result__7888__auto__;
}
break;
}
}catch (e28726){if((e28726 instanceof Object)){
var ex__7889__auto__ = e28726;
var statearr_28727_28744 = state_28707;
(statearr_28727_28744[(5)] = ex__7889__auto__);


cljs.core.async.impl.ioc_helpers.process_exception(state_28707);

return cljs.core.cst$kw$recur;
} else {
throw e28726;

}
}})();
if(cljs.core.keyword_identical_QMARK_(ret_value__7887__auto__,cljs.core.cst$kw$recur)){
var G__28745 = state_28707;
state_28707 = G__28745;
continue;
} else {
return ret_value__7887__auto__;
}
break;
}
});
cljs$core$async$state_machine__7886__auto__ = function(state_28707){
switch(arguments.length){
case 0:
return cljs$core$async$state_machine__7886__auto____0.call(this);
case 1:
return cljs$core$async$state_machine__7886__auto____1.call(this,state_28707);
}
throw(new Error('Invalid arity: ' + arguments.length));
};
cljs$core$async$state_machine__7886__auto__.cljs$core$IFn$_invoke$arity$0 = cljs$core$async$state_machine__7886__auto____0;
cljs$core$async$state_machine__7886__auto__.cljs$core$IFn$_invoke$arity$1 = cljs$core$async$state_machine__7886__auto____1;
return cljs$core$async$state_machine__7886__auto__;
})()
;})(switch__7885__auto__,c__7992__auto__))
})();
var state__7994__auto__ = (function (){var statearr_28728 = (f__7993__auto__.cljs$core$IFn$_invoke$arity$0 ? f__7993__auto__.cljs$core$IFn$_invoke$arity$0() : f__7993__auto__.call(null));
(statearr_28728[(6)] = c__7992__auto__);

return statearr_28728;
})();
return cljs.core.async.impl.ioc_helpers.run_state_machine_wrapped(state__7994__auto__);
});})(c__7992__auto__))
);

return c__7992__auto__;
});

cljs.core.async.onto_chan.cljs$lang$maxFixedArity = 3;

/**
 * Creates and returns a channel which contains the contents of coll,
 *   closing when exhausted.
 */
cljs.core.async.to_chan = (function cljs$core$async$to_chan(coll){
var ch = cljs.core.async.chan.cljs$core$IFn$_invoke$arity$1(cljs.core.bounded_count((100),coll));
cljs.core.async.onto_chan.cljs$core$IFn$_invoke$arity$2(ch,coll);

return ch;
});

/**
 * @interface
 */
cljs.core.async.Mux = function(){};

cljs.core.async.muxch_STAR_ = (function cljs$core$async$muxch_STAR_(_){
if((((!((_ == null)))) && ((!((_.cljs$core$async$Mux$muxch_STAR_$arity$1 == null)))))){
return _.cljs$core$async$Mux$muxch_STAR_$arity$1(_);
} else {
var x__4347__auto__ = (((_ == null))?null:_);
var m__4348__auto__ = (cljs.core.async.muxch_STAR_[goog.typeOf(x__4347__auto__)]);
if((!((m__4348__auto__ == null)))){
return (m__4348__auto__.cljs$core$IFn$_invoke$arity$1 ? m__4348__auto__.cljs$core$IFn$_invoke$arity$1(_) : m__4348__auto__.call(null,_));
} else {
var m__4348__auto____$1 = (cljs.core.async.muxch_STAR_["_"]);
if((!((m__4348__auto____$1 == null)))){
return (m__4348__auto____$1.cljs$core$IFn$_invoke$arity$1 ? m__4348__auto____$1.cljs$core$IFn$_invoke$arity$1(_) : m__4348__auto____$1.call(null,_));
} else {
throw cljs.core.missing_protocol("Mux.muxch*",_);
}
}
}
});


/**
 * @interface
 */
cljs.core.async.Mult = function(){};

cljs.core.async.tap_STAR_ = (function cljs$core$async$tap_STAR_(m,ch,close_QMARK_){
if((((!((m == null)))) && ((!((m.cljs$core$async$Mult$tap_STAR_$arity$3 == null)))))){
return m.cljs$core$async$Mult$tap_STAR_$arity$3(m,ch,close_QMARK_);
} else {
var x__4347__auto__ = (((m == null))?null:m);
var m__4348__auto__ = (cljs.core.async.tap_STAR_[goog.typeOf(x__4347__auto__)]);
if((!((m__4348__auto__ == null)))){
return (m__4348__auto__.cljs$core$IFn$_invoke$arity$3 ? m__4348__auto__.cljs$core$IFn$_invoke$arity$3(m,ch,close_QMARK_) : m__4348__auto__.call(null,m,ch,close_QMARK_));
} else {
var m__4348__auto____$1 = (cljs.core.async.tap_STAR_["_"]);
if((!((m__4348__auto____$1 == null)))){
return (m__4348__auto____$1.cljs$core$IFn$_invoke$arity$3 ? m__4348__auto____$1.cljs$core$IFn$_invoke$arity$3(m,ch,close_QMARK_) : m__4348__auto____$1.call(null,m,ch,close_QMARK_));
} else {
throw cljs.core.missing_protocol("Mult.tap*",m);
}
}
}
});

cljs.core.async.untap_STAR_ = (function cljs$core$async$untap_STAR_(m,ch){
if((((!((m == null)))) && ((!((m.cljs$core$async$Mult$untap_STAR_$arity$2 == null)))))){
return m.cljs$core$async$Mult$untap_STAR_$arity$2(m,ch);
} else {
var x__4347__auto__ = (((m == null))?null:m);
var m__4348__auto__ = (cljs.core.async.untap_STAR_[goog.typeOf(x__4347__auto__)]);
if((!((m__4348__auto__ == null)))){
return (m__4348__auto__.cljs$core$IFn$_invoke$arity$2 ? m__4348__auto__.cljs$core$IFn$_invoke$arity$2(m,ch) : m__4348__auto__.call(null,m,ch));
} else {
var m__4348__auto____$1 = (cljs.core.async.untap_STAR_["_"]);
if((!((m__4348__auto____$1 == null)))){
return (m__4348__auto____$1.cljs$core$IFn$_invoke$arity$2 ? m__4348__auto____$1.cljs$core$IFn$_invoke$arity$2(m,ch) : m__4348__auto____$1.call(null,m,ch));
} else {
throw cljs.core.missing_protocol("Mult.untap*",m);
}
}
}
});

cljs.core.async.untap_all_STAR_ = (function cljs$core$async$untap_all_STAR_(m){
if((((!((m == null)))) && ((!((m.cljs$core$async$Mult$untap_all_STAR_$arity$1 == null)))))){
return m.cljs$core$async$Mult$untap_all_STAR_$arity$1(m);
} else {
var x__4347__auto__ = (((m == null))?null:m);
var m__4348__auto__ = (cljs.core.async.untap_all_STAR_[goog.typeOf(x__4347__auto__)]);
if((!((m__4348__auto__ == null)))){
return (m__4348__auto__.cljs$core$IFn$_invoke$arity$1 ? m__4348__auto__.cljs$core$IFn$_invoke$arity$1(m) : m__4348__auto__.call(null,m));
} else {
var m__4348__auto____$1 = (cljs.core.async.untap_all_STAR_["_"]);
if((!((m__4348__auto____$1 == null)))){
return (m__4348__auto____$1.cljs$core$IFn$_invoke$arity$1 ? m__4348__auto____$1.cljs$core$IFn$_invoke$arity$1(m) : m__4348__auto____$1.call(null,m));
} else {
throw cljs.core.missing_protocol("Mult.untap-all*",m);
}
}
}
});

/**
 * Creates and returns a mult(iple) of the supplied channel. Channels
 *   containing copies of the channel can be created with 'tap', and
 *   detached with 'untap'.
 * 
 *   Each item is distributed to all taps in parallel and synchronously,
 *   i.e. each tap must accept before the next item is distributed. Use
 *   buffering/windowing to prevent slow taps from holding up the mult.
 * 
 *   Items received when there are no taps get dropped.
 * 
 *   If a tap puts to a closed channel, it will be removed from the mult.
 */
cljs.core.async.mult = (function cljs$core$async$mult(ch){
var cs = cljs.core.atom.cljs$core$IFn$_invoke$arity$1(cljs.core.PersistentArrayMap.EMPTY);
var m = (function (){
if((typeof cljs !== 'undefined') && (typeof cljs.core !== 'undefined') && (typeof cljs.core.async !== 'undefined') && (typeof cljs.core.async.t_cljs$core$async28746 !== 'undefined')){
} else {

/**
* @constructor
 * @implements {cljs.core.async.Mult}
 * @implements {cljs.core.IMeta}
 * @implements {cljs.core.async.Mux}
 * @implements {cljs.core.IWithMeta}
*/
cljs.core.async.t_cljs$core$async28746 = (function (ch,cs,meta28747){
this.ch = ch;
this.cs = cs;
this.meta28747 = meta28747;
this.cljs$lang$protocol_mask$partition0$ = 393216;
this.cljs$lang$protocol_mask$partition1$ = 0;
});
cljs.core.async.t_cljs$core$async28746.prototype.cljs$core$IWithMeta$_with_meta$arity$2 = ((function (cs){
return (function (_28748,meta28747__$1){
var self__ = this;
var _28748__$1 = this;
return (new cljs.core.async.t_cljs$core$async28746(self__.ch,self__.cs,meta28747__$1));
});})(cs))
;

cljs.core.async.t_cljs$core$async28746.prototype.cljs$core$IMeta$_meta$arity$1 = ((function (cs){
return (function (_28748){
var self__ = this;
var _28748__$1 = this;
return self__.meta28747;
});})(cs))
;

cljs.core.async.t_cljs$core$async28746.prototype.cljs$core$async$Mux$ = cljs.core.PROTOCOL_SENTINEL;

cljs.core.async.t_cljs$core$async28746.prototype.cljs$core$async$Mux$muxch_STAR_$arity$1 = ((function (cs){
return (function (_){
var self__ = this;
var ___$1 = this;
return self__.ch;
});})(cs))
;

cljs.core.async.t_cljs$core$async28746.prototype.cljs$core$async$Mult$ = cljs.core.PROTOCOL_SENTINEL;

cljs.core.async.t_cljs$core$async28746.prototype.cljs$core$async$Mult$tap_STAR_$arity$3 = ((function (cs){
return (function (_,ch__$1,close_QMARK_){
var self__ = this;
var ___$1 = this;
cljs.core.swap_BANG_.cljs$core$IFn$_invoke$arity$4(self__.cs,cljs.core.assoc,ch__$1,close_QMARK_);

return null;
});})(cs))
;

cljs.core.async.t_cljs$core$async28746.prototype.cljs$core$async$Mult$untap_STAR_$arity$2 = ((function (cs){
return (function (_,ch__$1){
var self__ = this;
var ___$1 = this;
cljs.core.swap_BANG_.cljs$core$IFn$_invoke$arity$3(self__.cs,cljs.core.dissoc,ch__$1);

return null;
});})(cs))
;

cljs.core.async.t_cljs$core$async28746.prototype.cljs$core$async$Mult$untap_all_STAR_$arity$1 = ((function (cs){
return (function (_){
var self__ = this;
var ___$1 = this;
cljs.core.reset_BANG_(self__.cs,cljs.core.PersistentArrayMap.EMPTY);

return null;
});})(cs))
;

cljs.core.async.t_cljs$core$async28746.getBasis = ((function (cs){
return (function (){
return new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [cljs.core.cst$sym$ch,cljs.core.cst$sym$cs,cljs.core.cst$sym$meta28747], null);
});})(cs))
;

cljs.core.async.t_cljs$core$async28746.cljs$lang$type = true;

cljs.core.async.t_cljs$core$async28746.cljs$lang$ctorStr = "cljs.core.async/t_cljs$core$async28746";

cljs.core.async.t_cljs$core$async28746.cljs$lang$ctorPrWriter = ((function (cs){
return (function (this__4290__auto__,writer__4291__auto__,opt__4292__auto__){
return cljs.core._write(writer__4291__auto__,"cljs.core.async/t_cljs$core$async28746");
});})(cs))
;

/**
 * Positional factory function for cljs.core.async/t_cljs$core$async28746.
 */
cljs.core.async.__GT_t_cljs$core$async28746 = ((function (cs){
return (function cljs$core$async$mult_$___GT_t_cljs$core$async28746(ch__$1,cs__$1,meta28747){
return (new cljs.core.async.t_cljs$core$async28746(ch__$1,cs__$1,meta28747));
});})(cs))
;

}

return (new cljs.core.async.t_cljs$core$async28746(ch,cs,cljs.core.PersistentArrayMap.EMPTY));
})()
;
var dchan = cljs.core.async.chan.cljs$core$IFn$_invoke$arity$1((1));
var dctr = cljs.core.atom.cljs$core$IFn$_invoke$arity$1(null);
var done = ((function (cs,m,dchan,dctr){
return (function (_){
if((cljs.core.swap_BANG_.cljs$core$IFn$_invoke$arity$2(dctr,cljs.core.dec) === (0))){
return cljs.core.async.put_BANG_.cljs$core$IFn$_invoke$arity$2(dchan,true);
} else {
return null;
}
});})(cs,m,dchan,dctr))
;
var c__7992__auto___28968 = cljs.core.async.chan.cljs$core$IFn$_invoke$arity$1((1));
cljs.core.async.impl.dispatch.run(((function (c__7992__auto___28968,cs,m,dchan,dctr,done){
return (function (){
var f__7993__auto__ = (function (){var switch__7885__auto__ = ((function (c__7992__auto___28968,cs,m,dchan,dctr,done){
return (function (state_28883){
var state_val_28884 = (state_28883[(1)]);
if((state_val_28884 === (7))){
var inst_28879 = (state_28883[(2)]);
var state_28883__$1 = state_28883;
var statearr_28885_28969 = state_28883__$1;
(statearr_28885_28969[(2)] = inst_28879);

(statearr_28885_28969[(1)] = (3));


return cljs.core.cst$kw$recur;
} else {
if((state_val_28884 === (20))){
var inst_28782 = (state_28883[(7)]);
var inst_28794 = cljs.core.first(inst_28782);
var inst_28795 = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(inst_28794,(0),null);
var inst_28796 = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(inst_28794,(1),null);
var state_28883__$1 = (function (){var statearr_28886 = state_28883;
(statearr_28886[(8)] = inst_28795);

return statearr_28886;
})();
if(cljs.core.truth_(inst_28796)){
var statearr_28887_28970 = state_28883__$1;
(statearr_28887_28970[(1)] = (22));

} else {
var statearr_28888_28971 = state_28883__$1;
(statearr_28888_28971[(1)] = (23));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_28884 === (27))){
var inst_28831 = (state_28883[(9)]);
var inst_28826 = (state_28883[(10)]);
var inst_28824 = (state_28883[(11)]);
var inst_28751 = (state_28883[(12)]);
var inst_28831__$1 = cljs.core._nth.cljs$core$IFn$_invoke$arity$2(inst_28824,inst_28826);
var inst_28832 = cljs.core.async.put_BANG_.cljs$core$IFn$_invoke$arity$3(inst_28831__$1,inst_28751,done);
var state_28883__$1 = (function (){var statearr_28889 = state_28883;
(statearr_28889[(9)] = inst_28831__$1);

return statearr_28889;
})();
if(cljs.core.truth_(inst_28832)){
var statearr_28890_28972 = state_28883__$1;
(statearr_28890_28972[(1)] = (30));

} else {
var statearr_28891_28973 = state_28883__$1;
(statearr_28891_28973[(1)] = (31));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_28884 === (1))){
var state_28883__$1 = state_28883;
var statearr_28892_28974 = state_28883__$1;
(statearr_28892_28974[(2)] = null);

(statearr_28892_28974[(1)] = (2));


return cljs.core.cst$kw$recur;
} else {
if((state_val_28884 === (24))){
var inst_28782 = (state_28883[(7)]);
var inst_28801 = (state_28883[(2)]);
var inst_28802 = cljs.core.next(inst_28782);
var inst_28760 = inst_28802;
var inst_28761 = null;
var inst_28762 = (0);
var inst_28763 = (0);
var state_28883__$1 = (function (){var statearr_28893 = state_28883;
(statearr_28893[(13)] = inst_28762);

(statearr_28893[(14)] = inst_28801);

(statearr_28893[(15)] = inst_28761);

(statearr_28893[(16)] = inst_28760);

(statearr_28893[(17)] = inst_28763);

return statearr_28893;
})();
var statearr_28894_28975 = state_28883__$1;
(statearr_28894_28975[(2)] = null);

(statearr_28894_28975[(1)] = (8));


return cljs.core.cst$kw$recur;
} else {
if((state_val_28884 === (39))){
var state_28883__$1 = state_28883;
var statearr_28898_28976 = state_28883__$1;
(statearr_28898_28976[(2)] = null);

(statearr_28898_28976[(1)] = (41));


return cljs.core.cst$kw$recur;
} else {
if((state_val_28884 === (4))){
var inst_28751 = (state_28883[(12)]);
var inst_28751__$1 = (state_28883[(2)]);
var inst_28752 = (inst_28751__$1 == null);
var state_28883__$1 = (function (){var statearr_28899 = state_28883;
(statearr_28899[(12)] = inst_28751__$1);

return statearr_28899;
})();
if(cljs.core.truth_(inst_28752)){
var statearr_28900_28977 = state_28883__$1;
(statearr_28900_28977[(1)] = (5));

} else {
var statearr_28901_28978 = state_28883__$1;
(statearr_28901_28978[(1)] = (6));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_28884 === (15))){
var inst_28762 = (state_28883[(13)]);
var inst_28761 = (state_28883[(15)]);
var inst_28760 = (state_28883[(16)]);
var inst_28763 = (state_28883[(17)]);
var inst_28778 = (state_28883[(2)]);
var inst_28779 = (inst_28763 + (1));
var tmp28895 = inst_28762;
var tmp28896 = inst_28761;
var tmp28897 = inst_28760;
var inst_28760__$1 = tmp28897;
var inst_28761__$1 = tmp28896;
var inst_28762__$1 = tmp28895;
var inst_28763__$1 = inst_28779;
var state_28883__$1 = (function (){var statearr_28902 = state_28883;
(statearr_28902[(13)] = inst_28762__$1);

(statearr_28902[(15)] = inst_28761__$1);

(statearr_28902[(18)] = inst_28778);

(statearr_28902[(16)] = inst_28760__$1);

(statearr_28902[(17)] = inst_28763__$1);

return statearr_28902;
})();
var statearr_28903_28979 = state_28883__$1;
(statearr_28903_28979[(2)] = null);

(statearr_28903_28979[(1)] = (8));


return cljs.core.cst$kw$recur;
} else {
if((state_val_28884 === (21))){
var inst_28805 = (state_28883[(2)]);
var state_28883__$1 = state_28883;
var statearr_28907_28980 = state_28883__$1;
(statearr_28907_28980[(2)] = inst_28805);

(statearr_28907_28980[(1)] = (18));


return cljs.core.cst$kw$recur;
} else {
if((state_val_28884 === (31))){
var inst_28831 = (state_28883[(9)]);
var inst_28835 = done(null);
var inst_28836 = m.cljs$core$async$Mult$untap_STAR_$arity$2(null,inst_28831);
var state_28883__$1 = (function (){var statearr_28908 = state_28883;
(statearr_28908[(19)] = inst_28835);

return statearr_28908;
})();
var statearr_28909_28981 = state_28883__$1;
(statearr_28909_28981[(2)] = inst_28836);

(statearr_28909_28981[(1)] = (32));


return cljs.core.cst$kw$recur;
} else {
if((state_val_28884 === (32))){
var inst_28826 = (state_28883[(10)]);
var inst_28825 = (state_28883[(20)]);
var inst_28824 = (state_28883[(11)]);
var inst_28823 = (state_28883[(21)]);
var inst_28838 = (state_28883[(2)]);
var inst_28839 = (inst_28826 + (1));
var tmp28904 = inst_28825;
var tmp28905 = inst_28824;
var tmp28906 = inst_28823;
var inst_28823__$1 = tmp28906;
var inst_28824__$1 = tmp28905;
var inst_28825__$1 = tmp28904;
var inst_28826__$1 = inst_28839;
var state_28883__$1 = (function (){var statearr_28910 = state_28883;
(statearr_28910[(10)] = inst_28826__$1);

(statearr_28910[(22)] = inst_28838);

(statearr_28910[(20)] = inst_28825__$1);

(statearr_28910[(11)] = inst_28824__$1);

(statearr_28910[(21)] = inst_28823__$1);

return statearr_28910;
})();
var statearr_28911_28982 = state_28883__$1;
(statearr_28911_28982[(2)] = null);

(statearr_28911_28982[(1)] = (25));


return cljs.core.cst$kw$recur;
} else {
if((state_val_28884 === (40))){
var inst_28851 = (state_28883[(23)]);
var inst_28855 = done(null);
var inst_28856 = m.cljs$core$async$Mult$untap_STAR_$arity$2(null,inst_28851);
var state_28883__$1 = (function (){var statearr_28912 = state_28883;
(statearr_28912[(24)] = inst_28855);

return statearr_28912;
})();
var statearr_28913_28983 = state_28883__$1;
(statearr_28913_28983[(2)] = inst_28856);

(statearr_28913_28983[(1)] = (41));


return cljs.core.cst$kw$recur;
} else {
if((state_val_28884 === (33))){
var inst_28842 = (state_28883[(25)]);
var inst_28844 = cljs.core.chunked_seq_QMARK_(inst_28842);
var state_28883__$1 = state_28883;
if(inst_28844){
var statearr_28914_28984 = state_28883__$1;
(statearr_28914_28984[(1)] = (36));

} else {
var statearr_28915_28985 = state_28883__$1;
(statearr_28915_28985[(1)] = (37));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_28884 === (13))){
var inst_28772 = (state_28883[(26)]);
var inst_28775 = cljs.core.async.close_BANG_(inst_28772);
var state_28883__$1 = state_28883;
var statearr_28916_28986 = state_28883__$1;
(statearr_28916_28986[(2)] = inst_28775);

(statearr_28916_28986[(1)] = (15));


return cljs.core.cst$kw$recur;
} else {
if((state_val_28884 === (22))){
var inst_28795 = (state_28883[(8)]);
var inst_28798 = cljs.core.async.close_BANG_(inst_28795);
var state_28883__$1 = state_28883;
var statearr_28917_28987 = state_28883__$1;
(statearr_28917_28987[(2)] = inst_28798);

(statearr_28917_28987[(1)] = (24));


return cljs.core.cst$kw$recur;
} else {
if((state_val_28884 === (36))){
var inst_28842 = (state_28883[(25)]);
var inst_28846 = cljs.core.chunk_first(inst_28842);
var inst_28847 = cljs.core.chunk_rest(inst_28842);
var inst_28848 = cljs.core.count(inst_28846);
var inst_28823 = inst_28847;
var inst_28824 = inst_28846;
var inst_28825 = inst_28848;
var inst_28826 = (0);
var state_28883__$1 = (function (){var statearr_28918 = state_28883;
(statearr_28918[(10)] = inst_28826);

(statearr_28918[(20)] = inst_28825);

(statearr_28918[(11)] = inst_28824);

(statearr_28918[(21)] = inst_28823);

return statearr_28918;
})();
var statearr_28919_28988 = state_28883__$1;
(statearr_28919_28988[(2)] = null);

(statearr_28919_28988[(1)] = (25));


return cljs.core.cst$kw$recur;
} else {
if((state_val_28884 === (41))){
var inst_28842 = (state_28883[(25)]);
var inst_28858 = (state_28883[(2)]);
var inst_28859 = cljs.core.next(inst_28842);
var inst_28823 = inst_28859;
var inst_28824 = null;
var inst_28825 = (0);
var inst_28826 = (0);
var state_28883__$1 = (function (){var statearr_28920 = state_28883;
(statearr_28920[(10)] = inst_28826);

(statearr_28920[(20)] = inst_28825);

(statearr_28920[(11)] = inst_28824);

(statearr_28920[(27)] = inst_28858);

(statearr_28920[(21)] = inst_28823);

return statearr_28920;
})();
var statearr_28921_28989 = state_28883__$1;
(statearr_28921_28989[(2)] = null);

(statearr_28921_28989[(1)] = (25));


return cljs.core.cst$kw$recur;
} else {
if((state_val_28884 === (43))){
var state_28883__$1 = state_28883;
var statearr_28922_28990 = state_28883__$1;
(statearr_28922_28990[(2)] = null);

(statearr_28922_28990[(1)] = (44));


return cljs.core.cst$kw$recur;
} else {
if((state_val_28884 === (29))){
var inst_28867 = (state_28883[(2)]);
var state_28883__$1 = state_28883;
var statearr_28923_28991 = state_28883__$1;
(statearr_28923_28991[(2)] = inst_28867);

(statearr_28923_28991[(1)] = (26));


return cljs.core.cst$kw$recur;
} else {
if((state_val_28884 === (44))){
var inst_28876 = (state_28883[(2)]);
var state_28883__$1 = (function (){var statearr_28924 = state_28883;
(statearr_28924[(28)] = inst_28876);

return statearr_28924;
})();
var statearr_28925_28992 = state_28883__$1;
(statearr_28925_28992[(2)] = null);

(statearr_28925_28992[(1)] = (2));


return cljs.core.cst$kw$recur;
} else {
if((state_val_28884 === (6))){
var inst_28815 = (state_28883[(29)]);
var inst_28814 = cljs.core.deref(cs);
var inst_28815__$1 = cljs.core.keys(inst_28814);
var inst_28816 = cljs.core.count(inst_28815__$1);
var inst_28817 = cljs.core.reset_BANG_(dctr,inst_28816);
var inst_28822 = cljs.core.seq(inst_28815__$1);
var inst_28823 = inst_28822;
var inst_28824 = null;
var inst_28825 = (0);
var inst_28826 = (0);
var state_28883__$1 = (function (){var statearr_28926 = state_28883;
(statearr_28926[(10)] = inst_28826);

(statearr_28926[(29)] = inst_28815__$1);

(statearr_28926[(20)] = inst_28825);

(statearr_28926[(11)] = inst_28824);

(statearr_28926[(30)] = inst_28817);

(statearr_28926[(21)] = inst_28823);

return statearr_28926;
})();
var statearr_28927_28993 = state_28883__$1;
(statearr_28927_28993[(2)] = null);

(statearr_28927_28993[(1)] = (25));


return cljs.core.cst$kw$recur;
} else {
if((state_val_28884 === (28))){
var inst_28842 = (state_28883[(25)]);
var inst_28823 = (state_28883[(21)]);
var inst_28842__$1 = cljs.core.seq(inst_28823);
var state_28883__$1 = (function (){var statearr_28928 = state_28883;
(statearr_28928[(25)] = inst_28842__$1);

return statearr_28928;
})();
if(inst_28842__$1){
var statearr_28929_28994 = state_28883__$1;
(statearr_28929_28994[(1)] = (33));

} else {
var statearr_28930_28995 = state_28883__$1;
(statearr_28930_28995[(1)] = (34));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_28884 === (25))){
var inst_28826 = (state_28883[(10)]);
var inst_28825 = (state_28883[(20)]);
var inst_28828 = (inst_28826 < inst_28825);
var inst_28829 = inst_28828;
var state_28883__$1 = state_28883;
if(cljs.core.truth_(inst_28829)){
var statearr_28931_28996 = state_28883__$1;
(statearr_28931_28996[(1)] = (27));

} else {
var statearr_28932_28997 = state_28883__$1;
(statearr_28932_28997[(1)] = (28));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_28884 === (34))){
var state_28883__$1 = state_28883;
var statearr_28933_28998 = state_28883__$1;
(statearr_28933_28998[(2)] = null);

(statearr_28933_28998[(1)] = (35));


return cljs.core.cst$kw$recur;
} else {
if((state_val_28884 === (17))){
var state_28883__$1 = state_28883;
var statearr_28934_28999 = state_28883__$1;
(statearr_28934_28999[(2)] = null);

(statearr_28934_28999[(1)] = (18));


return cljs.core.cst$kw$recur;
} else {
if((state_val_28884 === (3))){
var inst_28881 = (state_28883[(2)]);
var state_28883__$1 = state_28883;
return cljs.core.async.impl.ioc_helpers.return_chan(state_28883__$1,inst_28881);
} else {
if((state_val_28884 === (12))){
var inst_28810 = (state_28883[(2)]);
var state_28883__$1 = state_28883;
var statearr_28935_29000 = state_28883__$1;
(statearr_28935_29000[(2)] = inst_28810);

(statearr_28935_29000[(1)] = (9));


return cljs.core.cst$kw$recur;
} else {
if((state_val_28884 === (2))){
var state_28883__$1 = state_28883;
return cljs.core.async.impl.ioc_helpers.take_BANG_(state_28883__$1,(4),ch);
} else {
if((state_val_28884 === (23))){
var state_28883__$1 = state_28883;
var statearr_28936_29001 = state_28883__$1;
(statearr_28936_29001[(2)] = null);

(statearr_28936_29001[(1)] = (24));


return cljs.core.cst$kw$recur;
} else {
if((state_val_28884 === (35))){
var inst_28865 = (state_28883[(2)]);
var state_28883__$1 = state_28883;
var statearr_28937_29002 = state_28883__$1;
(statearr_28937_29002[(2)] = inst_28865);

(statearr_28937_29002[(1)] = (29));


return cljs.core.cst$kw$recur;
} else {
if((state_val_28884 === (19))){
var inst_28782 = (state_28883[(7)]);
var inst_28786 = cljs.core.chunk_first(inst_28782);
var inst_28787 = cljs.core.chunk_rest(inst_28782);
var inst_28788 = cljs.core.count(inst_28786);
var inst_28760 = inst_28787;
var inst_28761 = inst_28786;
var inst_28762 = inst_28788;
var inst_28763 = (0);
var state_28883__$1 = (function (){var statearr_28938 = state_28883;
(statearr_28938[(13)] = inst_28762);

(statearr_28938[(15)] = inst_28761);

(statearr_28938[(16)] = inst_28760);

(statearr_28938[(17)] = inst_28763);

return statearr_28938;
})();
var statearr_28939_29003 = state_28883__$1;
(statearr_28939_29003[(2)] = null);

(statearr_28939_29003[(1)] = (8));


return cljs.core.cst$kw$recur;
} else {
if((state_val_28884 === (11))){
var inst_28782 = (state_28883[(7)]);
var inst_28760 = (state_28883[(16)]);
var inst_28782__$1 = cljs.core.seq(inst_28760);
var state_28883__$1 = (function (){var statearr_28940 = state_28883;
(statearr_28940[(7)] = inst_28782__$1);

return statearr_28940;
})();
if(inst_28782__$1){
var statearr_28941_29004 = state_28883__$1;
(statearr_28941_29004[(1)] = (16));

} else {
var statearr_28942_29005 = state_28883__$1;
(statearr_28942_29005[(1)] = (17));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_28884 === (9))){
var inst_28812 = (state_28883[(2)]);
var state_28883__$1 = state_28883;
var statearr_28943_29006 = state_28883__$1;
(statearr_28943_29006[(2)] = inst_28812);

(statearr_28943_29006[(1)] = (7));


return cljs.core.cst$kw$recur;
} else {
if((state_val_28884 === (5))){
var inst_28758 = cljs.core.deref(cs);
var inst_28759 = cljs.core.seq(inst_28758);
var inst_28760 = inst_28759;
var inst_28761 = null;
var inst_28762 = (0);
var inst_28763 = (0);
var state_28883__$1 = (function (){var statearr_28944 = state_28883;
(statearr_28944[(13)] = inst_28762);

(statearr_28944[(15)] = inst_28761);

(statearr_28944[(16)] = inst_28760);

(statearr_28944[(17)] = inst_28763);

return statearr_28944;
})();
var statearr_28945_29007 = state_28883__$1;
(statearr_28945_29007[(2)] = null);

(statearr_28945_29007[(1)] = (8));


return cljs.core.cst$kw$recur;
} else {
if((state_val_28884 === (14))){
var state_28883__$1 = state_28883;
var statearr_28946_29008 = state_28883__$1;
(statearr_28946_29008[(2)] = null);

(statearr_28946_29008[(1)] = (15));


return cljs.core.cst$kw$recur;
} else {
if((state_val_28884 === (45))){
var inst_28873 = (state_28883[(2)]);
var state_28883__$1 = state_28883;
var statearr_28947_29009 = state_28883__$1;
(statearr_28947_29009[(2)] = inst_28873);

(statearr_28947_29009[(1)] = (44));


return cljs.core.cst$kw$recur;
} else {
if((state_val_28884 === (26))){
var inst_28815 = (state_28883[(29)]);
var inst_28869 = (state_28883[(2)]);
var inst_28870 = cljs.core.seq(inst_28815);
var state_28883__$1 = (function (){var statearr_28948 = state_28883;
(statearr_28948[(31)] = inst_28869);

return statearr_28948;
})();
if(inst_28870){
var statearr_28949_29010 = state_28883__$1;
(statearr_28949_29010[(1)] = (42));

} else {
var statearr_28950_29011 = state_28883__$1;
(statearr_28950_29011[(1)] = (43));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_28884 === (16))){
var inst_28782 = (state_28883[(7)]);
var inst_28784 = cljs.core.chunked_seq_QMARK_(inst_28782);
var state_28883__$1 = state_28883;
if(inst_28784){
var statearr_28951_29012 = state_28883__$1;
(statearr_28951_29012[(1)] = (19));

} else {
var statearr_28952_29013 = state_28883__$1;
(statearr_28952_29013[(1)] = (20));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_28884 === (38))){
var inst_28862 = (state_28883[(2)]);
var state_28883__$1 = state_28883;
var statearr_28953_29014 = state_28883__$1;
(statearr_28953_29014[(2)] = inst_28862);

(statearr_28953_29014[(1)] = (35));


return cljs.core.cst$kw$recur;
} else {
if((state_val_28884 === (30))){
var state_28883__$1 = state_28883;
var statearr_28954_29015 = state_28883__$1;
(statearr_28954_29015[(2)] = null);

(statearr_28954_29015[(1)] = (32));


return cljs.core.cst$kw$recur;
} else {
if((state_val_28884 === (10))){
var inst_28761 = (state_28883[(15)]);
var inst_28763 = (state_28883[(17)]);
var inst_28771 = cljs.core._nth.cljs$core$IFn$_invoke$arity$2(inst_28761,inst_28763);
var inst_28772 = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(inst_28771,(0),null);
var inst_28773 = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(inst_28771,(1),null);
var state_28883__$1 = (function (){var statearr_28955 = state_28883;
(statearr_28955[(26)] = inst_28772);

return statearr_28955;
})();
if(cljs.core.truth_(inst_28773)){
var statearr_28956_29016 = state_28883__$1;
(statearr_28956_29016[(1)] = (13));

} else {
var statearr_28957_29017 = state_28883__$1;
(statearr_28957_29017[(1)] = (14));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_28884 === (18))){
var inst_28808 = (state_28883[(2)]);
var state_28883__$1 = state_28883;
var statearr_28958_29018 = state_28883__$1;
(statearr_28958_29018[(2)] = inst_28808);

(statearr_28958_29018[(1)] = (12));


return cljs.core.cst$kw$recur;
} else {
if((state_val_28884 === (42))){
var state_28883__$1 = state_28883;
return cljs.core.async.impl.ioc_helpers.take_BANG_(state_28883__$1,(45),dchan);
} else {
if((state_val_28884 === (37))){
var inst_28842 = (state_28883[(25)]);
var inst_28751 = (state_28883[(12)]);
var inst_28851 = (state_28883[(23)]);
var inst_28851__$1 = cljs.core.first(inst_28842);
var inst_28852 = cljs.core.async.put_BANG_.cljs$core$IFn$_invoke$arity$3(inst_28851__$1,inst_28751,done);
var state_28883__$1 = (function (){var statearr_28959 = state_28883;
(statearr_28959[(23)] = inst_28851__$1);

return statearr_28959;
})();
if(cljs.core.truth_(inst_28852)){
var statearr_28960_29019 = state_28883__$1;
(statearr_28960_29019[(1)] = (39));

} else {
var statearr_28961_29020 = state_28883__$1;
(statearr_28961_29020[(1)] = (40));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_28884 === (8))){
var inst_28762 = (state_28883[(13)]);
var inst_28763 = (state_28883[(17)]);
var inst_28765 = (inst_28763 < inst_28762);
var inst_28766 = inst_28765;
var state_28883__$1 = state_28883;
if(cljs.core.truth_(inst_28766)){
var statearr_28962_29021 = state_28883__$1;
(statearr_28962_29021[(1)] = (10));

} else {
var statearr_28963_29022 = state_28883__$1;
(statearr_28963_29022[(1)] = (11));

}

return cljs.core.cst$kw$recur;
} else {
return null;
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
});})(c__7992__auto___28968,cs,m,dchan,dctr,done))
;
return ((function (switch__7885__auto__,c__7992__auto___28968,cs,m,dchan,dctr,done){
return (function() {
var cljs$core$async$mult_$_state_machine__7886__auto__ = null;
var cljs$core$async$mult_$_state_machine__7886__auto____0 = (function (){
var statearr_28964 = [null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null];
(statearr_28964[(0)] = cljs$core$async$mult_$_state_machine__7886__auto__);

(statearr_28964[(1)] = (1));

return statearr_28964;
});
var cljs$core$async$mult_$_state_machine__7886__auto____1 = (function (state_28883){
while(true){
var ret_value__7887__auto__ = (function (){try{while(true){
var result__7888__auto__ = switch__7885__auto__(state_28883);
if(cljs.core.keyword_identical_QMARK_(result__7888__auto__,cljs.core.cst$kw$recur)){
continue;
} else {
return result__7888__auto__;
}
break;
}
}catch (e28965){if((e28965 instanceof Object)){
var ex__7889__auto__ = e28965;
var statearr_28966_29023 = state_28883;
(statearr_28966_29023[(5)] = ex__7889__auto__);


cljs.core.async.impl.ioc_helpers.process_exception(state_28883);

return cljs.core.cst$kw$recur;
} else {
throw e28965;

}
}})();
if(cljs.core.keyword_identical_QMARK_(ret_value__7887__auto__,cljs.core.cst$kw$recur)){
var G__29024 = state_28883;
state_28883 = G__29024;
continue;
} else {
return ret_value__7887__auto__;
}
break;
}
});
cljs$core$async$mult_$_state_machine__7886__auto__ = function(state_28883){
switch(arguments.length){
case 0:
return cljs$core$async$mult_$_state_machine__7886__auto____0.call(this);
case 1:
return cljs$core$async$mult_$_state_machine__7886__auto____1.call(this,state_28883);
}
throw(new Error('Invalid arity: ' + arguments.length));
};
cljs$core$async$mult_$_state_machine__7886__auto__.cljs$core$IFn$_invoke$arity$0 = cljs$core$async$mult_$_state_machine__7886__auto____0;
cljs$core$async$mult_$_state_machine__7886__auto__.cljs$core$IFn$_invoke$arity$1 = cljs$core$async$mult_$_state_machine__7886__auto____1;
return cljs$core$async$mult_$_state_machine__7886__auto__;
})()
;})(switch__7885__auto__,c__7992__auto___28968,cs,m,dchan,dctr,done))
})();
var state__7994__auto__ = (function (){var statearr_28967 = (f__7993__auto__.cljs$core$IFn$_invoke$arity$0 ? f__7993__auto__.cljs$core$IFn$_invoke$arity$0() : f__7993__auto__.call(null));
(statearr_28967[(6)] = c__7992__auto___28968);

return statearr_28967;
})();
return cljs.core.async.impl.ioc_helpers.run_state_machine_wrapped(state__7994__auto__);
});})(c__7992__auto___28968,cs,m,dchan,dctr,done))
);


return m;
});
/**
 * Copies the mult source onto the supplied channel.
 * 
 *   By default the channel will be closed when the source closes,
 *   but can be determined by the close? parameter.
 */
cljs.core.async.tap = (function cljs$core$async$tap(var_args){
var G__29026 = arguments.length;
switch (G__29026) {
case 2:
return cljs.core.async.tap.cljs$core$IFn$_invoke$arity$2((arguments[(0)]),(arguments[(1)]));

break;
case 3:
return cljs.core.async.tap.cljs$core$IFn$_invoke$arity$3((arguments[(0)]),(arguments[(1)]),(arguments[(2)]));

break;
default:
throw (new Error(["Invalid arity: ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(arguments.length)].join('')));

}
});

cljs.core.async.tap.cljs$core$IFn$_invoke$arity$2 = (function (mult,ch){
return cljs.core.async.tap.cljs$core$IFn$_invoke$arity$3(mult,ch,true);
});

cljs.core.async.tap.cljs$core$IFn$_invoke$arity$3 = (function (mult,ch,close_QMARK_){
cljs.core.async.tap_STAR_(mult,ch,close_QMARK_);

return ch;
});

cljs.core.async.tap.cljs$lang$maxFixedArity = 3;

/**
 * Disconnects a target channel from a mult
 */
cljs.core.async.untap = (function cljs$core$async$untap(mult,ch){
return cljs.core.async.untap_STAR_(mult,ch);
});
/**
 * Disconnects all target channels from a mult
 */
cljs.core.async.untap_all = (function cljs$core$async$untap_all(mult){
return cljs.core.async.untap_all_STAR_(mult);
});

/**
 * @interface
 */
cljs.core.async.Mix = function(){};

cljs.core.async.admix_STAR_ = (function cljs$core$async$admix_STAR_(m,ch){
if((((!((m == null)))) && ((!((m.cljs$core$async$Mix$admix_STAR_$arity$2 == null)))))){
return m.cljs$core$async$Mix$admix_STAR_$arity$2(m,ch);
} else {
var x__4347__auto__ = (((m == null))?null:m);
var m__4348__auto__ = (cljs.core.async.admix_STAR_[goog.typeOf(x__4347__auto__)]);
if((!((m__4348__auto__ == null)))){
return (m__4348__auto__.cljs$core$IFn$_invoke$arity$2 ? m__4348__auto__.cljs$core$IFn$_invoke$arity$2(m,ch) : m__4348__auto__.call(null,m,ch));
} else {
var m__4348__auto____$1 = (cljs.core.async.admix_STAR_["_"]);
if((!((m__4348__auto____$1 == null)))){
return (m__4348__auto____$1.cljs$core$IFn$_invoke$arity$2 ? m__4348__auto____$1.cljs$core$IFn$_invoke$arity$2(m,ch) : m__4348__auto____$1.call(null,m,ch));
} else {
throw cljs.core.missing_protocol("Mix.admix*",m);
}
}
}
});

cljs.core.async.unmix_STAR_ = (function cljs$core$async$unmix_STAR_(m,ch){
if((((!((m == null)))) && ((!((m.cljs$core$async$Mix$unmix_STAR_$arity$2 == null)))))){
return m.cljs$core$async$Mix$unmix_STAR_$arity$2(m,ch);
} else {
var x__4347__auto__ = (((m == null))?null:m);
var m__4348__auto__ = (cljs.core.async.unmix_STAR_[goog.typeOf(x__4347__auto__)]);
if((!((m__4348__auto__ == null)))){
return (m__4348__auto__.cljs$core$IFn$_invoke$arity$2 ? m__4348__auto__.cljs$core$IFn$_invoke$arity$2(m,ch) : m__4348__auto__.call(null,m,ch));
} else {
var m__4348__auto____$1 = (cljs.core.async.unmix_STAR_["_"]);
if((!((m__4348__auto____$1 == null)))){
return (m__4348__auto____$1.cljs$core$IFn$_invoke$arity$2 ? m__4348__auto____$1.cljs$core$IFn$_invoke$arity$2(m,ch) : m__4348__auto____$1.call(null,m,ch));
} else {
throw cljs.core.missing_protocol("Mix.unmix*",m);
}
}
}
});

cljs.core.async.unmix_all_STAR_ = (function cljs$core$async$unmix_all_STAR_(m){
if((((!((m == null)))) && ((!((m.cljs$core$async$Mix$unmix_all_STAR_$arity$1 == null)))))){
return m.cljs$core$async$Mix$unmix_all_STAR_$arity$1(m);
} else {
var x__4347__auto__ = (((m == null))?null:m);
var m__4348__auto__ = (cljs.core.async.unmix_all_STAR_[goog.typeOf(x__4347__auto__)]);
if((!((m__4348__auto__ == null)))){
return (m__4348__auto__.cljs$core$IFn$_invoke$arity$1 ? m__4348__auto__.cljs$core$IFn$_invoke$arity$1(m) : m__4348__auto__.call(null,m));
} else {
var m__4348__auto____$1 = (cljs.core.async.unmix_all_STAR_["_"]);
if((!((m__4348__auto____$1 == null)))){
return (m__4348__auto____$1.cljs$core$IFn$_invoke$arity$1 ? m__4348__auto____$1.cljs$core$IFn$_invoke$arity$1(m) : m__4348__auto____$1.call(null,m));
} else {
throw cljs.core.missing_protocol("Mix.unmix-all*",m);
}
}
}
});

cljs.core.async.toggle_STAR_ = (function cljs$core$async$toggle_STAR_(m,state_map){
if((((!((m == null)))) && ((!((m.cljs$core$async$Mix$toggle_STAR_$arity$2 == null)))))){
return m.cljs$core$async$Mix$toggle_STAR_$arity$2(m,state_map);
} else {
var x__4347__auto__ = (((m == null))?null:m);
var m__4348__auto__ = (cljs.core.async.toggle_STAR_[goog.typeOf(x__4347__auto__)]);
if((!((m__4348__auto__ == null)))){
return (m__4348__auto__.cljs$core$IFn$_invoke$arity$2 ? m__4348__auto__.cljs$core$IFn$_invoke$arity$2(m,state_map) : m__4348__auto__.call(null,m,state_map));
} else {
var m__4348__auto____$1 = (cljs.core.async.toggle_STAR_["_"]);
if((!((m__4348__auto____$1 == null)))){
return (m__4348__auto____$1.cljs$core$IFn$_invoke$arity$2 ? m__4348__auto____$1.cljs$core$IFn$_invoke$arity$2(m,state_map) : m__4348__auto____$1.call(null,m,state_map));
} else {
throw cljs.core.missing_protocol("Mix.toggle*",m);
}
}
}
});

cljs.core.async.solo_mode_STAR_ = (function cljs$core$async$solo_mode_STAR_(m,mode){
if((((!((m == null)))) && ((!((m.cljs$core$async$Mix$solo_mode_STAR_$arity$2 == null)))))){
return m.cljs$core$async$Mix$solo_mode_STAR_$arity$2(m,mode);
} else {
var x__4347__auto__ = (((m == null))?null:m);
var m__4348__auto__ = (cljs.core.async.solo_mode_STAR_[goog.typeOf(x__4347__auto__)]);
if((!((m__4348__auto__ == null)))){
return (m__4348__auto__.cljs$core$IFn$_invoke$arity$2 ? m__4348__auto__.cljs$core$IFn$_invoke$arity$2(m,mode) : m__4348__auto__.call(null,m,mode));
} else {
var m__4348__auto____$1 = (cljs.core.async.solo_mode_STAR_["_"]);
if((!((m__4348__auto____$1 == null)))){
return (m__4348__auto____$1.cljs$core$IFn$_invoke$arity$2 ? m__4348__auto____$1.cljs$core$IFn$_invoke$arity$2(m,mode) : m__4348__auto____$1.call(null,m,mode));
} else {
throw cljs.core.missing_protocol("Mix.solo-mode*",m);
}
}
}
});

cljs.core.async.ioc_alts_BANG_ = (function cljs$core$async$ioc_alts_BANG_(var_args){
var args__4647__auto__ = [];
var len__4641__auto___29038 = arguments.length;
var i__4642__auto___29039 = (0);
while(true){
if((i__4642__auto___29039 < len__4641__auto___29038)){
args__4647__auto__.push((arguments[i__4642__auto___29039]));

var G__29040 = (i__4642__auto___29039 + (1));
i__4642__auto___29039 = G__29040;
continue;
} else {
}
break;
}

var argseq__4648__auto__ = ((((3) < args__4647__auto__.length))?(new cljs.core.IndexedSeq(args__4647__auto__.slice((3)),(0),null)):null);
return cljs.core.async.ioc_alts_BANG_.cljs$core$IFn$_invoke$arity$variadic((arguments[(0)]),(arguments[(1)]),(arguments[(2)]),argseq__4648__auto__);
});

cljs.core.async.ioc_alts_BANG_.cljs$core$IFn$_invoke$arity$variadic = (function (state,cont_block,ports,p__29032){
var map__29033 = p__29032;
var map__29033__$1 = (((((!((map__29033 == null))))?(((((map__29033.cljs$lang$protocol_mask$partition0$ & (64))) || ((cljs.core.PROTOCOL_SENTINEL === map__29033.cljs$core$ISeq$))))?true:false):false))?cljs.core.apply.cljs$core$IFn$_invoke$arity$2(cljs.core.hash_map,map__29033):map__29033);
var opts = map__29033__$1;
var statearr_29035_29041 = state;
(statearr_29035_29041[(1)] = cont_block);


var temp__5457__auto__ = cljs.core.async.do_alts(((function (map__29033,map__29033__$1,opts){
return (function (val){
var statearr_29036_29042 = state;
(statearr_29036_29042[(2)] = val);


return cljs.core.async.impl.ioc_helpers.run_state_machine_wrapped(state);
});})(map__29033,map__29033__$1,opts))
,ports,opts);
if(cljs.core.truth_(temp__5457__auto__)){
var cb = temp__5457__auto__;
var statearr_29037_29043 = state;
(statearr_29037_29043[(2)] = cljs.core.deref(cb));


return cljs.core.cst$kw$recur;
} else {
return null;
}
});

cljs.core.async.ioc_alts_BANG_.cljs$lang$maxFixedArity = (3);

/** @this {Function} */
cljs.core.async.ioc_alts_BANG_.cljs$lang$applyTo = (function (seq29028){
var G__29029 = cljs.core.first(seq29028);
var seq29028__$1 = cljs.core.next(seq29028);
var G__29030 = cljs.core.first(seq29028__$1);
var seq29028__$2 = cljs.core.next(seq29028__$1);
var G__29031 = cljs.core.first(seq29028__$2);
var seq29028__$3 = cljs.core.next(seq29028__$2);
var self__4628__auto__ = this;
return self__4628__auto__.cljs$core$IFn$_invoke$arity$variadic(G__29029,G__29030,G__29031,seq29028__$3);
});

/**
 * Creates and returns a mix of one or more input channels which will
 *   be put on the supplied out channel. Input sources can be added to
 *   the mix with 'admix', and removed with 'unmix'. A mix supports
 *   soloing, muting and pausing multiple inputs atomically using
 *   'toggle', and can solo using either muting or pausing as determined
 *   by 'solo-mode'.
 * 
 *   Each channel can have zero or more boolean modes set via 'toggle':
 * 
 *   :solo - when true, only this (ond other soloed) channel(s) will appear
 *        in the mix output channel. :mute and :pause states of soloed
 *        channels are ignored. If solo-mode is :mute, non-soloed
 *        channels are muted, if :pause, non-soloed channels are
 *        paused.
 * 
 *   :mute - muted channels will have their contents consumed but not included in the mix
 *   :pause - paused channels will not have their contents consumed (and thus also not included in the mix)
 */
cljs.core.async.mix = (function cljs$core$async$mix(out){
var cs = cljs.core.atom.cljs$core$IFn$_invoke$arity$1(cljs.core.PersistentArrayMap.EMPTY);
var solo_modes = new cljs.core.PersistentHashSet(null, new cljs.core.PersistentArrayMap(null, 2, [cljs.core.cst$kw$pause,null,cljs.core.cst$kw$mute,null], null), null);
var attrs = cljs.core.conj.cljs$core$IFn$_invoke$arity$2(solo_modes,cljs.core.cst$kw$solo);
var solo_mode = cljs.core.atom.cljs$core$IFn$_invoke$arity$1(cljs.core.cst$kw$mute);
var change = cljs.core.async.chan.cljs$core$IFn$_invoke$arity$0();
var changed = ((function (cs,solo_modes,attrs,solo_mode,change){
return (function (){
return cljs.core.async.put_BANG_.cljs$core$IFn$_invoke$arity$2(change,true);
});})(cs,solo_modes,attrs,solo_mode,change))
;
var pick = ((function (cs,solo_modes,attrs,solo_mode,change,changed){
return (function (attr,chs){
return cljs.core.reduce_kv(((function (cs,solo_modes,attrs,solo_mode,change,changed){
return (function (ret,c,v){
if(cljs.core.truth_((attr.cljs$core$IFn$_invoke$arity$1 ? attr.cljs$core$IFn$_invoke$arity$1(v) : attr.call(null,v)))){
return cljs.core.conj.cljs$core$IFn$_invoke$arity$2(ret,c);
} else {
return ret;
}
});})(cs,solo_modes,attrs,solo_mode,change,changed))
,cljs.core.PersistentHashSet.EMPTY,chs);
});})(cs,solo_modes,attrs,solo_mode,change,changed))
;
var calc_state = ((function (cs,solo_modes,attrs,solo_mode,change,changed,pick){
return (function (){
var chs = cljs.core.deref(cs);
var mode = cljs.core.deref(solo_mode);
var solos = pick(cljs.core.cst$kw$solo,chs);
var pauses = pick(cljs.core.cst$kw$pause,chs);
return new cljs.core.PersistentArrayMap(null, 3, [cljs.core.cst$kw$solos,solos,cljs.core.cst$kw$mutes,pick(cljs.core.cst$kw$mute,chs),cljs.core.cst$kw$reads,cljs.core.conj.cljs$core$IFn$_invoke$arity$2(((((cljs.core._EQ_.cljs$core$IFn$_invoke$arity$2(mode,cljs.core.cst$kw$pause)) && ((!(cljs.core.empty_QMARK_(solos))))))?cljs.core.vec(solos):cljs.core.vec(cljs.core.remove.cljs$core$IFn$_invoke$arity$2(pauses,cljs.core.keys(chs)))),change)], null);
});})(cs,solo_modes,attrs,solo_mode,change,changed,pick))
;
var m = (function (){
if((typeof cljs !== 'undefined') && (typeof cljs.core !== 'undefined') && (typeof cljs.core.async !== 'undefined') && (typeof cljs.core.async.t_cljs$core$async29044 !== 'undefined')){
} else {

/**
* @constructor
 * @implements {cljs.core.IMeta}
 * @implements {cljs.core.async.Mix}
 * @implements {cljs.core.async.Mux}
 * @implements {cljs.core.IWithMeta}
*/
cljs.core.async.t_cljs$core$async29044 = (function (out,cs,solo_modes,attrs,solo_mode,change,changed,pick,calc_state,meta29045){
this.out = out;
this.cs = cs;
this.solo_modes = solo_modes;
this.attrs = attrs;
this.solo_mode = solo_mode;
this.change = change;
this.changed = changed;
this.pick = pick;
this.calc_state = calc_state;
this.meta29045 = meta29045;
this.cljs$lang$protocol_mask$partition0$ = 393216;
this.cljs$lang$protocol_mask$partition1$ = 0;
});
cljs.core.async.t_cljs$core$async29044.prototype.cljs$core$IWithMeta$_with_meta$arity$2 = ((function (cs,solo_modes,attrs,solo_mode,change,changed,pick,calc_state){
return (function (_29046,meta29045__$1){
var self__ = this;
var _29046__$1 = this;
return (new cljs.core.async.t_cljs$core$async29044(self__.out,self__.cs,self__.solo_modes,self__.attrs,self__.solo_mode,self__.change,self__.changed,self__.pick,self__.calc_state,meta29045__$1));
});})(cs,solo_modes,attrs,solo_mode,change,changed,pick,calc_state))
;

cljs.core.async.t_cljs$core$async29044.prototype.cljs$core$IMeta$_meta$arity$1 = ((function (cs,solo_modes,attrs,solo_mode,change,changed,pick,calc_state){
return (function (_29046){
var self__ = this;
var _29046__$1 = this;
return self__.meta29045;
});})(cs,solo_modes,attrs,solo_mode,change,changed,pick,calc_state))
;

cljs.core.async.t_cljs$core$async29044.prototype.cljs$core$async$Mux$ = cljs.core.PROTOCOL_SENTINEL;

cljs.core.async.t_cljs$core$async29044.prototype.cljs$core$async$Mux$muxch_STAR_$arity$1 = ((function (cs,solo_modes,attrs,solo_mode,change,changed,pick,calc_state){
return (function (_){
var self__ = this;
var ___$1 = this;
return self__.out;
});})(cs,solo_modes,attrs,solo_mode,change,changed,pick,calc_state))
;

cljs.core.async.t_cljs$core$async29044.prototype.cljs$core$async$Mix$ = cljs.core.PROTOCOL_SENTINEL;

cljs.core.async.t_cljs$core$async29044.prototype.cljs$core$async$Mix$admix_STAR_$arity$2 = ((function (cs,solo_modes,attrs,solo_mode,change,changed,pick,calc_state){
return (function (_,ch){
var self__ = this;
var ___$1 = this;
cljs.core.swap_BANG_.cljs$core$IFn$_invoke$arity$4(self__.cs,cljs.core.assoc,ch,cljs.core.PersistentArrayMap.EMPTY);

return (self__.changed.cljs$core$IFn$_invoke$arity$0 ? self__.changed.cljs$core$IFn$_invoke$arity$0() : self__.changed.call(null));
});})(cs,solo_modes,attrs,solo_mode,change,changed,pick,calc_state))
;

cljs.core.async.t_cljs$core$async29044.prototype.cljs$core$async$Mix$unmix_STAR_$arity$2 = ((function (cs,solo_modes,attrs,solo_mode,change,changed,pick,calc_state){
return (function (_,ch){
var self__ = this;
var ___$1 = this;
cljs.core.swap_BANG_.cljs$core$IFn$_invoke$arity$3(self__.cs,cljs.core.dissoc,ch);

return (self__.changed.cljs$core$IFn$_invoke$arity$0 ? self__.changed.cljs$core$IFn$_invoke$arity$0() : self__.changed.call(null));
});})(cs,solo_modes,attrs,solo_mode,change,changed,pick,calc_state))
;

cljs.core.async.t_cljs$core$async29044.prototype.cljs$core$async$Mix$unmix_all_STAR_$arity$1 = ((function (cs,solo_modes,attrs,solo_mode,change,changed,pick,calc_state){
return (function (_){
var self__ = this;
var ___$1 = this;
cljs.core.reset_BANG_(self__.cs,cljs.core.PersistentArrayMap.EMPTY);

return (self__.changed.cljs$core$IFn$_invoke$arity$0 ? self__.changed.cljs$core$IFn$_invoke$arity$0() : self__.changed.call(null));
});})(cs,solo_modes,attrs,solo_mode,change,changed,pick,calc_state))
;

cljs.core.async.t_cljs$core$async29044.prototype.cljs$core$async$Mix$toggle_STAR_$arity$2 = ((function (cs,solo_modes,attrs,solo_mode,change,changed,pick,calc_state){
return (function (_,state_map){
var self__ = this;
var ___$1 = this;
cljs.core.swap_BANG_.cljs$core$IFn$_invoke$arity$3(self__.cs,cljs.core.partial.cljs$core$IFn$_invoke$arity$2(cljs.core.merge_with,cljs.core.merge),state_map);

return (self__.changed.cljs$core$IFn$_invoke$arity$0 ? self__.changed.cljs$core$IFn$_invoke$arity$0() : self__.changed.call(null));
});})(cs,solo_modes,attrs,solo_mode,change,changed,pick,calc_state))
;

cljs.core.async.t_cljs$core$async29044.prototype.cljs$core$async$Mix$solo_mode_STAR_$arity$2 = ((function (cs,solo_modes,attrs,solo_mode,change,changed,pick,calc_state){
return (function (_,mode){
var self__ = this;
var ___$1 = this;

cljs.core.reset_BANG_(self__.solo_mode,mode);

return (self__.changed.cljs$core$IFn$_invoke$arity$0 ? self__.changed.cljs$core$IFn$_invoke$arity$0() : self__.changed.call(null));
});})(cs,solo_modes,attrs,solo_mode,change,changed,pick,calc_state))
;

cljs.core.async.t_cljs$core$async29044.getBasis = ((function (cs,solo_modes,attrs,solo_mode,change,changed,pick,calc_state){
return (function (){
return new cljs.core.PersistentVector(null, 10, 5, cljs.core.PersistentVector.EMPTY_NODE, [cljs.core.cst$sym$out,cljs.core.cst$sym$cs,cljs.core.cst$sym$solo_DASH_modes,cljs.core.cst$sym$attrs,cljs.core.cst$sym$solo_DASH_mode,cljs.core.cst$sym$change,cljs.core.cst$sym$changed,cljs.core.cst$sym$pick,cljs.core.cst$sym$calc_DASH_state,cljs.core.cst$sym$meta29045], null);
});})(cs,solo_modes,attrs,solo_mode,change,changed,pick,calc_state))
;

cljs.core.async.t_cljs$core$async29044.cljs$lang$type = true;

cljs.core.async.t_cljs$core$async29044.cljs$lang$ctorStr = "cljs.core.async/t_cljs$core$async29044";

cljs.core.async.t_cljs$core$async29044.cljs$lang$ctorPrWriter = ((function (cs,solo_modes,attrs,solo_mode,change,changed,pick,calc_state){
return (function (this__4290__auto__,writer__4291__auto__,opt__4292__auto__){
return cljs.core._write(writer__4291__auto__,"cljs.core.async/t_cljs$core$async29044");
});})(cs,solo_modes,attrs,solo_mode,change,changed,pick,calc_state))
;

/**
 * Positional factory function for cljs.core.async/t_cljs$core$async29044.
 */
cljs.core.async.__GT_t_cljs$core$async29044 = ((function (cs,solo_modes,attrs,solo_mode,change,changed,pick,calc_state){
return (function cljs$core$async$mix_$___GT_t_cljs$core$async29044(out__$1,cs__$1,solo_modes__$1,attrs__$1,solo_mode__$1,change__$1,changed__$1,pick__$1,calc_state__$1,meta29045){
return (new cljs.core.async.t_cljs$core$async29044(out__$1,cs__$1,solo_modes__$1,attrs__$1,solo_mode__$1,change__$1,changed__$1,pick__$1,calc_state__$1,meta29045));
});})(cs,solo_modes,attrs,solo_mode,change,changed,pick,calc_state))
;

}

return (new cljs.core.async.t_cljs$core$async29044(out,cs,solo_modes,attrs,solo_mode,change,changed,pick,calc_state,cljs.core.PersistentArrayMap.EMPTY));
})()
;
var c__7992__auto___29208 = cljs.core.async.chan.cljs$core$IFn$_invoke$arity$1((1));
cljs.core.async.impl.dispatch.run(((function (c__7992__auto___29208,cs,solo_modes,attrs,solo_mode,change,changed,pick,calc_state,m){
return (function (){
var f__7993__auto__ = (function (){var switch__7885__auto__ = ((function (c__7992__auto___29208,cs,solo_modes,attrs,solo_mode,change,changed,pick,calc_state,m){
return (function (state_29148){
var state_val_29149 = (state_29148[(1)]);
if((state_val_29149 === (7))){
var inst_29063 = (state_29148[(2)]);
var state_29148__$1 = state_29148;
var statearr_29150_29209 = state_29148__$1;
(statearr_29150_29209[(2)] = inst_29063);

(statearr_29150_29209[(1)] = (4));


return cljs.core.cst$kw$recur;
} else {
if((state_val_29149 === (20))){
var inst_29075 = (state_29148[(7)]);
var state_29148__$1 = state_29148;
var statearr_29151_29210 = state_29148__$1;
(statearr_29151_29210[(2)] = inst_29075);

(statearr_29151_29210[(1)] = (21));


return cljs.core.cst$kw$recur;
} else {
if((state_val_29149 === (27))){
var state_29148__$1 = state_29148;
var statearr_29152_29211 = state_29148__$1;
(statearr_29152_29211[(2)] = null);

(statearr_29152_29211[(1)] = (28));


return cljs.core.cst$kw$recur;
} else {
if((state_val_29149 === (1))){
var inst_29050 = (state_29148[(8)]);
var inst_29050__$1 = calc_state();
var inst_29052 = (inst_29050__$1 == null);
var inst_29053 = cljs.core.not(inst_29052);
var state_29148__$1 = (function (){var statearr_29153 = state_29148;
(statearr_29153[(8)] = inst_29050__$1);

return statearr_29153;
})();
if(inst_29053){
var statearr_29154_29212 = state_29148__$1;
(statearr_29154_29212[(1)] = (2));

} else {
var statearr_29155_29213 = state_29148__$1;
(statearr_29155_29213[(1)] = (3));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_29149 === (24))){
var inst_29108 = (state_29148[(9)]);
var inst_29122 = (state_29148[(10)]);
var inst_29099 = (state_29148[(11)]);
var inst_29122__$1 = (inst_29099.cljs$core$IFn$_invoke$arity$1 ? inst_29099.cljs$core$IFn$_invoke$arity$1(inst_29108) : inst_29099.call(null,inst_29108));
var state_29148__$1 = (function (){var statearr_29156 = state_29148;
(statearr_29156[(10)] = inst_29122__$1);

return statearr_29156;
})();
if(cljs.core.truth_(inst_29122__$1)){
var statearr_29157_29214 = state_29148__$1;
(statearr_29157_29214[(1)] = (29));

} else {
var statearr_29158_29215 = state_29148__$1;
(statearr_29158_29215[(1)] = (30));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_29149 === (4))){
var inst_29066 = (state_29148[(2)]);
var state_29148__$1 = state_29148;
if(cljs.core.truth_(inst_29066)){
var statearr_29159_29216 = state_29148__$1;
(statearr_29159_29216[(1)] = (8));

} else {
var statearr_29160_29217 = state_29148__$1;
(statearr_29160_29217[(1)] = (9));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_29149 === (15))){
var inst_29093 = (state_29148[(2)]);
var state_29148__$1 = state_29148;
if(cljs.core.truth_(inst_29093)){
var statearr_29161_29218 = state_29148__$1;
(statearr_29161_29218[(1)] = (19));

} else {
var statearr_29162_29219 = state_29148__$1;
(statearr_29162_29219[(1)] = (20));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_29149 === (21))){
var inst_29098 = (state_29148[(12)]);
var inst_29098__$1 = (state_29148[(2)]);
var inst_29099 = cljs.core.get.cljs$core$IFn$_invoke$arity$2(inst_29098__$1,cljs.core.cst$kw$solos);
var inst_29100 = cljs.core.get.cljs$core$IFn$_invoke$arity$2(inst_29098__$1,cljs.core.cst$kw$mutes);
var inst_29101 = cljs.core.get.cljs$core$IFn$_invoke$arity$2(inst_29098__$1,cljs.core.cst$kw$reads);
var state_29148__$1 = (function (){var statearr_29163 = state_29148;
(statearr_29163[(13)] = inst_29100);

(statearr_29163[(12)] = inst_29098__$1);

(statearr_29163[(11)] = inst_29099);

return statearr_29163;
})();
return cljs.core.async.ioc_alts_BANG_(state_29148__$1,(22),inst_29101);
} else {
if((state_val_29149 === (31))){
var inst_29130 = (state_29148[(2)]);
var state_29148__$1 = state_29148;
if(cljs.core.truth_(inst_29130)){
var statearr_29164_29220 = state_29148__$1;
(statearr_29164_29220[(1)] = (32));

} else {
var statearr_29165_29221 = state_29148__$1;
(statearr_29165_29221[(1)] = (33));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_29149 === (32))){
var inst_29107 = (state_29148[(14)]);
var state_29148__$1 = state_29148;
return cljs.core.async.impl.ioc_helpers.put_BANG_(state_29148__$1,(35),out,inst_29107);
} else {
if((state_val_29149 === (33))){
var inst_29098 = (state_29148[(12)]);
var inst_29075 = inst_29098;
var state_29148__$1 = (function (){var statearr_29166 = state_29148;
(statearr_29166[(7)] = inst_29075);

return statearr_29166;
})();
var statearr_29167_29222 = state_29148__$1;
(statearr_29167_29222[(2)] = null);

(statearr_29167_29222[(1)] = (11));


return cljs.core.cst$kw$recur;
} else {
if((state_val_29149 === (13))){
var inst_29075 = (state_29148[(7)]);
var inst_29082 = inst_29075.cljs$lang$protocol_mask$partition0$;
var inst_29083 = (inst_29082 & (64));
var inst_29084 = inst_29075.cljs$core$ISeq$;
var inst_29085 = (cljs.core.PROTOCOL_SENTINEL === inst_29084);
var inst_29086 = ((inst_29083) || (inst_29085));
var state_29148__$1 = state_29148;
if(cljs.core.truth_(inst_29086)){
var statearr_29168_29223 = state_29148__$1;
(statearr_29168_29223[(1)] = (16));

} else {
var statearr_29169_29224 = state_29148__$1;
(statearr_29169_29224[(1)] = (17));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_29149 === (22))){
var inst_29107 = (state_29148[(14)]);
var inst_29108 = (state_29148[(9)]);
var inst_29106 = (state_29148[(2)]);
var inst_29107__$1 = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(inst_29106,(0),null);
var inst_29108__$1 = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(inst_29106,(1),null);
var inst_29109 = (inst_29107__$1 == null);
var inst_29110 = cljs.core._EQ_.cljs$core$IFn$_invoke$arity$2(inst_29108__$1,change);
var inst_29111 = ((inst_29109) || (inst_29110));
var state_29148__$1 = (function (){var statearr_29170 = state_29148;
(statearr_29170[(14)] = inst_29107__$1);

(statearr_29170[(9)] = inst_29108__$1);

return statearr_29170;
})();
if(cljs.core.truth_(inst_29111)){
var statearr_29171_29225 = state_29148__$1;
(statearr_29171_29225[(1)] = (23));

} else {
var statearr_29172_29226 = state_29148__$1;
(statearr_29172_29226[(1)] = (24));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_29149 === (36))){
var inst_29098 = (state_29148[(12)]);
var inst_29075 = inst_29098;
var state_29148__$1 = (function (){var statearr_29173 = state_29148;
(statearr_29173[(7)] = inst_29075);

return statearr_29173;
})();
var statearr_29174_29227 = state_29148__$1;
(statearr_29174_29227[(2)] = null);

(statearr_29174_29227[(1)] = (11));


return cljs.core.cst$kw$recur;
} else {
if((state_val_29149 === (29))){
var inst_29122 = (state_29148[(10)]);
var state_29148__$1 = state_29148;
var statearr_29175_29228 = state_29148__$1;
(statearr_29175_29228[(2)] = inst_29122);

(statearr_29175_29228[(1)] = (31));


return cljs.core.cst$kw$recur;
} else {
if((state_val_29149 === (6))){
var state_29148__$1 = state_29148;
var statearr_29176_29229 = state_29148__$1;
(statearr_29176_29229[(2)] = false);

(statearr_29176_29229[(1)] = (7));


return cljs.core.cst$kw$recur;
} else {
if((state_val_29149 === (28))){
var inst_29118 = (state_29148[(2)]);
var inst_29119 = calc_state();
var inst_29075 = inst_29119;
var state_29148__$1 = (function (){var statearr_29177 = state_29148;
(statearr_29177[(15)] = inst_29118);

(statearr_29177[(7)] = inst_29075);

return statearr_29177;
})();
var statearr_29178_29230 = state_29148__$1;
(statearr_29178_29230[(2)] = null);

(statearr_29178_29230[(1)] = (11));


return cljs.core.cst$kw$recur;
} else {
if((state_val_29149 === (25))){
var inst_29144 = (state_29148[(2)]);
var state_29148__$1 = state_29148;
var statearr_29179_29231 = state_29148__$1;
(statearr_29179_29231[(2)] = inst_29144);

(statearr_29179_29231[(1)] = (12));


return cljs.core.cst$kw$recur;
} else {
if((state_val_29149 === (34))){
var inst_29142 = (state_29148[(2)]);
var state_29148__$1 = state_29148;
var statearr_29180_29232 = state_29148__$1;
(statearr_29180_29232[(2)] = inst_29142);

(statearr_29180_29232[(1)] = (25));


return cljs.core.cst$kw$recur;
} else {
if((state_val_29149 === (17))){
var state_29148__$1 = state_29148;
var statearr_29181_29233 = state_29148__$1;
(statearr_29181_29233[(2)] = false);

(statearr_29181_29233[(1)] = (18));


return cljs.core.cst$kw$recur;
} else {
if((state_val_29149 === (3))){
var state_29148__$1 = state_29148;
var statearr_29182_29234 = state_29148__$1;
(statearr_29182_29234[(2)] = false);

(statearr_29182_29234[(1)] = (4));


return cljs.core.cst$kw$recur;
} else {
if((state_val_29149 === (12))){
var inst_29146 = (state_29148[(2)]);
var state_29148__$1 = state_29148;
return cljs.core.async.impl.ioc_helpers.return_chan(state_29148__$1,inst_29146);
} else {
if((state_val_29149 === (2))){
var inst_29050 = (state_29148[(8)]);
var inst_29055 = inst_29050.cljs$lang$protocol_mask$partition0$;
var inst_29056 = (inst_29055 & (64));
var inst_29057 = inst_29050.cljs$core$ISeq$;
var inst_29058 = (cljs.core.PROTOCOL_SENTINEL === inst_29057);
var inst_29059 = ((inst_29056) || (inst_29058));
var state_29148__$1 = state_29148;
if(cljs.core.truth_(inst_29059)){
var statearr_29183_29235 = state_29148__$1;
(statearr_29183_29235[(1)] = (5));

} else {
var statearr_29184_29236 = state_29148__$1;
(statearr_29184_29236[(1)] = (6));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_29149 === (23))){
var inst_29107 = (state_29148[(14)]);
var inst_29113 = (inst_29107 == null);
var state_29148__$1 = state_29148;
if(cljs.core.truth_(inst_29113)){
var statearr_29185_29237 = state_29148__$1;
(statearr_29185_29237[(1)] = (26));

} else {
var statearr_29186_29238 = state_29148__$1;
(statearr_29186_29238[(1)] = (27));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_29149 === (35))){
var inst_29133 = (state_29148[(2)]);
var state_29148__$1 = state_29148;
if(cljs.core.truth_(inst_29133)){
var statearr_29187_29239 = state_29148__$1;
(statearr_29187_29239[(1)] = (36));

} else {
var statearr_29188_29240 = state_29148__$1;
(statearr_29188_29240[(1)] = (37));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_29149 === (19))){
var inst_29075 = (state_29148[(7)]);
var inst_29095 = cljs.core.apply.cljs$core$IFn$_invoke$arity$2(cljs.core.hash_map,inst_29075);
var state_29148__$1 = state_29148;
var statearr_29189_29241 = state_29148__$1;
(statearr_29189_29241[(2)] = inst_29095);

(statearr_29189_29241[(1)] = (21));


return cljs.core.cst$kw$recur;
} else {
if((state_val_29149 === (11))){
var inst_29075 = (state_29148[(7)]);
var inst_29079 = (inst_29075 == null);
var inst_29080 = cljs.core.not(inst_29079);
var state_29148__$1 = state_29148;
if(inst_29080){
var statearr_29190_29242 = state_29148__$1;
(statearr_29190_29242[(1)] = (13));

} else {
var statearr_29191_29243 = state_29148__$1;
(statearr_29191_29243[(1)] = (14));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_29149 === (9))){
var inst_29050 = (state_29148[(8)]);
var state_29148__$1 = state_29148;
var statearr_29192_29244 = state_29148__$1;
(statearr_29192_29244[(2)] = inst_29050);

(statearr_29192_29244[(1)] = (10));


return cljs.core.cst$kw$recur;
} else {
if((state_val_29149 === (5))){
var state_29148__$1 = state_29148;
var statearr_29193_29245 = state_29148__$1;
(statearr_29193_29245[(2)] = true);

(statearr_29193_29245[(1)] = (7));


return cljs.core.cst$kw$recur;
} else {
if((state_val_29149 === (14))){
var state_29148__$1 = state_29148;
var statearr_29194_29246 = state_29148__$1;
(statearr_29194_29246[(2)] = false);

(statearr_29194_29246[(1)] = (15));


return cljs.core.cst$kw$recur;
} else {
if((state_val_29149 === (26))){
var inst_29108 = (state_29148[(9)]);
var inst_29115 = cljs.core.swap_BANG_.cljs$core$IFn$_invoke$arity$3(cs,cljs.core.dissoc,inst_29108);
var state_29148__$1 = state_29148;
var statearr_29195_29247 = state_29148__$1;
(statearr_29195_29247[(2)] = inst_29115);

(statearr_29195_29247[(1)] = (28));


return cljs.core.cst$kw$recur;
} else {
if((state_val_29149 === (16))){
var state_29148__$1 = state_29148;
var statearr_29196_29248 = state_29148__$1;
(statearr_29196_29248[(2)] = true);

(statearr_29196_29248[(1)] = (18));


return cljs.core.cst$kw$recur;
} else {
if((state_val_29149 === (38))){
var inst_29138 = (state_29148[(2)]);
var state_29148__$1 = state_29148;
var statearr_29197_29249 = state_29148__$1;
(statearr_29197_29249[(2)] = inst_29138);

(statearr_29197_29249[(1)] = (34));


return cljs.core.cst$kw$recur;
} else {
if((state_val_29149 === (30))){
var inst_29100 = (state_29148[(13)]);
var inst_29108 = (state_29148[(9)]);
var inst_29099 = (state_29148[(11)]);
var inst_29125 = cljs.core.empty_QMARK_(inst_29099);
var inst_29126 = (inst_29100.cljs$core$IFn$_invoke$arity$1 ? inst_29100.cljs$core$IFn$_invoke$arity$1(inst_29108) : inst_29100.call(null,inst_29108));
var inst_29127 = cljs.core.not(inst_29126);
var inst_29128 = ((inst_29125) && (inst_29127));
var state_29148__$1 = state_29148;
var statearr_29198_29250 = state_29148__$1;
(statearr_29198_29250[(2)] = inst_29128);

(statearr_29198_29250[(1)] = (31));


return cljs.core.cst$kw$recur;
} else {
if((state_val_29149 === (10))){
var inst_29050 = (state_29148[(8)]);
var inst_29071 = (state_29148[(2)]);
var inst_29072 = cljs.core.get.cljs$core$IFn$_invoke$arity$2(inst_29071,cljs.core.cst$kw$solos);
var inst_29073 = cljs.core.get.cljs$core$IFn$_invoke$arity$2(inst_29071,cljs.core.cst$kw$mutes);
var inst_29074 = cljs.core.get.cljs$core$IFn$_invoke$arity$2(inst_29071,cljs.core.cst$kw$reads);
var inst_29075 = inst_29050;
var state_29148__$1 = (function (){var statearr_29199 = state_29148;
(statearr_29199[(16)] = inst_29074);

(statearr_29199[(7)] = inst_29075);

(statearr_29199[(17)] = inst_29073);

(statearr_29199[(18)] = inst_29072);

return statearr_29199;
})();
var statearr_29200_29251 = state_29148__$1;
(statearr_29200_29251[(2)] = null);

(statearr_29200_29251[(1)] = (11));


return cljs.core.cst$kw$recur;
} else {
if((state_val_29149 === (18))){
var inst_29090 = (state_29148[(2)]);
var state_29148__$1 = state_29148;
var statearr_29201_29252 = state_29148__$1;
(statearr_29201_29252[(2)] = inst_29090);

(statearr_29201_29252[(1)] = (15));


return cljs.core.cst$kw$recur;
} else {
if((state_val_29149 === (37))){
var state_29148__$1 = state_29148;
var statearr_29202_29253 = state_29148__$1;
(statearr_29202_29253[(2)] = null);

(statearr_29202_29253[(1)] = (38));


return cljs.core.cst$kw$recur;
} else {
if((state_val_29149 === (8))){
var inst_29050 = (state_29148[(8)]);
var inst_29068 = cljs.core.apply.cljs$core$IFn$_invoke$arity$2(cljs.core.hash_map,inst_29050);
var state_29148__$1 = state_29148;
var statearr_29203_29254 = state_29148__$1;
(statearr_29203_29254[(2)] = inst_29068);

(statearr_29203_29254[(1)] = (10));


return cljs.core.cst$kw$recur;
} else {
return null;
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
});})(c__7992__auto___29208,cs,solo_modes,attrs,solo_mode,change,changed,pick,calc_state,m))
;
return ((function (switch__7885__auto__,c__7992__auto___29208,cs,solo_modes,attrs,solo_mode,change,changed,pick,calc_state,m){
return (function() {
var cljs$core$async$mix_$_state_machine__7886__auto__ = null;
var cljs$core$async$mix_$_state_machine__7886__auto____0 = (function (){
var statearr_29204 = [null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null];
(statearr_29204[(0)] = cljs$core$async$mix_$_state_machine__7886__auto__);

(statearr_29204[(1)] = (1));

return statearr_29204;
});
var cljs$core$async$mix_$_state_machine__7886__auto____1 = (function (state_29148){
while(true){
var ret_value__7887__auto__ = (function (){try{while(true){
var result__7888__auto__ = switch__7885__auto__(state_29148);
if(cljs.core.keyword_identical_QMARK_(result__7888__auto__,cljs.core.cst$kw$recur)){
continue;
} else {
return result__7888__auto__;
}
break;
}
}catch (e29205){if((e29205 instanceof Object)){
var ex__7889__auto__ = e29205;
var statearr_29206_29255 = state_29148;
(statearr_29206_29255[(5)] = ex__7889__auto__);


cljs.core.async.impl.ioc_helpers.process_exception(state_29148);

return cljs.core.cst$kw$recur;
} else {
throw e29205;

}
}})();
if(cljs.core.keyword_identical_QMARK_(ret_value__7887__auto__,cljs.core.cst$kw$recur)){
var G__29256 = state_29148;
state_29148 = G__29256;
continue;
} else {
return ret_value__7887__auto__;
}
break;
}
});
cljs$core$async$mix_$_state_machine__7886__auto__ = function(state_29148){
switch(arguments.length){
case 0:
return cljs$core$async$mix_$_state_machine__7886__auto____0.call(this);
case 1:
return cljs$core$async$mix_$_state_machine__7886__auto____1.call(this,state_29148);
}
throw(new Error('Invalid arity: ' + arguments.length));
};
cljs$core$async$mix_$_state_machine__7886__auto__.cljs$core$IFn$_invoke$arity$0 = cljs$core$async$mix_$_state_machine__7886__auto____0;
cljs$core$async$mix_$_state_machine__7886__auto__.cljs$core$IFn$_invoke$arity$1 = cljs$core$async$mix_$_state_machine__7886__auto____1;
return cljs$core$async$mix_$_state_machine__7886__auto__;
})()
;})(switch__7885__auto__,c__7992__auto___29208,cs,solo_modes,attrs,solo_mode,change,changed,pick,calc_state,m))
})();
var state__7994__auto__ = (function (){var statearr_29207 = (f__7993__auto__.cljs$core$IFn$_invoke$arity$0 ? f__7993__auto__.cljs$core$IFn$_invoke$arity$0() : f__7993__auto__.call(null));
(statearr_29207[(6)] = c__7992__auto___29208);

return statearr_29207;
})();
return cljs.core.async.impl.ioc_helpers.run_state_machine_wrapped(state__7994__auto__);
});})(c__7992__auto___29208,cs,solo_modes,attrs,solo_mode,change,changed,pick,calc_state,m))
);


return m;
});
/**
 * Adds ch as an input to the mix
 */
cljs.core.async.admix = (function cljs$core$async$admix(mix,ch){
return cljs.core.async.admix_STAR_(mix,ch);
});
/**
 * Removes ch as an input to the mix
 */
cljs.core.async.unmix = (function cljs$core$async$unmix(mix,ch){
return cljs.core.async.unmix_STAR_(mix,ch);
});
/**
 * removes all inputs from the mix
 */
cljs.core.async.unmix_all = (function cljs$core$async$unmix_all(mix){
return cljs.core.async.unmix_all_STAR_(mix);
});
/**
 * Atomically sets the state(s) of one or more channels in a mix. The
 *   state map is a map of channels -> channel-state-map. A
 *   channel-state-map is a map of attrs -> boolean, where attr is one or
 *   more of :mute, :pause or :solo. Any states supplied are merged with
 *   the current state.
 * 
 *   Note that channels can be added to a mix via toggle, which can be
 *   used to add channels in a particular (e.g. paused) state.
 */
cljs.core.async.toggle = (function cljs$core$async$toggle(mix,state_map){
return cljs.core.async.toggle_STAR_(mix,state_map);
});
/**
 * Sets the solo mode of the mix. mode must be one of :mute or :pause
 */
cljs.core.async.solo_mode = (function cljs$core$async$solo_mode(mix,mode){
return cljs.core.async.solo_mode_STAR_(mix,mode);
});

/**
 * @interface
 */
cljs.core.async.Pub = function(){};

cljs.core.async.sub_STAR_ = (function cljs$core$async$sub_STAR_(p,v,ch,close_QMARK_){
if((((!((p == null)))) && ((!((p.cljs$core$async$Pub$sub_STAR_$arity$4 == null)))))){
return p.cljs$core$async$Pub$sub_STAR_$arity$4(p,v,ch,close_QMARK_);
} else {
var x__4347__auto__ = (((p == null))?null:p);
var m__4348__auto__ = (cljs.core.async.sub_STAR_[goog.typeOf(x__4347__auto__)]);
if((!((m__4348__auto__ == null)))){
return (m__4348__auto__.cljs$core$IFn$_invoke$arity$4 ? m__4348__auto__.cljs$core$IFn$_invoke$arity$4(p,v,ch,close_QMARK_) : m__4348__auto__.call(null,p,v,ch,close_QMARK_));
} else {
var m__4348__auto____$1 = (cljs.core.async.sub_STAR_["_"]);
if((!((m__4348__auto____$1 == null)))){
return (m__4348__auto____$1.cljs$core$IFn$_invoke$arity$4 ? m__4348__auto____$1.cljs$core$IFn$_invoke$arity$4(p,v,ch,close_QMARK_) : m__4348__auto____$1.call(null,p,v,ch,close_QMARK_));
} else {
throw cljs.core.missing_protocol("Pub.sub*",p);
}
}
}
});

cljs.core.async.unsub_STAR_ = (function cljs$core$async$unsub_STAR_(p,v,ch){
if((((!((p == null)))) && ((!((p.cljs$core$async$Pub$unsub_STAR_$arity$3 == null)))))){
return p.cljs$core$async$Pub$unsub_STAR_$arity$3(p,v,ch);
} else {
var x__4347__auto__ = (((p == null))?null:p);
var m__4348__auto__ = (cljs.core.async.unsub_STAR_[goog.typeOf(x__4347__auto__)]);
if((!((m__4348__auto__ == null)))){
return (m__4348__auto__.cljs$core$IFn$_invoke$arity$3 ? m__4348__auto__.cljs$core$IFn$_invoke$arity$3(p,v,ch) : m__4348__auto__.call(null,p,v,ch));
} else {
var m__4348__auto____$1 = (cljs.core.async.unsub_STAR_["_"]);
if((!((m__4348__auto____$1 == null)))){
return (m__4348__auto____$1.cljs$core$IFn$_invoke$arity$3 ? m__4348__auto____$1.cljs$core$IFn$_invoke$arity$3(p,v,ch) : m__4348__auto____$1.call(null,p,v,ch));
} else {
throw cljs.core.missing_protocol("Pub.unsub*",p);
}
}
}
});

cljs.core.async.unsub_all_STAR_ = (function cljs$core$async$unsub_all_STAR_(var_args){
var G__29258 = arguments.length;
switch (G__29258) {
case 1:
return cljs.core.async.unsub_all_STAR_.cljs$core$IFn$_invoke$arity$1((arguments[(0)]));

break;
case 2:
return cljs.core.async.unsub_all_STAR_.cljs$core$IFn$_invoke$arity$2((arguments[(0)]),(arguments[(1)]));

break;
default:
throw (new Error(["Invalid arity: ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(arguments.length)].join('')));

}
});

cljs.core.async.unsub_all_STAR_.cljs$core$IFn$_invoke$arity$1 = (function (p){
if((((!((p == null)))) && ((!((p.cljs$core$async$Pub$unsub_all_STAR_$arity$1 == null)))))){
return p.cljs$core$async$Pub$unsub_all_STAR_$arity$1(p);
} else {
var x__4347__auto__ = (((p == null))?null:p);
var m__4348__auto__ = (cljs.core.async.unsub_all_STAR_[goog.typeOf(x__4347__auto__)]);
if((!((m__4348__auto__ == null)))){
return (m__4348__auto__.cljs$core$IFn$_invoke$arity$1 ? m__4348__auto__.cljs$core$IFn$_invoke$arity$1(p) : m__4348__auto__.call(null,p));
} else {
var m__4348__auto____$1 = (cljs.core.async.unsub_all_STAR_["_"]);
if((!((m__4348__auto____$1 == null)))){
return (m__4348__auto____$1.cljs$core$IFn$_invoke$arity$1 ? m__4348__auto____$1.cljs$core$IFn$_invoke$arity$1(p) : m__4348__auto____$1.call(null,p));
} else {
throw cljs.core.missing_protocol("Pub.unsub-all*",p);
}
}
}
});

cljs.core.async.unsub_all_STAR_.cljs$core$IFn$_invoke$arity$2 = (function (p,v){
if((((!((p == null)))) && ((!((p.cljs$core$async$Pub$unsub_all_STAR_$arity$2 == null)))))){
return p.cljs$core$async$Pub$unsub_all_STAR_$arity$2(p,v);
} else {
var x__4347__auto__ = (((p == null))?null:p);
var m__4348__auto__ = (cljs.core.async.unsub_all_STAR_[goog.typeOf(x__4347__auto__)]);
if((!((m__4348__auto__ == null)))){
return (m__4348__auto__.cljs$core$IFn$_invoke$arity$2 ? m__4348__auto__.cljs$core$IFn$_invoke$arity$2(p,v) : m__4348__auto__.call(null,p,v));
} else {
var m__4348__auto____$1 = (cljs.core.async.unsub_all_STAR_["_"]);
if((!((m__4348__auto____$1 == null)))){
return (m__4348__auto____$1.cljs$core$IFn$_invoke$arity$2 ? m__4348__auto____$1.cljs$core$IFn$_invoke$arity$2(p,v) : m__4348__auto____$1.call(null,p,v));
} else {
throw cljs.core.missing_protocol("Pub.unsub-all*",p);
}
}
}
});

cljs.core.async.unsub_all_STAR_.cljs$lang$maxFixedArity = 2;


/**
 * Creates and returns a pub(lication) of the supplied channel,
 *   partitioned into topics by the topic-fn. topic-fn will be applied to
 *   each value on the channel and the result will determine the 'topic'
 *   on which that value will be put. Channels can be subscribed to
 *   receive copies of topics using 'sub', and unsubscribed using
 *   'unsub'. Each topic will be handled by an internal mult on a
 *   dedicated channel. By default these internal channels are
 *   unbuffered, but a buf-fn can be supplied which, given a topic,
 *   creates a buffer with desired properties.
 * 
 *   Each item is distributed to all subs in parallel and synchronously,
 *   i.e. each sub must accept before the next item is distributed. Use
 *   buffering/windowing to prevent slow subs from holding up the pub.
 * 
 *   Items received when there are no matching subs get dropped.
 * 
 *   Note that if buf-fns are used then each topic is handled
 *   asynchronously, i.e. if a channel is subscribed to more than one
 *   topic it should not expect them to be interleaved identically with
 *   the source.
 */
cljs.core.async.pub = (function cljs$core$async$pub(var_args){
var G__29262 = arguments.length;
switch (G__29262) {
case 2:
return cljs.core.async.pub.cljs$core$IFn$_invoke$arity$2((arguments[(0)]),(arguments[(1)]));

break;
case 3:
return cljs.core.async.pub.cljs$core$IFn$_invoke$arity$3((arguments[(0)]),(arguments[(1)]),(arguments[(2)]));

break;
default:
throw (new Error(["Invalid arity: ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(arguments.length)].join('')));

}
});

cljs.core.async.pub.cljs$core$IFn$_invoke$arity$2 = (function (ch,topic_fn){
return cljs.core.async.pub.cljs$core$IFn$_invoke$arity$3(ch,topic_fn,cljs.core.constantly(null));
});

cljs.core.async.pub.cljs$core$IFn$_invoke$arity$3 = (function (ch,topic_fn,buf_fn){
var mults = cljs.core.atom.cljs$core$IFn$_invoke$arity$1(cljs.core.PersistentArrayMap.EMPTY);
var ensure_mult = ((function (mults){
return (function (topic){
var or__4047__auto__ = cljs.core.get.cljs$core$IFn$_invoke$arity$2(cljs.core.deref(mults),topic);
if(cljs.core.truth_(or__4047__auto__)){
return or__4047__auto__;
} else {
return cljs.core.get.cljs$core$IFn$_invoke$arity$2(cljs.core.swap_BANG_.cljs$core$IFn$_invoke$arity$2(mults,((function (or__4047__auto__,mults){
return (function (p1__29260_SHARP_){
if(cljs.core.truth_((p1__29260_SHARP_.cljs$core$IFn$_invoke$arity$1 ? p1__29260_SHARP_.cljs$core$IFn$_invoke$arity$1(topic) : p1__29260_SHARP_.call(null,topic)))){
return p1__29260_SHARP_;
} else {
return cljs.core.assoc.cljs$core$IFn$_invoke$arity$3(p1__29260_SHARP_,topic,cljs.core.async.mult(cljs.core.async.chan.cljs$core$IFn$_invoke$arity$1((buf_fn.cljs$core$IFn$_invoke$arity$1 ? buf_fn.cljs$core$IFn$_invoke$arity$1(topic) : buf_fn.call(null,topic)))));
}
});})(or__4047__auto__,mults))
),topic);
}
});})(mults))
;
var p = (function (){
if((typeof cljs !== 'undefined') && (typeof cljs.core !== 'undefined') && (typeof cljs.core.async !== 'undefined') && (typeof cljs.core.async.t_cljs$core$async29263 !== 'undefined')){
} else {

/**
* @constructor
 * @implements {cljs.core.async.Pub}
 * @implements {cljs.core.IMeta}
 * @implements {cljs.core.async.Mux}
 * @implements {cljs.core.IWithMeta}
*/
cljs.core.async.t_cljs$core$async29263 = (function (ch,topic_fn,buf_fn,mults,ensure_mult,meta29264){
this.ch = ch;
this.topic_fn = topic_fn;
this.buf_fn = buf_fn;
this.mults = mults;
this.ensure_mult = ensure_mult;
this.meta29264 = meta29264;
this.cljs$lang$protocol_mask$partition0$ = 393216;
this.cljs$lang$protocol_mask$partition1$ = 0;
});
cljs.core.async.t_cljs$core$async29263.prototype.cljs$core$IWithMeta$_with_meta$arity$2 = ((function (mults,ensure_mult){
return (function (_29265,meta29264__$1){
var self__ = this;
var _29265__$1 = this;
return (new cljs.core.async.t_cljs$core$async29263(self__.ch,self__.topic_fn,self__.buf_fn,self__.mults,self__.ensure_mult,meta29264__$1));
});})(mults,ensure_mult))
;

cljs.core.async.t_cljs$core$async29263.prototype.cljs$core$IMeta$_meta$arity$1 = ((function (mults,ensure_mult){
return (function (_29265){
var self__ = this;
var _29265__$1 = this;
return self__.meta29264;
});})(mults,ensure_mult))
;

cljs.core.async.t_cljs$core$async29263.prototype.cljs$core$async$Mux$ = cljs.core.PROTOCOL_SENTINEL;

cljs.core.async.t_cljs$core$async29263.prototype.cljs$core$async$Mux$muxch_STAR_$arity$1 = ((function (mults,ensure_mult){
return (function (_){
var self__ = this;
var ___$1 = this;
return self__.ch;
});})(mults,ensure_mult))
;

cljs.core.async.t_cljs$core$async29263.prototype.cljs$core$async$Pub$ = cljs.core.PROTOCOL_SENTINEL;

cljs.core.async.t_cljs$core$async29263.prototype.cljs$core$async$Pub$sub_STAR_$arity$4 = ((function (mults,ensure_mult){
return (function (p,topic,ch__$1,close_QMARK_){
var self__ = this;
var p__$1 = this;
var m = (self__.ensure_mult.cljs$core$IFn$_invoke$arity$1 ? self__.ensure_mult.cljs$core$IFn$_invoke$arity$1(topic) : self__.ensure_mult.call(null,topic));
return cljs.core.async.tap.cljs$core$IFn$_invoke$arity$3(m,ch__$1,close_QMARK_);
});})(mults,ensure_mult))
;

cljs.core.async.t_cljs$core$async29263.prototype.cljs$core$async$Pub$unsub_STAR_$arity$3 = ((function (mults,ensure_mult){
return (function (p,topic,ch__$1){
var self__ = this;
var p__$1 = this;
var temp__5457__auto__ = cljs.core.get.cljs$core$IFn$_invoke$arity$2(cljs.core.deref(self__.mults),topic);
if(cljs.core.truth_(temp__5457__auto__)){
var m = temp__5457__auto__;
return cljs.core.async.untap(m,ch__$1);
} else {
return null;
}
});})(mults,ensure_mult))
;

cljs.core.async.t_cljs$core$async29263.prototype.cljs$core$async$Pub$unsub_all_STAR_$arity$1 = ((function (mults,ensure_mult){
return (function (_){
var self__ = this;
var ___$1 = this;
return cljs.core.reset_BANG_(self__.mults,cljs.core.PersistentArrayMap.EMPTY);
});})(mults,ensure_mult))
;

cljs.core.async.t_cljs$core$async29263.prototype.cljs$core$async$Pub$unsub_all_STAR_$arity$2 = ((function (mults,ensure_mult){
return (function (_,topic){
var self__ = this;
var ___$1 = this;
return cljs.core.swap_BANG_.cljs$core$IFn$_invoke$arity$3(self__.mults,cljs.core.dissoc,topic);
});})(mults,ensure_mult))
;

cljs.core.async.t_cljs$core$async29263.getBasis = ((function (mults,ensure_mult){
return (function (){
return new cljs.core.PersistentVector(null, 6, 5, cljs.core.PersistentVector.EMPTY_NODE, [cljs.core.cst$sym$ch,cljs.core.cst$sym$topic_DASH_fn,cljs.core.cst$sym$buf_DASH_fn,cljs.core.cst$sym$mults,cljs.core.cst$sym$ensure_DASH_mult,cljs.core.cst$sym$meta29264], null);
});})(mults,ensure_mult))
;

cljs.core.async.t_cljs$core$async29263.cljs$lang$type = true;

cljs.core.async.t_cljs$core$async29263.cljs$lang$ctorStr = "cljs.core.async/t_cljs$core$async29263";

cljs.core.async.t_cljs$core$async29263.cljs$lang$ctorPrWriter = ((function (mults,ensure_mult){
return (function (this__4290__auto__,writer__4291__auto__,opt__4292__auto__){
return cljs.core._write(writer__4291__auto__,"cljs.core.async/t_cljs$core$async29263");
});})(mults,ensure_mult))
;

/**
 * Positional factory function for cljs.core.async/t_cljs$core$async29263.
 */
cljs.core.async.__GT_t_cljs$core$async29263 = ((function (mults,ensure_mult){
return (function cljs$core$async$__GT_t_cljs$core$async29263(ch__$1,topic_fn__$1,buf_fn__$1,mults__$1,ensure_mult__$1,meta29264){
return (new cljs.core.async.t_cljs$core$async29263(ch__$1,topic_fn__$1,buf_fn__$1,mults__$1,ensure_mult__$1,meta29264));
});})(mults,ensure_mult))
;

}

return (new cljs.core.async.t_cljs$core$async29263(ch,topic_fn,buf_fn,mults,ensure_mult,cljs.core.PersistentArrayMap.EMPTY));
})()
;
var c__7992__auto___29383 = cljs.core.async.chan.cljs$core$IFn$_invoke$arity$1((1));
cljs.core.async.impl.dispatch.run(((function (c__7992__auto___29383,mults,ensure_mult,p){
return (function (){
var f__7993__auto__ = (function (){var switch__7885__auto__ = ((function (c__7992__auto___29383,mults,ensure_mult,p){
return (function (state_29337){
var state_val_29338 = (state_29337[(1)]);
if((state_val_29338 === (7))){
var inst_29333 = (state_29337[(2)]);
var state_29337__$1 = state_29337;
var statearr_29339_29384 = state_29337__$1;
(statearr_29339_29384[(2)] = inst_29333);

(statearr_29339_29384[(1)] = (3));


return cljs.core.cst$kw$recur;
} else {
if((state_val_29338 === (20))){
var state_29337__$1 = state_29337;
var statearr_29340_29385 = state_29337__$1;
(statearr_29340_29385[(2)] = null);

(statearr_29340_29385[(1)] = (21));


return cljs.core.cst$kw$recur;
} else {
if((state_val_29338 === (1))){
var state_29337__$1 = state_29337;
var statearr_29341_29386 = state_29337__$1;
(statearr_29341_29386[(2)] = null);

(statearr_29341_29386[(1)] = (2));


return cljs.core.cst$kw$recur;
} else {
if((state_val_29338 === (24))){
var inst_29316 = (state_29337[(7)]);
var inst_29325 = cljs.core.swap_BANG_.cljs$core$IFn$_invoke$arity$3(mults,cljs.core.dissoc,inst_29316);
var state_29337__$1 = state_29337;
var statearr_29342_29387 = state_29337__$1;
(statearr_29342_29387[(2)] = inst_29325);

(statearr_29342_29387[(1)] = (25));


return cljs.core.cst$kw$recur;
} else {
if((state_val_29338 === (4))){
var inst_29268 = (state_29337[(8)]);
var inst_29268__$1 = (state_29337[(2)]);
var inst_29269 = (inst_29268__$1 == null);
var state_29337__$1 = (function (){var statearr_29343 = state_29337;
(statearr_29343[(8)] = inst_29268__$1);

return statearr_29343;
})();
if(cljs.core.truth_(inst_29269)){
var statearr_29344_29388 = state_29337__$1;
(statearr_29344_29388[(1)] = (5));

} else {
var statearr_29345_29389 = state_29337__$1;
(statearr_29345_29389[(1)] = (6));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_29338 === (15))){
var inst_29310 = (state_29337[(2)]);
var state_29337__$1 = state_29337;
var statearr_29346_29390 = state_29337__$1;
(statearr_29346_29390[(2)] = inst_29310);

(statearr_29346_29390[(1)] = (12));


return cljs.core.cst$kw$recur;
} else {
if((state_val_29338 === (21))){
var inst_29330 = (state_29337[(2)]);
var state_29337__$1 = (function (){var statearr_29347 = state_29337;
(statearr_29347[(9)] = inst_29330);

return statearr_29347;
})();
var statearr_29348_29391 = state_29337__$1;
(statearr_29348_29391[(2)] = null);

(statearr_29348_29391[(1)] = (2));


return cljs.core.cst$kw$recur;
} else {
if((state_val_29338 === (13))){
var inst_29292 = (state_29337[(10)]);
var inst_29294 = cljs.core.chunked_seq_QMARK_(inst_29292);
var state_29337__$1 = state_29337;
if(inst_29294){
var statearr_29349_29392 = state_29337__$1;
(statearr_29349_29392[(1)] = (16));

} else {
var statearr_29350_29393 = state_29337__$1;
(statearr_29350_29393[(1)] = (17));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_29338 === (22))){
var inst_29322 = (state_29337[(2)]);
var state_29337__$1 = state_29337;
if(cljs.core.truth_(inst_29322)){
var statearr_29351_29394 = state_29337__$1;
(statearr_29351_29394[(1)] = (23));

} else {
var statearr_29352_29395 = state_29337__$1;
(statearr_29352_29395[(1)] = (24));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_29338 === (6))){
var inst_29318 = (state_29337[(11)]);
var inst_29316 = (state_29337[(7)]);
var inst_29268 = (state_29337[(8)]);
var inst_29316__$1 = (topic_fn.cljs$core$IFn$_invoke$arity$1 ? topic_fn.cljs$core$IFn$_invoke$arity$1(inst_29268) : topic_fn.call(null,inst_29268));
var inst_29317 = cljs.core.deref(mults);
var inst_29318__$1 = cljs.core.get.cljs$core$IFn$_invoke$arity$2(inst_29317,inst_29316__$1);
var state_29337__$1 = (function (){var statearr_29353 = state_29337;
(statearr_29353[(11)] = inst_29318__$1);

(statearr_29353[(7)] = inst_29316__$1);

return statearr_29353;
})();
if(cljs.core.truth_(inst_29318__$1)){
var statearr_29354_29396 = state_29337__$1;
(statearr_29354_29396[(1)] = (19));

} else {
var statearr_29355_29397 = state_29337__$1;
(statearr_29355_29397[(1)] = (20));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_29338 === (25))){
var inst_29327 = (state_29337[(2)]);
var state_29337__$1 = state_29337;
var statearr_29356_29398 = state_29337__$1;
(statearr_29356_29398[(2)] = inst_29327);

(statearr_29356_29398[(1)] = (21));


return cljs.core.cst$kw$recur;
} else {
if((state_val_29338 === (17))){
var inst_29292 = (state_29337[(10)]);
var inst_29301 = cljs.core.first(inst_29292);
var inst_29302 = cljs.core.async.muxch_STAR_(inst_29301);
var inst_29303 = cljs.core.async.close_BANG_(inst_29302);
var inst_29304 = cljs.core.next(inst_29292);
var inst_29278 = inst_29304;
var inst_29279 = null;
var inst_29280 = (0);
var inst_29281 = (0);
var state_29337__$1 = (function (){var statearr_29357 = state_29337;
(statearr_29357[(12)] = inst_29303);

(statearr_29357[(13)] = inst_29281);

(statearr_29357[(14)] = inst_29279);

(statearr_29357[(15)] = inst_29280);

(statearr_29357[(16)] = inst_29278);

return statearr_29357;
})();
var statearr_29358_29399 = state_29337__$1;
(statearr_29358_29399[(2)] = null);

(statearr_29358_29399[(1)] = (8));


return cljs.core.cst$kw$recur;
} else {
if((state_val_29338 === (3))){
var inst_29335 = (state_29337[(2)]);
var state_29337__$1 = state_29337;
return cljs.core.async.impl.ioc_helpers.return_chan(state_29337__$1,inst_29335);
} else {
if((state_val_29338 === (12))){
var inst_29312 = (state_29337[(2)]);
var state_29337__$1 = state_29337;
var statearr_29359_29400 = state_29337__$1;
(statearr_29359_29400[(2)] = inst_29312);

(statearr_29359_29400[(1)] = (9));


return cljs.core.cst$kw$recur;
} else {
if((state_val_29338 === (2))){
var state_29337__$1 = state_29337;
return cljs.core.async.impl.ioc_helpers.take_BANG_(state_29337__$1,(4),ch);
} else {
if((state_val_29338 === (23))){
var state_29337__$1 = state_29337;
var statearr_29360_29401 = state_29337__$1;
(statearr_29360_29401[(2)] = null);

(statearr_29360_29401[(1)] = (25));


return cljs.core.cst$kw$recur;
} else {
if((state_val_29338 === (19))){
var inst_29318 = (state_29337[(11)]);
var inst_29268 = (state_29337[(8)]);
var inst_29320 = cljs.core.async.muxch_STAR_(inst_29318);
var state_29337__$1 = state_29337;
return cljs.core.async.impl.ioc_helpers.put_BANG_(state_29337__$1,(22),inst_29320,inst_29268);
} else {
if((state_val_29338 === (11))){
var inst_29292 = (state_29337[(10)]);
var inst_29278 = (state_29337[(16)]);
var inst_29292__$1 = cljs.core.seq(inst_29278);
var state_29337__$1 = (function (){var statearr_29361 = state_29337;
(statearr_29361[(10)] = inst_29292__$1);

return statearr_29361;
})();
if(inst_29292__$1){
var statearr_29362_29402 = state_29337__$1;
(statearr_29362_29402[(1)] = (13));

} else {
var statearr_29363_29403 = state_29337__$1;
(statearr_29363_29403[(1)] = (14));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_29338 === (9))){
var inst_29314 = (state_29337[(2)]);
var state_29337__$1 = state_29337;
var statearr_29364_29404 = state_29337__$1;
(statearr_29364_29404[(2)] = inst_29314);

(statearr_29364_29404[(1)] = (7));


return cljs.core.cst$kw$recur;
} else {
if((state_val_29338 === (5))){
var inst_29275 = cljs.core.deref(mults);
var inst_29276 = cljs.core.vals(inst_29275);
var inst_29277 = cljs.core.seq(inst_29276);
var inst_29278 = inst_29277;
var inst_29279 = null;
var inst_29280 = (0);
var inst_29281 = (0);
var state_29337__$1 = (function (){var statearr_29365 = state_29337;
(statearr_29365[(13)] = inst_29281);

(statearr_29365[(14)] = inst_29279);

(statearr_29365[(15)] = inst_29280);

(statearr_29365[(16)] = inst_29278);

return statearr_29365;
})();
var statearr_29366_29405 = state_29337__$1;
(statearr_29366_29405[(2)] = null);

(statearr_29366_29405[(1)] = (8));


return cljs.core.cst$kw$recur;
} else {
if((state_val_29338 === (14))){
var state_29337__$1 = state_29337;
var statearr_29370_29406 = state_29337__$1;
(statearr_29370_29406[(2)] = null);

(statearr_29370_29406[(1)] = (15));


return cljs.core.cst$kw$recur;
} else {
if((state_val_29338 === (16))){
var inst_29292 = (state_29337[(10)]);
var inst_29296 = cljs.core.chunk_first(inst_29292);
var inst_29297 = cljs.core.chunk_rest(inst_29292);
var inst_29298 = cljs.core.count(inst_29296);
var inst_29278 = inst_29297;
var inst_29279 = inst_29296;
var inst_29280 = inst_29298;
var inst_29281 = (0);
var state_29337__$1 = (function (){var statearr_29371 = state_29337;
(statearr_29371[(13)] = inst_29281);

(statearr_29371[(14)] = inst_29279);

(statearr_29371[(15)] = inst_29280);

(statearr_29371[(16)] = inst_29278);

return statearr_29371;
})();
var statearr_29372_29407 = state_29337__$1;
(statearr_29372_29407[(2)] = null);

(statearr_29372_29407[(1)] = (8));


return cljs.core.cst$kw$recur;
} else {
if((state_val_29338 === (10))){
var inst_29281 = (state_29337[(13)]);
var inst_29279 = (state_29337[(14)]);
var inst_29280 = (state_29337[(15)]);
var inst_29278 = (state_29337[(16)]);
var inst_29286 = cljs.core._nth.cljs$core$IFn$_invoke$arity$2(inst_29279,inst_29281);
var inst_29287 = cljs.core.async.muxch_STAR_(inst_29286);
var inst_29288 = cljs.core.async.close_BANG_(inst_29287);
var inst_29289 = (inst_29281 + (1));
var tmp29367 = inst_29279;
var tmp29368 = inst_29280;
var tmp29369 = inst_29278;
var inst_29278__$1 = tmp29369;
var inst_29279__$1 = tmp29367;
var inst_29280__$1 = tmp29368;
var inst_29281__$1 = inst_29289;
var state_29337__$1 = (function (){var statearr_29373 = state_29337;
(statearr_29373[(13)] = inst_29281__$1);

(statearr_29373[(14)] = inst_29279__$1);

(statearr_29373[(15)] = inst_29280__$1);

(statearr_29373[(16)] = inst_29278__$1);

(statearr_29373[(17)] = inst_29288);

return statearr_29373;
})();
var statearr_29374_29408 = state_29337__$1;
(statearr_29374_29408[(2)] = null);

(statearr_29374_29408[(1)] = (8));


return cljs.core.cst$kw$recur;
} else {
if((state_val_29338 === (18))){
var inst_29307 = (state_29337[(2)]);
var state_29337__$1 = state_29337;
var statearr_29375_29409 = state_29337__$1;
(statearr_29375_29409[(2)] = inst_29307);

(statearr_29375_29409[(1)] = (15));


return cljs.core.cst$kw$recur;
} else {
if((state_val_29338 === (8))){
var inst_29281 = (state_29337[(13)]);
var inst_29280 = (state_29337[(15)]);
var inst_29283 = (inst_29281 < inst_29280);
var inst_29284 = inst_29283;
var state_29337__$1 = state_29337;
if(cljs.core.truth_(inst_29284)){
var statearr_29376_29410 = state_29337__$1;
(statearr_29376_29410[(1)] = (10));

} else {
var statearr_29377_29411 = state_29337__$1;
(statearr_29377_29411[(1)] = (11));

}

return cljs.core.cst$kw$recur;
} else {
return null;
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
});})(c__7992__auto___29383,mults,ensure_mult,p))
;
return ((function (switch__7885__auto__,c__7992__auto___29383,mults,ensure_mult,p){
return (function() {
var cljs$core$async$state_machine__7886__auto__ = null;
var cljs$core$async$state_machine__7886__auto____0 = (function (){
var statearr_29378 = [null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null];
(statearr_29378[(0)] = cljs$core$async$state_machine__7886__auto__);

(statearr_29378[(1)] = (1));

return statearr_29378;
});
var cljs$core$async$state_machine__7886__auto____1 = (function (state_29337){
while(true){
var ret_value__7887__auto__ = (function (){try{while(true){
var result__7888__auto__ = switch__7885__auto__(state_29337);
if(cljs.core.keyword_identical_QMARK_(result__7888__auto__,cljs.core.cst$kw$recur)){
continue;
} else {
return result__7888__auto__;
}
break;
}
}catch (e29379){if((e29379 instanceof Object)){
var ex__7889__auto__ = e29379;
var statearr_29380_29412 = state_29337;
(statearr_29380_29412[(5)] = ex__7889__auto__);


cljs.core.async.impl.ioc_helpers.process_exception(state_29337);

return cljs.core.cst$kw$recur;
} else {
throw e29379;

}
}})();
if(cljs.core.keyword_identical_QMARK_(ret_value__7887__auto__,cljs.core.cst$kw$recur)){
var G__29413 = state_29337;
state_29337 = G__29413;
continue;
} else {
return ret_value__7887__auto__;
}
break;
}
});
cljs$core$async$state_machine__7886__auto__ = function(state_29337){
switch(arguments.length){
case 0:
return cljs$core$async$state_machine__7886__auto____0.call(this);
case 1:
return cljs$core$async$state_machine__7886__auto____1.call(this,state_29337);
}
throw(new Error('Invalid arity: ' + arguments.length));
};
cljs$core$async$state_machine__7886__auto__.cljs$core$IFn$_invoke$arity$0 = cljs$core$async$state_machine__7886__auto____0;
cljs$core$async$state_machine__7886__auto__.cljs$core$IFn$_invoke$arity$1 = cljs$core$async$state_machine__7886__auto____1;
return cljs$core$async$state_machine__7886__auto__;
})()
;})(switch__7885__auto__,c__7992__auto___29383,mults,ensure_mult,p))
})();
var state__7994__auto__ = (function (){var statearr_29381 = (f__7993__auto__.cljs$core$IFn$_invoke$arity$0 ? f__7993__auto__.cljs$core$IFn$_invoke$arity$0() : f__7993__auto__.call(null));
(statearr_29381[(6)] = c__7992__auto___29383);

return statearr_29381;
})();
return cljs.core.async.impl.ioc_helpers.run_state_machine_wrapped(state__7994__auto__);
});})(c__7992__auto___29383,mults,ensure_mult,p))
);


return p;
});

cljs.core.async.pub.cljs$lang$maxFixedArity = 3;

/**
 * Subscribes a channel to a topic of a pub.
 * 
 *   By default the channel will be closed when the source closes,
 *   but can be determined by the close? parameter.
 */
cljs.core.async.sub = (function cljs$core$async$sub(var_args){
var G__29415 = arguments.length;
switch (G__29415) {
case 3:
return cljs.core.async.sub.cljs$core$IFn$_invoke$arity$3((arguments[(0)]),(arguments[(1)]),(arguments[(2)]));

break;
case 4:
return cljs.core.async.sub.cljs$core$IFn$_invoke$arity$4((arguments[(0)]),(arguments[(1)]),(arguments[(2)]),(arguments[(3)]));

break;
default:
throw (new Error(["Invalid arity: ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(arguments.length)].join('')));

}
});

cljs.core.async.sub.cljs$core$IFn$_invoke$arity$3 = (function (p,topic,ch){
return cljs.core.async.sub.cljs$core$IFn$_invoke$arity$4(p,topic,ch,true);
});

cljs.core.async.sub.cljs$core$IFn$_invoke$arity$4 = (function (p,topic,ch,close_QMARK_){
return cljs.core.async.sub_STAR_(p,topic,ch,close_QMARK_);
});

cljs.core.async.sub.cljs$lang$maxFixedArity = 4;

/**
 * Unsubscribes a channel from a topic of a pub
 */
cljs.core.async.unsub = (function cljs$core$async$unsub(p,topic,ch){
return cljs.core.async.unsub_STAR_(p,topic,ch);
});
/**
 * Unsubscribes all channels from a pub, or a topic of a pub
 */
cljs.core.async.unsub_all = (function cljs$core$async$unsub_all(var_args){
var G__29418 = arguments.length;
switch (G__29418) {
case 1:
return cljs.core.async.unsub_all.cljs$core$IFn$_invoke$arity$1((arguments[(0)]));

break;
case 2:
return cljs.core.async.unsub_all.cljs$core$IFn$_invoke$arity$2((arguments[(0)]),(arguments[(1)]));

break;
default:
throw (new Error(["Invalid arity: ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(arguments.length)].join('')));

}
});

cljs.core.async.unsub_all.cljs$core$IFn$_invoke$arity$1 = (function (p){
return cljs.core.async.unsub_all_STAR_.cljs$core$IFn$_invoke$arity$1(p);
});

cljs.core.async.unsub_all.cljs$core$IFn$_invoke$arity$2 = (function (p,topic){
return cljs.core.async.unsub_all_STAR_.cljs$core$IFn$_invoke$arity$2(p,topic);
});

cljs.core.async.unsub_all.cljs$lang$maxFixedArity = 2;

/**
 * Takes a function and a collection of source channels, and returns a
 *   channel which contains the values produced by applying f to the set
 *   of first items taken from each source channel, followed by applying
 *   f to the set of second items from each channel, until any one of the
 *   channels is closed, at which point the output channel will be
 *   closed. The returned channel will be unbuffered by default, or a
 *   buf-or-n can be supplied
 */
cljs.core.async.map = (function cljs$core$async$map(var_args){
var G__29421 = arguments.length;
switch (G__29421) {
case 2:
return cljs.core.async.map.cljs$core$IFn$_invoke$arity$2((arguments[(0)]),(arguments[(1)]));

break;
case 3:
return cljs.core.async.map.cljs$core$IFn$_invoke$arity$3((arguments[(0)]),(arguments[(1)]),(arguments[(2)]));

break;
default:
throw (new Error(["Invalid arity: ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(arguments.length)].join('')));

}
});

cljs.core.async.map.cljs$core$IFn$_invoke$arity$2 = (function (f,chs){
return cljs.core.async.map.cljs$core$IFn$_invoke$arity$3(f,chs,null);
});

cljs.core.async.map.cljs$core$IFn$_invoke$arity$3 = (function (f,chs,buf_or_n){
var chs__$1 = cljs.core.vec(chs);
var out = cljs.core.async.chan.cljs$core$IFn$_invoke$arity$1(buf_or_n);
var cnt = cljs.core.count(chs__$1);
var rets = cljs.core.object_array.cljs$core$IFn$_invoke$arity$1(cnt);
var dchan = cljs.core.async.chan.cljs$core$IFn$_invoke$arity$1((1));
var dctr = cljs.core.atom.cljs$core$IFn$_invoke$arity$1(null);
var done = cljs.core.mapv.cljs$core$IFn$_invoke$arity$2(((function (chs__$1,out,cnt,rets,dchan,dctr){
return (function (i){
return ((function (chs__$1,out,cnt,rets,dchan,dctr){
return (function (ret){
(rets[i] = ret);

if((cljs.core.swap_BANG_.cljs$core$IFn$_invoke$arity$2(dctr,cljs.core.dec) === (0))){
return cljs.core.async.put_BANG_.cljs$core$IFn$_invoke$arity$2(dchan,rets.slice((0)));
} else {
return null;
}
});
;})(chs__$1,out,cnt,rets,dchan,dctr))
});})(chs__$1,out,cnt,rets,dchan,dctr))
,cljs.core.range.cljs$core$IFn$_invoke$arity$1(cnt));
var c__7992__auto___29488 = cljs.core.async.chan.cljs$core$IFn$_invoke$arity$1((1));
cljs.core.async.impl.dispatch.run(((function (c__7992__auto___29488,chs__$1,out,cnt,rets,dchan,dctr,done){
return (function (){
var f__7993__auto__ = (function (){var switch__7885__auto__ = ((function (c__7992__auto___29488,chs__$1,out,cnt,rets,dchan,dctr,done){
return (function (state_29460){
var state_val_29461 = (state_29460[(1)]);
if((state_val_29461 === (7))){
var state_29460__$1 = state_29460;
var statearr_29462_29489 = state_29460__$1;
(statearr_29462_29489[(2)] = null);

(statearr_29462_29489[(1)] = (8));


return cljs.core.cst$kw$recur;
} else {
if((state_val_29461 === (1))){
var state_29460__$1 = state_29460;
var statearr_29463_29490 = state_29460__$1;
(statearr_29463_29490[(2)] = null);

(statearr_29463_29490[(1)] = (2));


return cljs.core.cst$kw$recur;
} else {
if((state_val_29461 === (4))){
var inst_29424 = (state_29460[(7)]);
var inst_29426 = (inst_29424 < cnt);
var state_29460__$1 = state_29460;
if(cljs.core.truth_(inst_29426)){
var statearr_29464_29491 = state_29460__$1;
(statearr_29464_29491[(1)] = (6));

} else {
var statearr_29465_29492 = state_29460__$1;
(statearr_29465_29492[(1)] = (7));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_29461 === (15))){
var inst_29456 = (state_29460[(2)]);
var state_29460__$1 = state_29460;
var statearr_29466_29493 = state_29460__$1;
(statearr_29466_29493[(2)] = inst_29456);

(statearr_29466_29493[(1)] = (3));


return cljs.core.cst$kw$recur;
} else {
if((state_val_29461 === (13))){
var inst_29449 = cljs.core.async.close_BANG_(out);
var state_29460__$1 = state_29460;
var statearr_29467_29494 = state_29460__$1;
(statearr_29467_29494[(2)] = inst_29449);

(statearr_29467_29494[(1)] = (15));


return cljs.core.cst$kw$recur;
} else {
if((state_val_29461 === (6))){
var state_29460__$1 = state_29460;
var statearr_29468_29495 = state_29460__$1;
(statearr_29468_29495[(2)] = null);

(statearr_29468_29495[(1)] = (11));


return cljs.core.cst$kw$recur;
} else {
if((state_val_29461 === (3))){
var inst_29458 = (state_29460[(2)]);
var state_29460__$1 = state_29460;
return cljs.core.async.impl.ioc_helpers.return_chan(state_29460__$1,inst_29458);
} else {
if((state_val_29461 === (12))){
var inst_29446 = (state_29460[(8)]);
var inst_29446__$1 = (state_29460[(2)]);
var inst_29447 = cljs.core.some(cljs.core.nil_QMARK_,inst_29446__$1);
var state_29460__$1 = (function (){var statearr_29469 = state_29460;
(statearr_29469[(8)] = inst_29446__$1);

return statearr_29469;
})();
if(cljs.core.truth_(inst_29447)){
var statearr_29470_29496 = state_29460__$1;
(statearr_29470_29496[(1)] = (13));

} else {
var statearr_29471_29497 = state_29460__$1;
(statearr_29471_29497[(1)] = (14));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_29461 === (2))){
var inst_29423 = cljs.core.reset_BANG_(dctr,cnt);
var inst_29424 = (0);
var state_29460__$1 = (function (){var statearr_29472 = state_29460;
(statearr_29472[(7)] = inst_29424);

(statearr_29472[(9)] = inst_29423);

return statearr_29472;
})();
var statearr_29473_29498 = state_29460__$1;
(statearr_29473_29498[(2)] = null);

(statearr_29473_29498[(1)] = (4));


return cljs.core.cst$kw$recur;
} else {
if((state_val_29461 === (11))){
var inst_29424 = (state_29460[(7)]);
var _ = cljs.core.async.impl.ioc_helpers.add_exception_frame(state_29460,(10),Object,null,(9));
var inst_29433 = (chs__$1.cljs$core$IFn$_invoke$arity$1 ? chs__$1.cljs$core$IFn$_invoke$arity$1(inst_29424) : chs__$1.call(null,inst_29424));
var inst_29434 = (done.cljs$core$IFn$_invoke$arity$1 ? done.cljs$core$IFn$_invoke$arity$1(inst_29424) : done.call(null,inst_29424));
var inst_29435 = cljs.core.async.take_BANG_.cljs$core$IFn$_invoke$arity$2(inst_29433,inst_29434);
var state_29460__$1 = state_29460;
var statearr_29474_29499 = state_29460__$1;
(statearr_29474_29499[(2)] = inst_29435);


cljs.core.async.impl.ioc_helpers.process_exception(state_29460__$1);

return cljs.core.cst$kw$recur;
} else {
if((state_val_29461 === (9))){
var inst_29424 = (state_29460[(7)]);
var inst_29437 = (state_29460[(2)]);
var inst_29438 = (inst_29424 + (1));
var inst_29424__$1 = inst_29438;
var state_29460__$1 = (function (){var statearr_29475 = state_29460;
(statearr_29475[(7)] = inst_29424__$1);

(statearr_29475[(10)] = inst_29437);

return statearr_29475;
})();
var statearr_29476_29500 = state_29460__$1;
(statearr_29476_29500[(2)] = null);

(statearr_29476_29500[(1)] = (4));


return cljs.core.cst$kw$recur;
} else {
if((state_val_29461 === (5))){
var inst_29444 = (state_29460[(2)]);
var state_29460__$1 = (function (){var statearr_29477 = state_29460;
(statearr_29477[(11)] = inst_29444);

return statearr_29477;
})();
return cljs.core.async.impl.ioc_helpers.take_BANG_(state_29460__$1,(12),dchan);
} else {
if((state_val_29461 === (14))){
var inst_29446 = (state_29460[(8)]);
var inst_29451 = cljs.core.apply.cljs$core$IFn$_invoke$arity$2(f,inst_29446);
var state_29460__$1 = state_29460;
return cljs.core.async.impl.ioc_helpers.put_BANG_(state_29460__$1,(16),out,inst_29451);
} else {
if((state_val_29461 === (16))){
var inst_29453 = (state_29460[(2)]);
var state_29460__$1 = (function (){var statearr_29478 = state_29460;
(statearr_29478[(12)] = inst_29453);

return statearr_29478;
})();
var statearr_29479_29501 = state_29460__$1;
(statearr_29479_29501[(2)] = null);

(statearr_29479_29501[(1)] = (2));


return cljs.core.cst$kw$recur;
} else {
if((state_val_29461 === (10))){
var inst_29428 = (state_29460[(2)]);
var inst_29429 = cljs.core.swap_BANG_.cljs$core$IFn$_invoke$arity$2(dctr,cljs.core.dec);
var state_29460__$1 = (function (){var statearr_29480 = state_29460;
(statearr_29480[(13)] = inst_29428);

return statearr_29480;
})();
var statearr_29481_29502 = state_29460__$1;
(statearr_29481_29502[(2)] = inst_29429);


cljs.core.async.impl.ioc_helpers.process_exception(state_29460__$1);

return cljs.core.cst$kw$recur;
} else {
if((state_val_29461 === (8))){
var inst_29442 = (state_29460[(2)]);
var state_29460__$1 = state_29460;
var statearr_29482_29503 = state_29460__$1;
(statearr_29482_29503[(2)] = inst_29442);

(statearr_29482_29503[(1)] = (5));


return cljs.core.cst$kw$recur;
} else {
return null;
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
});})(c__7992__auto___29488,chs__$1,out,cnt,rets,dchan,dctr,done))
;
return ((function (switch__7885__auto__,c__7992__auto___29488,chs__$1,out,cnt,rets,dchan,dctr,done){
return (function() {
var cljs$core$async$state_machine__7886__auto__ = null;
var cljs$core$async$state_machine__7886__auto____0 = (function (){
var statearr_29483 = [null,null,null,null,null,null,null,null,null,null,null,null,null,null];
(statearr_29483[(0)] = cljs$core$async$state_machine__7886__auto__);

(statearr_29483[(1)] = (1));

return statearr_29483;
});
var cljs$core$async$state_machine__7886__auto____1 = (function (state_29460){
while(true){
var ret_value__7887__auto__ = (function (){try{while(true){
var result__7888__auto__ = switch__7885__auto__(state_29460);
if(cljs.core.keyword_identical_QMARK_(result__7888__auto__,cljs.core.cst$kw$recur)){
continue;
} else {
return result__7888__auto__;
}
break;
}
}catch (e29484){if((e29484 instanceof Object)){
var ex__7889__auto__ = e29484;
var statearr_29485_29504 = state_29460;
(statearr_29485_29504[(5)] = ex__7889__auto__);


cljs.core.async.impl.ioc_helpers.process_exception(state_29460);

return cljs.core.cst$kw$recur;
} else {
throw e29484;

}
}})();
if(cljs.core.keyword_identical_QMARK_(ret_value__7887__auto__,cljs.core.cst$kw$recur)){
var G__29505 = state_29460;
state_29460 = G__29505;
continue;
} else {
return ret_value__7887__auto__;
}
break;
}
});
cljs$core$async$state_machine__7886__auto__ = function(state_29460){
switch(arguments.length){
case 0:
return cljs$core$async$state_machine__7886__auto____0.call(this);
case 1:
return cljs$core$async$state_machine__7886__auto____1.call(this,state_29460);
}
throw(new Error('Invalid arity: ' + arguments.length));
};
cljs$core$async$state_machine__7886__auto__.cljs$core$IFn$_invoke$arity$0 = cljs$core$async$state_machine__7886__auto____0;
cljs$core$async$state_machine__7886__auto__.cljs$core$IFn$_invoke$arity$1 = cljs$core$async$state_machine__7886__auto____1;
return cljs$core$async$state_machine__7886__auto__;
})()
;})(switch__7885__auto__,c__7992__auto___29488,chs__$1,out,cnt,rets,dchan,dctr,done))
})();
var state__7994__auto__ = (function (){var statearr_29486 = (f__7993__auto__.cljs$core$IFn$_invoke$arity$0 ? f__7993__auto__.cljs$core$IFn$_invoke$arity$0() : f__7993__auto__.call(null));
(statearr_29486[(6)] = c__7992__auto___29488);

return statearr_29486;
})();
return cljs.core.async.impl.ioc_helpers.run_state_machine_wrapped(state__7994__auto__);
});})(c__7992__auto___29488,chs__$1,out,cnt,rets,dchan,dctr,done))
);


return out;
});

cljs.core.async.map.cljs$lang$maxFixedArity = 3;

/**
 * Takes a collection of source channels and returns a channel which
 *   contains all values taken from them. The returned channel will be
 *   unbuffered by default, or a buf-or-n can be supplied. The channel
 *   will close after all the source channels have closed.
 */
cljs.core.async.merge = (function cljs$core$async$merge(var_args){
var G__29508 = arguments.length;
switch (G__29508) {
case 1:
return cljs.core.async.merge.cljs$core$IFn$_invoke$arity$1((arguments[(0)]));

break;
case 2:
return cljs.core.async.merge.cljs$core$IFn$_invoke$arity$2((arguments[(0)]),(arguments[(1)]));

break;
default:
throw (new Error(["Invalid arity: ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(arguments.length)].join('')));

}
});

cljs.core.async.merge.cljs$core$IFn$_invoke$arity$1 = (function (chs){
return cljs.core.async.merge.cljs$core$IFn$_invoke$arity$2(chs,null);
});

cljs.core.async.merge.cljs$core$IFn$_invoke$arity$2 = (function (chs,buf_or_n){
var out = cljs.core.async.chan.cljs$core$IFn$_invoke$arity$1(buf_or_n);
var c__7992__auto___29562 = cljs.core.async.chan.cljs$core$IFn$_invoke$arity$1((1));
cljs.core.async.impl.dispatch.run(((function (c__7992__auto___29562,out){
return (function (){
var f__7993__auto__ = (function (){var switch__7885__auto__ = ((function (c__7992__auto___29562,out){
return (function (state_29540){
var state_val_29541 = (state_29540[(1)]);
if((state_val_29541 === (7))){
var inst_29519 = (state_29540[(7)]);
var inst_29520 = (state_29540[(8)]);
var inst_29519__$1 = (state_29540[(2)]);
var inst_29520__$1 = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(inst_29519__$1,(0),null);
var inst_29521 = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(inst_29519__$1,(1),null);
var inst_29522 = (inst_29520__$1 == null);
var state_29540__$1 = (function (){var statearr_29542 = state_29540;
(statearr_29542[(9)] = inst_29521);

(statearr_29542[(7)] = inst_29519__$1);

(statearr_29542[(8)] = inst_29520__$1);

return statearr_29542;
})();
if(cljs.core.truth_(inst_29522)){
var statearr_29543_29563 = state_29540__$1;
(statearr_29543_29563[(1)] = (8));

} else {
var statearr_29544_29564 = state_29540__$1;
(statearr_29544_29564[(1)] = (9));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_29541 === (1))){
var inst_29509 = cljs.core.vec(chs);
var inst_29510 = inst_29509;
var state_29540__$1 = (function (){var statearr_29545 = state_29540;
(statearr_29545[(10)] = inst_29510);

return statearr_29545;
})();
var statearr_29546_29565 = state_29540__$1;
(statearr_29546_29565[(2)] = null);

(statearr_29546_29565[(1)] = (2));


return cljs.core.cst$kw$recur;
} else {
if((state_val_29541 === (4))){
var inst_29510 = (state_29540[(10)]);
var state_29540__$1 = state_29540;
return cljs.core.async.ioc_alts_BANG_(state_29540__$1,(7),inst_29510);
} else {
if((state_val_29541 === (6))){
var inst_29536 = (state_29540[(2)]);
var state_29540__$1 = state_29540;
var statearr_29547_29566 = state_29540__$1;
(statearr_29547_29566[(2)] = inst_29536);

(statearr_29547_29566[(1)] = (3));


return cljs.core.cst$kw$recur;
} else {
if((state_val_29541 === (3))){
var inst_29538 = (state_29540[(2)]);
var state_29540__$1 = state_29540;
return cljs.core.async.impl.ioc_helpers.return_chan(state_29540__$1,inst_29538);
} else {
if((state_val_29541 === (2))){
var inst_29510 = (state_29540[(10)]);
var inst_29512 = cljs.core.count(inst_29510);
var inst_29513 = (inst_29512 > (0));
var state_29540__$1 = state_29540;
if(cljs.core.truth_(inst_29513)){
var statearr_29549_29567 = state_29540__$1;
(statearr_29549_29567[(1)] = (4));

} else {
var statearr_29550_29568 = state_29540__$1;
(statearr_29550_29568[(1)] = (5));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_29541 === (11))){
var inst_29510 = (state_29540[(10)]);
var inst_29529 = (state_29540[(2)]);
var tmp29548 = inst_29510;
var inst_29510__$1 = tmp29548;
var state_29540__$1 = (function (){var statearr_29551 = state_29540;
(statearr_29551[(11)] = inst_29529);

(statearr_29551[(10)] = inst_29510__$1);

return statearr_29551;
})();
var statearr_29552_29569 = state_29540__$1;
(statearr_29552_29569[(2)] = null);

(statearr_29552_29569[(1)] = (2));


return cljs.core.cst$kw$recur;
} else {
if((state_val_29541 === (9))){
var inst_29520 = (state_29540[(8)]);
var state_29540__$1 = state_29540;
return cljs.core.async.impl.ioc_helpers.put_BANG_(state_29540__$1,(11),out,inst_29520);
} else {
if((state_val_29541 === (5))){
var inst_29534 = cljs.core.async.close_BANG_(out);
var state_29540__$1 = state_29540;
var statearr_29553_29570 = state_29540__$1;
(statearr_29553_29570[(2)] = inst_29534);

(statearr_29553_29570[(1)] = (6));


return cljs.core.cst$kw$recur;
} else {
if((state_val_29541 === (10))){
var inst_29532 = (state_29540[(2)]);
var state_29540__$1 = state_29540;
var statearr_29554_29571 = state_29540__$1;
(statearr_29554_29571[(2)] = inst_29532);

(statearr_29554_29571[(1)] = (6));


return cljs.core.cst$kw$recur;
} else {
if((state_val_29541 === (8))){
var inst_29521 = (state_29540[(9)]);
var inst_29519 = (state_29540[(7)]);
var inst_29520 = (state_29540[(8)]);
var inst_29510 = (state_29540[(10)]);
var inst_29524 = (function (){var cs = inst_29510;
var vec__29515 = inst_29519;
var v = inst_29520;
var c = inst_29521;
return ((function (cs,vec__29515,v,c,inst_29521,inst_29519,inst_29520,inst_29510,state_val_29541,c__7992__auto___29562,out){
return (function (p1__29506_SHARP_){
return cljs.core.not_EQ_.cljs$core$IFn$_invoke$arity$2(c,p1__29506_SHARP_);
});
;})(cs,vec__29515,v,c,inst_29521,inst_29519,inst_29520,inst_29510,state_val_29541,c__7992__auto___29562,out))
})();
var inst_29525 = cljs.core.filterv(inst_29524,inst_29510);
var inst_29510__$1 = inst_29525;
var state_29540__$1 = (function (){var statearr_29555 = state_29540;
(statearr_29555[(10)] = inst_29510__$1);

return statearr_29555;
})();
var statearr_29556_29572 = state_29540__$1;
(statearr_29556_29572[(2)] = null);

(statearr_29556_29572[(1)] = (2));


return cljs.core.cst$kw$recur;
} else {
return null;
}
}
}
}
}
}
}
}
}
}
}
});})(c__7992__auto___29562,out))
;
return ((function (switch__7885__auto__,c__7992__auto___29562,out){
return (function() {
var cljs$core$async$state_machine__7886__auto__ = null;
var cljs$core$async$state_machine__7886__auto____0 = (function (){
var statearr_29557 = [null,null,null,null,null,null,null,null,null,null,null,null];
(statearr_29557[(0)] = cljs$core$async$state_machine__7886__auto__);

(statearr_29557[(1)] = (1));

return statearr_29557;
});
var cljs$core$async$state_machine__7886__auto____1 = (function (state_29540){
while(true){
var ret_value__7887__auto__ = (function (){try{while(true){
var result__7888__auto__ = switch__7885__auto__(state_29540);
if(cljs.core.keyword_identical_QMARK_(result__7888__auto__,cljs.core.cst$kw$recur)){
continue;
} else {
return result__7888__auto__;
}
break;
}
}catch (e29558){if((e29558 instanceof Object)){
var ex__7889__auto__ = e29558;
var statearr_29559_29573 = state_29540;
(statearr_29559_29573[(5)] = ex__7889__auto__);


cljs.core.async.impl.ioc_helpers.process_exception(state_29540);

return cljs.core.cst$kw$recur;
} else {
throw e29558;

}
}})();
if(cljs.core.keyword_identical_QMARK_(ret_value__7887__auto__,cljs.core.cst$kw$recur)){
var G__29574 = state_29540;
state_29540 = G__29574;
continue;
} else {
return ret_value__7887__auto__;
}
break;
}
});
cljs$core$async$state_machine__7886__auto__ = function(state_29540){
switch(arguments.length){
case 0:
return cljs$core$async$state_machine__7886__auto____0.call(this);
case 1:
return cljs$core$async$state_machine__7886__auto____1.call(this,state_29540);
}
throw(new Error('Invalid arity: ' + arguments.length));
};
cljs$core$async$state_machine__7886__auto__.cljs$core$IFn$_invoke$arity$0 = cljs$core$async$state_machine__7886__auto____0;
cljs$core$async$state_machine__7886__auto__.cljs$core$IFn$_invoke$arity$1 = cljs$core$async$state_machine__7886__auto____1;
return cljs$core$async$state_machine__7886__auto__;
})()
;})(switch__7885__auto__,c__7992__auto___29562,out))
})();
var state__7994__auto__ = (function (){var statearr_29560 = (f__7993__auto__.cljs$core$IFn$_invoke$arity$0 ? f__7993__auto__.cljs$core$IFn$_invoke$arity$0() : f__7993__auto__.call(null));
(statearr_29560[(6)] = c__7992__auto___29562);

return statearr_29560;
})();
return cljs.core.async.impl.ioc_helpers.run_state_machine_wrapped(state__7994__auto__);
});})(c__7992__auto___29562,out))
);


return out;
});

cljs.core.async.merge.cljs$lang$maxFixedArity = 2;

/**
 * Returns a channel containing the single (collection) result of the
 *   items taken from the channel conjoined to the supplied
 *   collection. ch must close before into produces a result.
 */
cljs.core.async.into = (function cljs$core$async$into(coll,ch){
return cljs.core.async.reduce(cljs.core.conj,coll,ch);
});
/**
 * Returns a channel that will return, at most, n items from ch. After n items
 * have been returned, or ch has been closed, the return chanel will close.
 * 
 *   The output channel is unbuffered by default, unless buf-or-n is given.
 */
cljs.core.async.take = (function cljs$core$async$take(var_args){
var G__29576 = arguments.length;
switch (G__29576) {
case 2:
return cljs.core.async.take.cljs$core$IFn$_invoke$arity$2((arguments[(0)]),(arguments[(1)]));

break;
case 3:
return cljs.core.async.take.cljs$core$IFn$_invoke$arity$3((arguments[(0)]),(arguments[(1)]),(arguments[(2)]));

break;
default:
throw (new Error(["Invalid arity: ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(arguments.length)].join('')));

}
});

cljs.core.async.take.cljs$core$IFn$_invoke$arity$2 = (function (n,ch){
return cljs.core.async.take.cljs$core$IFn$_invoke$arity$3(n,ch,null);
});

cljs.core.async.take.cljs$core$IFn$_invoke$arity$3 = (function (n,ch,buf_or_n){
var out = cljs.core.async.chan.cljs$core$IFn$_invoke$arity$1(buf_or_n);
var c__7992__auto___29621 = cljs.core.async.chan.cljs$core$IFn$_invoke$arity$1((1));
cljs.core.async.impl.dispatch.run(((function (c__7992__auto___29621,out){
return (function (){
var f__7993__auto__ = (function (){var switch__7885__auto__ = ((function (c__7992__auto___29621,out){
return (function (state_29600){
var state_val_29601 = (state_29600[(1)]);
if((state_val_29601 === (7))){
var inst_29582 = (state_29600[(7)]);
var inst_29582__$1 = (state_29600[(2)]);
var inst_29583 = (inst_29582__$1 == null);
var inst_29584 = cljs.core.not(inst_29583);
var state_29600__$1 = (function (){var statearr_29602 = state_29600;
(statearr_29602[(7)] = inst_29582__$1);

return statearr_29602;
})();
if(inst_29584){
var statearr_29603_29622 = state_29600__$1;
(statearr_29603_29622[(1)] = (8));

} else {
var statearr_29604_29623 = state_29600__$1;
(statearr_29604_29623[(1)] = (9));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_29601 === (1))){
var inst_29577 = (0);
var state_29600__$1 = (function (){var statearr_29605 = state_29600;
(statearr_29605[(8)] = inst_29577);

return statearr_29605;
})();
var statearr_29606_29624 = state_29600__$1;
(statearr_29606_29624[(2)] = null);

(statearr_29606_29624[(1)] = (2));


return cljs.core.cst$kw$recur;
} else {
if((state_val_29601 === (4))){
var state_29600__$1 = state_29600;
return cljs.core.async.impl.ioc_helpers.take_BANG_(state_29600__$1,(7),ch);
} else {
if((state_val_29601 === (6))){
var inst_29595 = (state_29600[(2)]);
var state_29600__$1 = state_29600;
var statearr_29607_29625 = state_29600__$1;
(statearr_29607_29625[(2)] = inst_29595);

(statearr_29607_29625[(1)] = (3));


return cljs.core.cst$kw$recur;
} else {
if((state_val_29601 === (3))){
var inst_29597 = (state_29600[(2)]);
var inst_29598 = cljs.core.async.close_BANG_(out);
var state_29600__$1 = (function (){var statearr_29608 = state_29600;
(statearr_29608[(9)] = inst_29597);

return statearr_29608;
})();
return cljs.core.async.impl.ioc_helpers.return_chan(state_29600__$1,inst_29598);
} else {
if((state_val_29601 === (2))){
var inst_29577 = (state_29600[(8)]);
var inst_29579 = (inst_29577 < n);
var state_29600__$1 = state_29600;
if(cljs.core.truth_(inst_29579)){
var statearr_29609_29626 = state_29600__$1;
(statearr_29609_29626[(1)] = (4));

} else {
var statearr_29610_29627 = state_29600__$1;
(statearr_29610_29627[(1)] = (5));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_29601 === (11))){
var inst_29577 = (state_29600[(8)]);
var inst_29587 = (state_29600[(2)]);
var inst_29588 = (inst_29577 + (1));
var inst_29577__$1 = inst_29588;
var state_29600__$1 = (function (){var statearr_29611 = state_29600;
(statearr_29611[(10)] = inst_29587);

(statearr_29611[(8)] = inst_29577__$1);

return statearr_29611;
})();
var statearr_29612_29628 = state_29600__$1;
(statearr_29612_29628[(2)] = null);

(statearr_29612_29628[(1)] = (2));


return cljs.core.cst$kw$recur;
} else {
if((state_val_29601 === (9))){
var state_29600__$1 = state_29600;
var statearr_29613_29629 = state_29600__$1;
(statearr_29613_29629[(2)] = null);

(statearr_29613_29629[(1)] = (10));


return cljs.core.cst$kw$recur;
} else {
if((state_val_29601 === (5))){
var state_29600__$1 = state_29600;
var statearr_29614_29630 = state_29600__$1;
(statearr_29614_29630[(2)] = null);

(statearr_29614_29630[(1)] = (6));


return cljs.core.cst$kw$recur;
} else {
if((state_val_29601 === (10))){
var inst_29592 = (state_29600[(2)]);
var state_29600__$1 = state_29600;
var statearr_29615_29631 = state_29600__$1;
(statearr_29615_29631[(2)] = inst_29592);

(statearr_29615_29631[(1)] = (6));


return cljs.core.cst$kw$recur;
} else {
if((state_val_29601 === (8))){
var inst_29582 = (state_29600[(7)]);
var state_29600__$1 = state_29600;
return cljs.core.async.impl.ioc_helpers.put_BANG_(state_29600__$1,(11),out,inst_29582);
} else {
return null;
}
}
}
}
}
}
}
}
}
}
}
});})(c__7992__auto___29621,out))
;
return ((function (switch__7885__auto__,c__7992__auto___29621,out){
return (function() {
var cljs$core$async$state_machine__7886__auto__ = null;
var cljs$core$async$state_machine__7886__auto____0 = (function (){
var statearr_29616 = [null,null,null,null,null,null,null,null,null,null,null];
(statearr_29616[(0)] = cljs$core$async$state_machine__7886__auto__);

(statearr_29616[(1)] = (1));

return statearr_29616;
});
var cljs$core$async$state_machine__7886__auto____1 = (function (state_29600){
while(true){
var ret_value__7887__auto__ = (function (){try{while(true){
var result__7888__auto__ = switch__7885__auto__(state_29600);
if(cljs.core.keyword_identical_QMARK_(result__7888__auto__,cljs.core.cst$kw$recur)){
continue;
} else {
return result__7888__auto__;
}
break;
}
}catch (e29617){if((e29617 instanceof Object)){
var ex__7889__auto__ = e29617;
var statearr_29618_29632 = state_29600;
(statearr_29618_29632[(5)] = ex__7889__auto__);


cljs.core.async.impl.ioc_helpers.process_exception(state_29600);

return cljs.core.cst$kw$recur;
} else {
throw e29617;

}
}})();
if(cljs.core.keyword_identical_QMARK_(ret_value__7887__auto__,cljs.core.cst$kw$recur)){
var G__29633 = state_29600;
state_29600 = G__29633;
continue;
} else {
return ret_value__7887__auto__;
}
break;
}
});
cljs$core$async$state_machine__7886__auto__ = function(state_29600){
switch(arguments.length){
case 0:
return cljs$core$async$state_machine__7886__auto____0.call(this);
case 1:
return cljs$core$async$state_machine__7886__auto____1.call(this,state_29600);
}
throw(new Error('Invalid arity: ' + arguments.length));
};
cljs$core$async$state_machine__7886__auto__.cljs$core$IFn$_invoke$arity$0 = cljs$core$async$state_machine__7886__auto____0;
cljs$core$async$state_machine__7886__auto__.cljs$core$IFn$_invoke$arity$1 = cljs$core$async$state_machine__7886__auto____1;
return cljs$core$async$state_machine__7886__auto__;
})()
;})(switch__7885__auto__,c__7992__auto___29621,out))
})();
var state__7994__auto__ = (function (){var statearr_29619 = (f__7993__auto__.cljs$core$IFn$_invoke$arity$0 ? f__7993__auto__.cljs$core$IFn$_invoke$arity$0() : f__7993__auto__.call(null));
(statearr_29619[(6)] = c__7992__auto___29621);

return statearr_29619;
})();
return cljs.core.async.impl.ioc_helpers.run_state_machine_wrapped(state__7994__auto__);
});})(c__7992__auto___29621,out))
);


return out;
});

cljs.core.async.take.cljs$lang$maxFixedArity = 3;

/**
 * Deprecated - this function will be removed. Use transducer instead
 */
cljs.core.async.map_LT_ = (function cljs$core$async$map_LT_(f,ch){
if((typeof cljs !== 'undefined') && (typeof cljs.core !== 'undefined') && (typeof cljs.core.async !== 'undefined') && (typeof cljs.core.async.t_cljs$core$async29635 !== 'undefined')){
} else {

/**
* @constructor
 * @implements {cljs.core.async.impl.protocols.Channel}
 * @implements {cljs.core.async.impl.protocols.WritePort}
 * @implements {cljs.core.async.impl.protocols.ReadPort}
 * @implements {cljs.core.IMeta}
 * @implements {cljs.core.IWithMeta}
*/
cljs.core.async.t_cljs$core$async29635 = (function (f,ch,meta29636){
this.f = f;
this.ch = ch;
this.meta29636 = meta29636;
this.cljs$lang$protocol_mask$partition0$ = 393216;
this.cljs$lang$protocol_mask$partition1$ = 0;
});
cljs.core.async.t_cljs$core$async29635.prototype.cljs$core$IWithMeta$_with_meta$arity$2 = (function (_29637,meta29636__$1){
var self__ = this;
var _29637__$1 = this;
return (new cljs.core.async.t_cljs$core$async29635(self__.f,self__.ch,meta29636__$1));
});

cljs.core.async.t_cljs$core$async29635.prototype.cljs$core$IMeta$_meta$arity$1 = (function (_29637){
var self__ = this;
var _29637__$1 = this;
return self__.meta29636;
});

cljs.core.async.t_cljs$core$async29635.prototype.cljs$core$async$impl$protocols$Channel$ = cljs.core.PROTOCOL_SENTINEL;

cljs.core.async.t_cljs$core$async29635.prototype.cljs$core$async$impl$protocols$Channel$close_BANG_$arity$1 = (function (_){
var self__ = this;
var ___$1 = this;
return cljs.core.async.impl.protocols.close_BANG_(self__.ch);
});

cljs.core.async.t_cljs$core$async29635.prototype.cljs$core$async$impl$protocols$Channel$closed_QMARK_$arity$1 = (function (_){
var self__ = this;
var ___$1 = this;
return cljs.core.async.impl.protocols.closed_QMARK_(self__.ch);
});

cljs.core.async.t_cljs$core$async29635.prototype.cljs$core$async$impl$protocols$ReadPort$ = cljs.core.PROTOCOL_SENTINEL;

cljs.core.async.t_cljs$core$async29635.prototype.cljs$core$async$impl$protocols$ReadPort$take_BANG_$arity$2 = (function (_,fn1){
var self__ = this;
var ___$1 = this;
var ret = cljs.core.async.impl.protocols.take_BANG_(self__.ch,(function (){
if((typeof cljs !== 'undefined') && (typeof cljs.core !== 'undefined') && (typeof cljs.core.async !== 'undefined') && (typeof cljs.core.async.t_cljs$core$async29638 !== 'undefined')){
} else {

/**
* @constructor
 * @implements {cljs.core.async.impl.protocols.Handler}
 * @implements {cljs.core.IMeta}
 * @implements {cljs.core.IWithMeta}
*/
cljs.core.async.t_cljs$core$async29638 = (function (f,ch,meta29636,_,fn1,meta29639){
this.f = f;
this.ch = ch;
this.meta29636 = meta29636;
this._ = _;
this.fn1 = fn1;
this.meta29639 = meta29639;
this.cljs$lang$protocol_mask$partition0$ = 393216;
this.cljs$lang$protocol_mask$partition1$ = 0;
});
cljs.core.async.t_cljs$core$async29638.prototype.cljs$core$IWithMeta$_with_meta$arity$2 = ((function (___$1){
return (function (_29640,meta29639__$1){
var self__ = this;
var _29640__$1 = this;
return (new cljs.core.async.t_cljs$core$async29638(self__.f,self__.ch,self__.meta29636,self__._,self__.fn1,meta29639__$1));
});})(___$1))
;

cljs.core.async.t_cljs$core$async29638.prototype.cljs$core$IMeta$_meta$arity$1 = ((function (___$1){
return (function (_29640){
var self__ = this;
var _29640__$1 = this;
return self__.meta29639;
});})(___$1))
;

cljs.core.async.t_cljs$core$async29638.prototype.cljs$core$async$impl$protocols$Handler$ = cljs.core.PROTOCOL_SENTINEL;

cljs.core.async.t_cljs$core$async29638.prototype.cljs$core$async$impl$protocols$Handler$active_QMARK_$arity$1 = ((function (___$1){
return (function (___$1){
var self__ = this;
var ___$2 = this;
return cljs.core.async.impl.protocols.active_QMARK_(self__.fn1);
});})(___$1))
;

cljs.core.async.t_cljs$core$async29638.prototype.cljs$core$async$impl$protocols$Handler$blockable_QMARK_$arity$1 = ((function (___$1){
return (function (___$1){
var self__ = this;
var ___$2 = this;
return true;
});})(___$1))
;

cljs.core.async.t_cljs$core$async29638.prototype.cljs$core$async$impl$protocols$Handler$commit$arity$1 = ((function (___$1){
return (function (___$1){
var self__ = this;
var ___$2 = this;
var f1 = cljs.core.async.impl.protocols.commit(self__.fn1);
return ((function (f1,___$2,___$1){
return (function (p1__29634_SHARP_){
var G__29641 = (((p1__29634_SHARP_ == null))?null:(self__.f.cljs$core$IFn$_invoke$arity$1 ? self__.f.cljs$core$IFn$_invoke$arity$1(p1__29634_SHARP_) : self__.f.call(null,p1__29634_SHARP_)));
return (f1.cljs$core$IFn$_invoke$arity$1 ? f1.cljs$core$IFn$_invoke$arity$1(G__29641) : f1.call(null,G__29641));
});
;})(f1,___$2,___$1))
});})(___$1))
;

cljs.core.async.t_cljs$core$async29638.getBasis = ((function (___$1){
return (function (){
return new cljs.core.PersistentVector(null, 6, 5, cljs.core.PersistentVector.EMPTY_NODE, [cljs.core.cst$sym$f,cljs.core.cst$sym$ch,cljs.core.cst$sym$meta29636,cljs.core.with_meta(cljs.core.cst$sym$_,new cljs.core.PersistentArrayMap(null, 1, [cljs.core.cst$kw$tag,cljs.core.cst$sym$cljs$core$async_SLASH_t_cljs$core$async29635], null)),cljs.core.cst$sym$fn1,cljs.core.cst$sym$meta29639], null);
});})(___$1))
;

cljs.core.async.t_cljs$core$async29638.cljs$lang$type = true;

cljs.core.async.t_cljs$core$async29638.cljs$lang$ctorStr = "cljs.core.async/t_cljs$core$async29638";

cljs.core.async.t_cljs$core$async29638.cljs$lang$ctorPrWriter = ((function (___$1){
return (function (this__4290__auto__,writer__4291__auto__,opt__4292__auto__){
return cljs.core._write(writer__4291__auto__,"cljs.core.async/t_cljs$core$async29638");
});})(___$1))
;

/**
 * Positional factory function for cljs.core.async/t_cljs$core$async29638.
 */
cljs.core.async.__GT_t_cljs$core$async29638 = ((function (___$1){
return (function cljs$core$async$map_LT__$___GT_t_cljs$core$async29638(f__$1,ch__$1,meta29636__$1,___$2,fn1__$1,meta29639){
return (new cljs.core.async.t_cljs$core$async29638(f__$1,ch__$1,meta29636__$1,___$2,fn1__$1,meta29639));
});})(___$1))
;

}

return (new cljs.core.async.t_cljs$core$async29638(self__.f,self__.ch,self__.meta29636,___$1,fn1,cljs.core.PersistentArrayMap.EMPTY));
})()
);
if(cljs.core.truth_((function (){var and__4036__auto__ = ret;
if(cljs.core.truth_(and__4036__auto__)){
return (!((cljs.core.deref(ret) == null)));
} else {
return and__4036__auto__;
}
})())){
return cljs.core.async.impl.channels.box((function (){var G__29642 = cljs.core.deref(ret);
return (self__.f.cljs$core$IFn$_invoke$arity$1 ? self__.f.cljs$core$IFn$_invoke$arity$1(G__29642) : self__.f.call(null,G__29642));
})());
} else {
return ret;
}
});

cljs.core.async.t_cljs$core$async29635.prototype.cljs$core$async$impl$protocols$WritePort$ = cljs.core.PROTOCOL_SENTINEL;

cljs.core.async.t_cljs$core$async29635.prototype.cljs$core$async$impl$protocols$WritePort$put_BANG_$arity$3 = (function (_,val,fn1){
var self__ = this;
var ___$1 = this;
return cljs.core.async.impl.protocols.put_BANG_(self__.ch,val,fn1);
});

cljs.core.async.t_cljs$core$async29635.getBasis = (function (){
return new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [cljs.core.cst$sym$f,cljs.core.cst$sym$ch,cljs.core.cst$sym$meta29636], null);
});

cljs.core.async.t_cljs$core$async29635.cljs$lang$type = true;

cljs.core.async.t_cljs$core$async29635.cljs$lang$ctorStr = "cljs.core.async/t_cljs$core$async29635";

cljs.core.async.t_cljs$core$async29635.cljs$lang$ctorPrWriter = (function (this__4290__auto__,writer__4291__auto__,opt__4292__auto__){
return cljs.core._write(writer__4291__auto__,"cljs.core.async/t_cljs$core$async29635");
});

/**
 * Positional factory function for cljs.core.async/t_cljs$core$async29635.
 */
cljs.core.async.__GT_t_cljs$core$async29635 = (function cljs$core$async$map_LT__$___GT_t_cljs$core$async29635(f__$1,ch__$1,meta29636){
return (new cljs.core.async.t_cljs$core$async29635(f__$1,ch__$1,meta29636));
});

}

return (new cljs.core.async.t_cljs$core$async29635(f,ch,cljs.core.PersistentArrayMap.EMPTY));
});
/**
 * Deprecated - this function will be removed. Use transducer instead
 */
cljs.core.async.map_GT_ = (function cljs$core$async$map_GT_(f,ch){
if((typeof cljs !== 'undefined') && (typeof cljs.core !== 'undefined') && (typeof cljs.core.async !== 'undefined') && (typeof cljs.core.async.t_cljs$core$async29643 !== 'undefined')){
} else {

/**
* @constructor
 * @implements {cljs.core.async.impl.protocols.Channel}
 * @implements {cljs.core.async.impl.protocols.WritePort}
 * @implements {cljs.core.async.impl.protocols.ReadPort}
 * @implements {cljs.core.IMeta}
 * @implements {cljs.core.IWithMeta}
*/
cljs.core.async.t_cljs$core$async29643 = (function (f,ch,meta29644){
this.f = f;
this.ch = ch;
this.meta29644 = meta29644;
this.cljs$lang$protocol_mask$partition0$ = 393216;
this.cljs$lang$protocol_mask$partition1$ = 0;
});
cljs.core.async.t_cljs$core$async29643.prototype.cljs$core$IWithMeta$_with_meta$arity$2 = (function (_29645,meta29644__$1){
var self__ = this;
var _29645__$1 = this;
return (new cljs.core.async.t_cljs$core$async29643(self__.f,self__.ch,meta29644__$1));
});

cljs.core.async.t_cljs$core$async29643.prototype.cljs$core$IMeta$_meta$arity$1 = (function (_29645){
var self__ = this;
var _29645__$1 = this;
return self__.meta29644;
});

cljs.core.async.t_cljs$core$async29643.prototype.cljs$core$async$impl$protocols$Channel$ = cljs.core.PROTOCOL_SENTINEL;

cljs.core.async.t_cljs$core$async29643.prototype.cljs$core$async$impl$protocols$Channel$close_BANG_$arity$1 = (function (_){
var self__ = this;
var ___$1 = this;
return cljs.core.async.impl.protocols.close_BANG_(self__.ch);
});

cljs.core.async.t_cljs$core$async29643.prototype.cljs$core$async$impl$protocols$ReadPort$ = cljs.core.PROTOCOL_SENTINEL;

cljs.core.async.t_cljs$core$async29643.prototype.cljs$core$async$impl$protocols$ReadPort$take_BANG_$arity$2 = (function (_,fn1){
var self__ = this;
var ___$1 = this;
return cljs.core.async.impl.protocols.take_BANG_(self__.ch,fn1);
});

cljs.core.async.t_cljs$core$async29643.prototype.cljs$core$async$impl$protocols$WritePort$ = cljs.core.PROTOCOL_SENTINEL;

cljs.core.async.t_cljs$core$async29643.prototype.cljs$core$async$impl$protocols$WritePort$put_BANG_$arity$3 = (function (_,val,fn1){
var self__ = this;
var ___$1 = this;
return cljs.core.async.impl.protocols.put_BANG_(self__.ch,(self__.f.cljs$core$IFn$_invoke$arity$1 ? self__.f.cljs$core$IFn$_invoke$arity$1(val) : self__.f.call(null,val)),fn1);
});

cljs.core.async.t_cljs$core$async29643.getBasis = (function (){
return new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [cljs.core.cst$sym$f,cljs.core.cst$sym$ch,cljs.core.cst$sym$meta29644], null);
});

cljs.core.async.t_cljs$core$async29643.cljs$lang$type = true;

cljs.core.async.t_cljs$core$async29643.cljs$lang$ctorStr = "cljs.core.async/t_cljs$core$async29643";

cljs.core.async.t_cljs$core$async29643.cljs$lang$ctorPrWriter = (function (this__4290__auto__,writer__4291__auto__,opt__4292__auto__){
return cljs.core._write(writer__4291__auto__,"cljs.core.async/t_cljs$core$async29643");
});

/**
 * Positional factory function for cljs.core.async/t_cljs$core$async29643.
 */
cljs.core.async.__GT_t_cljs$core$async29643 = (function cljs$core$async$map_GT__$___GT_t_cljs$core$async29643(f__$1,ch__$1,meta29644){
return (new cljs.core.async.t_cljs$core$async29643(f__$1,ch__$1,meta29644));
});

}

return (new cljs.core.async.t_cljs$core$async29643(f,ch,cljs.core.PersistentArrayMap.EMPTY));
});
/**
 * Deprecated - this function will be removed. Use transducer instead
 */
cljs.core.async.filter_GT_ = (function cljs$core$async$filter_GT_(p,ch){
if((typeof cljs !== 'undefined') && (typeof cljs.core !== 'undefined') && (typeof cljs.core.async !== 'undefined') && (typeof cljs.core.async.t_cljs$core$async29646 !== 'undefined')){
} else {

/**
* @constructor
 * @implements {cljs.core.async.impl.protocols.Channel}
 * @implements {cljs.core.async.impl.protocols.WritePort}
 * @implements {cljs.core.async.impl.protocols.ReadPort}
 * @implements {cljs.core.IMeta}
 * @implements {cljs.core.IWithMeta}
*/
cljs.core.async.t_cljs$core$async29646 = (function (p,ch,meta29647){
this.p = p;
this.ch = ch;
this.meta29647 = meta29647;
this.cljs$lang$protocol_mask$partition0$ = 393216;
this.cljs$lang$protocol_mask$partition1$ = 0;
});
cljs.core.async.t_cljs$core$async29646.prototype.cljs$core$IWithMeta$_with_meta$arity$2 = (function (_29648,meta29647__$1){
var self__ = this;
var _29648__$1 = this;
return (new cljs.core.async.t_cljs$core$async29646(self__.p,self__.ch,meta29647__$1));
});

cljs.core.async.t_cljs$core$async29646.prototype.cljs$core$IMeta$_meta$arity$1 = (function (_29648){
var self__ = this;
var _29648__$1 = this;
return self__.meta29647;
});

cljs.core.async.t_cljs$core$async29646.prototype.cljs$core$async$impl$protocols$Channel$ = cljs.core.PROTOCOL_SENTINEL;

cljs.core.async.t_cljs$core$async29646.prototype.cljs$core$async$impl$protocols$Channel$close_BANG_$arity$1 = (function (_){
var self__ = this;
var ___$1 = this;
return cljs.core.async.impl.protocols.close_BANG_(self__.ch);
});

cljs.core.async.t_cljs$core$async29646.prototype.cljs$core$async$impl$protocols$Channel$closed_QMARK_$arity$1 = (function (_){
var self__ = this;
var ___$1 = this;
return cljs.core.async.impl.protocols.closed_QMARK_(self__.ch);
});

cljs.core.async.t_cljs$core$async29646.prototype.cljs$core$async$impl$protocols$ReadPort$ = cljs.core.PROTOCOL_SENTINEL;

cljs.core.async.t_cljs$core$async29646.prototype.cljs$core$async$impl$protocols$ReadPort$take_BANG_$arity$2 = (function (_,fn1){
var self__ = this;
var ___$1 = this;
return cljs.core.async.impl.protocols.take_BANG_(self__.ch,fn1);
});

cljs.core.async.t_cljs$core$async29646.prototype.cljs$core$async$impl$protocols$WritePort$ = cljs.core.PROTOCOL_SENTINEL;

cljs.core.async.t_cljs$core$async29646.prototype.cljs$core$async$impl$protocols$WritePort$put_BANG_$arity$3 = (function (_,val,fn1){
var self__ = this;
var ___$1 = this;
if(cljs.core.truth_((self__.p.cljs$core$IFn$_invoke$arity$1 ? self__.p.cljs$core$IFn$_invoke$arity$1(val) : self__.p.call(null,val)))){
return cljs.core.async.impl.protocols.put_BANG_(self__.ch,val,fn1);
} else {
return cljs.core.async.impl.channels.box(cljs.core.not(cljs.core.async.impl.protocols.closed_QMARK_(self__.ch)));
}
});

cljs.core.async.t_cljs$core$async29646.getBasis = (function (){
return new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [cljs.core.cst$sym$p,cljs.core.cst$sym$ch,cljs.core.cst$sym$meta29647], null);
});

cljs.core.async.t_cljs$core$async29646.cljs$lang$type = true;

cljs.core.async.t_cljs$core$async29646.cljs$lang$ctorStr = "cljs.core.async/t_cljs$core$async29646";

cljs.core.async.t_cljs$core$async29646.cljs$lang$ctorPrWriter = (function (this__4290__auto__,writer__4291__auto__,opt__4292__auto__){
return cljs.core._write(writer__4291__auto__,"cljs.core.async/t_cljs$core$async29646");
});

/**
 * Positional factory function for cljs.core.async/t_cljs$core$async29646.
 */
cljs.core.async.__GT_t_cljs$core$async29646 = (function cljs$core$async$filter_GT__$___GT_t_cljs$core$async29646(p__$1,ch__$1,meta29647){
return (new cljs.core.async.t_cljs$core$async29646(p__$1,ch__$1,meta29647));
});

}

return (new cljs.core.async.t_cljs$core$async29646(p,ch,cljs.core.PersistentArrayMap.EMPTY));
});
/**
 * Deprecated - this function will be removed. Use transducer instead
 */
cljs.core.async.remove_GT_ = (function cljs$core$async$remove_GT_(p,ch){
return cljs.core.async.filter_GT_(cljs.core.complement(p),ch);
});
/**
 * Deprecated - this function will be removed. Use transducer instead
 */
cljs.core.async.filter_LT_ = (function cljs$core$async$filter_LT_(var_args){
var G__29650 = arguments.length;
switch (G__29650) {
case 2:
return cljs.core.async.filter_LT_.cljs$core$IFn$_invoke$arity$2((arguments[(0)]),(arguments[(1)]));

break;
case 3:
return cljs.core.async.filter_LT_.cljs$core$IFn$_invoke$arity$3((arguments[(0)]),(arguments[(1)]),(arguments[(2)]));

break;
default:
throw (new Error(["Invalid arity: ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(arguments.length)].join('')));

}
});

cljs.core.async.filter_LT_.cljs$core$IFn$_invoke$arity$2 = (function (p,ch){
return cljs.core.async.filter_LT_.cljs$core$IFn$_invoke$arity$3(p,ch,null);
});

cljs.core.async.filter_LT_.cljs$core$IFn$_invoke$arity$3 = (function (p,ch,buf_or_n){
var out = cljs.core.async.chan.cljs$core$IFn$_invoke$arity$1(buf_or_n);
var c__7992__auto___29690 = cljs.core.async.chan.cljs$core$IFn$_invoke$arity$1((1));
cljs.core.async.impl.dispatch.run(((function (c__7992__auto___29690,out){
return (function (){
var f__7993__auto__ = (function (){var switch__7885__auto__ = ((function (c__7992__auto___29690,out){
return (function (state_29671){
var state_val_29672 = (state_29671[(1)]);
if((state_val_29672 === (7))){
var inst_29667 = (state_29671[(2)]);
var state_29671__$1 = state_29671;
var statearr_29673_29691 = state_29671__$1;
(statearr_29673_29691[(2)] = inst_29667);

(statearr_29673_29691[(1)] = (3));


return cljs.core.cst$kw$recur;
} else {
if((state_val_29672 === (1))){
var state_29671__$1 = state_29671;
var statearr_29674_29692 = state_29671__$1;
(statearr_29674_29692[(2)] = null);

(statearr_29674_29692[(1)] = (2));


return cljs.core.cst$kw$recur;
} else {
if((state_val_29672 === (4))){
var inst_29653 = (state_29671[(7)]);
var inst_29653__$1 = (state_29671[(2)]);
var inst_29654 = (inst_29653__$1 == null);
var state_29671__$1 = (function (){var statearr_29675 = state_29671;
(statearr_29675[(7)] = inst_29653__$1);

return statearr_29675;
})();
if(cljs.core.truth_(inst_29654)){
var statearr_29676_29693 = state_29671__$1;
(statearr_29676_29693[(1)] = (5));

} else {
var statearr_29677_29694 = state_29671__$1;
(statearr_29677_29694[(1)] = (6));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_29672 === (6))){
var inst_29653 = (state_29671[(7)]);
var inst_29658 = (p.cljs$core$IFn$_invoke$arity$1 ? p.cljs$core$IFn$_invoke$arity$1(inst_29653) : p.call(null,inst_29653));
var state_29671__$1 = state_29671;
if(cljs.core.truth_(inst_29658)){
var statearr_29678_29695 = state_29671__$1;
(statearr_29678_29695[(1)] = (8));

} else {
var statearr_29679_29696 = state_29671__$1;
(statearr_29679_29696[(1)] = (9));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_29672 === (3))){
var inst_29669 = (state_29671[(2)]);
var state_29671__$1 = state_29671;
return cljs.core.async.impl.ioc_helpers.return_chan(state_29671__$1,inst_29669);
} else {
if((state_val_29672 === (2))){
var state_29671__$1 = state_29671;
return cljs.core.async.impl.ioc_helpers.take_BANG_(state_29671__$1,(4),ch);
} else {
if((state_val_29672 === (11))){
var inst_29661 = (state_29671[(2)]);
var state_29671__$1 = state_29671;
var statearr_29680_29697 = state_29671__$1;
(statearr_29680_29697[(2)] = inst_29661);

(statearr_29680_29697[(1)] = (10));


return cljs.core.cst$kw$recur;
} else {
if((state_val_29672 === (9))){
var state_29671__$1 = state_29671;
var statearr_29681_29698 = state_29671__$1;
(statearr_29681_29698[(2)] = null);

(statearr_29681_29698[(1)] = (10));


return cljs.core.cst$kw$recur;
} else {
if((state_val_29672 === (5))){
var inst_29656 = cljs.core.async.close_BANG_(out);
var state_29671__$1 = state_29671;
var statearr_29682_29699 = state_29671__$1;
(statearr_29682_29699[(2)] = inst_29656);

(statearr_29682_29699[(1)] = (7));


return cljs.core.cst$kw$recur;
} else {
if((state_val_29672 === (10))){
var inst_29664 = (state_29671[(2)]);
var state_29671__$1 = (function (){var statearr_29683 = state_29671;
(statearr_29683[(8)] = inst_29664);

return statearr_29683;
})();
var statearr_29684_29700 = state_29671__$1;
(statearr_29684_29700[(2)] = null);

(statearr_29684_29700[(1)] = (2));


return cljs.core.cst$kw$recur;
} else {
if((state_val_29672 === (8))){
var inst_29653 = (state_29671[(7)]);
var state_29671__$1 = state_29671;
return cljs.core.async.impl.ioc_helpers.put_BANG_(state_29671__$1,(11),out,inst_29653);
} else {
return null;
}
}
}
}
}
}
}
}
}
}
}
});})(c__7992__auto___29690,out))
;
return ((function (switch__7885__auto__,c__7992__auto___29690,out){
return (function() {
var cljs$core$async$state_machine__7886__auto__ = null;
var cljs$core$async$state_machine__7886__auto____0 = (function (){
var statearr_29685 = [null,null,null,null,null,null,null,null,null];
(statearr_29685[(0)] = cljs$core$async$state_machine__7886__auto__);

(statearr_29685[(1)] = (1));

return statearr_29685;
});
var cljs$core$async$state_machine__7886__auto____1 = (function (state_29671){
while(true){
var ret_value__7887__auto__ = (function (){try{while(true){
var result__7888__auto__ = switch__7885__auto__(state_29671);
if(cljs.core.keyword_identical_QMARK_(result__7888__auto__,cljs.core.cst$kw$recur)){
continue;
} else {
return result__7888__auto__;
}
break;
}
}catch (e29686){if((e29686 instanceof Object)){
var ex__7889__auto__ = e29686;
var statearr_29687_29701 = state_29671;
(statearr_29687_29701[(5)] = ex__7889__auto__);


cljs.core.async.impl.ioc_helpers.process_exception(state_29671);

return cljs.core.cst$kw$recur;
} else {
throw e29686;

}
}})();
if(cljs.core.keyword_identical_QMARK_(ret_value__7887__auto__,cljs.core.cst$kw$recur)){
var G__29702 = state_29671;
state_29671 = G__29702;
continue;
} else {
return ret_value__7887__auto__;
}
break;
}
});
cljs$core$async$state_machine__7886__auto__ = function(state_29671){
switch(arguments.length){
case 0:
return cljs$core$async$state_machine__7886__auto____0.call(this);
case 1:
return cljs$core$async$state_machine__7886__auto____1.call(this,state_29671);
}
throw(new Error('Invalid arity: ' + arguments.length));
};
cljs$core$async$state_machine__7886__auto__.cljs$core$IFn$_invoke$arity$0 = cljs$core$async$state_machine__7886__auto____0;
cljs$core$async$state_machine__7886__auto__.cljs$core$IFn$_invoke$arity$1 = cljs$core$async$state_machine__7886__auto____1;
return cljs$core$async$state_machine__7886__auto__;
})()
;})(switch__7885__auto__,c__7992__auto___29690,out))
})();
var state__7994__auto__ = (function (){var statearr_29688 = (f__7993__auto__.cljs$core$IFn$_invoke$arity$0 ? f__7993__auto__.cljs$core$IFn$_invoke$arity$0() : f__7993__auto__.call(null));
(statearr_29688[(6)] = c__7992__auto___29690);

return statearr_29688;
})();
return cljs.core.async.impl.ioc_helpers.run_state_machine_wrapped(state__7994__auto__);
});})(c__7992__auto___29690,out))
);


return out;
});

cljs.core.async.filter_LT_.cljs$lang$maxFixedArity = 3;

/**
 * Deprecated - this function will be removed. Use transducer instead
 */
cljs.core.async.remove_LT_ = (function cljs$core$async$remove_LT_(var_args){
var G__29704 = arguments.length;
switch (G__29704) {
case 2:
return cljs.core.async.remove_LT_.cljs$core$IFn$_invoke$arity$2((arguments[(0)]),(arguments[(1)]));

break;
case 3:
return cljs.core.async.remove_LT_.cljs$core$IFn$_invoke$arity$3((arguments[(0)]),(arguments[(1)]),(arguments[(2)]));

break;
default:
throw (new Error(["Invalid arity: ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(arguments.length)].join('')));

}
});

cljs.core.async.remove_LT_.cljs$core$IFn$_invoke$arity$2 = (function (p,ch){
return cljs.core.async.remove_LT_.cljs$core$IFn$_invoke$arity$3(p,ch,null);
});

cljs.core.async.remove_LT_.cljs$core$IFn$_invoke$arity$3 = (function (p,ch,buf_or_n){
return cljs.core.async.filter_LT_.cljs$core$IFn$_invoke$arity$3(cljs.core.complement(p),ch,buf_or_n);
});

cljs.core.async.remove_LT_.cljs$lang$maxFixedArity = 3;

cljs.core.async.mapcat_STAR_ = (function cljs$core$async$mapcat_STAR_(f,in$,out){
var c__7992__auto__ = cljs.core.async.chan.cljs$core$IFn$_invoke$arity$1((1));
cljs.core.async.impl.dispatch.run(((function (c__7992__auto__){
return (function (){
var f__7993__auto__ = (function (){var switch__7885__auto__ = ((function (c__7992__auto__){
return (function (state_29767){
var state_val_29768 = (state_29767[(1)]);
if((state_val_29768 === (7))){
var inst_29763 = (state_29767[(2)]);
var state_29767__$1 = state_29767;
var statearr_29769_29807 = state_29767__$1;
(statearr_29769_29807[(2)] = inst_29763);

(statearr_29769_29807[(1)] = (3));


return cljs.core.cst$kw$recur;
} else {
if((state_val_29768 === (20))){
var inst_29733 = (state_29767[(7)]);
var inst_29744 = (state_29767[(2)]);
var inst_29745 = cljs.core.next(inst_29733);
var inst_29719 = inst_29745;
var inst_29720 = null;
var inst_29721 = (0);
var inst_29722 = (0);
var state_29767__$1 = (function (){var statearr_29770 = state_29767;
(statearr_29770[(8)] = inst_29722);

(statearr_29770[(9)] = inst_29719);

(statearr_29770[(10)] = inst_29721);

(statearr_29770[(11)] = inst_29744);

(statearr_29770[(12)] = inst_29720);

return statearr_29770;
})();
var statearr_29771_29808 = state_29767__$1;
(statearr_29771_29808[(2)] = null);

(statearr_29771_29808[(1)] = (8));


return cljs.core.cst$kw$recur;
} else {
if((state_val_29768 === (1))){
var state_29767__$1 = state_29767;
var statearr_29772_29809 = state_29767__$1;
(statearr_29772_29809[(2)] = null);

(statearr_29772_29809[(1)] = (2));


return cljs.core.cst$kw$recur;
} else {
if((state_val_29768 === (4))){
var inst_29708 = (state_29767[(13)]);
var inst_29708__$1 = (state_29767[(2)]);
var inst_29709 = (inst_29708__$1 == null);
var state_29767__$1 = (function (){var statearr_29773 = state_29767;
(statearr_29773[(13)] = inst_29708__$1);

return statearr_29773;
})();
if(cljs.core.truth_(inst_29709)){
var statearr_29774_29810 = state_29767__$1;
(statearr_29774_29810[(1)] = (5));

} else {
var statearr_29775_29811 = state_29767__$1;
(statearr_29775_29811[(1)] = (6));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_29768 === (15))){
var state_29767__$1 = state_29767;
var statearr_29779_29812 = state_29767__$1;
(statearr_29779_29812[(2)] = null);

(statearr_29779_29812[(1)] = (16));


return cljs.core.cst$kw$recur;
} else {
if((state_val_29768 === (21))){
var state_29767__$1 = state_29767;
var statearr_29780_29813 = state_29767__$1;
(statearr_29780_29813[(2)] = null);

(statearr_29780_29813[(1)] = (23));


return cljs.core.cst$kw$recur;
} else {
if((state_val_29768 === (13))){
var inst_29722 = (state_29767[(8)]);
var inst_29719 = (state_29767[(9)]);
var inst_29721 = (state_29767[(10)]);
var inst_29720 = (state_29767[(12)]);
var inst_29729 = (state_29767[(2)]);
var inst_29730 = (inst_29722 + (1));
var tmp29776 = inst_29719;
var tmp29777 = inst_29721;
var tmp29778 = inst_29720;
var inst_29719__$1 = tmp29776;
var inst_29720__$1 = tmp29778;
var inst_29721__$1 = tmp29777;
var inst_29722__$1 = inst_29730;
var state_29767__$1 = (function (){var statearr_29781 = state_29767;
(statearr_29781[(8)] = inst_29722__$1);

(statearr_29781[(9)] = inst_29719__$1);

(statearr_29781[(10)] = inst_29721__$1);

(statearr_29781[(14)] = inst_29729);

(statearr_29781[(12)] = inst_29720__$1);

return statearr_29781;
})();
var statearr_29782_29814 = state_29767__$1;
(statearr_29782_29814[(2)] = null);

(statearr_29782_29814[(1)] = (8));


return cljs.core.cst$kw$recur;
} else {
if((state_val_29768 === (22))){
var state_29767__$1 = state_29767;
var statearr_29783_29815 = state_29767__$1;
(statearr_29783_29815[(2)] = null);

(statearr_29783_29815[(1)] = (2));


return cljs.core.cst$kw$recur;
} else {
if((state_val_29768 === (6))){
var inst_29708 = (state_29767[(13)]);
var inst_29717 = (f.cljs$core$IFn$_invoke$arity$1 ? f.cljs$core$IFn$_invoke$arity$1(inst_29708) : f.call(null,inst_29708));
var inst_29718 = cljs.core.seq(inst_29717);
var inst_29719 = inst_29718;
var inst_29720 = null;
var inst_29721 = (0);
var inst_29722 = (0);
var state_29767__$1 = (function (){var statearr_29784 = state_29767;
(statearr_29784[(8)] = inst_29722);

(statearr_29784[(9)] = inst_29719);

(statearr_29784[(10)] = inst_29721);

(statearr_29784[(12)] = inst_29720);

return statearr_29784;
})();
var statearr_29785_29816 = state_29767__$1;
(statearr_29785_29816[(2)] = null);

(statearr_29785_29816[(1)] = (8));


return cljs.core.cst$kw$recur;
} else {
if((state_val_29768 === (17))){
var inst_29733 = (state_29767[(7)]);
var inst_29737 = cljs.core.chunk_first(inst_29733);
var inst_29738 = cljs.core.chunk_rest(inst_29733);
var inst_29739 = cljs.core.count(inst_29737);
var inst_29719 = inst_29738;
var inst_29720 = inst_29737;
var inst_29721 = inst_29739;
var inst_29722 = (0);
var state_29767__$1 = (function (){var statearr_29786 = state_29767;
(statearr_29786[(8)] = inst_29722);

(statearr_29786[(9)] = inst_29719);

(statearr_29786[(10)] = inst_29721);

(statearr_29786[(12)] = inst_29720);

return statearr_29786;
})();
var statearr_29787_29817 = state_29767__$1;
(statearr_29787_29817[(2)] = null);

(statearr_29787_29817[(1)] = (8));


return cljs.core.cst$kw$recur;
} else {
if((state_val_29768 === (3))){
var inst_29765 = (state_29767[(2)]);
var state_29767__$1 = state_29767;
return cljs.core.async.impl.ioc_helpers.return_chan(state_29767__$1,inst_29765);
} else {
if((state_val_29768 === (12))){
var inst_29753 = (state_29767[(2)]);
var state_29767__$1 = state_29767;
var statearr_29788_29818 = state_29767__$1;
(statearr_29788_29818[(2)] = inst_29753);

(statearr_29788_29818[(1)] = (9));


return cljs.core.cst$kw$recur;
} else {
if((state_val_29768 === (2))){
var state_29767__$1 = state_29767;
return cljs.core.async.impl.ioc_helpers.take_BANG_(state_29767__$1,(4),in$);
} else {
if((state_val_29768 === (23))){
var inst_29761 = (state_29767[(2)]);
var state_29767__$1 = state_29767;
var statearr_29789_29819 = state_29767__$1;
(statearr_29789_29819[(2)] = inst_29761);

(statearr_29789_29819[(1)] = (7));


return cljs.core.cst$kw$recur;
} else {
if((state_val_29768 === (19))){
var inst_29748 = (state_29767[(2)]);
var state_29767__$1 = state_29767;
var statearr_29790_29820 = state_29767__$1;
(statearr_29790_29820[(2)] = inst_29748);

(statearr_29790_29820[(1)] = (16));


return cljs.core.cst$kw$recur;
} else {
if((state_val_29768 === (11))){
var inst_29719 = (state_29767[(9)]);
var inst_29733 = (state_29767[(7)]);
var inst_29733__$1 = cljs.core.seq(inst_29719);
var state_29767__$1 = (function (){var statearr_29791 = state_29767;
(statearr_29791[(7)] = inst_29733__$1);

return statearr_29791;
})();
if(inst_29733__$1){
var statearr_29792_29821 = state_29767__$1;
(statearr_29792_29821[(1)] = (14));

} else {
var statearr_29793_29822 = state_29767__$1;
(statearr_29793_29822[(1)] = (15));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_29768 === (9))){
var inst_29755 = (state_29767[(2)]);
var inst_29756 = cljs.core.async.impl.protocols.closed_QMARK_(out);
var state_29767__$1 = (function (){var statearr_29794 = state_29767;
(statearr_29794[(15)] = inst_29755);

return statearr_29794;
})();
if(cljs.core.truth_(inst_29756)){
var statearr_29795_29823 = state_29767__$1;
(statearr_29795_29823[(1)] = (21));

} else {
var statearr_29796_29824 = state_29767__$1;
(statearr_29796_29824[(1)] = (22));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_29768 === (5))){
var inst_29711 = cljs.core.async.close_BANG_(out);
var state_29767__$1 = state_29767;
var statearr_29797_29825 = state_29767__$1;
(statearr_29797_29825[(2)] = inst_29711);

(statearr_29797_29825[(1)] = (7));


return cljs.core.cst$kw$recur;
} else {
if((state_val_29768 === (14))){
var inst_29733 = (state_29767[(7)]);
var inst_29735 = cljs.core.chunked_seq_QMARK_(inst_29733);
var state_29767__$1 = state_29767;
if(inst_29735){
var statearr_29798_29826 = state_29767__$1;
(statearr_29798_29826[(1)] = (17));

} else {
var statearr_29799_29827 = state_29767__$1;
(statearr_29799_29827[(1)] = (18));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_29768 === (16))){
var inst_29751 = (state_29767[(2)]);
var state_29767__$1 = state_29767;
var statearr_29800_29828 = state_29767__$1;
(statearr_29800_29828[(2)] = inst_29751);

(statearr_29800_29828[(1)] = (12));


return cljs.core.cst$kw$recur;
} else {
if((state_val_29768 === (10))){
var inst_29722 = (state_29767[(8)]);
var inst_29720 = (state_29767[(12)]);
var inst_29727 = cljs.core._nth.cljs$core$IFn$_invoke$arity$2(inst_29720,inst_29722);
var state_29767__$1 = state_29767;
return cljs.core.async.impl.ioc_helpers.put_BANG_(state_29767__$1,(13),out,inst_29727);
} else {
if((state_val_29768 === (18))){
var inst_29733 = (state_29767[(7)]);
var inst_29742 = cljs.core.first(inst_29733);
var state_29767__$1 = state_29767;
return cljs.core.async.impl.ioc_helpers.put_BANG_(state_29767__$1,(20),out,inst_29742);
} else {
if((state_val_29768 === (8))){
var inst_29722 = (state_29767[(8)]);
var inst_29721 = (state_29767[(10)]);
var inst_29724 = (inst_29722 < inst_29721);
var inst_29725 = inst_29724;
var state_29767__$1 = state_29767;
if(cljs.core.truth_(inst_29725)){
var statearr_29801_29829 = state_29767__$1;
(statearr_29801_29829[(1)] = (10));

} else {
var statearr_29802_29830 = state_29767__$1;
(statearr_29802_29830[(1)] = (11));

}

return cljs.core.cst$kw$recur;
} else {
return null;
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
});})(c__7992__auto__))
;
return ((function (switch__7885__auto__,c__7992__auto__){
return (function() {
var cljs$core$async$mapcat_STAR__$_state_machine__7886__auto__ = null;
var cljs$core$async$mapcat_STAR__$_state_machine__7886__auto____0 = (function (){
var statearr_29803 = [null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null];
(statearr_29803[(0)] = cljs$core$async$mapcat_STAR__$_state_machine__7886__auto__);

(statearr_29803[(1)] = (1));

return statearr_29803;
});
var cljs$core$async$mapcat_STAR__$_state_machine__7886__auto____1 = (function (state_29767){
while(true){
var ret_value__7887__auto__ = (function (){try{while(true){
var result__7888__auto__ = switch__7885__auto__(state_29767);
if(cljs.core.keyword_identical_QMARK_(result__7888__auto__,cljs.core.cst$kw$recur)){
continue;
} else {
return result__7888__auto__;
}
break;
}
}catch (e29804){if((e29804 instanceof Object)){
var ex__7889__auto__ = e29804;
var statearr_29805_29831 = state_29767;
(statearr_29805_29831[(5)] = ex__7889__auto__);


cljs.core.async.impl.ioc_helpers.process_exception(state_29767);

return cljs.core.cst$kw$recur;
} else {
throw e29804;

}
}})();
if(cljs.core.keyword_identical_QMARK_(ret_value__7887__auto__,cljs.core.cst$kw$recur)){
var G__29832 = state_29767;
state_29767 = G__29832;
continue;
} else {
return ret_value__7887__auto__;
}
break;
}
});
cljs$core$async$mapcat_STAR__$_state_machine__7886__auto__ = function(state_29767){
switch(arguments.length){
case 0:
return cljs$core$async$mapcat_STAR__$_state_machine__7886__auto____0.call(this);
case 1:
return cljs$core$async$mapcat_STAR__$_state_machine__7886__auto____1.call(this,state_29767);
}
throw(new Error('Invalid arity: ' + arguments.length));
};
cljs$core$async$mapcat_STAR__$_state_machine__7886__auto__.cljs$core$IFn$_invoke$arity$0 = cljs$core$async$mapcat_STAR__$_state_machine__7886__auto____0;
cljs$core$async$mapcat_STAR__$_state_machine__7886__auto__.cljs$core$IFn$_invoke$arity$1 = cljs$core$async$mapcat_STAR__$_state_machine__7886__auto____1;
return cljs$core$async$mapcat_STAR__$_state_machine__7886__auto__;
})()
;})(switch__7885__auto__,c__7992__auto__))
})();
var state__7994__auto__ = (function (){var statearr_29806 = (f__7993__auto__.cljs$core$IFn$_invoke$arity$0 ? f__7993__auto__.cljs$core$IFn$_invoke$arity$0() : f__7993__auto__.call(null));
(statearr_29806[(6)] = c__7992__auto__);

return statearr_29806;
})();
return cljs.core.async.impl.ioc_helpers.run_state_machine_wrapped(state__7994__auto__);
});})(c__7992__auto__))
);

return c__7992__auto__;
});
/**
 * Deprecated - this function will be removed. Use transducer instead
 */
cljs.core.async.mapcat_LT_ = (function cljs$core$async$mapcat_LT_(var_args){
var G__29834 = arguments.length;
switch (G__29834) {
case 2:
return cljs.core.async.mapcat_LT_.cljs$core$IFn$_invoke$arity$2((arguments[(0)]),(arguments[(1)]));

break;
case 3:
return cljs.core.async.mapcat_LT_.cljs$core$IFn$_invoke$arity$3((arguments[(0)]),(arguments[(1)]),(arguments[(2)]));

break;
default:
throw (new Error(["Invalid arity: ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(arguments.length)].join('')));

}
});

cljs.core.async.mapcat_LT_.cljs$core$IFn$_invoke$arity$2 = (function (f,in$){
return cljs.core.async.mapcat_LT_.cljs$core$IFn$_invoke$arity$3(f,in$,null);
});

cljs.core.async.mapcat_LT_.cljs$core$IFn$_invoke$arity$3 = (function (f,in$,buf_or_n){
var out = cljs.core.async.chan.cljs$core$IFn$_invoke$arity$1(buf_or_n);
cljs.core.async.mapcat_STAR_(f,in$,out);

return out;
});

cljs.core.async.mapcat_LT_.cljs$lang$maxFixedArity = 3;

/**
 * Deprecated - this function will be removed. Use transducer instead
 */
cljs.core.async.mapcat_GT_ = (function cljs$core$async$mapcat_GT_(var_args){
var G__29837 = arguments.length;
switch (G__29837) {
case 2:
return cljs.core.async.mapcat_GT_.cljs$core$IFn$_invoke$arity$2((arguments[(0)]),(arguments[(1)]));

break;
case 3:
return cljs.core.async.mapcat_GT_.cljs$core$IFn$_invoke$arity$3((arguments[(0)]),(arguments[(1)]),(arguments[(2)]));

break;
default:
throw (new Error(["Invalid arity: ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(arguments.length)].join('')));

}
});

cljs.core.async.mapcat_GT_.cljs$core$IFn$_invoke$arity$2 = (function (f,out){
return cljs.core.async.mapcat_GT_.cljs$core$IFn$_invoke$arity$3(f,out,null);
});

cljs.core.async.mapcat_GT_.cljs$core$IFn$_invoke$arity$3 = (function (f,out,buf_or_n){
var in$ = cljs.core.async.chan.cljs$core$IFn$_invoke$arity$1(buf_or_n);
cljs.core.async.mapcat_STAR_(f,in$,out);

return in$;
});

cljs.core.async.mapcat_GT_.cljs$lang$maxFixedArity = 3;

/**
 * Deprecated - this function will be removed. Use transducer instead
 */
cljs.core.async.unique = (function cljs$core$async$unique(var_args){
var G__29840 = arguments.length;
switch (G__29840) {
case 1:
return cljs.core.async.unique.cljs$core$IFn$_invoke$arity$1((arguments[(0)]));

break;
case 2:
return cljs.core.async.unique.cljs$core$IFn$_invoke$arity$2((arguments[(0)]),(arguments[(1)]));

break;
default:
throw (new Error(["Invalid arity: ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(arguments.length)].join('')));

}
});

cljs.core.async.unique.cljs$core$IFn$_invoke$arity$1 = (function (ch){
return cljs.core.async.unique.cljs$core$IFn$_invoke$arity$2(ch,null);
});

cljs.core.async.unique.cljs$core$IFn$_invoke$arity$2 = (function (ch,buf_or_n){
var out = cljs.core.async.chan.cljs$core$IFn$_invoke$arity$1(buf_or_n);
var c__7992__auto___29887 = cljs.core.async.chan.cljs$core$IFn$_invoke$arity$1((1));
cljs.core.async.impl.dispatch.run(((function (c__7992__auto___29887,out){
return (function (){
var f__7993__auto__ = (function (){var switch__7885__auto__ = ((function (c__7992__auto___29887,out){
return (function (state_29864){
var state_val_29865 = (state_29864[(1)]);
if((state_val_29865 === (7))){
var inst_29859 = (state_29864[(2)]);
var state_29864__$1 = state_29864;
var statearr_29866_29888 = state_29864__$1;
(statearr_29866_29888[(2)] = inst_29859);

(statearr_29866_29888[(1)] = (3));


return cljs.core.cst$kw$recur;
} else {
if((state_val_29865 === (1))){
var inst_29841 = null;
var state_29864__$1 = (function (){var statearr_29867 = state_29864;
(statearr_29867[(7)] = inst_29841);

return statearr_29867;
})();
var statearr_29868_29889 = state_29864__$1;
(statearr_29868_29889[(2)] = null);

(statearr_29868_29889[(1)] = (2));


return cljs.core.cst$kw$recur;
} else {
if((state_val_29865 === (4))){
var inst_29844 = (state_29864[(8)]);
var inst_29844__$1 = (state_29864[(2)]);
var inst_29845 = (inst_29844__$1 == null);
var inst_29846 = cljs.core.not(inst_29845);
var state_29864__$1 = (function (){var statearr_29869 = state_29864;
(statearr_29869[(8)] = inst_29844__$1);

return statearr_29869;
})();
if(inst_29846){
var statearr_29870_29890 = state_29864__$1;
(statearr_29870_29890[(1)] = (5));

} else {
var statearr_29871_29891 = state_29864__$1;
(statearr_29871_29891[(1)] = (6));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_29865 === (6))){
var state_29864__$1 = state_29864;
var statearr_29872_29892 = state_29864__$1;
(statearr_29872_29892[(2)] = null);

(statearr_29872_29892[(1)] = (7));


return cljs.core.cst$kw$recur;
} else {
if((state_val_29865 === (3))){
var inst_29861 = (state_29864[(2)]);
var inst_29862 = cljs.core.async.close_BANG_(out);
var state_29864__$1 = (function (){var statearr_29873 = state_29864;
(statearr_29873[(9)] = inst_29861);

return statearr_29873;
})();
return cljs.core.async.impl.ioc_helpers.return_chan(state_29864__$1,inst_29862);
} else {
if((state_val_29865 === (2))){
var state_29864__$1 = state_29864;
return cljs.core.async.impl.ioc_helpers.take_BANG_(state_29864__$1,(4),ch);
} else {
if((state_val_29865 === (11))){
var inst_29844 = (state_29864[(8)]);
var inst_29853 = (state_29864[(2)]);
var inst_29841 = inst_29844;
var state_29864__$1 = (function (){var statearr_29874 = state_29864;
(statearr_29874[(7)] = inst_29841);

(statearr_29874[(10)] = inst_29853);

return statearr_29874;
})();
var statearr_29875_29893 = state_29864__$1;
(statearr_29875_29893[(2)] = null);

(statearr_29875_29893[(1)] = (2));


return cljs.core.cst$kw$recur;
} else {
if((state_val_29865 === (9))){
var inst_29844 = (state_29864[(8)]);
var state_29864__$1 = state_29864;
return cljs.core.async.impl.ioc_helpers.put_BANG_(state_29864__$1,(11),out,inst_29844);
} else {
if((state_val_29865 === (5))){
var inst_29841 = (state_29864[(7)]);
var inst_29844 = (state_29864[(8)]);
var inst_29848 = cljs.core._EQ_.cljs$core$IFn$_invoke$arity$2(inst_29844,inst_29841);
var state_29864__$1 = state_29864;
if(inst_29848){
var statearr_29877_29894 = state_29864__$1;
(statearr_29877_29894[(1)] = (8));

} else {
var statearr_29878_29895 = state_29864__$1;
(statearr_29878_29895[(1)] = (9));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_29865 === (10))){
var inst_29856 = (state_29864[(2)]);
var state_29864__$1 = state_29864;
var statearr_29879_29896 = state_29864__$1;
(statearr_29879_29896[(2)] = inst_29856);

(statearr_29879_29896[(1)] = (7));


return cljs.core.cst$kw$recur;
} else {
if((state_val_29865 === (8))){
var inst_29841 = (state_29864[(7)]);
var tmp29876 = inst_29841;
var inst_29841__$1 = tmp29876;
var state_29864__$1 = (function (){var statearr_29880 = state_29864;
(statearr_29880[(7)] = inst_29841__$1);

return statearr_29880;
})();
var statearr_29881_29897 = state_29864__$1;
(statearr_29881_29897[(2)] = null);

(statearr_29881_29897[(1)] = (2));


return cljs.core.cst$kw$recur;
} else {
return null;
}
}
}
}
}
}
}
}
}
}
}
});})(c__7992__auto___29887,out))
;
return ((function (switch__7885__auto__,c__7992__auto___29887,out){
return (function() {
var cljs$core$async$state_machine__7886__auto__ = null;
var cljs$core$async$state_machine__7886__auto____0 = (function (){
var statearr_29882 = [null,null,null,null,null,null,null,null,null,null,null];
(statearr_29882[(0)] = cljs$core$async$state_machine__7886__auto__);

(statearr_29882[(1)] = (1));

return statearr_29882;
});
var cljs$core$async$state_machine__7886__auto____1 = (function (state_29864){
while(true){
var ret_value__7887__auto__ = (function (){try{while(true){
var result__7888__auto__ = switch__7885__auto__(state_29864);
if(cljs.core.keyword_identical_QMARK_(result__7888__auto__,cljs.core.cst$kw$recur)){
continue;
} else {
return result__7888__auto__;
}
break;
}
}catch (e29883){if((e29883 instanceof Object)){
var ex__7889__auto__ = e29883;
var statearr_29884_29898 = state_29864;
(statearr_29884_29898[(5)] = ex__7889__auto__);


cljs.core.async.impl.ioc_helpers.process_exception(state_29864);

return cljs.core.cst$kw$recur;
} else {
throw e29883;

}
}})();
if(cljs.core.keyword_identical_QMARK_(ret_value__7887__auto__,cljs.core.cst$kw$recur)){
var G__29899 = state_29864;
state_29864 = G__29899;
continue;
} else {
return ret_value__7887__auto__;
}
break;
}
});
cljs$core$async$state_machine__7886__auto__ = function(state_29864){
switch(arguments.length){
case 0:
return cljs$core$async$state_machine__7886__auto____0.call(this);
case 1:
return cljs$core$async$state_machine__7886__auto____1.call(this,state_29864);
}
throw(new Error('Invalid arity: ' + arguments.length));
};
cljs$core$async$state_machine__7886__auto__.cljs$core$IFn$_invoke$arity$0 = cljs$core$async$state_machine__7886__auto____0;
cljs$core$async$state_machine__7886__auto__.cljs$core$IFn$_invoke$arity$1 = cljs$core$async$state_machine__7886__auto____1;
return cljs$core$async$state_machine__7886__auto__;
})()
;})(switch__7885__auto__,c__7992__auto___29887,out))
})();
var state__7994__auto__ = (function (){var statearr_29885 = (f__7993__auto__.cljs$core$IFn$_invoke$arity$0 ? f__7993__auto__.cljs$core$IFn$_invoke$arity$0() : f__7993__auto__.call(null));
(statearr_29885[(6)] = c__7992__auto___29887);

return statearr_29885;
})();
return cljs.core.async.impl.ioc_helpers.run_state_machine_wrapped(state__7994__auto__);
});})(c__7992__auto___29887,out))
);


return out;
});

cljs.core.async.unique.cljs$lang$maxFixedArity = 2;

/**
 * Deprecated - this function will be removed. Use transducer instead
 */
cljs.core.async.partition = (function cljs$core$async$partition(var_args){
var G__29901 = arguments.length;
switch (G__29901) {
case 2:
return cljs.core.async.partition.cljs$core$IFn$_invoke$arity$2((arguments[(0)]),(arguments[(1)]));

break;
case 3:
return cljs.core.async.partition.cljs$core$IFn$_invoke$arity$3((arguments[(0)]),(arguments[(1)]),(arguments[(2)]));

break;
default:
throw (new Error(["Invalid arity: ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(arguments.length)].join('')));

}
});

cljs.core.async.partition.cljs$core$IFn$_invoke$arity$2 = (function (n,ch){
return cljs.core.async.partition.cljs$core$IFn$_invoke$arity$3(n,ch,null);
});

cljs.core.async.partition.cljs$core$IFn$_invoke$arity$3 = (function (n,ch,buf_or_n){
var out = cljs.core.async.chan.cljs$core$IFn$_invoke$arity$1(buf_or_n);
var c__7992__auto___29967 = cljs.core.async.chan.cljs$core$IFn$_invoke$arity$1((1));
cljs.core.async.impl.dispatch.run(((function (c__7992__auto___29967,out){
return (function (){
var f__7993__auto__ = (function (){var switch__7885__auto__ = ((function (c__7992__auto___29967,out){
return (function (state_29939){
var state_val_29940 = (state_29939[(1)]);
if((state_val_29940 === (7))){
var inst_29935 = (state_29939[(2)]);
var state_29939__$1 = state_29939;
var statearr_29941_29968 = state_29939__$1;
(statearr_29941_29968[(2)] = inst_29935);

(statearr_29941_29968[(1)] = (3));


return cljs.core.cst$kw$recur;
} else {
if((state_val_29940 === (1))){
var inst_29902 = (new Array(n));
var inst_29903 = inst_29902;
var inst_29904 = (0);
var state_29939__$1 = (function (){var statearr_29942 = state_29939;
(statearr_29942[(7)] = inst_29903);

(statearr_29942[(8)] = inst_29904);

return statearr_29942;
})();
var statearr_29943_29969 = state_29939__$1;
(statearr_29943_29969[(2)] = null);

(statearr_29943_29969[(1)] = (2));


return cljs.core.cst$kw$recur;
} else {
if((state_val_29940 === (4))){
var inst_29907 = (state_29939[(9)]);
var inst_29907__$1 = (state_29939[(2)]);
var inst_29908 = (inst_29907__$1 == null);
var inst_29909 = cljs.core.not(inst_29908);
var state_29939__$1 = (function (){var statearr_29944 = state_29939;
(statearr_29944[(9)] = inst_29907__$1);

return statearr_29944;
})();
if(inst_29909){
var statearr_29945_29970 = state_29939__$1;
(statearr_29945_29970[(1)] = (5));

} else {
var statearr_29946_29971 = state_29939__$1;
(statearr_29946_29971[(1)] = (6));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_29940 === (15))){
var inst_29929 = (state_29939[(2)]);
var state_29939__$1 = state_29939;
var statearr_29947_29972 = state_29939__$1;
(statearr_29947_29972[(2)] = inst_29929);

(statearr_29947_29972[(1)] = (14));


return cljs.core.cst$kw$recur;
} else {
if((state_val_29940 === (13))){
var state_29939__$1 = state_29939;
var statearr_29948_29973 = state_29939__$1;
(statearr_29948_29973[(2)] = null);

(statearr_29948_29973[(1)] = (14));


return cljs.core.cst$kw$recur;
} else {
if((state_val_29940 === (6))){
var inst_29904 = (state_29939[(8)]);
var inst_29925 = (inst_29904 > (0));
var state_29939__$1 = state_29939;
if(cljs.core.truth_(inst_29925)){
var statearr_29949_29974 = state_29939__$1;
(statearr_29949_29974[(1)] = (12));

} else {
var statearr_29950_29975 = state_29939__$1;
(statearr_29950_29975[(1)] = (13));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_29940 === (3))){
var inst_29937 = (state_29939[(2)]);
var state_29939__$1 = state_29939;
return cljs.core.async.impl.ioc_helpers.return_chan(state_29939__$1,inst_29937);
} else {
if((state_val_29940 === (12))){
var inst_29903 = (state_29939[(7)]);
var inst_29927 = cljs.core.vec(inst_29903);
var state_29939__$1 = state_29939;
return cljs.core.async.impl.ioc_helpers.put_BANG_(state_29939__$1,(15),out,inst_29927);
} else {
if((state_val_29940 === (2))){
var state_29939__$1 = state_29939;
return cljs.core.async.impl.ioc_helpers.take_BANG_(state_29939__$1,(4),ch);
} else {
if((state_val_29940 === (11))){
var inst_29919 = (state_29939[(2)]);
var inst_29920 = (new Array(n));
var inst_29903 = inst_29920;
var inst_29904 = (0);
var state_29939__$1 = (function (){var statearr_29951 = state_29939;
(statearr_29951[(7)] = inst_29903);

(statearr_29951[(8)] = inst_29904);

(statearr_29951[(10)] = inst_29919);

return statearr_29951;
})();
var statearr_29952_29976 = state_29939__$1;
(statearr_29952_29976[(2)] = null);

(statearr_29952_29976[(1)] = (2));


return cljs.core.cst$kw$recur;
} else {
if((state_val_29940 === (9))){
var inst_29903 = (state_29939[(7)]);
var inst_29917 = cljs.core.vec(inst_29903);
var state_29939__$1 = state_29939;
return cljs.core.async.impl.ioc_helpers.put_BANG_(state_29939__$1,(11),out,inst_29917);
} else {
if((state_val_29940 === (5))){
var inst_29903 = (state_29939[(7)]);
var inst_29912 = (state_29939[(11)]);
var inst_29904 = (state_29939[(8)]);
var inst_29907 = (state_29939[(9)]);
var inst_29911 = (inst_29903[inst_29904] = inst_29907);
var inst_29912__$1 = (inst_29904 + (1));
var inst_29913 = (inst_29912__$1 < n);
var state_29939__$1 = (function (){var statearr_29953 = state_29939;
(statearr_29953[(11)] = inst_29912__$1);

(statearr_29953[(12)] = inst_29911);

return statearr_29953;
})();
if(cljs.core.truth_(inst_29913)){
var statearr_29954_29977 = state_29939__$1;
(statearr_29954_29977[(1)] = (8));

} else {
var statearr_29955_29978 = state_29939__$1;
(statearr_29955_29978[(1)] = (9));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_29940 === (14))){
var inst_29932 = (state_29939[(2)]);
var inst_29933 = cljs.core.async.close_BANG_(out);
var state_29939__$1 = (function (){var statearr_29957 = state_29939;
(statearr_29957[(13)] = inst_29932);

return statearr_29957;
})();
var statearr_29958_29979 = state_29939__$1;
(statearr_29958_29979[(2)] = inst_29933);

(statearr_29958_29979[(1)] = (7));


return cljs.core.cst$kw$recur;
} else {
if((state_val_29940 === (10))){
var inst_29923 = (state_29939[(2)]);
var state_29939__$1 = state_29939;
var statearr_29959_29980 = state_29939__$1;
(statearr_29959_29980[(2)] = inst_29923);

(statearr_29959_29980[(1)] = (7));


return cljs.core.cst$kw$recur;
} else {
if((state_val_29940 === (8))){
var inst_29903 = (state_29939[(7)]);
var inst_29912 = (state_29939[(11)]);
var tmp29956 = inst_29903;
var inst_29903__$1 = tmp29956;
var inst_29904 = inst_29912;
var state_29939__$1 = (function (){var statearr_29960 = state_29939;
(statearr_29960[(7)] = inst_29903__$1);

(statearr_29960[(8)] = inst_29904);

return statearr_29960;
})();
var statearr_29961_29981 = state_29939__$1;
(statearr_29961_29981[(2)] = null);

(statearr_29961_29981[(1)] = (2));


return cljs.core.cst$kw$recur;
} else {
return null;
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
});})(c__7992__auto___29967,out))
;
return ((function (switch__7885__auto__,c__7992__auto___29967,out){
return (function() {
var cljs$core$async$state_machine__7886__auto__ = null;
var cljs$core$async$state_machine__7886__auto____0 = (function (){
var statearr_29962 = [null,null,null,null,null,null,null,null,null,null,null,null,null,null];
(statearr_29962[(0)] = cljs$core$async$state_machine__7886__auto__);

(statearr_29962[(1)] = (1));

return statearr_29962;
});
var cljs$core$async$state_machine__7886__auto____1 = (function (state_29939){
while(true){
var ret_value__7887__auto__ = (function (){try{while(true){
var result__7888__auto__ = switch__7885__auto__(state_29939);
if(cljs.core.keyword_identical_QMARK_(result__7888__auto__,cljs.core.cst$kw$recur)){
continue;
} else {
return result__7888__auto__;
}
break;
}
}catch (e29963){if((e29963 instanceof Object)){
var ex__7889__auto__ = e29963;
var statearr_29964_29982 = state_29939;
(statearr_29964_29982[(5)] = ex__7889__auto__);


cljs.core.async.impl.ioc_helpers.process_exception(state_29939);

return cljs.core.cst$kw$recur;
} else {
throw e29963;

}
}})();
if(cljs.core.keyword_identical_QMARK_(ret_value__7887__auto__,cljs.core.cst$kw$recur)){
var G__29983 = state_29939;
state_29939 = G__29983;
continue;
} else {
return ret_value__7887__auto__;
}
break;
}
});
cljs$core$async$state_machine__7886__auto__ = function(state_29939){
switch(arguments.length){
case 0:
return cljs$core$async$state_machine__7886__auto____0.call(this);
case 1:
return cljs$core$async$state_machine__7886__auto____1.call(this,state_29939);
}
throw(new Error('Invalid arity: ' + arguments.length));
};
cljs$core$async$state_machine__7886__auto__.cljs$core$IFn$_invoke$arity$0 = cljs$core$async$state_machine__7886__auto____0;
cljs$core$async$state_machine__7886__auto__.cljs$core$IFn$_invoke$arity$1 = cljs$core$async$state_machine__7886__auto____1;
return cljs$core$async$state_machine__7886__auto__;
})()
;})(switch__7885__auto__,c__7992__auto___29967,out))
})();
var state__7994__auto__ = (function (){var statearr_29965 = (f__7993__auto__.cljs$core$IFn$_invoke$arity$0 ? f__7993__auto__.cljs$core$IFn$_invoke$arity$0() : f__7993__auto__.call(null));
(statearr_29965[(6)] = c__7992__auto___29967);

return statearr_29965;
})();
return cljs.core.async.impl.ioc_helpers.run_state_machine_wrapped(state__7994__auto__);
});})(c__7992__auto___29967,out))
);


return out;
});

cljs.core.async.partition.cljs$lang$maxFixedArity = 3;

/**
 * Deprecated - this function will be removed. Use transducer instead
 */
cljs.core.async.partition_by = (function cljs$core$async$partition_by(var_args){
var G__29985 = arguments.length;
switch (G__29985) {
case 2:
return cljs.core.async.partition_by.cljs$core$IFn$_invoke$arity$2((arguments[(0)]),(arguments[(1)]));

break;
case 3:
return cljs.core.async.partition_by.cljs$core$IFn$_invoke$arity$3((arguments[(0)]),(arguments[(1)]),(arguments[(2)]));

break;
default:
throw (new Error(["Invalid arity: ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(arguments.length)].join('')));

}
});

cljs.core.async.partition_by.cljs$core$IFn$_invoke$arity$2 = (function (f,ch){
return cljs.core.async.partition_by.cljs$core$IFn$_invoke$arity$3(f,ch,null);
});

cljs.core.async.partition_by.cljs$core$IFn$_invoke$arity$3 = (function (f,ch,buf_or_n){
var out = cljs.core.async.chan.cljs$core$IFn$_invoke$arity$1(buf_or_n);
var c__7992__auto___30055 = cljs.core.async.chan.cljs$core$IFn$_invoke$arity$1((1));
cljs.core.async.impl.dispatch.run(((function (c__7992__auto___30055,out){
return (function (){
var f__7993__auto__ = (function (){var switch__7885__auto__ = ((function (c__7992__auto___30055,out){
return (function (state_30027){
var state_val_30028 = (state_30027[(1)]);
if((state_val_30028 === (7))){
var inst_30023 = (state_30027[(2)]);
var state_30027__$1 = state_30027;
var statearr_30029_30056 = state_30027__$1;
(statearr_30029_30056[(2)] = inst_30023);

(statearr_30029_30056[(1)] = (3));


return cljs.core.cst$kw$recur;
} else {
if((state_val_30028 === (1))){
var inst_29986 = [];
var inst_29987 = inst_29986;
var inst_29988 = cljs.core.cst$kw$cljs$core$async_SLASH_nothing;
var state_30027__$1 = (function (){var statearr_30030 = state_30027;
(statearr_30030[(7)] = inst_29987);

(statearr_30030[(8)] = inst_29988);

return statearr_30030;
})();
var statearr_30031_30057 = state_30027__$1;
(statearr_30031_30057[(2)] = null);

(statearr_30031_30057[(1)] = (2));


return cljs.core.cst$kw$recur;
} else {
if((state_val_30028 === (4))){
var inst_29991 = (state_30027[(9)]);
var inst_29991__$1 = (state_30027[(2)]);
var inst_29992 = (inst_29991__$1 == null);
var inst_29993 = cljs.core.not(inst_29992);
var state_30027__$1 = (function (){var statearr_30032 = state_30027;
(statearr_30032[(9)] = inst_29991__$1);

return statearr_30032;
})();
if(inst_29993){
var statearr_30033_30058 = state_30027__$1;
(statearr_30033_30058[(1)] = (5));

} else {
var statearr_30034_30059 = state_30027__$1;
(statearr_30034_30059[(1)] = (6));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_30028 === (15))){
var inst_30017 = (state_30027[(2)]);
var state_30027__$1 = state_30027;
var statearr_30035_30060 = state_30027__$1;
(statearr_30035_30060[(2)] = inst_30017);

(statearr_30035_30060[(1)] = (14));


return cljs.core.cst$kw$recur;
} else {
if((state_val_30028 === (13))){
var state_30027__$1 = state_30027;
var statearr_30036_30061 = state_30027__$1;
(statearr_30036_30061[(2)] = null);

(statearr_30036_30061[(1)] = (14));


return cljs.core.cst$kw$recur;
} else {
if((state_val_30028 === (6))){
var inst_29987 = (state_30027[(7)]);
var inst_30012 = inst_29987.length;
var inst_30013 = (inst_30012 > (0));
var state_30027__$1 = state_30027;
if(cljs.core.truth_(inst_30013)){
var statearr_30037_30062 = state_30027__$1;
(statearr_30037_30062[(1)] = (12));

} else {
var statearr_30038_30063 = state_30027__$1;
(statearr_30038_30063[(1)] = (13));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_30028 === (3))){
var inst_30025 = (state_30027[(2)]);
var state_30027__$1 = state_30027;
return cljs.core.async.impl.ioc_helpers.return_chan(state_30027__$1,inst_30025);
} else {
if((state_val_30028 === (12))){
var inst_29987 = (state_30027[(7)]);
var inst_30015 = cljs.core.vec(inst_29987);
var state_30027__$1 = state_30027;
return cljs.core.async.impl.ioc_helpers.put_BANG_(state_30027__$1,(15),out,inst_30015);
} else {
if((state_val_30028 === (2))){
var state_30027__$1 = state_30027;
return cljs.core.async.impl.ioc_helpers.take_BANG_(state_30027__$1,(4),ch);
} else {
if((state_val_30028 === (11))){
var inst_29991 = (state_30027[(9)]);
var inst_29995 = (state_30027[(10)]);
var inst_30005 = (state_30027[(2)]);
var inst_30006 = [];
var inst_30007 = inst_30006.push(inst_29991);
var inst_29987 = inst_30006;
var inst_29988 = inst_29995;
var state_30027__$1 = (function (){var statearr_30039 = state_30027;
(statearr_30039[(7)] = inst_29987);

(statearr_30039[(11)] = inst_30005);

(statearr_30039[(8)] = inst_29988);

(statearr_30039[(12)] = inst_30007);

return statearr_30039;
})();
var statearr_30040_30064 = state_30027__$1;
(statearr_30040_30064[(2)] = null);

(statearr_30040_30064[(1)] = (2));


return cljs.core.cst$kw$recur;
} else {
if((state_val_30028 === (9))){
var inst_29987 = (state_30027[(7)]);
var inst_30003 = cljs.core.vec(inst_29987);
var state_30027__$1 = state_30027;
return cljs.core.async.impl.ioc_helpers.put_BANG_(state_30027__$1,(11),out,inst_30003);
} else {
if((state_val_30028 === (5))){
var inst_29991 = (state_30027[(9)]);
var inst_29995 = (state_30027[(10)]);
var inst_29988 = (state_30027[(8)]);
var inst_29995__$1 = (f.cljs$core$IFn$_invoke$arity$1 ? f.cljs$core$IFn$_invoke$arity$1(inst_29991) : f.call(null,inst_29991));
var inst_29996 = cljs.core._EQ_.cljs$core$IFn$_invoke$arity$2(inst_29995__$1,inst_29988);
var inst_29997 = cljs.core.keyword_identical_QMARK_(inst_29988,cljs.core.cst$kw$cljs$core$async_SLASH_nothing);
var inst_29998 = ((inst_29996) || (inst_29997));
var state_30027__$1 = (function (){var statearr_30041 = state_30027;
(statearr_30041[(10)] = inst_29995__$1);

return statearr_30041;
})();
if(cljs.core.truth_(inst_29998)){
var statearr_30042_30065 = state_30027__$1;
(statearr_30042_30065[(1)] = (8));

} else {
var statearr_30043_30066 = state_30027__$1;
(statearr_30043_30066[(1)] = (9));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_30028 === (14))){
var inst_30020 = (state_30027[(2)]);
var inst_30021 = cljs.core.async.close_BANG_(out);
var state_30027__$1 = (function (){var statearr_30045 = state_30027;
(statearr_30045[(13)] = inst_30020);

return statearr_30045;
})();
var statearr_30046_30067 = state_30027__$1;
(statearr_30046_30067[(2)] = inst_30021);

(statearr_30046_30067[(1)] = (7));


return cljs.core.cst$kw$recur;
} else {
if((state_val_30028 === (10))){
var inst_30010 = (state_30027[(2)]);
var state_30027__$1 = state_30027;
var statearr_30047_30068 = state_30027__$1;
(statearr_30047_30068[(2)] = inst_30010);

(statearr_30047_30068[(1)] = (7));


return cljs.core.cst$kw$recur;
} else {
if((state_val_30028 === (8))){
var inst_29991 = (state_30027[(9)]);
var inst_29987 = (state_30027[(7)]);
var inst_29995 = (state_30027[(10)]);
var inst_30000 = inst_29987.push(inst_29991);
var tmp30044 = inst_29987;
var inst_29987__$1 = tmp30044;
var inst_29988 = inst_29995;
var state_30027__$1 = (function (){var statearr_30048 = state_30027;
(statearr_30048[(7)] = inst_29987__$1);

(statearr_30048[(8)] = inst_29988);

(statearr_30048[(14)] = inst_30000);

return statearr_30048;
})();
var statearr_30049_30069 = state_30027__$1;
(statearr_30049_30069[(2)] = null);

(statearr_30049_30069[(1)] = (2));


return cljs.core.cst$kw$recur;
} else {
return null;
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
});})(c__7992__auto___30055,out))
;
return ((function (switch__7885__auto__,c__7992__auto___30055,out){
return (function() {
var cljs$core$async$state_machine__7886__auto__ = null;
var cljs$core$async$state_machine__7886__auto____0 = (function (){
var statearr_30050 = [null,null,null,null,null,null,null,null,null,null,null,null,null,null,null];
(statearr_30050[(0)] = cljs$core$async$state_machine__7886__auto__);

(statearr_30050[(1)] = (1));

return statearr_30050;
});
var cljs$core$async$state_machine__7886__auto____1 = (function (state_30027){
while(true){
var ret_value__7887__auto__ = (function (){try{while(true){
var result__7888__auto__ = switch__7885__auto__(state_30027);
if(cljs.core.keyword_identical_QMARK_(result__7888__auto__,cljs.core.cst$kw$recur)){
continue;
} else {
return result__7888__auto__;
}
break;
}
}catch (e30051){if((e30051 instanceof Object)){
var ex__7889__auto__ = e30051;
var statearr_30052_30070 = state_30027;
(statearr_30052_30070[(5)] = ex__7889__auto__);


cljs.core.async.impl.ioc_helpers.process_exception(state_30027);

return cljs.core.cst$kw$recur;
} else {
throw e30051;

}
}})();
if(cljs.core.keyword_identical_QMARK_(ret_value__7887__auto__,cljs.core.cst$kw$recur)){
var G__30071 = state_30027;
state_30027 = G__30071;
continue;
} else {
return ret_value__7887__auto__;
}
break;
}
});
cljs$core$async$state_machine__7886__auto__ = function(state_30027){
switch(arguments.length){
case 0:
return cljs$core$async$state_machine__7886__auto____0.call(this);
case 1:
return cljs$core$async$state_machine__7886__auto____1.call(this,state_30027);
}
throw(new Error('Invalid arity: ' + arguments.length));
};
cljs$core$async$state_machine__7886__auto__.cljs$core$IFn$_invoke$arity$0 = cljs$core$async$state_machine__7886__auto____0;
cljs$core$async$state_machine__7886__auto__.cljs$core$IFn$_invoke$arity$1 = cljs$core$async$state_machine__7886__auto____1;
return cljs$core$async$state_machine__7886__auto__;
})()
;})(switch__7885__auto__,c__7992__auto___30055,out))
})();
var state__7994__auto__ = (function (){var statearr_30053 = (f__7993__auto__.cljs$core$IFn$_invoke$arity$0 ? f__7993__auto__.cljs$core$IFn$_invoke$arity$0() : f__7993__auto__.call(null));
(statearr_30053[(6)] = c__7992__auto___30055);

return statearr_30053;
})();
return cljs.core.async.impl.ioc_helpers.run_state_machine_wrapped(state__7994__auto__);
});})(c__7992__auto___30055,out))
);


return out;
});

cljs.core.async.partition_by.cljs$lang$maxFixedArity = 3;

