// Compiled by ClojureScript 1.10.439 {:static-fns true, :optimize-constants true, :elide-asserts true}
goog.provide('chromex_sample.background.storage');
goog.require('cljs.core');
goog.require('cljs.core.constants');
goog.require('cljs.core.async');
goog.require('chromex.logging');
goog.require('chromex.protocols.chrome_storage_area');
goog.require('chromex.ext.storage');
chromex_sample.background.storage.test_storage_BANG_ = (function chromex_sample$background$storage$test_storage_BANG_(){
var local_storage = chromex.ext.storage.local_STAR_(chromex.config.get_active_config());
chromex.protocols.chrome_storage_area.set(local_storage,({"key1": "string", "key2": [(1),(2),(3)], "key3": true, "key4": null}));

var c__7992__auto___13426 = cljs.core.async.chan.cljs$core$IFn$_invoke$arity$1((1));
cljs.core.async.impl.dispatch.run(((function (c__7992__auto___13426,local_storage){
return (function (){
var f__7993__auto__ = (function (){var switch__7885__auto__ = ((function (c__7992__auto___13426,local_storage){
return (function (state_13352){
var state_val_13353 = (state_13352[(1)]);
if((state_val_13353 === (1))){
var inst_13339 = chromex.protocols.chrome_storage_area.get.cljs$core$IFn$_invoke$arity$1(local_storage);
var state_13352__$1 = state_13352;
return cljs.core.async.impl.ioc_helpers.take_BANG_(state_13352__$1,(2),inst_13339);
} else {
if((state_val_13353 === (2))){
var inst_13344 = (state_13352[(7)]);
var inst_13341 = (state_13352[(2)]);
var inst_13342 = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(inst_13341,(0),null);
var inst_13343 = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(inst_13342,(0),null);
var inst_13344__$1 = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(inst_13341,(1),null);
var state_13352__$1 = (function (){var statearr_13354 = state_13352;
(statearr_13354[(8)] = inst_13343);

(statearr_13354[(7)] = inst_13344__$1);

return statearr_13354;
})();
if(cljs.core.truth_(inst_13344__$1)){
var statearr_13355_13427 = state_13352__$1;
(statearr_13355_13427[(1)] = (3));

} else {
var statearr_13356_13428 = state_13352__$1;
(statearr_13356_13428[(1)] = (4));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_13353 === (3))){
var inst_13344 = (state_13352[(7)]);
var inst_13346 = (inst_13344.cljs$core$IFn$_invoke$arity$2 ? inst_13344.cljs$core$IFn$_invoke$arity$2("fetch all error:",inst_13344) : inst_13344.call(null,"fetch all error:",inst_13344));
var state_13352__$1 = state_13352;
var statearr_13357_13429 = state_13352__$1;
(statearr_13357_13429[(2)] = inst_13346);

(statearr_13357_13429[(1)] = (5));


return cljs.core.cst$kw$recur;
} else {
if((state_val_13353 === (4))){
var inst_13343 = (state_13352[(8)]);
var inst_13348 = console.log("fetch all:",inst_13343);
var state_13352__$1 = (function (){var statearr_13358 = state_13352;
(statearr_13358[(9)] = inst_13348);

return statearr_13358;
})();
var statearr_13359_13430 = state_13352__$1;
(statearr_13359_13430[(2)] = null);

(statearr_13359_13430[(1)] = (5));


return cljs.core.cst$kw$recur;
} else {
if((state_val_13353 === (5))){
var inst_13350 = (state_13352[(2)]);
var state_13352__$1 = state_13352;
return cljs.core.async.impl.ioc_helpers.return_chan(state_13352__$1,inst_13350);
} else {
return null;
}
}
}
}
}
});})(c__7992__auto___13426,local_storage))
;
return ((function (switch__7885__auto__,c__7992__auto___13426,local_storage){
return (function() {
var chromex_sample$background$storage$test_storage_BANG__$_state_machine__7886__auto__ = null;
var chromex_sample$background$storage$test_storage_BANG__$_state_machine__7886__auto____0 = (function (){
var statearr_13360 = [null,null,null,null,null,null,null,null,null,null];
(statearr_13360[(0)] = chromex_sample$background$storage$test_storage_BANG__$_state_machine__7886__auto__);

(statearr_13360[(1)] = (1));

return statearr_13360;
});
var chromex_sample$background$storage$test_storage_BANG__$_state_machine__7886__auto____1 = (function (state_13352){
while(true){
var ret_value__7887__auto__ = (function (){try{while(true){
var result__7888__auto__ = switch__7885__auto__(state_13352);
if(cljs.core.keyword_identical_QMARK_(result__7888__auto__,cljs.core.cst$kw$recur)){
continue;
} else {
return result__7888__auto__;
}
break;
}
}catch (e13361){if((e13361 instanceof Object)){
var ex__7889__auto__ = e13361;
var statearr_13362_13431 = state_13352;
(statearr_13362_13431[(5)] = ex__7889__auto__);


cljs.core.async.impl.ioc_helpers.process_exception(state_13352);

return cljs.core.cst$kw$recur;
} else {
throw e13361;

}
}})();
if(cljs.core.keyword_identical_QMARK_(ret_value__7887__auto__,cljs.core.cst$kw$recur)){
var G__13432 = state_13352;
state_13352 = G__13432;
continue;
} else {
return ret_value__7887__auto__;
}
break;
}
});
chromex_sample$background$storage$test_storage_BANG__$_state_machine__7886__auto__ = function(state_13352){
switch(arguments.length){
case 0:
return chromex_sample$background$storage$test_storage_BANG__$_state_machine__7886__auto____0.call(this);
case 1:
return chromex_sample$background$storage$test_storage_BANG__$_state_machine__7886__auto____1.call(this,state_13352);
}
throw(new Error('Invalid arity: ' + arguments.length));
};
chromex_sample$background$storage$test_storage_BANG__$_state_machine__7886__auto__.cljs$core$IFn$_invoke$arity$0 = chromex_sample$background$storage$test_storage_BANG__$_state_machine__7886__auto____0;
chromex_sample$background$storage$test_storage_BANG__$_state_machine__7886__auto__.cljs$core$IFn$_invoke$arity$1 = chromex_sample$background$storage$test_storage_BANG__$_state_machine__7886__auto____1;
return chromex_sample$background$storage$test_storage_BANG__$_state_machine__7886__auto__;
})()
;})(switch__7885__auto__,c__7992__auto___13426,local_storage))
})();
var state__7994__auto__ = (function (){var statearr_13363 = (f__7993__auto__.cljs$core$IFn$_invoke$arity$0 ? f__7993__auto__.cljs$core$IFn$_invoke$arity$0() : f__7993__auto__.call(null));
(statearr_13363[(6)] = c__7992__auto___13426);

return statearr_13363;
})();
return cljs.core.async.impl.ioc_helpers.run_state_machine_wrapped(state__7994__auto__);
});})(c__7992__auto___13426,local_storage))
);


var c__7992__auto___13433 = cljs.core.async.chan.cljs$core$IFn$_invoke$arity$1((1));
cljs.core.async.impl.dispatch.run(((function (c__7992__auto___13433,local_storage){
return (function (){
var f__7993__auto__ = (function (){var switch__7885__auto__ = ((function (c__7992__auto___13433,local_storage){
return (function (state_13383){
var state_val_13384 = (state_13383[(1)]);
if((state_val_13384 === (1))){
var inst_13370 = chromex.protocols.chrome_storage_area.get.cljs$core$IFn$_invoke$arity$2(local_storage,"key1");
var state_13383__$1 = state_13383;
return cljs.core.async.impl.ioc_helpers.take_BANG_(state_13383__$1,(2),inst_13370);
} else {
if((state_val_13384 === (2))){
var inst_13375 = (state_13383[(7)]);
var inst_13372 = (state_13383[(2)]);
var inst_13373 = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(inst_13372,(0),null);
var inst_13374 = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(inst_13373,(0),null);
var inst_13375__$1 = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(inst_13372,(1),null);
var state_13383__$1 = (function (){var statearr_13385 = state_13383;
(statearr_13385[(8)] = inst_13374);

(statearr_13385[(7)] = inst_13375__$1);

return statearr_13385;
})();
if(cljs.core.truth_(inst_13375__$1)){
var statearr_13386_13434 = state_13383__$1;
(statearr_13386_13434[(1)] = (3));

} else {
var statearr_13387_13435 = state_13383__$1;
(statearr_13387_13435[(1)] = (4));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_13384 === (3))){
var inst_13375 = (state_13383[(7)]);
var inst_13377 = (inst_13375.cljs$core$IFn$_invoke$arity$2 ? inst_13375.cljs$core$IFn$_invoke$arity$2("fetch key1 error:",inst_13375) : inst_13375.call(null,"fetch key1 error:",inst_13375));
var state_13383__$1 = state_13383;
var statearr_13388_13436 = state_13383__$1;
(statearr_13388_13436[(2)] = inst_13377);

(statearr_13388_13436[(1)] = (5));


return cljs.core.cst$kw$recur;
} else {
if((state_val_13384 === (4))){
var inst_13374 = (state_13383[(8)]);
var inst_13379 = console.log("fetch key1:",inst_13374);
var state_13383__$1 = (function (){var statearr_13389 = state_13383;
(statearr_13389[(9)] = inst_13379);

return statearr_13389;
})();
var statearr_13390_13437 = state_13383__$1;
(statearr_13390_13437[(2)] = null);

(statearr_13390_13437[(1)] = (5));


return cljs.core.cst$kw$recur;
} else {
if((state_val_13384 === (5))){
var inst_13381 = (state_13383[(2)]);
var state_13383__$1 = state_13383;
return cljs.core.async.impl.ioc_helpers.return_chan(state_13383__$1,inst_13381);
} else {
return null;
}
}
}
}
}
});})(c__7992__auto___13433,local_storage))
;
return ((function (switch__7885__auto__,c__7992__auto___13433,local_storage){
return (function() {
var chromex_sample$background$storage$test_storage_BANG__$_state_machine__7886__auto__ = null;
var chromex_sample$background$storage$test_storage_BANG__$_state_machine__7886__auto____0 = (function (){
var statearr_13391 = [null,null,null,null,null,null,null,null,null,null];
(statearr_13391[(0)] = chromex_sample$background$storage$test_storage_BANG__$_state_machine__7886__auto__);

(statearr_13391[(1)] = (1));

return statearr_13391;
});
var chromex_sample$background$storage$test_storage_BANG__$_state_machine__7886__auto____1 = (function (state_13383){
while(true){
var ret_value__7887__auto__ = (function (){try{while(true){
var result__7888__auto__ = switch__7885__auto__(state_13383);
if(cljs.core.keyword_identical_QMARK_(result__7888__auto__,cljs.core.cst$kw$recur)){
continue;
} else {
return result__7888__auto__;
}
break;
}
}catch (e13392){if((e13392 instanceof Object)){
var ex__7889__auto__ = e13392;
var statearr_13393_13438 = state_13383;
(statearr_13393_13438[(5)] = ex__7889__auto__);


cljs.core.async.impl.ioc_helpers.process_exception(state_13383);

return cljs.core.cst$kw$recur;
} else {
throw e13392;

}
}})();
if(cljs.core.keyword_identical_QMARK_(ret_value__7887__auto__,cljs.core.cst$kw$recur)){
var G__13439 = state_13383;
state_13383 = G__13439;
continue;
} else {
return ret_value__7887__auto__;
}
break;
}
});
chromex_sample$background$storage$test_storage_BANG__$_state_machine__7886__auto__ = function(state_13383){
switch(arguments.length){
case 0:
return chromex_sample$background$storage$test_storage_BANG__$_state_machine__7886__auto____0.call(this);
case 1:
return chromex_sample$background$storage$test_storage_BANG__$_state_machine__7886__auto____1.call(this,state_13383);
}
throw(new Error('Invalid arity: ' + arguments.length));
};
chromex_sample$background$storage$test_storage_BANG__$_state_machine__7886__auto__.cljs$core$IFn$_invoke$arity$0 = chromex_sample$background$storage$test_storage_BANG__$_state_machine__7886__auto____0;
chromex_sample$background$storage$test_storage_BANG__$_state_machine__7886__auto__.cljs$core$IFn$_invoke$arity$1 = chromex_sample$background$storage$test_storage_BANG__$_state_machine__7886__auto____1;
return chromex_sample$background$storage$test_storage_BANG__$_state_machine__7886__auto__;
})()
;})(switch__7885__auto__,c__7992__auto___13433,local_storage))
})();
var state__7994__auto__ = (function (){var statearr_13394 = (f__7993__auto__.cljs$core$IFn$_invoke$arity$0 ? f__7993__auto__.cljs$core$IFn$_invoke$arity$0() : f__7993__auto__.call(null));
(statearr_13394[(6)] = c__7992__auto___13433);

return statearr_13394;
})();
return cljs.core.async.impl.ioc_helpers.run_state_machine_wrapped(state__7994__auto__);
});})(c__7992__auto___13433,local_storage))
);


var c__7992__auto__ = cljs.core.async.chan.cljs$core$IFn$_invoke$arity$1((1));
cljs.core.async.impl.dispatch.run(((function (c__7992__auto__,local_storage){
return (function (){
var f__7993__auto__ = (function (){var switch__7885__auto__ = ((function (c__7992__auto__,local_storage){
return (function (state_13414){
var state_val_13415 = (state_13414[(1)]);
if((state_val_13415 === (1))){
var inst_13401 = chromex.protocols.chrome_storage_area.get.cljs$core$IFn$_invoke$arity$2(local_storage,["key2","key3"]);
var state_13414__$1 = state_13414;
return cljs.core.async.impl.ioc_helpers.take_BANG_(state_13414__$1,(2),inst_13401);
} else {
if((state_val_13415 === (2))){
var inst_13406 = (state_13414[(7)]);
var inst_13403 = (state_13414[(2)]);
var inst_13404 = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(inst_13403,(0),null);
var inst_13405 = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(inst_13404,(0),null);
var inst_13406__$1 = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(inst_13403,(1),null);
var state_13414__$1 = (function (){var statearr_13416 = state_13414;
(statearr_13416[(7)] = inst_13406__$1);

(statearr_13416[(8)] = inst_13405);

return statearr_13416;
})();
if(cljs.core.truth_(inst_13406__$1)){
var statearr_13417_13440 = state_13414__$1;
(statearr_13417_13440[(1)] = (3));

} else {
var statearr_13418_13441 = state_13414__$1;
(statearr_13418_13441[(1)] = (4));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_13415 === (3))){
var inst_13406 = (state_13414[(7)]);
var inst_13408 = (inst_13406.cljs$core$IFn$_invoke$arity$2 ? inst_13406.cljs$core$IFn$_invoke$arity$2("fetch key2 and key3 error:",inst_13406) : inst_13406.call(null,"fetch key2 and key3 error:",inst_13406));
var state_13414__$1 = state_13414;
var statearr_13419_13442 = state_13414__$1;
(statearr_13419_13442[(2)] = inst_13408);

(statearr_13419_13442[(1)] = (5));


return cljs.core.cst$kw$recur;
} else {
if((state_val_13415 === (4))){
var inst_13405 = (state_13414[(8)]);
var inst_13410 = console.log("fetch key2 and key3:",inst_13405);
var state_13414__$1 = (function (){var statearr_13420 = state_13414;
(statearr_13420[(9)] = inst_13410);

return statearr_13420;
})();
var statearr_13421_13443 = state_13414__$1;
(statearr_13421_13443[(2)] = null);

(statearr_13421_13443[(1)] = (5));


return cljs.core.cst$kw$recur;
} else {
if((state_val_13415 === (5))){
var inst_13412 = (state_13414[(2)]);
var state_13414__$1 = state_13414;
return cljs.core.async.impl.ioc_helpers.return_chan(state_13414__$1,inst_13412);
} else {
return null;
}
}
}
}
}
});})(c__7992__auto__,local_storage))
;
return ((function (switch__7885__auto__,c__7992__auto__,local_storage){
return (function() {
var chromex_sample$background$storage$test_storage_BANG__$_state_machine__7886__auto__ = null;
var chromex_sample$background$storage$test_storage_BANG__$_state_machine__7886__auto____0 = (function (){
var statearr_13422 = [null,null,null,null,null,null,null,null,null,null];
(statearr_13422[(0)] = chromex_sample$background$storage$test_storage_BANG__$_state_machine__7886__auto__);

(statearr_13422[(1)] = (1));

return statearr_13422;
});
var chromex_sample$background$storage$test_storage_BANG__$_state_machine__7886__auto____1 = (function (state_13414){
while(true){
var ret_value__7887__auto__ = (function (){try{while(true){
var result__7888__auto__ = switch__7885__auto__(state_13414);
if(cljs.core.keyword_identical_QMARK_(result__7888__auto__,cljs.core.cst$kw$recur)){
continue;
} else {
return result__7888__auto__;
}
break;
}
}catch (e13423){if((e13423 instanceof Object)){
var ex__7889__auto__ = e13423;
var statearr_13424_13444 = state_13414;
(statearr_13424_13444[(5)] = ex__7889__auto__);


cljs.core.async.impl.ioc_helpers.process_exception(state_13414);

return cljs.core.cst$kw$recur;
} else {
throw e13423;

}
}})();
if(cljs.core.keyword_identical_QMARK_(ret_value__7887__auto__,cljs.core.cst$kw$recur)){
var G__13445 = state_13414;
state_13414 = G__13445;
continue;
} else {
return ret_value__7887__auto__;
}
break;
}
});
chromex_sample$background$storage$test_storage_BANG__$_state_machine__7886__auto__ = function(state_13414){
switch(arguments.length){
case 0:
return chromex_sample$background$storage$test_storage_BANG__$_state_machine__7886__auto____0.call(this);
case 1:
return chromex_sample$background$storage$test_storage_BANG__$_state_machine__7886__auto____1.call(this,state_13414);
}
throw(new Error('Invalid arity: ' + arguments.length));
};
chromex_sample$background$storage$test_storage_BANG__$_state_machine__7886__auto__.cljs$core$IFn$_invoke$arity$0 = chromex_sample$background$storage$test_storage_BANG__$_state_machine__7886__auto____0;
chromex_sample$background$storage$test_storage_BANG__$_state_machine__7886__auto__.cljs$core$IFn$_invoke$arity$1 = chromex_sample$background$storage$test_storage_BANG__$_state_machine__7886__auto____1;
return chromex_sample$background$storage$test_storage_BANG__$_state_machine__7886__auto__;
})()
;})(switch__7885__auto__,c__7992__auto__,local_storage))
})();
var state__7994__auto__ = (function (){var statearr_13425 = (f__7993__auto__.cljs$core$IFn$_invoke$arity$0 ? f__7993__auto__.cljs$core$IFn$_invoke$arity$0() : f__7993__auto__.call(null));
(statearr_13425[(6)] = c__7992__auto__);

return statearr_13425;
})();
return cljs.core.async.impl.ioc_helpers.run_state_machine_wrapped(state__7994__auto__);
});})(c__7992__auto__,local_storage))
);

return c__7992__auto__;
});
