// Compiled by ClojureScript 1.10.439 {:static-fns true, :optimize-constants true, :elide-asserts true}
goog.provide('chromex_sample.background.core');
goog.require('cljs.core');
goog.require('cljs.core.constants');
goog.require('goog.string');
goog.require('goog.string.format');
goog.require('goog.object');
goog.require('clojure.string');
goog.require('cljs.core.async');
goog.require('chromex.logging');
goog.require('chromex.chrome_event_channel');
goog.require('chromex.protocols.chrome_port');
goog.require('chromex.ext.tabs');
goog.require('chromex.ext.runtime');
goog.require('chromex.ext.browser_action');
goog.require('chromex_sample.background.storage');
chromex_sample.background.core.clients = cljs.core.atom.cljs$core$IFn$_invoke$arity$1(cljs.core.PersistentVector.EMPTY);
chromex_sample.background.core.add_client_BANG_ = (function chromex_sample$background$core$add_client_BANG_(client){
console.log("BACKGROUND: client connected",chromex.protocols.chrome_port.get_sender(client));


return cljs.core.swap_BANG_.cljs$core$IFn$_invoke$arity$3(chromex_sample.background.core.clients,cljs.core.conj,client);
});
chromex_sample.background.core.remove_client_BANG_ = (function chromex_sample$background$core$remove_client_BANG_(client){
console.log("BACKGROUND: client disconnected",chromex.protocols.chrome_port.get_sender(client));


var remove_item = (function (coll,item){
return cljs.core.remove.cljs$core$IFn$_invoke$arity$2((function (p1__15030_SHARP_){
return (item === p1__15030_SHARP_);
}),coll);
});
return cljs.core.swap_BANG_.cljs$core$IFn$_invoke$arity$3(chromex_sample.background.core.clients,remove_item,client);
});
chromex_sample.background.core.run_client_message_loop_BANG_ = (function chromex_sample$background$core$run_client_message_loop_BANG_(client){
console.log("BACKGROUND: starting event loop for client:",chromex.protocols.chrome_port.get_sender(client));


var c__7992__auto__ = cljs.core.async.chan.cljs$core$IFn$_invoke$arity$1((1));
cljs.core.async.impl.dispatch.run(((function (c__7992__auto__){
return (function (){
var f__7993__auto__ = (function (){var switch__7885__auto__ = ((function (c__7992__auto__){
return (function (state_15048){
var state_val_15049 = (state_15048[(1)]);
if((state_val_15049 === (1))){
var state_15048__$1 = state_15048;
var statearr_15050_15063 = state_15048__$1;
(statearr_15050_15063[(2)] = null);

(statearr_15050_15063[(1)] = (2));


return cljs.core.cst$kw$recur;
} else {
if((state_val_15049 === (2))){
var state_15048__$1 = state_15048;
return cljs.core.async.impl.ioc_helpers.take_BANG_(state_15048__$1,(4),client);
} else {
if((state_val_15049 === (3))){
var inst_15046 = (state_15048[(2)]);
var state_15048__$1 = state_15048;
return cljs.core.async.impl.ioc_helpers.return_chan(state_15048__$1,inst_15046);
} else {
if((state_val_15049 === (4))){
var inst_15033 = (state_15048[(7)]);
var inst_15033__$1 = (state_15048[(2)]);
var inst_15034 = (inst_15033__$1 == null);
var state_15048__$1 = (function (){var statearr_15051 = state_15048;
(statearr_15051[(7)] = inst_15033__$1);

return statearr_15051;
})();
if(cljs.core.truth_(inst_15034)){
var statearr_15052_15064 = state_15048__$1;
(statearr_15052_15064[(1)] = (5));

} else {
var statearr_15053_15065 = state_15048__$1;
(statearr_15053_15065[(1)] = (6));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_15049 === (5))){
var state_15048__$1 = state_15048;
var statearr_15054_15066 = state_15048__$1;
(statearr_15054_15066[(2)] = null);

(statearr_15054_15066[(1)] = (7));


return cljs.core.cst$kw$recur;
} else {
if((state_val_15049 === (6))){
var inst_15033 = (state_15048[(7)]);
var inst_15037 = chromex.protocols.chrome_port.get_sender(client);
var inst_15038 = console.log("BACKGROUND: got client message:",inst_15033,"from",inst_15037);
var state_15048__$1 = (function (){var statearr_15055 = state_15048;
(statearr_15055[(8)] = inst_15038);

return statearr_15055;
})();
var statearr_15056_15067 = state_15048__$1;
(statearr_15056_15067[(2)] = null);

(statearr_15056_15067[(1)] = (2));


return cljs.core.cst$kw$recur;
} else {
if((state_val_15049 === (7))){
var inst_15041 = (state_15048[(2)]);
var inst_15042 = chromex.protocols.chrome_port.get_sender(client);
var inst_15043 = console.log("BACKGROUND: leaving event loop for client:",inst_15042);
var inst_15044 = chromex_sample.background.core.remove_client_BANG_(client);
var state_15048__$1 = (function (){var statearr_15057 = state_15048;
(statearr_15057[(9)] = inst_15043);

(statearr_15057[(10)] = inst_15041);

return statearr_15057;
})();
var statearr_15058_15068 = state_15048__$1;
(statearr_15058_15068[(2)] = inst_15044);

(statearr_15058_15068[(1)] = (3));


return cljs.core.cst$kw$recur;
} else {
return null;
}
}
}
}
}
}
}
});})(c__7992__auto__))
;
return ((function (switch__7885__auto__,c__7992__auto__){
return (function() {
var chromex_sample$background$core$run_client_message_loop_BANG__$_state_machine__7886__auto__ = null;
var chromex_sample$background$core$run_client_message_loop_BANG__$_state_machine__7886__auto____0 = (function (){
var statearr_15059 = [null,null,null,null,null,null,null,null,null,null,null];
(statearr_15059[(0)] = chromex_sample$background$core$run_client_message_loop_BANG__$_state_machine__7886__auto__);

(statearr_15059[(1)] = (1));

return statearr_15059;
});
var chromex_sample$background$core$run_client_message_loop_BANG__$_state_machine__7886__auto____1 = (function (state_15048){
while(true){
var ret_value__7887__auto__ = (function (){try{while(true){
var result__7888__auto__ = switch__7885__auto__(state_15048);
if(cljs.core.keyword_identical_QMARK_(result__7888__auto__,cljs.core.cst$kw$recur)){
continue;
} else {
return result__7888__auto__;
}
break;
}
}catch (e15060){if((e15060 instanceof Object)){
var ex__7889__auto__ = e15060;
var statearr_15061_15069 = state_15048;
(statearr_15061_15069[(5)] = ex__7889__auto__);


cljs.core.async.impl.ioc_helpers.process_exception(state_15048);

return cljs.core.cst$kw$recur;
} else {
throw e15060;

}
}})();
if(cljs.core.keyword_identical_QMARK_(ret_value__7887__auto__,cljs.core.cst$kw$recur)){
var G__15070 = state_15048;
state_15048 = G__15070;
continue;
} else {
return ret_value__7887__auto__;
}
break;
}
});
chromex_sample$background$core$run_client_message_loop_BANG__$_state_machine__7886__auto__ = function(state_15048){
switch(arguments.length){
case 0:
return chromex_sample$background$core$run_client_message_loop_BANG__$_state_machine__7886__auto____0.call(this);
case 1:
return chromex_sample$background$core$run_client_message_loop_BANG__$_state_machine__7886__auto____1.call(this,state_15048);
}
throw(new Error('Invalid arity: ' + arguments.length));
};
chromex_sample$background$core$run_client_message_loop_BANG__$_state_machine__7886__auto__.cljs$core$IFn$_invoke$arity$0 = chromex_sample$background$core$run_client_message_loop_BANG__$_state_machine__7886__auto____0;
chromex_sample$background$core$run_client_message_loop_BANG__$_state_machine__7886__auto__.cljs$core$IFn$_invoke$arity$1 = chromex_sample$background$core$run_client_message_loop_BANG__$_state_machine__7886__auto____1;
return chromex_sample$background$core$run_client_message_loop_BANG__$_state_machine__7886__auto__;
})()
;})(switch__7885__auto__,c__7992__auto__))
})();
var state__7994__auto__ = (function (){var statearr_15062 = (f__7993__auto__.cljs$core$IFn$_invoke$arity$0 ? f__7993__auto__.cljs$core$IFn$_invoke$arity$0() : f__7993__auto__.call(null));
(statearr_15062[(6)] = c__7992__auto__);

return statearr_15062;
})();
return cljs.core.async.impl.ioc_helpers.run_state_machine_wrapped(state__7994__auto__);
});})(c__7992__auto__))
);

return c__7992__auto__;
});
chromex_sample.background.core.handle_client_connection_BANG_ = (function chromex_sample$background$core$handle_client_connection_BANG_(client){
chromex_sample.background.core.add_client_BANG_(client);

chromex.protocols.chrome_port.post_message_BANG_(client,"hello from BACKGROUND PAGE!");

return chromex_sample.background.core.run_client_message_loop_BANG_(client);
});
chromex_sample.background.core.tell_clients_about_new_tab_BANG_ = (function chromex_sample$background$core$tell_clients_about_new_tab_BANG_(){
var seq__15071 = cljs.core.seq(cljs.core.deref(chromex_sample.background.core.clients));
var chunk__15072 = null;
var count__15073 = (0);
var i__15074 = (0);
while(true){
if((i__15074 < count__15073)){
var client = chunk__15072.cljs$core$IIndexed$_nth$arity$2(null,i__15074);
chromex.protocols.chrome_port.post_message_BANG_(client,"a new tab was created");


var G__15075 = seq__15071;
var G__15076 = chunk__15072;
var G__15077 = count__15073;
var G__15078 = (i__15074 + (1));
seq__15071 = G__15075;
chunk__15072 = G__15076;
count__15073 = G__15077;
i__15074 = G__15078;
continue;
} else {
var temp__5457__auto__ = cljs.core.seq(seq__15071);
if(temp__5457__auto__){
var seq__15071__$1 = temp__5457__auto__;
if(cljs.core.chunked_seq_QMARK_(seq__15071__$1)){
var c__4461__auto__ = cljs.core.chunk_first(seq__15071__$1);
var G__15079 = cljs.core.chunk_rest(seq__15071__$1);
var G__15080 = c__4461__auto__;
var G__15081 = cljs.core.count(c__4461__auto__);
var G__15082 = (0);
seq__15071 = G__15079;
chunk__15072 = G__15080;
count__15073 = G__15081;
i__15074 = G__15082;
continue;
} else {
var client = cljs.core.first(seq__15071__$1);
chromex.protocols.chrome_port.post_message_BANG_(client,"a new tab was created");


var G__15083 = cljs.core.next(seq__15071__$1);
var G__15084 = null;
var G__15085 = (0);
var G__15086 = (0);
seq__15071 = G__15083;
chunk__15072 = G__15084;
count__15073 = G__15085;
i__15074 = G__15086;
continue;
}
} else {
return null;
}
}
break;
}
});
chromex_sample.background.core.youtube_regex = cljs.core.re_pattern("(?:youtube\\.com/\\S*(?:(?:\\/e(?:mbed))?/|watch\\?(?:\\S*?&?v\\=))|youtu\\.be/)([a-zA-Z0-9_-]{6,11})");
chromex_sample.background.core.select_youtube_links = (function chromex_sample$background$core$select_youtube_links(tab){
var url = cljs.core.cst$kw$url.cljs$core$IFn$_invoke$arity$1(tab);
return cljs.core.re_find(chromex_sample.background.core.youtube_regex,url);
});
chromex_sample.background.core.close_youtube_tabs = (function chromex_sample$background$core$close_youtube_tabs(ids){
return chromex.ext.tabs.remove_STAR_(chromex.config.get_active_config(),cljs.core.to_array(ids));
});
chromex_sample.background.core.get_id = (function chromex_sample$background$core$get_id(url){
var vec__15087 = cljs.core.re_find(chromex_sample.background.core.youtube_regex,url);
var _ = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(vec__15087,(0),null);
var id = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(vec__15087,(1),null);
return id;
});
chromex_sample.background.core.prepare_playlist = (function chromex_sample$background$core$prepare_playlist(urls){
var ids = cljs.core.map.cljs$core$IFn$_invoke$arity$2(chromex_sample.background.core.get_id,urls);
var playlist_url = "http://www.youtube.com/watch_videos?video_ids=";
return [cljs.core.str.cljs$core$IFn$_invoke$arity$1(playlist_url),cljs.core.str.cljs$core$IFn$_invoke$arity$1(clojure.string.join.cljs$core$IFn$_invoke$arity$2(",",ids))].join('');
});
chromex_sample.background.core.open_playlist = (function chromex_sample$background$core$open_playlist(playlist_url){
return chromex.ext.tabs.create_STAR_(chromex.config.get_active_config(),cljs.core.clj__GT_js(new cljs.core.PersistentArrayMap(null, 1, [cljs.core.cst$kw$url,playlist_url], null)));
});
chromex_sample.background.core.build_youtube_playlist = (function chromex_sample$background$core$build_youtube_playlist(){
var res = chromex.ext.tabs.query_STAR_(chromex.config.get_active_config(),cljs.core.clj__GT_js(new cljs.core.PersistentArrayMap(null, 1, [cljs.core.cst$kw$currentWindow,true], null)));
var c__7992__auto__ = cljs.core.async.chan.cljs$core$IFn$_invoke$arity$1((1));
cljs.core.async.impl.dispatch.run(((function (c__7992__auto__,res){
return (function (){
var f__7993__auto__ = (function (){var switch__7885__auto__ = ((function (c__7992__auto__,res){
return (function (state_15101){
var state_val_15102 = (state_15101[(1)]);
if((state_val_15102 === (1))){
var state_15101__$1 = state_15101;
return cljs.core.async.impl.ioc_helpers.take_BANG_(state_15101__$1,(2),res);
} else {
if((state_val_15102 === (2))){
var inst_15091 = (state_15101[(2)]);
var inst_15092 = cljs.core.js__GT_clj.cljs$core$IFn$_invoke$arity$variadic(inst_15091,cljs.core.prim_seq.cljs$core$IFn$_invoke$arity$2([cljs.core.cst$kw$keywordize_DASH_keys,true], 0));
var inst_15093 = cljs.core.first(inst_15092);
var inst_15094 = cljs.core.filter.cljs$core$IFn$_invoke$arity$2(chromex_sample.background.core.select_youtube_links,inst_15093);
var inst_15095 = cljs.core.map.cljs$core$IFn$_invoke$arity$2(cljs.core.cst$kw$url,inst_15094);
var inst_15096 = chromex_sample.background.core.prepare_playlist(inst_15095);
var inst_15097 = chromex_sample.background.core.open_playlist(inst_15096);
var inst_15098 = cljs.core.map.cljs$core$IFn$_invoke$arity$2(cljs.core.cst$kw$id,inst_15094);
var inst_15099 = chromex_sample.background.core.close_youtube_tabs(inst_15098);
var state_15101__$1 = (function (){var statearr_15103 = state_15101;
(statearr_15103[(7)] = inst_15097);

return statearr_15103;
})();
return cljs.core.async.impl.ioc_helpers.return_chan(state_15101__$1,inst_15099);
} else {
return null;
}
}
});})(c__7992__auto__,res))
;
return ((function (switch__7885__auto__,c__7992__auto__,res){
return (function() {
var chromex_sample$background$core$build_youtube_playlist_$_state_machine__7886__auto__ = null;
var chromex_sample$background$core$build_youtube_playlist_$_state_machine__7886__auto____0 = (function (){
var statearr_15104 = [null,null,null,null,null,null,null,null];
(statearr_15104[(0)] = chromex_sample$background$core$build_youtube_playlist_$_state_machine__7886__auto__);

(statearr_15104[(1)] = (1));

return statearr_15104;
});
var chromex_sample$background$core$build_youtube_playlist_$_state_machine__7886__auto____1 = (function (state_15101){
while(true){
var ret_value__7887__auto__ = (function (){try{while(true){
var result__7888__auto__ = switch__7885__auto__(state_15101);
if(cljs.core.keyword_identical_QMARK_(result__7888__auto__,cljs.core.cst$kw$recur)){
continue;
} else {
return result__7888__auto__;
}
break;
}
}catch (e15105){if((e15105 instanceof Object)){
var ex__7889__auto__ = e15105;
var statearr_15106_15108 = state_15101;
(statearr_15106_15108[(5)] = ex__7889__auto__);


cljs.core.async.impl.ioc_helpers.process_exception(state_15101);

return cljs.core.cst$kw$recur;
} else {
throw e15105;

}
}})();
if(cljs.core.keyword_identical_QMARK_(ret_value__7887__auto__,cljs.core.cst$kw$recur)){
var G__15109 = state_15101;
state_15101 = G__15109;
continue;
} else {
return ret_value__7887__auto__;
}
break;
}
});
chromex_sample$background$core$build_youtube_playlist_$_state_machine__7886__auto__ = function(state_15101){
switch(arguments.length){
case 0:
return chromex_sample$background$core$build_youtube_playlist_$_state_machine__7886__auto____0.call(this);
case 1:
return chromex_sample$background$core$build_youtube_playlist_$_state_machine__7886__auto____1.call(this,state_15101);
}
throw(new Error('Invalid arity: ' + arguments.length));
};
chromex_sample$background$core$build_youtube_playlist_$_state_machine__7886__auto__.cljs$core$IFn$_invoke$arity$0 = chromex_sample$background$core$build_youtube_playlist_$_state_machine__7886__auto____0;
chromex_sample$background$core$build_youtube_playlist_$_state_machine__7886__auto__.cljs$core$IFn$_invoke$arity$1 = chromex_sample$background$core$build_youtube_playlist_$_state_machine__7886__auto____1;
return chromex_sample$background$core$build_youtube_playlist_$_state_machine__7886__auto__;
})()
;})(switch__7885__auto__,c__7992__auto__,res))
})();
var state__7994__auto__ = (function (){var statearr_15107 = (f__7993__auto__.cljs$core$IFn$_invoke$arity$0 ? f__7993__auto__.cljs$core$IFn$_invoke$arity$0() : f__7993__auto__.call(null));
(statearr_15107[(6)] = c__7992__auto__);

return statearr_15107;
})();
return cljs.core.async.impl.ioc_helpers.run_state_machine_wrapped(state__7994__auto__);
});})(c__7992__auto__,res))
);

return c__7992__auto__;
});
chromex_sample.background.core.process_chrome_event = (function chromex_sample$background$core$process_chrome_event(event_num,event){
console.log(goog.string.format("BACKGROUND: got chrome event (%05d)",event_num),event);


var vec__15110 = event;
var event_id = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(vec__15110,(0),null);
var event_args = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(vec__15110,(1),null);
var G__15113 = event_id;
var G__15113__$1 = (((G__15113 instanceof cljs.core.Keyword))?G__15113.fqn:null);
switch (G__15113__$1) {
case "chromex.ext.runtime/on-connect":
return cljs.core.apply.cljs$core$IFn$_invoke$arity$2(chromex_sample.background.core.handle_client_connection_BANG_,event_args);

break;
case "chromex.ext.tabs/on-created":
return chromex_sample.background.core.tell_clients_about_new_tab_BANG_();

break;
case "chromex.ext.browser-action/on-clicked":
return chromex_sample.background.core.build_youtube_playlist();

break;
default:
return null;

}
});
chromex_sample.background.core.run_chrome_event_loop_BANG_ = (function chromex_sample$background$core$run_chrome_event_loop_BANG_(chrome_event_channel){
console.log("BACKGROUND: starting main event loop...");


var c__7992__auto__ = cljs.core.async.chan.cljs$core$IFn$_invoke$arity$1((1));
cljs.core.async.impl.dispatch.run(((function (c__7992__auto__){
return (function (){
var f__7993__auto__ = (function (){var switch__7885__auto__ = ((function (c__7992__auto__){
return (function (state_15131){
var state_val_15132 = (state_15131[(1)]);
if((state_val_15132 === (1))){
var inst_15115 = (1);
var state_15131__$1 = (function (){var statearr_15133 = state_15131;
(statearr_15133[(7)] = inst_15115);

return statearr_15133;
})();
var statearr_15134_15147 = state_15131__$1;
(statearr_15134_15147[(2)] = null);

(statearr_15134_15147[(1)] = (2));


return cljs.core.cst$kw$recur;
} else {
if((state_val_15132 === (2))){
var state_15131__$1 = state_15131;
return cljs.core.async.impl.ioc_helpers.take_BANG_(state_15131__$1,(4),chrome_event_channel);
} else {
if((state_val_15132 === (3))){
var inst_15129 = (state_15131[(2)]);
var state_15131__$1 = state_15131;
return cljs.core.async.impl.ioc_helpers.return_chan(state_15131__$1,inst_15129);
} else {
if((state_val_15132 === (4))){
var inst_15118 = (state_15131[(8)]);
var inst_15118__$1 = (state_15131[(2)]);
var inst_15119 = (inst_15118__$1 == null);
var state_15131__$1 = (function (){var statearr_15135 = state_15131;
(statearr_15135[(8)] = inst_15118__$1);

return statearr_15135;
})();
if(cljs.core.truth_(inst_15119)){
var statearr_15136_15148 = state_15131__$1;
(statearr_15136_15148[(1)] = (5));

} else {
var statearr_15137_15149 = state_15131__$1;
(statearr_15137_15149[(1)] = (6));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_15132 === (5))){
var state_15131__$1 = state_15131;
var statearr_15138_15150 = state_15131__$1;
(statearr_15138_15150[(2)] = null);

(statearr_15138_15150[(1)] = (7));


return cljs.core.cst$kw$recur;
} else {
if((state_val_15132 === (6))){
var inst_15118 = (state_15131[(8)]);
var inst_15115 = (state_15131[(7)]);
var inst_15122 = chromex_sample.background.core.process_chrome_event(inst_15115,inst_15118);
var inst_15123 = (inst_15115 + (1));
var inst_15115__$1 = inst_15123;
var state_15131__$1 = (function (){var statearr_15139 = state_15131;
(statearr_15139[(9)] = inst_15122);

(statearr_15139[(7)] = inst_15115__$1);

return statearr_15139;
})();
var statearr_15140_15151 = state_15131__$1;
(statearr_15140_15151[(2)] = null);

(statearr_15140_15151[(1)] = (2));


return cljs.core.cst$kw$recur;
} else {
if((state_val_15132 === (7))){
var inst_15126 = (state_15131[(2)]);
var inst_15127 = console.log("BACKGROUND: leaving main event loop");
var state_15131__$1 = (function (){var statearr_15141 = state_15131;
(statearr_15141[(10)] = inst_15127);

(statearr_15141[(11)] = inst_15126);

return statearr_15141;
})();
var statearr_15142_15152 = state_15131__$1;
(statearr_15142_15152[(2)] = null);

(statearr_15142_15152[(1)] = (3));


return cljs.core.cst$kw$recur;
} else {
return null;
}
}
}
}
}
}
}
});})(c__7992__auto__))
;
return ((function (switch__7885__auto__,c__7992__auto__){
return (function() {
var chromex_sample$background$core$run_chrome_event_loop_BANG__$_state_machine__7886__auto__ = null;
var chromex_sample$background$core$run_chrome_event_loop_BANG__$_state_machine__7886__auto____0 = (function (){
var statearr_15143 = [null,null,null,null,null,null,null,null,null,null,null,null];
(statearr_15143[(0)] = chromex_sample$background$core$run_chrome_event_loop_BANG__$_state_machine__7886__auto__);

(statearr_15143[(1)] = (1));

return statearr_15143;
});
var chromex_sample$background$core$run_chrome_event_loop_BANG__$_state_machine__7886__auto____1 = (function (state_15131){
while(true){
var ret_value__7887__auto__ = (function (){try{while(true){
var result__7888__auto__ = switch__7885__auto__(state_15131);
if(cljs.core.keyword_identical_QMARK_(result__7888__auto__,cljs.core.cst$kw$recur)){
continue;
} else {
return result__7888__auto__;
}
break;
}
}catch (e15144){if((e15144 instanceof Object)){
var ex__7889__auto__ = e15144;
var statearr_15145_15153 = state_15131;
(statearr_15145_15153[(5)] = ex__7889__auto__);


cljs.core.async.impl.ioc_helpers.process_exception(state_15131);

return cljs.core.cst$kw$recur;
} else {
throw e15144;

}
}})();
if(cljs.core.keyword_identical_QMARK_(ret_value__7887__auto__,cljs.core.cst$kw$recur)){
var G__15154 = state_15131;
state_15131 = G__15154;
continue;
} else {
return ret_value__7887__auto__;
}
break;
}
});
chromex_sample$background$core$run_chrome_event_loop_BANG__$_state_machine__7886__auto__ = function(state_15131){
switch(arguments.length){
case 0:
return chromex_sample$background$core$run_chrome_event_loop_BANG__$_state_machine__7886__auto____0.call(this);
case 1:
return chromex_sample$background$core$run_chrome_event_loop_BANG__$_state_machine__7886__auto____1.call(this,state_15131);
}
throw(new Error('Invalid arity: ' + arguments.length));
};
chromex_sample$background$core$run_chrome_event_loop_BANG__$_state_machine__7886__auto__.cljs$core$IFn$_invoke$arity$0 = chromex_sample$background$core$run_chrome_event_loop_BANG__$_state_machine__7886__auto____0;
chromex_sample$background$core$run_chrome_event_loop_BANG__$_state_machine__7886__auto__.cljs$core$IFn$_invoke$arity$1 = chromex_sample$background$core$run_chrome_event_loop_BANG__$_state_machine__7886__auto____1;
return chromex_sample$background$core$run_chrome_event_loop_BANG__$_state_machine__7886__auto__;
})()
;})(switch__7885__auto__,c__7992__auto__))
})();
var state__7994__auto__ = (function (){var statearr_15146 = (f__7993__auto__.cljs$core$IFn$_invoke$arity$0 ? f__7993__auto__.cljs$core$IFn$_invoke$arity$0() : f__7993__auto__.call(null));
(statearr_15146[(6)] = c__7992__auto__);

return statearr_15146;
})();
return cljs.core.async.impl.ioc_helpers.run_state_machine_wrapped(state__7994__auto__);
});})(c__7992__auto__))
);

return c__7992__auto__;
});
chromex_sample.background.core.boot_chrome_event_loop_BANG_ = (function chromex_sample$background$core$boot_chrome_event_loop_BANG_(){
var chrome_event_channel = chromex.chrome_event_channel.make_chrome_event_channel(cljs.core.async.chan.cljs$core$IFn$_invoke$arity$0());
var chan15155_15159 = chrome_event_channel;
var config15156_15160 = chromex.config.get_active_config();
chromex.ext.tabs.on_created_STAR_(config15156_15160,chan15155_15159);

chromex.ext.tabs.on_updated_STAR_(config15156_15160,chan15155_15159);

chromex.ext.tabs.on_moved_STAR_(config15156_15160,chan15155_15159);

chromex.ext.tabs.on_activated_STAR_(config15156_15160,chan15155_15159);

chromex.ext.tabs.on_highlighted_STAR_(config15156_15160,chan15155_15159);

chromex.ext.tabs.on_detached_STAR_(config15156_15160,chan15155_15159);

chromex.ext.tabs.on_attached_STAR_(config15156_15160,chan15155_15159);

chromex.ext.tabs.on_removed_STAR_(config15156_15160,chan15155_15159);

chromex.ext.tabs.on_replaced_STAR_(config15156_15160,chan15155_15159);

chromex.ext.tabs.on_zoom_change_STAR_(config15156_15160,chan15155_15159);

var chan15157_15161 = chrome_event_channel;
var config15158_15162 = chromex.config.get_active_config();
chromex.ext.runtime.on_startup_STAR_(config15158_15162,chan15157_15161);

chromex.ext.runtime.on_installed_STAR_(config15158_15162,chan15157_15161);

chromex.ext.runtime.on_suspend_STAR_(config15158_15162,chan15157_15161);

chromex.ext.runtime.on_suspend_canceled_STAR_(config15158_15162,chan15157_15161);

chromex.ext.runtime.on_update_available_STAR_(config15158_15162,chan15157_15161);

chromex.ext.runtime.on_connect_STAR_(config15158_15162,chan15157_15161);

chromex.ext.runtime.on_connect_external_STAR_(config15158_15162,chan15157_15161);

chromex.ext.runtime.on_message_STAR_(config15158_15162,chan15157_15161);

chromex.ext.runtime.on_message_external_STAR_(config15158_15162,chan15157_15161);

chromex.ext.runtime.on_restart_required_STAR_(config15158_15162,chan15157_15161);

chromex.ext.browser_action.on_clicked_STAR_(chromex.config.get_active_config(),chrome_event_channel);

return chromex_sample.background.core.run_chrome_event_loop_BANG_(chrome_event_channel);
});
chromex_sample.background.core.init_BANG_ = (function chromex_sample$background$core$init_BANG_(){
console.log("BACKGROUND: init");


chromex_sample.background.storage.test_storage_BANG_();

return chromex_sample.background.core.boot_chrome_event_loop_BANG_();
});
