// Compiled by ClojureScript 1.10.439 {:static-fns true, :optimize-constants true, :elide-asserts true}
goog.provide('chromex.ext.tabs');
goog.require('cljs.core');
goog.require('cljs.core.constants');
goog.require('chromex.core');
chromex.ext.tabs.tab_id_none_STAR_ = (function chromex$ext$tabs$tab_id_none_STAR_(config){
var result_14029 = (function (){var final_args_array_14030 = chromex.support.prepare_final_args_array(cljs.core.PersistentVector.EMPTY,"chrome.tabs.TAB_ID_NONE");
var ns_14031 = (function (){var target_obj_14033 = cljs.core.cst$kw$root.cljs$core$IFn$_invoke$arity$1(config);
var next_obj_14034 = (target_obj_14033["chrome"]);
var next_obj_14035 = (next_obj_14034["tabs"]);
return next_obj_14035;
})();


var target_14032 = (function (){var target_obj_14036 = ns_14031;
var next_obj_14037 = (target_obj_14036["TAB_ID_NONE"]);
if((!((next_obj_14037 == null)))){
return next_obj_14037;
} else {
return null;
}
})();
return target_14032;
})();
return result_14029;
});
chromex.ext.tabs.get_STAR_ = (function chromex$ext$tabs$get_STAR_(config,tab_id){
var callback_chan_14038 = (function (){var config__6143__auto__ = config;
var handler_key__6144__auto__ = cljs.core.cst$kw$callback_DASH_channel_DASH_factory;
var handler__6145__auto__ = handler_key__6144__auto__.cljs$core$IFn$_invoke$arity$1(config__6143__auto__);

return (handler__6145__auto__.cljs$core$IFn$_invoke$arity$1 ? handler__6145__auto__.cljs$core$IFn$_invoke$arity$1(config__6143__auto__) : handler__6145__auto__.call(null,config__6143__auto__));
})();
var marshalled_tab_id_14040_14059 = (function (){var omit_test_14045 = tab_id;
if(cljs.core.keyword_identical_QMARK_(omit_test_14045,cljs.core.cst$kw$omit)){
return cljs.core.cst$kw$omit;
} else {
return omit_test_14045;
}
})();
var marshalled_callback_14041_14060 = ((function (marshalled_tab_id_14040_14059,callback_chan_14038){
return (function (cb_tab_14046){
var fexpr__14050 = (function (){var config__6143__auto__ = config;
var handler_key__6144__auto__ = cljs.core.cst$kw$callback_DASH_fn_DASH_factory;
var handler__6145__auto__ = handler_key__6144__auto__.cljs$core$IFn$_invoke$arity$1(config__6143__auto__);

var G__14051 = config__6143__auto__;
var G__14052 = new cljs.core.PersistentArrayMap(null, 5, [cljs.core.cst$kw$id,cljs.core.cst$kw$chromex$ext$tabs_SLASH_get,cljs.core.cst$kw$name,"get",cljs.core.cst$kw$callback_QMARK_,true,cljs.core.cst$kw$params,new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentArrayMap(null, 2, [cljs.core.cst$kw$name,"tab-id",cljs.core.cst$kw$type,"integer"], null),new cljs.core.PersistentArrayMap(null, 3, [cljs.core.cst$kw$name,"callback",cljs.core.cst$kw$type,cljs.core.cst$kw$callback,cljs.core.cst$kw$callback,new cljs.core.PersistentArrayMap(null, 1, [cljs.core.cst$kw$params,new cljs.core.PersistentVector(null, 1, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentArrayMap(null, 2, [cljs.core.cst$kw$name,"tab",cljs.core.cst$kw$type,"tabs.Tab"], null)], null)], null)], null)], null),cljs.core.cst$kw$function_QMARK_,true], null);
var G__14053 = callback_chan_14038;
return (handler__6145__auto__.cljs$core$IFn$_invoke$arity$3 ? handler__6145__auto__.cljs$core$IFn$_invoke$arity$3(G__14051,G__14052,G__14053) : handler__6145__auto__.call(null,G__14051,G__14052,G__14053));
})();
return (fexpr__14050.cljs$core$IFn$_invoke$arity$1 ? fexpr__14050.cljs$core$IFn$_invoke$arity$1(cb_tab_14046) : fexpr__14050.call(null,cb_tab_14046));
});})(marshalled_tab_id_14040_14059,callback_chan_14038))
;
var result_14039_14061 = (function (){var final_args_array_14042 = chromex.support.prepare_final_args_array(new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_tab_id_14040_14059,"tab-id",null], null),new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_callback_14041_14060,"callback",null], null)], null),"chrome.tabs.get");
var ns_14043 = (function (){var target_obj_14054 = cljs.core.cst$kw$root.cljs$core$IFn$_invoke$arity$1(config);
var next_obj_14055 = (target_obj_14054["chrome"]);
var next_obj_14056 = (next_obj_14055["tabs"]);
return next_obj_14056;
})();
var config__6181__auto___14062 = config;
var api_check_fn__6182__auto___14063 = cljs.core.cst$kw$missing_DASH_api_DASH_check_DASH_fn.cljs$core$IFn$_invoke$arity$1(config__6181__auto___14062);

(api_check_fn__6182__auto___14063.cljs$core$IFn$_invoke$arity$3 ? api_check_fn__6182__auto___14063.cljs$core$IFn$_invoke$arity$3("chrome.tabs.get",ns_14043,"get") : api_check_fn__6182__auto___14063.call(null,"chrome.tabs.get",ns_14043,"get"));


var target_14044 = (function (){var target_obj_14057 = ns_14043;
var next_obj_14058 = (target_obj_14057["get"]);
if((!((next_obj_14058 == null)))){
return next_obj_14058;
} else {
return null;
}
})();
return target_14044.apply(ns_14043,final_args_array_14042);
})();

return callback_chan_14038;
});
chromex.ext.tabs.get_current_STAR_ = (function chromex$ext$tabs$get_current_STAR_(config){
var callback_chan_14064 = (function (){var config__6143__auto__ = config;
var handler_key__6144__auto__ = cljs.core.cst$kw$callback_DASH_channel_DASH_factory;
var handler__6145__auto__ = handler_key__6144__auto__.cljs$core$IFn$_invoke$arity$1(config__6143__auto__);

return (handler__6145__auto__.cljs$core$IFn$_invoke$arity$1 ? handler__6145__auto__.cljs$core$IFn$_invoke$arity$1(config__6143__auto__) : handler__6145__auto__.call(null,config__6143__auto__));
})();
var marshalled_callback_14066_14083 = ((function (callback_chan_14064){
return (function (cb_tab_14070){
var fexpr__14074 = (function (){var config__6143__auto__ = config;
var handler_key__6144__auto__ = cljs.core.cst$kw$callback_DASH_fn_DASH_factory;
var handler__6145__auto__ = handler_key__6144__auto__.cljs$core$IFn$_invoke$arity$1(config__6143__auto__);

var G__14075 = config__6143__auto__;
var G__14076 = new cljs.core.PersistentArrayMap(null, 5, [cljs.core.cst$kw$id,cljs.core.cst$kw$chromex$ext$tabs_SLASH_get_DASH_current,cljs.core.cst$kw$name,"getCurrent",cljs.core.cst$kw$callback_QMARK_,true,cljs.core.cst$kw$params,new cljs.core.PersistentVector(null, 1, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentArrayMap(null, 3, [cljs.core.cst$kw$name,"callback",cljs.core.cst$kw$type,cljs.core.cst$kw$callback,cljs.core.cst$kw$callback,new cljs.core.PersistentArrayMap(null, 1, [cljs.core.cst$kw$params,new cljs.core.PersistentVector(null, 1, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentArrayMap(null, 3, [cljs.core.cst$kw$name,"tab",cljs.core.cst$kw$optional_QMARK_,true,cljs.core.cst$kw$type,"tabs.Tab"], null)], null)], null)], null)], null),cljs.core.cst$kw$function_QMARK_,true], null);
var G__14077 = callback_chan_14064;
return (handler__6145__auto__.cljs$core$IFn$_invoke$arity$3 ? handler__6145__auto__.cljs$core$IFn$_invoke$arity$3(G__14075,G__14076,G__14077) : handler__6145__auto__.call(null,G__14075,G__14076,G__14077));
})();
return (fexpr__14074.cljs$core$IFn$_invoke$arity$1 ? fexpr__14074.cljs$core$IFn$_invoke$arity$1(cb_tab_14070) : fexpr__14074.call(null,cb_tab_14070));
});})(callback_chan_14064))
;
var result_14065_14084 = (function (){var final_args_array_14067 = chromex.support.prepare_final_args_array(new cljs.core.PersistentVector(null, 1, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_callback_14066_14083,"callback",null], null)], null),"chrome.tabs.getCurrent");
var ns_14068 = (function (){var target_obj_14078 = cljs.core.cst$kw$root.cljs$core$IFn$_invoke$arity$1(config);
var next_obj_14079 = (target_obj_14078["chrome"]);
var next_obj_14080 = (next_obj_14079["tabs"]);
return next_obj_14080;
})();
var config__6181__auto___14085 = config;
var api_check_fn__6182__auto___14086 = cljs.core.cst$kw$missing_DASH_api_DASH_check_DASH_fn.cljs$core$IFn$_invoke$arity$1(config__6181__auto___14085);

(api_check_fn__6182__auto___14086.cljs$core$IFn$_invoke$arity$3 ? api_check_fn__6182__auto___14086.cljs$core$IFn$_invoke$arity$3("chrome.tabs.getCurrent",ns_14068,"getCurrent") : api_check_fn__6182__auto___14086.call(null,"chrome.tabs.getCurrent",ns_14068,"getCurrent"));


var target_14069 = (function (){var target_obj_14081 = ns_14068;
var next_obj_14082 = (target_obj_14081["getCurrent"]);
if((!((next_obj_14082 == null)))){
return next_obj_14082;
} else {
return null;
}
})();
return target_14069.apply(ns_14068,final_args_array_14067);
})();

return callback_chan_14064;
});
chromex.ext.tabs.connect_STAR_ = (function chromex$ext$tabs$connect_STAR_(config,tab_id,connect_info){
var marshalled_tab_id_14088 = (function (){var omit_test_14093 = tab_id;
if(cljs.core.keyword_identical_QMARK_(omit_test_14093,cljs.core.cst$kw$omit)){
return cljs.core.cst$kw$omit;
} else {
return omit_test_14093;
}
})();
var marshalled_connect_info_14089 = (function (){var omit_test_14094 = connect_info;
if(cljs.core.keyword_identical_QMARK_(omit_test_14094,cljs.core.cst$kw$omit)){
return cljs.core.cst$kw$omit;
} else {
return omit_test_14094;
}
})();
var result_14087 = (function (){var final_args_array_14090 = chromex.support.prepare_final_args_array(new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_tab_id_14088,"tab-id",null], null),new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_connect_info_14089,"connect-info",true], null)], null),"chrome.tabs.connect");
var ns_14091 = (function (){var target_obj_14095 = cljs.core.cst$kw$root.cljs$core$IFn$_invoke$arity$1(config);
var next_obj_14096 = (target_obj_14095["chrome"]);
var next_obj_14097 = (next_obj_14096["tabs"]);
return next_obj_14097;
})();
var config__6181__auto___14100 = config;
var api_check_fn__6182__auto___14101 = cljs.core.cst$kw$missing_DASH_api_DASH_check_DASH_fn.cljs$core$IFn$_invoke$arity$1(config__6181__auto___14100);

(api_check_fn__6182__auto___14101.cljs$core$IFn$_invoke$arity$3 ? api_check_fn__6182__auto___14101.cljs$core$IFn$_invoke$arity$3("chrome.tabs.connect",ns_14091,"connect") : api_check_fn__6182__auto___14101.call(null,"chrome.tabs.connect",ns_14091,"connect"));


var target_14092 = (function (){var target_obj_14098 = ns_14091;
var next_obj_14099 = (target_obj_14098["connect"]);
if((!((next_obj_14099 == null)))){
return next_obj_14099;
} else {
return null;
}
})();
return target_14092.apply(ns_14091,final_args_array_14090);
})();
return chromex.marshalling.from_native_chrome_port(config,result_14087);
});
chromex.ext.tabs.send_request_STAR_ = (function chromex$ext$tabs$send_request_STAR_(config,tab_id,request){
var callback_chan_14102 = (function (){var config__6143__auto__ = config;
var handler_key__6144__auto__ = cljs.core.cst$kw$callback_DASH_channel_DASH_factory;
var handler__6145__auto__ = handler_key__6144__auto__.cljs$core$IFn$_invoke$arity$1(config__6143__auto__);

return (handler__6145__auto__.cljs$core$IFn$_invoke$arity$1 ? handler__6145__auto__.cljs$core$IFn$_invoke$arity$1(config__6143__auto__) : handler__6145__auto__.call(null,config__6143__auto__));
})();
var marshalled_tab_id_14104_14125 = (function (){var omit_test_14110 = tab_id;
if(cljs.core.keyword_identical_QMARK_(omit_test_14110,cljs.core.cst$kw$omit)){
return cljs.core.cst$kw$omit;
} else {
return omit_test_14110;
}
})();
var marshalled_request_14105_14126 = (function (){var omit_test_14111 = request;
if(cljs.core.keyword_identical_QMARK_(omit_test_14111,cljs.core.cst$kw$omit)){
return cljs.core.cst$kw$omit;
} else {
return omit_test_14111;
}
})();
var marshalled_response_callback_14106_14127 = ((function (marshalled_tab_id_14104_14125,marshalled_request_14105_14126,callback_chan_14102){
return (function (cb_response_14112){
var fexpr__14116 = (function (){var config__6143__auto__ = config;
var handler_key__6144__auto__ = cljs.core.cst$kw$callback_DASH_fn_DASH_factory;
var handler__6145__auto__ = handler_key__6144__auto__.cljs$core$IFn$_invoke$arity$1(config__6143__auto__);

var G__14117 = config__6143__auto__;
var G__14118 = new cljs.core.PersistentArrayMap(null, 7, [cljs.core.cst$kw$id,cljs.core.cst$kw$chromex$ext$tabs_SLASH_send_DASH_request,cljs.core.cst$kw$name,"sendRequest",cljs.core.cst$kw$since,"33",cljs.core.cst$kw$deprecated,"Please use 'runtime.sendMessage'.",cljs.core.cst$kw$callback_QMARK_,true,cljs.core.cst$kw$params,new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentArrayMap(null, 2, [cljs.core.cst$kw$name,"tab-id",cljs.core.cst$kw$type,"integer"], null),new cljs.core.PersistentArrayMap(null, 2, [cljs.core.cst$kw$name,"request",cljs.core.cst$kw$type,"any"], null),new cljs.core.PersistentArrayMap(null, 4, [cljs.core.cst$kw$name,"response-callback",cljs.core.cst$kw$optional_QMARK_,true,cljs.core.cst$kw$type,cljs.core.cst$kw$callback,cljs.core.cst$kw$callback,new cljs.core.PersistentArrayMap(null, 1, [cljs.core.cst$kw$params,new cljs.core.PersistentVector(null, 1, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentArrayMap(null, 2, [cljs.core.cst$kw$name,"response",cljs.core.cst$kw$type,"any"], null)], null)], null)], null)], null),cljs.core.cst$kw$function_QMARK_,true], null);
var G__14119 = callback_chan_14102;
return (handler__6145__auto__.cljs$core$IFn$_invoke$arity$3 ? handler__6145__auto__.cljs$core$IFn$_invoke$arity$3(G__14117,G__14118,G__14119) : handler__6145__auto__.call(null,G__14117,G__14118,G__14119));
})();
return (fexpr__14116.cljs$core$IFn$_invoke$arity$1 ? fexpr__14116.cljs$core$IFn$_invoke$arity$1(cb_response_14112) : fexpr__14116.call(null,cb_response_14112));
});})(marshalled_tab_id_14104_14125,marshalled_request_14105_14126,callback_chan_14102))
;
var result_14103_14128 = (function (){var final_args_array_14107 = chromex.support.prepare_final_args_array(new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_tab_id_14104_14125,"tab-id",null], null),new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_request_14105_14126,"request",null], null),new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_response_callback_14106_14127,"response-callback",true], null)], null),"chrome.tabs.sendRequest");
var ns_14108 = (function (){var target_obj_14120 = cljs.core.cst$kw$root.cljs$core$IFn$_invoke$arity$1(config);
var next_obj_14121 = (target_obj_14120["chrome"]);
var next_obj_14122 = (next_obj_14121["tabs"]);
return next_obj_14122;
})();
var config__6181__auto___14129 = config;
var api_check_fn__6182__auto___14130 = cljs.core.cst$kw$missing_DASH_api_DASH_check_DASH_fn.cljs$core$IFn$_invoke$arity$1(config__6181__auto___14129);

(api_check_fn__6182__auto___14130.cljs$core$IFn$_invoke$arity$3 ? api_check_fn__6182__auto___14130.cljs$core$IFn$_invoke$arity$3("chrome.tabs.sendRequest",ns_14108,"sendRequest") : api_check_fn__6182__auto___14130.call(null,"chrome.tabs.sendRequest",ns_14108,"sendRequest"));


var target_14109 = (function (){var target_obj_14123 = ns_14108;
var next_obj_14124 = (target_obj_14123["sendRequest"]);
if((!((next_obj_14124 == null)))){
return next_obj_14124;
} else {
return null;
}
})();
return target_14109.apply(ns_14108,final_args_array_14107);
})();

return callback_chan_14102;
});
chromex.ext.tabs.send_message_STAR_ = (function chromex$ext$tabs$send_message_STAR_(config,tab_id,message,options){
var callback_chan_14131 = (function (){var config__6143__auto__ = config;
var handler_key__6144__auto__ = cljs.core.cst$kw$callback_DASH_channel_DASH_factory;
var handler__6145__auto__ = handler_key__6144__auto__.cljs$core$IFn$_invoke$arity$1(config__6143__auto__);

return (handler__6145__auto__.cljs$core$IFn$_invoke$arity$1 ? handler__6145__auto__.cljs$core$IFn$_invoke$arity$1(config__6143__auto__) : handler__6145__auto__.call(null,config__6143__auto__));
})();
var marshalled_tab_id_14133_14156 = (function (){var omit_test_14140 = tab_id;
if(cljs.core.keyword_identical_QMARK_(omit_test_14140,cljs.core.cst$kw$omit)){
return cljs.core.cst$kw$omit;
} else {
return omit_test_14140;
}
})();
var marshalled_message_14134_14157 = (function (){var omit_test_14141 = message;
if(cljs.core.keyword_identical_QMARK_(omit_test_14141,cljs.core.cst$kw$omit)){
return cljs.core.cst$kw$omit;
} else {
return omit_test_14141;
}
})();
var marshalled_options_14135_14158 = (function (){var omit_test_14142 = options;
if(cljs.core.keyword_identical_QMARK_(omit_test_14142,cljs.core.cst$kw$omit)){
return cljs.core.cst$kw$omit;
} else {
return omit_test_14142;
}
})();
var marshalled_response_callback_14136_14159 = ((function (marshalled_tab_id_14133_14156,marshalled_message_14134_14157,marshalled_options_14135_14158,callback_chan_14131){
return (function (cb_response_14143){
var fexpr__14147 = (function (){var config__6143__auto__ = config;
var handler_key__6144__auto__ = cljs.core.cst$kw$callback_DASH_fn_DASH_factory;
var handler__6145__auto__ = handler_key__6144__auto__.cljs$core$IFn$_invoke$arity$1(config__6143__auto__);

var G__14148 = config__6143__auto__;
var G__14149 = new cljs.core.PersistentArrayMap(null, 5, [cljs.core.cst$kw$id,cljs.core.cst$kw$chromex$ext$tabs_SLASH_send_DASH_message,cljs.core.cst$kw$name,"sendMessage",cljs.core.cst$kw$callback_QMARK_,true,cljs.core.cst$kw$params,new cljs.core.PersistentVector(null, 4, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentArrayMap(null, 2, [cljs.core.cst$kw$name,"tab-id",cljs.core.cst$kw$type,"integer"], null),new cljs.core.PersistentArrayMap(null, 2, [cljs.core.cst$kw$name,"message",cljs.core.cst$kw$type,"any"], null),new cljs.core.PersistentArrayMap(null, 3, [cljs.core.cst$kw$name,"options",cljs.core.cst$kw$optional_QMARK_,true,cljs.core.cst$kw$type,"object"], null),new cljs.core.PersistentArrayMap(null, 4, [cljs.core.cst$kw$name,"response-callback",cljs.core.cst$kw$optional_QMARK_,true,cljs.core.cst$kw$type,cljs.core.cst$kw$callback,cljs.core.cst$kw$callback,new cljs.core.PersistentArrayMap(null, 1, [cljs.core.cst$kw$params,new cljs.core.PersistentVector(null, 1, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentArrayMap(null, 2, [cljs.core.cst$kw$name,"response",cljs.core.cst$kw$type,"any"], null)], null)], null)], null)], null),cljs.core.cst$kw$function_QMARK_,true], null);
var G__14150 = callback_chan_14131;
return (handler__6145__auto__.cljs$core$IFn$_invoke$arity$3 ? handler__6145__auto__.cljs$core$IFn$_invoke$arity$3(G__14148,G__14149,G__14150) : handler__6145__auto__.call(null,G__14148,G__14149,G__14150));
})();
return (fexpr__14147.cljs$core$IFn$_invoke$arity$1 ? fexpr__14147.cljs$core$IFn$_invoke$arity$1(cb_response_14143) : fexpr__14147.call(null,cb_response_14143));
});})(marshalled_tab_id_14133_14156,marshalled_message_14134_14157,marshalled_options_14135_14158,callback_chan_14131))
;
var result_14132_14160 = (function (){var final_args_array_14137 = chromex.support.prepare_final_args_array(new cljs.core.PersistentVector(null, 4, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_tab_id_14133_14156,"tab-id",null], null),new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_message_14134_14157,"message",null], null),new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_options_14135_14158,"options",true], null),new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_response_callback_14136_14159,"response-callback",true], null)], null),"chrome.tabs.sendMessage");
var ns_14138 = (function (){var target_obj_14151 = cljs.core.cst$kw$root.cljs$core$IFn$_invoke$arity$1(config);
var next_obj_14152 = (target_obj_14151["chrome"]);
var next_obj_14153 = (next_obj_14152["tabs"]);
return next_obj_14153;
})();
var config__6181__auto___14161 = config;
var api_check_fn__6182__auto___14162 = cljs.core.cst$kw$missing_DASH_api_DASH_check_DASH_fn.cljs$core$IFn$_invoke$arity$1(config__6181__auto___14161);

(api_check_fn__6182__auto___14162.cljs$core$IFn$_invoke$arity$3 ? api_check_fn__6182__auto___14162.cljs$core$IFn$_invoke$arity$3("chrome.tabs.sendMessage",ns_14138,"sendMessage") : api_check_fn__6182__auto___14162.call(null,"chrome.tabs.sendMessage",ns_14138,"sendMessage"));


var target_14139 = (function (){var target_obj_14154 = ns_14138;
var next_obj_14155 = (target_obj_14154["sendMessage"]);
if((!((next_obj_14155 == null)))){
return next_obj_14155;
} else {
return null;
}
})();
return target_14139.apply(ns_14138,final_args_array_14137);
})();

return callback_chan_14131;
});
chromex.ext.tabs.get_selected_STAR_ = (function chromex$ext$tabs$get_selected_STAR_(config,window_id){
var callback_chan_14163 = (function (){var config__6143__auto__ = config;
var handler_key__6144__auto__ = cljs.core.cst$kw$callback_DASH_channel_DASH_factory;
var handler__6145__auto__ = handler_key__6144__auto__.cljs$core$IFn$_invoke$arity$1(config__6143__auto__);

return (handler__6145__auto__.cljs$core$IFn$_invoke$arity$1 ? handler__6145__auto__.cljs$core$IFn$_invoke$arity$1(config__6143__auto__) : handler__6145__auto__.call(null,config__6143__auto__));
})();
var marshalled_window_id_14165_14184 = (function (){var omit_test_14170 = window_id;
if(cljs.core.keyword_identical_QMARK_(omit_test_14170,cljs.core.cst$kw$omit)){
return cljs.core.cst$kw$omit;
} else {
return omit_test_14170;
}
})();
var marshalled_callback_14166_14185 = ((function (marshalled_window_id_14165_14184,callback_chan_14163){
return (function (cb_tab_14171){
var fexpr__14175 = (function (){var config__6143__auto__ = config;
var handler_key__6144__auto__ = cljs.core.cst$kw$callback_DASH_fn_DASH_factory;
var handler__6145__auto__ = handler_key__6144__auto__.cljs$core$IFn$_invoke$arity$1(config__6143__auto__);

var G__14176 = config__6143__auto__;
var G__14177 = new cljs.core.PersistentArrayMap(null, 7, [cljs.core.cst$kw$id,cljs.core.cst$kw$chromex$ext$tabs_SLASH_get_DASH_selected,cljs.core.cst$kw$name,"getSelected",cljs.core.cst$kw$since,"33",cljs.core.cst$kw$deprecated,"Please use 'tabs.query' {active: true}.",cljs.core.cst$kw$callback_QMARK_,true,cljs.core.cst$kw$params,new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentArrayMap(null, 3, [cljs.core.cst$kw$name,"window-id",cljs.core.cst$kw$optional_QMARK_,true,cljs.core.cst$kw$type,"integer"], null),new cljs.core.PersistentArrayMap(null, 3, [cljs.core.cst$kw$name,"callback",cljs.core.cst$kw$type,cljs.core.cst$kw$callback,cljs.core.cst$kw$callback,new cljs.core.PersistentArrayMap(null, 1, [cljs.core.cst$kw$params,new cljs.core.PersistentVector(null, 1, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentArrayMap(null, 2, [cljs.core.cst$kw$name,"tab",cljs.core.cst$kw$type,"tabs.Tab"], null)], null)], null)], null)], null),cljs.core.cst$kw$function_QMARK_,true], null);
var G__14178 = callback_chan_14163;
return (handler__6145__auto__.cljs$core$IFn$_invoke$arity$3 ? handler__6145__auto__.cljs$core$IFn$_invoke$arity$3(G__14176,G__14177,G__14178) : handler__6145__auto__.call(null,G__14176,G__14177,G__14178));
})();
return (fexpr__14175.cljs$core$IFn$_invoke$arity$1 ? fexpr__14175.cljs$core$IFn$_invoke$arity$1(cb_tab_14171) : fexpr__14175.call(null,cb_tab_14171));
});})(marshalled_window_id_14165_14184,callback_chan_14163))
;
var result_14164_14186 = (function (){var final_args_array_14167 = chromex.support.prepare_final_args_array(new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_window_id_14165_14184,"window-id",true], null),new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_callback_14166_14185,"callback",null], null)], null),"chrome.tabs.getSelected");
var ns_14168 = (function (){var target_obj_14179 = cljs.core.cst$kw$root.cljs$core$IFn$_invoke$arity$1(config);
var next_obj_14180 = (target_obj_14179["chrome"]);
var next_obj_14181 = (next_obj_14180["tabs"]);
return next_obj_14181;
})();
var config__6181__auto___14187 = config;
var api_check_fn__6182__auto___14188 = cljs.core.cst$kw$missing_DASH_api_DASH_check_DASH_fn.cljs$core$IFn$_invoke$arity$1(config__6181__auto___14187);

(api_check_fn__6182__auto___14188.cljs$core$IFn$_invoke$arity$3 ? api_check_fn__6182__auto___14188.cljs$core$IFn$_invoke$arity$3("chrome.tabs.getSelected",ns_14168,"getSelected") : api_check_fn__6182__auto___14188.call(null,"chrome.tabs.getSelected",ns_14168,"getSelected"));


var target_14169 = (function (){var target_obj_14182 = ns_14168;
var next_obj_14183 = (target_obj_14182["getSelected"]);
if((!((next_obj_14183 == null)))){
return next_obj_14183;
} else {
return null;
}
})();
return target_14169.apply(ns_14168,final_args_array_14167);
})();

return callback_chan_14163;
});
chromex.ext.tabs.get_all_in_window_STAR_ = (function chromex$ext$tabs$get_all_in_window_STAR_(config,window_id){
var callback_chan_14189 = (function (){var config__6143__auto__ = config;
var handler_key__6144__auto__ = cljs.core.cst$kw$callback_DASH_channel_DASH_factory;
var handler__6145__auto__ = handler_key__6144__auto__.cljs$core$IFn$_invoke$arity$1(config__6143__auto__);

return (handler__6145__auto__.cljs$core$IFn$_invoke$arity$1 ? handler__6145__auto__.cljs$core$IFn$_invoke$arity$1(config__6143__auto__) : handler__6145__auto__.call(null,config__6143__auto__));
})();
var marshalled_window_id_14191_14210 = (function (){var omit_test_14196 = window_id;
if(cljs.core.keyword_identical_QMARK_(omit_test_14196,cljs.core.cst$kw$omit)){
return cljs.core.cst$kw$omit;
} else {
return omit_test_14196;
}
})();
var marshalled_callback_14192_14211 = ((function (marshalled_window_id_14191_14210,callback_chan_14189){
return (function (cb_tabs_14197){
var fexpr__14201 = (function (){var config__6143__auto__ = config;
var handler_key__6144__auto__ = cljs.core.cst$kw$callback_DASH_fn_DASH_factory;
var handler__6145__auto__ = handler_key__6144__auto__.cljs$core$IFn$_invoke$arity$1(config__6143__auto__);

var G__14202 = config__6143__auto__;
var G__14203 = new cljs.core.PersistentArrayMap(null, 7, [cljs.core.cst$kw$id,cljs.core.cst$kw$chromex$ext$tabs_SLASH_get_DASH_all_DASH_in_DASH_window,cljs.core.cst$kw$name,"getAllInWindow",cljs.core.cst$kw$since,"33",cljs.core.cst$kw$deprecated,"Please use 'tabs.query' {windowId: windowId}.",cljs.core.cst$kw$callback_QMARK_,true,cljs.core.cst$kw$params,new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentArrayMap(null, 3, [cljs.core.cst$kw$name,"window-id",cljs.core.cst$kw$optional_QMARK_,true,cljs.core.cst$kw$type,"integer"], null),new cljs.core.PersistentArrayMap(null, 3, [cljs.core.cst$kw$name,"callback",cljs.core.cst$kw$type,cljs.core.cst$kw$callback,cljs.core.cst$kw$callback,new cljs.core.PersistentArrayMap(null, 1, [cljs.core.cst$kw$params,new cljs.core.PersistentVector(null, 1, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentArrayMap(null, 2, [cljs.core.cst$kw$name,"tabs",cljs.core.cst$kw$type,"[array-of-tabs.Tabs]"], null)], null)], null)], null)], null),cljs.core.cst$kw$function_QMARK_,true], null);
var G__14204 = callback_chan_14189;
return (handler__6145__auto__.cljs$core$IFn$_invoke$arity$3 ? handler__6145__auto__.cljs$core$IFn$_invoke$arity$3(G__14202,G__14203,G__14204) : handler__6145__auto__.call(null,G__14202,G__14203,G__14204));
})();
return (fexpr__14201.cljs$core$IFn$_invoke$arity$1 ? fexpr__14201.cljs$core$IFn$_invoke$arity$1(cb_tabs_14197) : fexpr__14201.call(null,cb_tabs_14197));
});})(marshalled_window_id_14191_14210,callback_chan_14189))
;
var result_14190_14212 = (function (){var final_args_array_14193 = chromex.support.prepare_final_args_array(new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_window_id_14191_14210,"window-id",true], null),new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_callback_14192_14211,"callback",null], null)], null),"chrome.tabs.getAllInWindow");
var ns_14194 = (function (){var target_obj_14205 = cljs.core.cst$kw$root.cljs$core$IFn$_invoke$arity$1(config);
var next_obj_14206 = (target_obj_14205["chrome"]);
var next_obj_14207 = (next_obj_14206["tabs"]);
return next_obj_14207;
})();
var config__6181__auto___14213 = config;
var api_check_fn__6182__auto___14214 = cljs.core.cst$kw$missing_DASH_api_DASH_check_DASH_fn.cljs$core$IFn$_invoke$arity$1(config__6181__auto___14213);

(api_check_fn__6182__auto___14214.cljs$core$IFn$_invoke$arity$3 ? api_check_fn__6182__auto___14214.cljs$core$IFn$_invoke$arity$3("chrome.tabs.getAllInWindow",ns_14194,"getAllInWindow") : api_check_fn__6182__auto___14214.call(null,"chrome.tabs.getAllInWindow",ns_14194,"getAllInWindow"));


var target_14195 = (function (){var target_obj_14208 = ns_14194;
var next_obj_14209 = (target_obj_14208["getAllInWindow"]);
if((!((next_obj_14209 == null)))){
return next_obj_14209;
} else {
return null;
}
})();
return target_14195.apply(ns_14194,final_args_array_14193);
})();

return callback_chan_14189;
});
chromex.ext.tabs.create_STAR_ = (function chromex$ext$tabs$create_STAR_(config,create_properties){
var callback_chan_14215 = (function (){var config__6143__auto__ = config;
var handler_key__6144__auto__ = cljs.core.cst$kw$callback_DASH_channel_DASH_factory;
var handler__6145__auto__ = handler_key__6144__auto__.cljs$core$IFn$_invoke$arity$1(config__6143__auto__);

return (handler__6145__auto__.cljs$core$IFn$_invoke$arity$1 ? handler__6145__auto__.cljs$core$IFn$_invoke$arity$1(config__6143__auto__) : handler__6145__auto__.call(null,config__6143__auto__));
})();
var marshalled_create_properties_14217_14236 = (function (){var omit_test_14222 = create_properties;
if(cljs.core.keyword_identical_QMARK_(omit_test_14222,cljs.core.cst$kw$omit)){
return cljs.core.cst$kw$omit;
} else {
return omit_test_14222;
}
})();
var marshalled_callback_14218_14237 = ((function (marshalled_create_properties_14217_14236,callback_chan_14215){
return (function (cb_tab_14223){
var fexpr__14227 = (function (){var config__6143__auto__ = config;
var handler_key__6144__auto__ = cljs.core.cst$kw$callback_DASH_fn_DASH_factory;
var handler__6145__auto__ = handler_key__6144__auto__.cljs$core$IFn$_invoke$arity$1(config__6143__auto__);

var G__14228 = config__6143__auto__;
var G__14229 = new cljs.core.PersistentArrayMap(null, 5, [cljs.core.cst$kw$id,cljs.core.cst$kw$chromex$ext$tabs_SLASH_create,cljs.core.cst$kw$name,"create",cljs.core.cst$kw$callback_QMARK_,true,cljs.core.cst$kw$params,new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentArrayMap(null, 2, [cljs.core.cst$kw$name,"create-properties",cljs.core.cst$kw$type,"object"], null),new cljs.core.PersistentArrayMap(null, 4, [cljs.core.cst$kw$name,"callback",cljs.core.cst$kw$optional_QMARK_,true,cljs.core.cst$kw$type,cljs.core.cst$kw$callback,cljs.core.cst$kw$callback,new cljs.core.PersistentArrayMap(null, 1, [cljs.core.cst$kw$params,new cljs.core.PersistentVector(null, 1, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentArrayMap(null, 2, [cljs.core.cst$kw$name,"tab",cljs.core.cst$kw$type,"tabs.Tab"], null)], null)], null)], null)], null),cljs.core.cst$kw$function_QMARK_,true], null);
var G__14230 = callback_chan_14215;
return (handler__6145__auto__.cljs$core$IFn$_invoke$arity$3 ? handler__6145__auto__.cljs$core$IFn$_invoke$arity$3(G__14228,G__14229,G__14230) : handler__6145__auto__.call(null,G__14228,G__14229,G__14230));
})();
return (fexpr__14227.cljs$core$IFn$_invoke$arity$1 ? fexpr__14227.cljs$core$IFn$_invoke$arity$1(cb_tab_14223) : fexpr__14227.call(null,cb_tab_14223));
});})(marshalled_create_properties_14217_14236,callback_chan_14215))
;
var result_14216_14238 = (function (){var final_args_array_14219 = chromex.support.prepare_final_args_array(new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_create_properties_14217_14236,"create-properties",null], null),new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_callback_14218_14237,"callback",true], null)], null),"chrome.tabs.create");
var ns_14220 = (function (){var target_obj_14231 = cljs.core.cst$kw$root.cljs$core$IFn$_invoke$arity$1(config);
var next_obj_14232 = (target_obj_14231["chrome"]);
var next_obj_14233 = (next_obj_14232["tabs"]);
return next_obj_14233;
})();
var config__6181__auto___14239 = config;
var api_check_fn__6182__auto___14240 = cljs.core.cst$kw$missing_DASH_api_DASH_check_DASH_fn.cljs$core$IFn$_invoke$arity$1(config__6181__auto___14239);

(api_check_fn__6182__auto___14240.cljs$core$IFn$_invoke$arity$3 ? api_check_fn__6182__auto___14240.cljs$core$IFn$_invoke$arity$3("chrome.tabs.create",ns_14220,"create") : api_check_fn__6182__auto___14240.call(null,"chrome.tabs.create",ns_14220,"create"));


var target_14221 = (function (){var target_obj_14234 = ns_14220;
var next_obj_14235 = (target_obj_14234["create"]);
if((!((next_obj_14235 == null)))){
return next_obj_14235;
} else {
return null;
}
})();
return target_14221.apply(ns_14220,final_args_array_14219);
})();

return callback_chan_14215;
});
chromex.ext.tabs.duplicate_STAR_ = (function chromex$ext$tabs$duplicate_STAR_(config,tab_id){
var callback_chan_14241 = (function (){var config__6143__auto__ = config;
var handler_key__6144__auto__ = cljs.core.cst$kw$callback_DASH_channel_DASH_factory;
var handler__6145__auto__ = handler_key__6144__auto__.cljs$core$IFn$_invoke$arity$1(config__6143__auto__);

return (handler__6145__auto__.cljs$core$IFn$_invoke$arity$1 ? handler__6145__auto__.cljs$core$IFn$_invoke$arity$1(config__6143__auto__) : handler__6145__auto__.call(null,config__6143__auto__));
})();
var marshalled_tab_id_14243_14262 = (function (){var omit_test_14248 = tab_id;
if(cljs.core.keyword_identical_QMARK_(omit_test_14248,cljs.core.cst$kw$omit)){
return cljs.core.cst$kw$omit;
} else {
return omit_test_14248;
}
})();
var marshalled_callback_14244_14263 = ((function (marshalled_tab_id_14243_14262,callback_chan_14241){
return (function (cb_tab_14249){
var fexpr__14253 = (function (){var config__6143__auto__ = config;
var handler_key__6144__auto__ = cljs.core.cst$kw$callback_DASH_fn_DASH_factory;
var handler__6145__auto__ = handler_key__6144__auto__.cljs$core$IFn$_invoke$arity$1(config__6143__auto__);

var G__14254 = config__6143__auto__;
var G__14255 = new cljs.core.PersistentArrayMap(null, 5, [cljs.core.cst$kw$id,cljs.core.cst$kw$chromex$ext$tabs_SLASH_duplicate,cljs.core.cst$kw$name,"duplicate",cljs.core.cst$kw$callback_QMARK_,true,cljs.core.cst$kw$params,new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentArrayMap(null, 2, [cljs.core.cst$kw$name,"tab-id",cljs.core.cst$kw$type,"integer"], null),new cljs.core.PersistentArrayMap(null, 4, [cljs.core.cst$kw$name,"callback",cljs.core.cst$kw$optional_QMARK_,true,cljs.core.cst$kw$type,cljs.core.cst$kw$callback,cljs.core.cst$kw$callback,new cljs.core.PersistentArrayMap(null, 1, [cljs.core.cst$kw$params,new cljs.core.PersistentVector(null, 1, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentArrayMap(null, 3, [cljs.core.cst$kw$name,"tab",cljs.core.cst$kw$optional_QMARK_,true,cljs.core.cst$kw$type,"tabs.Tab"], null)], null)], null)], null)], null),cljs.core.cst$kw$function_QMARK_,true], null);
var G__14256 = callback_chan_14241;
return (handler__6145__auto__.cljs$core$IFn$_invoke$arity$3 ? handler__6145__auto__.cljs$core$IFn$_invoke$arity$3(G__14254,G__14255,G__14256) : handler__6145__auto__.call(null,G__14254,G__14255,G__14256));
})();
return (fexpr__14253.cljs$core$IFn$_invoke$arity$1 ? fexpr__14253.cljs$core$IFn$_invoke$arity$1(cb_tab_14249) : fexpr__14253.call(null,cb_tab_14249));
});})(marshalled_tab_id_14243_14262,callback_chan_14241))
;
var result_14242_14264 = (function (){var final_args_array_14245 = chromex.support.prepare_final_args_array(new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_tab_id_14243_14262,"tab-id",null], null),new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_callback_14244_14263,"callback",true], null)], null),"chrome.tabs.duplicate");
var ns_14246 = (function (){var target_obj_14257 = cljs.core.cst$kw$root.cljs$core$IFn$_invoke$arity$1(config);
var next_obj_14258 = (target_obj_14257["chrome"]);
var next_obj_14259 = (next_obj_14258["tabs"]);
return next_obj_14259;
})();
var config__6181__auto___14265 = config;
var api_check_fn__6182__auto___14266 = cljs.core.cst$kw$missing_DASH_api_DASH_check_DASH_fn.cljs$core$IFn$_invoke$arity$1(config__6181__auto___14265);

(api_check_fn__6182__auto___14266.cljs$core$IFn$_invoke$arity$3 ? api_check_fn__6182__auto___14266.cljs$core$IFn$_invoke$arity$3("chrome.tabs.duplicate",ns_14246,"duplicate") : api_check_fn__6182__auto___14266.call(null,"chrome.tabs.duplicate",ns_14246,"duplicate"));


var target_14247 = (function (){var target_obj_14260 = ns_14246;
var next_obj_14261 = (target_obj_14260["duplicate"]);
if((!((next_obj_14261 == null)))){
return next_obj_14261;
} else {
return null;
}
})();
return target_14247.apply(ns_14246,final_args_array_14245);
})();

return callback_chan_14241;
});
chromex.ext.tabs.query_STAR_ = (function chromex$ext$tabs$query_STAR_(config,query_info){
var callback_chan_14267 = (function (){var config__6143__auto__ = config;
var handler_key__6144__auto__ = cljs.core.cst$kw$callback_DASH_channel_DASH_factory;
var handler__6145__auto__ = handler_key__6144__auto__.cljs$core$IFn$_invoke$arity$1(config__6143__auto__);

return (handler__6145__auto__.cljs$core$IFn$_invoke$arity$1 ? handler__6145__auto__.cljs$core$IFn$_invoke$arity$1(config__6143__auto__) : handler__6145__auto__.call(null,config__6143__auto__));
})();
var marshalled_query_info_14269_14288 = (function (){var omit_test_14274 = query_info;
if(cljs.core.keyword_identical_QMARK_(omit_test_14274,cljs.core.cst$kw$omit)){
return cljs.core.cst$kw$omit;
} else {
return omit_test_14274;
}
})();
var marshalled_callback_14270_14289 = ((function (marshalled_query_info_14269_14288,callback_chan_14267){
return (function (cb_result_14275){
var fexpr__14279 = (function (){var config__6143__auto__ = config;
var handler_key__6144__auto__ = cljs.core.cst$kw$callback_DASH_fn_DASH_factory;
var handler__6145__auto__ = handler_key__6144__auto__.cljs$core$IFn$_invoke$arity$1(config__6143__auto__);

var G__14280 = config__6143__auto__;
var G__14281 = new cljs.core.PersistentArrayMap(null, 5, [cljs.core.cst$kw$id,cljs.core.cst$kw$chromex$ext$tabs_SLASH_query,cljs.core.cst$kw$name,"query",cljs.core.cst$kw$callback_QMARK_,true,cljs.core.cst$kw$params,new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentArrayMap(null, 2, [cljs.core.cst$kw$name,"query-info",cljs.core.cst$kw$type,"object"], null),new cljs.core.PersistentArrayMap(null, 3, [cljs.core.cst$kw$name,"callback",cljs.core.cst$kw$type,cljs.core.cst$kw$callback,cljs.core.cst$kw$callback,new cljs.core.PersistentArrayMap(null, 1, [cljs.core.cst$kw$params,new cljs.core.PersistentVector(null, 1, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentArrayMap(null, 2, [cljs.core.cst$kw$name,"result",cljs.core.cst$kw$type,"[array-of-tabs.Tabs]"], null)], null)], null)], null)], null),cljs.core.cst$kw$function_QMARK_,true], null);
var G__14282 = callback_chan_14267;
return (handler__6145__auto__.cljs$core$IFn$_invoke$arity$3 ? handler__6145__auto__.cljs$core$IFn$_invoke$arity$3(G__14280,G__14281,G__14282) : handler__6145__auto__.call(null,G__14280,G__14281,G__14282));
})();
return (fexpr__14279.cljs$core$IFn$_invoke$arity$1 ? fexpr__14279.cljs$core$IFn$_invoke$arity$1(cb_result_14275) : fexpr__14279.call(null,cb_result_14275));
});})(marshalled_query_info_14269_14288,callback_chan_14267))
;
var result_14268_14290 = (function (){var final_args_array_14271 = chromex.support.prepare_final_args_array(new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_query_info_14269_14288,"query-info",null], null),new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_callback_14270_14289,"callback",null], null)], null),"chrome.tabs.query");
var ns_14272 = (function (){var target_obj_14283 = cljs.core.cst$kw$root.cljs$core$IFn$_invoke$arity$1(config);
var next_obj_14284 = (target_obj_14283["chrome"]);
var next_obj_14285 = (next_obj_14284["tabs"]);
return next_obj_14285;
})();
var config__6181__auto___14291 = config;
var api_check_fn__6182__auto___14292 = cljs.core.cst$kw$missing_DASH_api_DASH_check_DASH_fn.cljs$core$IFn$_invoke$arity$1(config__6181__auto___14291);

(api_check_fn__6182__auto___14292.cljs$core$IFn$_invoke$arity$3 ? api_check_fn__6182__auto___14292.cljs$core$IFn$_invoke$arity$3("chrome.tabs.query",ns_14272,"query") : api_check_fn__6182__auto___14292.call(null,"chrome.tabs.query",ns_14272,"query"));


var target_14273 = (function (){var target_obj_14286 = ns_14272;
var next_obj_14287 = (target_obj_14286["query"]);
if((!((next_obj_14287 == null)))){
return next_obj_14287;
} else {
return null;
}
})();
return target_14273.apply(ns_14272,final_args_array_14271);
})();

return callback_chan_14267;
});
chromex.ext.tabs.highlight_STAR_ = (function chromex$ext$tabs$highlight_STAR_(config,highlight_info){
var callback_chan_14293 = (function (){var config__6143__auto__ = config;
var handler_key__6144__auto__ = cljs.core.cst$kw$callback_DASH_channel_DASH_factory;
var handler__6145__auto__ = handler_key__6144__auto__.cljs$core$IFn$_invoke$arity$1(config__6143__auto__);

return (handler__6145__auto__.cljs$core$IFn$_invoke$arity$1 ? handler__6145__auto__.cljs$core$IFn$_invoke$arity$1(config__6143__auto__) : handler__6145__auto__.call(null,config__6143__auto__));
})();
var marshalled_highlight_info_14295_14314 = (function (){var omit_test_14300 = highlight_info;
if(cljs.core.keyword_identical_QMARK_(omit_test_14300,cljs.core.cst$kw$omit)){
return cljs.core.cst$kw$omit;
} else {
return omit_test_14300;
}
})();
var marshalled_callback_14296_14315 = ((function (marshalled_highlight_info_14295_14314,callback_chan_14293){
return (function (cb_window_14301){
var fexpr__14305 = (function (){var config__6143__auto__ = config;
var handler_key__6144__auto__ = cljs.core.cst$kw$callback_DASH_fn_DASH_factory;
var handler__6145__auto__ = handler_key__6144__auto__.cljs$core$IFn$_invoke$arity$1(config__6143__auto__);

var G__14306 = config__6143__auto__;
var G__14307 = new cljs.core.PersistentArrayMap(null, 5, [cljs.core.cst$kw$id,cljs.core.cst$kw$chromex$ext$tabs_SLASH_highlight,cljs.core.cst$kw$name,"highlight",cljs.core.cst$kw$callback_QMARK_,true,cljs.core.cst$kw$params,new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentArrayMap(null, 2, [cljs.core.cst$kw$name,"highlight-info",cljs.core.cst$kw$type,"object"], null),new cljs.core.PersistentArrayMap(null, 4, [cljs.core.cst$kw$name,"callback",cljs.core.cst$kw$optional_QMARK_,true,cljs.core.cst$kw$type,cljs.core.cst$kw$callback,cljs.core.cst$kw$callback,new cljs.core.PersistentArrayMap(null, 1, [cljs.core.cst$kw$params,new cljs.core.PersistentVector(null, 1, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentArrayMap(null, 2, [cljs.core.cst$kw$name,"window",cljs.core.cst$kw$type,"windows.Window"], null)], null)], null)], null)], null),cljs.core.cst$kw$function_QMARK_,true], null);
var G__14308 = callback_chan_14293;
return (handler__6145__auto__.cljs$core$IFn$_invoke$arity$3 ? handler__6145__auto__.cljs$core$IFn$_invoke$arity$3(G__14306,G__14307,G__14308) : handler__6145__auto__.call(null,G__14306,G__14307,G__14308));
})();
return (fexpr__14305.cljs$core$IFn$_invoke$arity$1 ? fexpr__14305.cljs$core$IFn$_invoke$arity$1(cb_window_14301) : fexpr__14305.call(null,cb_window_14301));
});})(marshalled_highlight_info_14295_14314,callback_chan_14293))
;
var result_14294_14316 = (function (){var final_args_array_14297 = chromex.support.prepare_final_args_array(new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_highlight_info_14295_14314,"highlight-info",null], null),new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_callback_14296_14315,"callback",true], null)], null),"chrome.tabs.highlight");
var ns_14298 = (function (){var target_obj_14309 = cljs.core.cst$kw$root.cljs$core$IFn$_invoke$arity$1(config);
var next_obj_14310 = (target_obj_14309["chrome"]);
var next_obj_14311 = (next_obj_14310["tabs"]);
return next_obj_14311;
})();
var config__6181__auto___14317 = config;
var api_check_fn__6182__auto___14318 = cljs.core.cst$kw$missing_DASH_api_DASH_check_DASH_fn.cljs$core$IFn$_invoke$arity$1(config__6181__auto___14317);

(api_check_fn__6182__auto___14318.cljs$core$IFn$_invoke$arity$3 ? api_check_fn__6182__auto___14318.cljs$core$IFn$_invoke$arity$3("chrome.tabs.highlight",ns_14298,"highlight") : api_check_fn__6182__auto___14318.call(null,"chrome.tabs.highlight",ns_14298,"highlight"));


var target_14299 = (function (){var target_obj_14312 = ns_14298;
var next_obj_14313 = (target_obj_14312["highlight"]);
if((!((next_obj_14313 == null)))){
return next_obj_14313;
} else {
return null;
}
})();
return target_14299.apply(ns_14298,final_args_array_14297);
})();

return callback_chan_14293;
});
chromex.ext.tabs.update_STAR_ = (function chromex$ext$tabs$update_STAR_(config,tab_id,update_properties){
var callback_chan_14319 = (function (){var config__6143__auto__ = config;
var handler_key__6144__auto__ = cljs.core.cst$kw$callback_DASH_channel_DASH_factory;
var handler__6145__auto__ = handler_key__6144__auto__.cljs$core$IFn$_invoke$arity$1(config__6143__auto__);

return (handler__6145__auto__.cljs$core$IFn$_invoke$arity$1 ? handler__6145__auto__.cljs$core$IFn$_invoke$arity$1(config__6143__auto__) : handler__6145__auto__.call(null,config__6143__auto__));
})();
var marshalled_tab_id_14321_14342 = (function (){var omit_test_14327 = tab_id;
if(cljs.core.keyword_identical_QMARK_(omit_test_14327,cljs.core.cst$kw$omit)){
return cljs.core.cst$kw$omit;
} else {
return omit_test_14327;
}
})();
var marshalled_update_properties_14322_14343 = (function (){var omit_test_14328 = update_properties;
if(cljs.core.keyword_identical_QMARK_(omit_test_14328,cljs.core.cst$kw$omit)){
return cljs.core.cst$kw$omit;
} else {
return omit_test_14328;
}
})();
var marshalled_callback_14323_14344 = ((function (marshalled_tab_id_14321_14342,marshalled_update_properties_14322_14343,callback_chan_14319){
return (function (cb_tab_14329){
var fexpr__14333 = (function (){var config__6143__auto__ = config;
var handler_key__6144__auto__ = cljs.core.cst$kw$callback_DASH_fn_DASH_factory;
var handler__6145__auto__ = handler_key__6144__auto__.cljs$core$IFn$_invoke$arity$1(config__6143__auto__);

var G__14334 = config__6143__auto__;
var G__14335 = new cljs.core.PersistentArrayMap(null, 5, [cljs.core.cst$kw$id,cljs.core.cst$kw$chromex$ext$tabs_SLASH_update,cljs.core.cst$kw$name,"update",cljs.core.cst$kw$callback_QMARK_,true,cljs.core.cst$kw$params,new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentArrayMap(null, 3, [cljs.core.cst$kw$name,"tab-id",cljs.core.cst$kw$optional_QMARK_,true,cljs.core.cst$kw$type,"integer"], null),new cljs.core.PersistentArrayMap(null, 2, [cljs.core.cst$kw$name,"update-properties",cljs.core.cst$kw$type,"object"], null),new cljs.core.PersistentArrayMap(null, 4, [cljs.core.cst$kw$name,"callback",cljs.core.cst$kw$optional_QMARK_,true,cljs.core.cst$kw$type,cljs.core.cst$kw$callback,cljs.core.cst$kw$callback,new cljs.core.PersistentArrayMap(null, 1, [cljs.core.cst$kw$params,new cljs.core.PersistentVector(null, 1, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentArrayMap(null, 3, [cljs.core.cst$kw$name,"tab",cljs.core.cst$kw$optional_QMARK_,true,cljs.core.cst$kw$type,"tabs.Tab"], null)], null)], null)], null)], null),cljs.core.cst$kw$function_QMARK_,true], null);
var G__14336 = callback_chan_14319;
return (handler__6145__auto__.cljs$core$IFn$_invoke$arity$3 ? handler__6145__auto__.cljs$core$IFn$_invoke$arity$3(G__14334,G__14335,G__14336) : handler__6145__auto__.call(null,G__14334,G__14335,G__14336));
})();
return (fexpr__14333.cljs$core$IFn$_invoke$arity$1 ? fexpr__14333.cljs$core$IFn$_invoke$arity$1(cb_tab_14329) : fexpr__14333.call(null,cb_tab_14329));
});})(marshalled_tab_id_14321_14342,marshalled_update_properties_14322_14343,callback_chan_14319))
;
var result_14320_14345 = (function (){var final_args_array_14324 = chromex.support.prepare_final_args_array(new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_tab_id_14321_14342,"tab-id",true], null),new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_update_properties_14322_14343,"update-properties",null], null),new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_callback_14323_14344,"callback",true], null)], null),"chrome.tabs.update");
var ns_14325 = (function (){var target_obj_14337 = cljs.core.cst$kw$root.cljs$core$IFn$_invoke$arity$1(config);
var next_obj_14338 = (target_obj_14337["chrome"]);
var next_obj_14339 = (next_obj_14338["tabs"]);
return next_obj_14339;
})();
var config__6181__auto___14346 = config;
var api_check_fn__6182__auto___14347 = cljs.core.cst$kw$missing_DASH_api_DASH_check_DASH_fn.cljs$core$IFn$_invoke$arity$1(config__6181__auto___14346);

(api_check_fn__6182__auto___14347.cljs$core$IFn$_invoke$arity$3 ? api_check_fn__6182__auto___14347.cljs$core$IFn$_invoke$arity$3("chrome.tabs.update",ns_14325,"update") : api_check_fn__6182__auto___14347.call(null,"chrome.tabs.update",ns_14325,"update"));


var target_14326 = (function (){var target_obj_14340 = ns_14325;
var next_obj_14341 = (target_obj_14340["update"]);
if((!((next_obj_14341 == null)))){
return next_obj_14341;
} else {
return null;
}
})();
return target_14326.apply(ns_14325,final_args_array_14324);
})();

return callback_chan_14319;
});
chromex.ext.tabs.move_STAR_ = (function chromex$ext$tabs$move_STAR_(config,tab_ids,move_properties){
var callback_chan_14348 = (function (){var config__6143__auto__ = config;
var handler_key__6144__auto__ = cljs.core.cst$kw$callback_DASH_channel_DASH_factory;
var handler__6145__auto__ = handler_key__6144__auto__.cljs$core$IFn$_invoke$arity$1(config__6143__auto__);

return (handler__6145__auto__.cljs$core$IFn$_invoke$arity$1 ? handler__6145__auto__.cljs$core$IFn$_invoke$arity$1(config__6143__auto__) : handler__6145__auto__.call(null,config__6143__auto__));
})();
var marshalled_tab_ids_14350_14371 = (function (){var omit_test_14356 = tab_ids;
if(cljs.core.keyword_identical_QMARK_(omit_test_14356,cljs.core.cst$kw$omit)){
return cljs.core.cst$kw$omit;
} else {
return omit_test_14356;
}
})();
var marshalled_move_properties_14351_14372 = (function (){var omit_test_14357 = move_properties;
if(cljs.core.keyword_identical_QMARK_(omit_test_14357,cljs.core.cst$kw$omit)){
return cljs.core.cst$kw$omit;
} else {
return omit_test_14357;
}
})();
var marshalled_callback_14352_14373 = ((function (marshalled_tab_ids_14350_14371,marshalled_move_properties_14351_14372,callback_chan_14348){
return (function (cb_tabs_14358){
var fexpr__14362 = (function (){var config__6143__auto__ = config;
var handler_key__6144__auto__ = cljs.core.cst$kw$callback_DASH_fn_DASH_factory;
var handler__6145__auto__ = handler_key__6144__auto__.cljs$core$IFn$_invoke$arity$1(config__6143__auto__);

var G__14363 = config__6143__auto__;
var G__14364 = new cljs.core.PersistentArrayMap(null, 5, [cljs.core.cst$kw$id,cljs.core.cst$kw$chromex$ext$tabs_SLASH_move,cljs.core.cst$kw$name,"move",cljs.core.cst$kw$callback_QMARK_,true,cljs.core.cst$kw$params,new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentArrayMap(null, 2, [cljs.core.cst$kw$name,"tab-ids",cljs.core.cst$kw$type,"integer-or-[array-of-integers]"], null),new cljs.core.PersistentArrayMap(null, 2, [cljs.core.cst$kw$name,"move-properties",cljs.core.cst$kw$type,"object"], null),new cljs.core.PersistentArrayMap(null, 4, [cljs.core.cst$kw$name,"callback",cljs.core.cst$kw$optional_QMARK_,true,cljs.core.cst$kw$type,cljs.core.cst$kw$callback,cljs.core.cst$kw$callback,new cljs.core.PersistentArrayMap(null, 1, [cljs.core.cst$kw$params,new cljs.core.PersistentVector(null, 1, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentArrayMap(null, 2, [cljs.core.cst$kw$name,"tabs",cljs.core.cst$kw$type,"tabs.Tab-or-[array-of-tabs.Tabs]"], null)], null)], null)], null)], null),cljs.core.cst$kw$function_QMARK_,true], null);
var G__14365 = callback_chan_14348;
return (handler__6145__auto__.cljs$core$IFn$_invoke$arity$3 ? handler__6145__auto__.cljs$core$IFn$_invoke$arity$3(G__14363,G__14364,G__14365) : handler__6145__auto__.call(null,G__14363,G__14364,G__14365));
})();
return (fexpr__14362.cljs$core$IFn$_invoke$arity$1 ? fexpr__14362.cljs$core$IFn$_invoke$arity$1(cb_tabs_14358) : fexpr__14362.call(null,cb_tabs_14358));
});})(marshalled_tab_ids_14350_14371,marshalled_move_properties_14351_14372,callback_chan_14348))
;
var result_14349_14374 = (function (){var final_args_array_14353 = chromex.support.prepare_final_args_array(new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_tab_ids_14350_14371,"tab-ids",null], null),new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_move_properties_14351_14372,"move-properties",null], null),new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_callback_14352_14373,"callback",true], null)], null),"chrome.tabs.move");
var ns_14354 = (function (){var target_obj_14366 = cljs.core.cst$kw$root.cljs$core$IFn$_invoke$arity$1(config);
var next_obj_14367 = (target_obj_14366["chrome"]);
var next_obj_14368 = (next_obj_14367["tabs"]);
return next_obj_14368;
})();
var config__6181__auto___14375 = config;
var api_check_fn__6182__auto___14376 = cljs.core.cst$kw$missing_DASH_api_DASH_check_DASH_fn.cljs$core$IFn$_invoke$arity$1(config__6181__auto___14375);

(api_check_fn__6182__auto___14376.cljs$core$IFn$_invoke$arity$3 ? api_check_fn__6182__auto___14376.cljs$core$IFn$_invoke$arity$3("chrome.tabs.move",ns_14354,"move") : api_check_fn__6182__auto___14376.call(null,"chrome.tabs.move",ns_14354,"move"));


var target_14355 = (function (){var target_obj_14369 = ns_14354;
var next_obj_14370 = (target_obj_14369["move"]);
if((!((next_obj_14370 == null)))){
return next_obj_14370;
} else {
return null;
}
})();
return target_14355.apply(ns_14354,final_args_array_14353);
})();

return callback_chan_14348;
});
chromex.ext.tabs.reload_STAR_ = (function chromex$ext$tabs$reload_STAR_(config,tab_id,reload_properties){
var callback_chan_14377 = (function (){var config__6143__auto__ = config;
var handler_key__6144__auto__ = cljs.core.cst$kw$callback_DASH_channel_DASH_factory;
var handler__6145__auto__ = handler_key__6144__auto__.cljs$core$IFn$_invoke$arity$1(config__6143__auto__);

return (handler__6145__auto__.cljs$core$IFn$_invoke$arity$1 ? handler__6145__auto__.cljs$core$IFn$_invoke$arity$1(config__6143__auto__) : handler__6145__auto__.call(null,config__6143__auto__));
})();
var marshalled_tab_id_14379_14395 = (function (){var omit_test_14385 = tab_id;
if(cljs.core.keyword_identical_QMARK_(omit_test_14385,cljs.core.cst$kw$omit)){
return cljs.core.cst$kw$omit;
} else {
return omit_test_14385;
}
})();
var marshalled_reload_properties_14380_14396 = (function (){var omit_test_14386 = reload_properties;
if(cljs.core.keyword_identical_QMARK_(omit_test_14386,cljs.core.cst$kw$omit)){
return cljs.core.cst$kw$omit;
} else {
return omit_test_14386;
}
})();
var marshalled_callback_14381_14397 = (function (){var config__6143__auto__ = config;
var handler_key__6144__auto__ = cljs.core.cst$kw$callback_DASH_fn_DASH_factory;
var handler__6145__auto__ = handler_key__6144__auto__.cljs$core$IFn$_invoke$arity$1(config__6143__auto__);

var G__14387 = config__6143__auto__;
var G__14388 = new cljs.core.PersistentArrayMap(null, 5, [cljs.core.cst$kw$id,cljs.core.cst$kw$chromex$ext$tabs_SLASH_reload,cljs.core.cst$kw$name,"reload",cljs.core.cst$kw$callback_QMARK_,true,cljs.core.cst$kw$params,new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentArrayMap(null, 3, [cljs.core.cst$kw$name,"tab-id",cljs.core.cst$kw$optional_QMARK_,true,cljs.core.cst$kw$type,"integer"], null),new cljs.core.PersistentArrayMap(null, 3, [cljs.core.cst$kw$name,"reload-properties",cljs.core.cst$kw$optional_QMARK_,true,cljs.core.cst$kw$type,"object"], null),new cljs.core.PersistentArrayMap(null, 3, [cljs.core.cst$kw$name,"callback",cljs.core.cst$kw$optional_QMARK_,true,cljs.core.cst$kw$type,cljs.core.cst$kw$callback], null)], null),cljs.core.cst$kw$function_QMARK_,true], null);
var G__14389 = callback_chan_14377;
return (handler__6145__auto__.cljs$core$IFn$_invoke$arity$3 ? handler__6145__auto__.cljs$core$IFn$_invoke$arity$3(G__14387,G__14388,G__14389) : handler__6145__auto__.call(null,G__14387,G__14388,G__14389));
})();
var result_14378_14398 = (function (){var final_args_array_14382 = chromex.support.prepare_final_args_array(new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_tab_id_14379_14395,"tab-id",true], null),new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_reload_properties_14380_14396,"reload-properties",true], null),new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_callback_14381_14397,"callback",true], null)], null),"chrome.tabs.reload");
var ns_14383 = (function (){var target_obj_14390 = cljs.core.cst$kw$root.cljs$core$IFn$_invoke$arity$1(config);
var next_obj_14391 = (target_obj_14390["chrome"]);
var next_obj_14392 = (next_obj_14391["tabs"]);
return next_obj_14392;
})();
var config__6181__auto___14399 = config;
var api_check_fn__6182__auto___14400 = cljs.core.cst$kw$missing_DASH_api_DASH_check_DASH_fn.cljs$core$IFn$_invoke$arity$1(config__6181__auto___14399);

(api_check_fn__6182__auto___14400.cljs$core$IFn$_invoke$arity$3 ? api_check_fn__6182__auto___14400.cljs$core$IFn$_invoke$arity$3("chrome.tabs.reload",ns_14383,"reload") : api_check_fn__6182__auto___14400.call(null,"chrome.tabs.reload",ns_14383,"reload"));


var target_14384 = (function (){var target_obj_14393 = ns_14383;
var next_obj_14394 = (target_obj_14393["reload"]);
if((!((next_obj_14394 == null)))){
return next_obj_14394;
} else {
return null;
}
})();
return target_14384.apply(ns_14383,final_args_array_14382);
})();

return callback_chan_14377;
});
chromex.ext.tabs.remove_STAR_ = (function chromex$ext$tabs$remove_STAR_(config,tab_ids){
var callback_chan_14401 = (function (){var config__6143__auto__ = config;
var handler_key__6144__auto__ = cljs.core.cst$kw$callback_DASH_channel_DASH_factory;
var handler__6145__auto__ = handler_key__6144__auto__.cljs$core$IFn$_invoke$arity$1(config__6143__auto__);

return (handler__6145__auto__.cljs$core$IFn$_invoke$arity$1 ? handler__6145__auto__.cljs$core$IFn$_invoke$arity$1(config__6143__auto__) : handler__6145__auto__.call(null,config__6143__auto__));
})();
var marshalled_tab_ids_14403_14417 = (function (){var omit_test_14408 = tab_ids;
if(cljs.core.keyword_identical_QMARK_(omit_test_14408,cljs.core.cst$kw$omit)){
return cljs.core.cst$kw$omit;
} else {
return omit_test_14408;
}
})();
var marshalled_callback_14404_14418 = (function (){var config__6143__auto__ = config;
var handler_key__6144__auto__ = cljs.core.cst$kw$callback_DASH_fn_DASH_factory;
var handler__6145__auto__ = handler_key__6144__auto__.cljs$core$IFn$_invoke$arity$1(config__6143__auto__);

var G__14409 = config__6143__auto__;
var G__14410 = new cljs.core.PersistentArrayMap(null, 5, [cljs.core.cst$kw$id,cljs.core.cst$kw$chromex$ext$tabs_SLASH_remove,cljs.core.cst$kw$name,"remove",cljs.core.cst$kw$callback_QMARK_,true,cljs.core.cst$kw$params,new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentArrayMap(null, 2, [cljs.core.cst$kw$name,"tab-ids",cljs.core.cst$kw$type,"integer-or-[array-of-integers]"], null),new cljs.core.PersistentArrayMap(null, 3, [cljs.core.cst$kw$name,"callback",cljs.core.cst$kw$optional_QMARK_,true,cljs.core.cst$kw$type,cljs.core.cst$kw$callback], null)], null),cljs.core.cst$kw$function_QMARK_,true], null);
var G__14411 = callback_chan_14401;
return (handler__6145__auto__.cljs$core$IFn$_invoke$arity$3 ? handler__6145__auto__.cljs$core$IFn$_invoke$arity$3(G__14409,G__14410,G__14411) : handler__6145__auto__.call(null,G__14409,G__14410,G__14411));
})();
var result_14402_14419 = (function (){var final_args_array_14405 = chromex.support.prepare_final_args_array(new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_tab_ids_14403_14417,"tab-ids",null], null),new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_callback_14404_14418,"callback",true], null)], null),"chrome.tabs.remove");
var ns_14406 = (function (){var target_obj_14412 = cljs.core.cst$kw$root.cljs$core$IFn$_invoke$arity$1(config);
var next_obj_14413 = (target_obj_14412["chrome"]);
var next_obj_14414 = (next_obj_14413["tabs"]);
return next_obj_14414;
})();
var config__6181__auto___14420 = config;
var api_check_fn__6182__auto___14421 = cljs.core.cst$kw$missing_DASH_api_DASH_check_DASH_fn.cljs$core$IFn$_invoke$arity$1(config__6181__auto___14420);

(api_check_fn__6182__auto___14421.cljs$core$IFn$_invoke$arity$3 ? api_check_fn__6182__auto___14421.cljs$core$IFn$_invoke$arity$3("chrome.tabs.remove",ns_14406,"remove") : api_check_fn__6182__auto___14421.call(null,"chrome.tabs.remove",ns_14406,"remove"));


var target_14407 = (function (){var target_obj_14415 = ns_14406;
var next_obj_14416 = (target_obj_14415["remove"]);
if((!((next_obj_14416 == null)))){
return next_obj_14416;
} else {
return null;
}
})();
return target_14407.apply(ns_14406,final_args_array_14405);
})();

return callback_chan_14401;
});
chromex.ext.tabs.detect_language_STAR_ = (function chromex$ext$tabs$detect_language_STAR_(config,tab_id){
var callback_chan_14422 = (function (){var config__6143__auto__ = config;
var handler_key__6144__auto__ = cljs.core.cst$kw$callback_DASH_channel_DASH_factory;
var handler__6145__auto__ = handler_key__6144__auto__.cljs$core$IFn$_invoke$arity$1(config__6143__auto__);

return (handler__6145__auto__.cljs$core$IFn$_invoke$arity$1 ? handler__6145__auto__.cljs$core$IFn$_invoke$arity$1(config__6143__auto__) : handler__6145__auto__.call(null,config__6143__auto__));
})();
var marshalled_tab_id_14424_14443 = (function (){var omit_test_14429 = tab_id;
if(cljs.core.keyword_identical_QMARK_(omit_test_14429,cljs.core.cst$kw$omit)){
return cljs.core.cst$kw$omit;
} else {
return omit_test_14429;
}
})();
var marshalled_callback_14425_14444 = ((function (marshalled_tab_id_14424_14443,callback_chan_14422){
return (function (cb_language_14430){
var fexpr__14434 = (function (){var config__6143__auto__ = config;
var handler_key__6144__auto__ = cljs.core.cst$kw$callback_DASH_fn_DASH_factory;
var handler__6145__auto__ = handler_key__6144__auto__.cljs$core$IFn$_invoke$arity$1(config__6143__auto__);

var G__14435 = config__6143__auto__;
var G__14436 = new cljs.core.PersistentArrayMap(null, 5, [cljs.core.cst$kw$id,cljs.core.cst$kw$chromex$ext$tabs_SLASH_detect_DASH_language,cljs.core.cst$kw$name,"detectLanguage",cljs.core.cst$kw$callback_QMARK_,true,cljs.core.cst$kw$params,new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentArrayMap(null, 3, [cljs.core.cst$kw$name,"tab-id",cljs.core.cst$kw$optional_QMARK_,true,cljs.core.cst$kw$type,"integer"], null),new cljs.core.PersistentArrayMap(null, 3, [cljs.core.cst$kw$name,"callback",cljs.core.cst$kw$type,cljs.core.cst$kw$callback,cljs.core.cst$kw$callback,new cljs.core.PersistentArrayMap(null, 1, [cljs.core.cst$kw$params,new cljs.core.PersistentVector(null, 1, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentArrayMap(null, 2, [cljs.core.cst$kw$name,"language",cljs.core.cst$kw$type,"string"], null)], null)], null)], null)], null),cljs.core.cst$kw$function_QMARK_,true], null);
var G__14437 = callback_chan_14422;
return (handler__6145__auto__.cljs$core$IFn$_invoke$arity$3 ? handler__6145__auto__.cljs$core$IFn$_invoke$arity$3(G__14435,G__14436,G__14437) : handler__6145__auto__.call(null,G__14435,G__14436,G__14437));
})();
return (fexpr__14434.cljs$core$IFn$_invoke$arity$1 ? fexpr__14434.cljs$core$IFn$_invoke$arity$1(cb_language_14430) : fexpr__14434.call(null,cb_language_14430));
});})(marshalled_tab_id_14424_14443,callback_chan_14422))
;
var result_14423_14445 = (function (){var final_args_array_14426 = chromex.support.prepare_final_args_array(new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_tab_id_14424_14443,"tab-id",true], null),new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_callback_14425_14444,"callback",null], null)], null),"chrome.tabs.detectLanguage");
var ns_14427 = (function (){var target_obj_14438 = cljs.core.cst$kw$root.cljs$core$IFn$_invoke$arity$1(config);
var next_obj_14439 = (target_obj_14438["chrome"]);
var next_obj_14440 = (next_obj_14439["tabs"]);
return next_obj_14440;
})();
var config__6181__auto___14446 = config;
var api_check_fn__6182__auto___14447 = cljs.core.cst$kw$missing_DASH_api_DASH_check_DASH_fn.cljs$core$IFn$_invoke$arity$1(config__6181__auto___14446);

(api_check_fn__6182__auto___14447.cljs$core$IFn$_invoke$arity$3 ? api_check_fn__6182__auto___14447.cljs$core$IFn$_invoke$arity$3("chrome.tabs.detectLanguage",ns_14427,"detectLanguage") : api_check_fn__6182__auto___14447.call(null,"chrome.tabs.detectLanguage",ns_14427,"detectLanguage"));


var target_14428 = (function (){var target_obj_14441 = ns_14427;
var next_obj_14442 = (target_obj_14441["detectLanguage"]);
if((!((next_obj_14442 == null)))){
return next_obj_14442;
} else {
return null;
}
})();
return target_14428.apply(ns_14427,final_args_array_14426);
})();

return callback_chan_14422;
});
chromex.ext.tabs.capture_visible_tab_STAR_ = (function chromex$ext$tabs$capture_visible_tab_STAR_(config,window_id,options){
var callback_chan_14448 = (function (){var config__6143__auto__ = config;
var handler_key__6144__auto__ = cljs.core.cst$kw$callback_DASH_channel_DASH_factory;
var handler__6145__auto__ = handler_key__6144__auto__.cljs$core$IFn$_invoke$arity$1(config__6143__auto__);

return (handler__6145__auto__.cljs$core$IFn$_invoke$arity$1 ? handler__6145__auto__.cljs$core$IFn$_invoke$arity$1(config__6143__auto__) : handler__6145__auto__.call(null,config__6143__auto__));
})();
var marshalled_window_id_14450_14471 = (function (){var omit_test_14456 = window_id;
if(cljs.core.keyword_identical_QMARK_(omit_test_14456,cljs.core.cst$kw$omit)){
return cljs.core.cst$kw$omit;
} else {
return omit_test_14456;
}
})();
var marshalled_options_14451_14472 = (function (){var omit_test_14457 = options;
if(cljs.core.keyword_identical_QMARK_(omit_test_14457,cljs.core.cst$kw$omit)){
return cljs.core.cst$kw$omit;
} else {
return omit_test_14457;
}
})();
var marshalled_callback_14452_14473 = ((function (marshalled_window_id_14450_14471,marshalled_options_14451_14472,callback_chan_14448){
return (function (cb_data_url_14458){
var fexpr__14462 = (function (){var config__6143__auto__ = config;
var handler_key__6144__auto__ = cljs.core.cst$kw$callback_DASH_fn_DASH_factory;
var handler__6145__auto__ = handler_key__6144__auto__.cljs$core$IFn$_invoke$arity$1(config__6143__auto__);

var G__14463 = config__6143__auto__;
var G__14464 = new cljs.core.PersistentArrayMap(null, 5, [cljs.core.cst$kw$id,cljs.core.cst$kw$chromex$ext$tabs_SLASH_capture_DASH_visible_DASH_tab,cljs.core.cst$kw$name,"captureVisibleTab",cljs.core.cst$kw$callback_QMARK_,true,cljs.core.cst$kw$params,new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentArrayMap(null, 3, [cljs.core.cst$kw$name,"window-id",cljs.core.cst$kw$optional_QMARK_,true,cljs.core.cst$kw$type,"integer"], null),new cljs.core.PersistentArrayMap(null, 3, [cljs.core.cst$kw$name,"options",cljs.core.cst$kw$optional_QMARK_,true,cljs.core.cst$kw$type,"object"], null),new cljs.core.PersistentArrayMap(null, 3, [cljs.core.cst$kw$name,"callback",cljs.core.cst$kw$type,cljs.core.cst$kw$callback,cljs.core.cst$kw$callback,new cljs.core.PersistentArrayMap(null, 1, [cljs.core.cst$kw$params,new cljs.core.PersistentVector(null, 1, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentArrayMap(null, 2, [cljs.core.cst$kw$name,"data-url",cljs.core.cst$kw$type,"string"], null)], null)], null)], null)], null),cljs.core.cst$kw$function_QMARK_,true], null);
var G__14465 = callback_chan_14448;
return (handler__6145__auto__.cljs$core$IFn$_invoke$arity$3 ? handler__6145__auto__.cljs$core$IFn$_invoke$arity$3(G__14463,G__14464,G__14465) : handler__6145__auto__.call(null,G__14463,G__14464,G__14465));
})();
return (fexpr__14462.cljs$core$IFn$_invoke$arity$1 ? fexpr__14462.cljs$core$IFn$_invoke$arity$1(cb_data_url_14458) : fexpr__14462.call(null,cb_data_url_14458));
});})(marshalled_window_id_14450_14471,marshalled_options_14451_14472,callback_chan_14448))
;
var result_14449_14474 = (function (){var final_args_array_14453 = chromex.support.prepare_final_args_array(new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_window_id_14450_14471,"window-id",true], null),new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_options_14451_14472,"options",true], null),new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_callback_14452_14473,"callback",null], null)], null),"chrome.tabs.captureVisibleTab");
var ns_14454 = (function (){var target_obj_14466 = cljs.core.cst$kw$root.cljs$core$IFn$_invoke$arity$1(config);
var next_obj_14467 = (target_obj_14466["chrome"]);
var next_obj_14468 = (next_obj_14467["tabs"]);
return next_obj_14468;
})();
var config__6181__auto___14475 = config;
var api_check_fn__6182__auto___14476 = cljs.core.cst$kw$missing_DASH_api_DASH_check_DASH_fn.cljs$core$IFn$_invoke$arity$1(config__6181__auto___14475);

(api_check_fn__6182__auto___14476.cljs$core$IFn$_invoke$arity$3 ? api_check_fn__6182__auto___14476.cljs$core$IFn$_invoke$arity$3("chrome.tabs.captureVisibleTab",ns_14454,"captureVisibleTab") : api_check_fn__6182__auto___14476.call(null,"chrome.tabs.captureVisibleTab",ns_14454,"captureVisibleTab"));


var target_14455 = (function (){var target_obj_14469 = ns_14454;
var next_obj_14470 = (target_obj_14469["captureVisibleTab"]);
if((!((next_obj_14470 == null)))){
return next_obj_14470;
} else {
return null;
}
})();
return target_14455.apply(ns_14454,final_args_array_14453);
})();

return callback_chan_14448;
});
chromex.ext.tabs.execute_script_STAR_ = (function chromex$ext$tabs$execute_script_STAR_(config,tab_id,details){
var callback_chan_14477 = (function (){var config__6143__auto__ = config;
var handler_key__6144__auto__ = cljs.core.cst$kw$callback_DASH_channel_DASH_factory;
var handler__6145__auto__ = handler_key__6144__auto__.cljs$core$IFn$_invoke$arity$1(config__6143__auto__);

return (handler__6145__auto__.cljs$core$IFn$_invoke$arity$1 ? handler__6145__auto__.cljs$core$IFn$_invoke$arity$1(config__6143__auto__) : handler__6145__auto__.call(null,config__6143__auto__));
})();
var marshalled_tab_id_14479_14500 = (function (){var omit_test_14485 = tab_id;
if(cljs.core.keyword_identical_QMARK_(omit_test_14485,cljs.core.cst$kw$omit)){
return cljs.core.cst$kw$omit;
} else {
return omit_test_14485;
}
})();
var marshalled_details_14480_14501 = (function (){var omit_test_14486 = details;
if(cljs.core.keyword_identical_QMARK_(omit_test_14486,cljs.core.cst$kw$omit)){
return cljs.core.cst$kw$omit;
} else {
return omit_test_14486;
}
})();
var marshalled_callback_14481_14502 = ((function (marshalled_tab_id_14479_14500,marshalled_details_14480_14501,callback_chan_14477){
return (function (cb_result_14487){
var fexpr__14491 = (function (){var config__6143__auto__ = config;
var handler_key__6144__auto__ = cljs.core.cst$kw$callback_DASH_fn_DASH_factory;
var handler__6145__auto__ = handler_key__6144__auto__.cljs$core$IFn$_invoke$arity$1(config__6143__auto__);

var G__14492 = config__6143__auto__;
var G__14493 = new cljs.core.PersistentArrayMap(null, 5, [cljs.core.cst$kw$id,cljs.core.cst$kw$chromex$ext$tabs_SLASH_execute_DASH_script,cljs.core.cst$kw$name,"executeScript",cljs.core.cst$kw$callback_QMARK_,true,cljs.core.cst$kw$params,new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentArrayMap(null, 3, [cljs.core.cst$kw$name,"tab-id",cljs.core.cst$kw$optional_QMARK_,true,cljs.core.cst$kw$type,"integer"], null),new cljs.core.PersistentArrayMap(null, 2, [cljs.core.cst$kw$name,"details",cljs.core.cst$kw$type,"object"], null),new cljs.core.PersistentArrayMap(null, 4, [cljs.core.cst$kw$name,"callback",cljs.core.cst$kw$optional_QMARK_,true,cljs.core.cst$kw$type,cljs.core.cst$kw$callback,cljs.core.cst$kw$callback,new cljs.core.PersistentArrayMap(null, 1, [cljs.core.cst$kw$params,new cljs.core.PersistentVector(null, 1, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentArrayMap(null, 3, [cljs.core.cst$kw$name,"result",cljs.core.cst$kw$optional_QMARK_,true,cljs.core.cst$kw$type,"[array-of-anys]"], null)], null)], null)], null)], null),cljs.core.cst$kw$function_QMARK_,true], null);
var G__14494 = callback_chan_14477;
return (handler__6145__auto__.cljs$core$IFn$_invoke$arity$3 ? handler__6145__auto__.cljs$core$IFn$_invoke$arity$3(G__14492,G__14493,G__14494) : handler__6145__auto__.call(null,G__14492,G__14493,G__14494));
})();
return (fexpr__14491.cljs$core$IFn$_invoke$arity$1 ? fexpr__14491.cljs$core$IFn$_invoke$arity$1(cb_result_14487) : fexpr__14491.call(null,cb_result_14487));
});})(marshalled_tab_id_14479_14500,marshalled_details_14480_14501,callback_chan_14477))
;
var result_14478_14503 = (function (){var final_args_array_14482 = chromex.support.prepare_final_args_array(new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_tab_id_14479_14500,"tab-id",true], null),new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_details_14480_14501,"details",null], null),new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_callback_14481_14502,"callback",true], null)], null),"chrome.tabs.executeScript");
var ns_14483 = (function (){var target_obj_14495 = cljs.core.cst$kw$root.cljs$core$IFn$_invoke$arity$1(config);
var next_obj_14496 = (target_obj_14495["chrome"]);
var next_obj_14497 = (next_obj_14496["tabs"]);
return next_obj_14497;
})();
var config__6181__auto___14504 = config;
var api_check_fn__6182__auto___14505 = cljs.core.cst$kw$missing_DASH_api_DASH_check_DASH_fn.cljs$core$IFn$_invoke$arity$1(config__6181__auto___14504);

(api_check_fn__6182__auto___14505.cljs$core$IFn$_invoke$arity$3 ? api_check_fn__6182__auto___14505.cljs$core$IFn$_invoke$arity$3("chrome.tabs.executeScript",ns_14483,"executeScript") : api_check_fn__6182__auto___14505.call(null,"chrome.tabs.executeScript",ns_14483,"executeScript"));


var target_14484 = (function (){var target_obj_14498 = ns_14483;
var next_obj_14499 = (target_obj_14498["executeScript"]);
if((!((next_obj_14499 == null)))){
return next_obj_14499;
} else {
return null;
}
})();
return target_14484.apply(ns_14483,final_args_array_14482);
})();

return callback_chan_14477;
});
chromex.ext.tabs.insert_css_STAR_ = (function chromex$ext$tabs$insert_css_STAR_(config,tab_id,details){
var callback_chan_14506 = (function (){var config__6143__auto__ = config;
var handler_key__6144__auto__ = cljs.core.cst$kw$callback_DASH_channel_DASH_factory;
var handler__6145__auto__ = handler_key__6144__auto__.cljs$core$IFn$_invoke$arity$1(config__6143__auto__);

return (handler__6145__auto__.cljs$core$IFn$_invoke$arity$1 ? handler__6145__auto__.cljs$core$IFn$_invoke$arity$1(config__6143__auto__) : handler__6145__auto__.call(null,config__6143__auto__));
})();
var marshalled_tab_id_14508_14524 = (function (){var omit_test_14514 = tab_id;
if(cljs.core.keyword_identical_QMARK_(omit_test_14514,cljs.core.cst$kw$omit)){
return cljs.core.cst$kw$omit;
} else {
return omit_test_14514;
}
})();
var marshalled_details_14509_14525 = (function (){var omit_test_14515 = details;
if(cljs.core.keyword_identical_QMARK_(omit_test_14515,cljs.core.cst$kw$omit)){
return cljs.core.cst$kw$omit;
} else {
return omit_test_14515;
}
})();
var marshalled_callback_14510_14526 = (function (){var config__6143__auto__ = config;
var handler_key__6144__auto__ = cljs.core.cst$kw$callback_DASH_fn_DASH_factory;
var handler__6145__auto__ = handler_key__6144__auto__.cljs$core$IFn$_invoke$arity$1(config__6143__auto__);

var G__14516 = config__6143__auto__;
var G__14517 = new cljs.core.PersistentArrayMap(null, 5, [cljs.core.cst$kw$id,cljs.core.cst$kw$chromex$ext$tabs_SLASH_insert_DASH_css,cljs.core.cst$kw$name,"insertCSS",cljs.core.cst$kw$callback_QMARK_,true,cljs.core.cst$kw$params,new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentArrayMap(null, 3, [cljs.core.cst$kw$name,"tab-id",cljs.core.cst$kw$optional_QMARK_,true,cljs.core.cst$kw$type,"integer"], null),new cljs.core.PersistentArrayMap(null, 2, [cljs.core.cst$kw$name,"details",cljs.core.cst$kw$type,"object"], null),new cljs.core.PersistentArrayMap(null, 3, [cljs.core.cst$kw$name,"callback",cljs.core.cst$kw$optional_QMARK_,true,cljs.core.cst$kw$type,cljs.core.cst$kw$callback], null)], null),cljs.core.cst$kw$function_QMARK_,true], null);
var G__14518 = callback_chan_14506;
return (handler__6145__auto__.cljs$core$IFn$_invoke$arity$3 ? handler__6145__auto__.cljs$core$IFn$_invoke$arity$3(G__14516,G__14517,G__14518) : handler__6145__auto__.call(null,G__14516,G__14517,G__14518));
})();
var result_14507_14527 = (function (){var final_args_array_14511 = chromex.support.prepare_final_args_array(new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_tab_id_14508_14524,"tab-id",true], null),new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_details_14509_14525,"details",null], null),new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_callback_14510_14526,"callback",true], null)], null),"chrome.tabs.insertCSS");
var ns_14512 = (function (){var target_obj_14519 = cljs.core.cst$kw$root.cljs$core$IFn$_invoke$arity$1(config);
var next_obj_14520 = (target_obj_14519["chrome"]);
var next_obj_14521 = (next_obj_14520["tabs"]);
return next_obj_14521;
})();
var config__6181__auto___14528 = config;
var api_check_fn__6182__auto___14529 = cljs.core.cst$kw$missing_DASH_api_DASH_check_DASH_fn.cljs$core$IFn$_invoke$arity$1(config__6181__auto___14528);

(api_check_fn__6182__auto___14529.cljs$core$IFn$_invoke$arity$3 ? api_check_fn__6182__auto___14529.cljs$core$IFn$_invoke$arity$3("chrome.tabs.insertCSS",ns_14512,"insertCSS") : api_check_fn__6182__auto___14529.call(null,"chrome.tabs.insertCSS",ns_14512,"insertCSS"));


var target_14513 = (function (){var target_obj_14522 = ns_14512;
var next_obj_14523 = (target_obj_14522["insertCSS"]);
if((!((next_obj_14523 == null)))){
return next_obj_14523;
} else {
return null;
}
})();
return target_14513.apply(ns_14512,final_args_array_14511);
})();

return callback_chan_14506;
});
chromex.ext.tabs.set_zoom_STAR_ = (function chromex$ext$tabs$set_zoom_STAR_(config,tab_id,zoom_factor){
var callback_chan_14530 = (function (){var config__6143__auto__ = config;
var handler_key__6144__auto__ = cljs.core.cst$kw$callback_DASH_channel_DASH_factory;
var handler__6145__auto__ = handler_key__6144__auto__.cljs$core$IFn$_invoke$arity$1(config__6143__auto__);

return (handler__6145__auto__.cljs$core$IFn$_invoke$arity$1 ? handler__6145__auto__.cljs$core$IFn$_invoke$arity$1(config__6143__auto__) : handler__6145__auto__.call(null,config__6143__auto__));
})();
var marshalled_tab_id_14532_14548 = (function (){var omit_test_14538 = tab_id;
if(cljs.core.keyword_identical_QMARK_(omit_test_14538,cljs.core.cst$kw$omit)){
return cljs.core.cst$kw$omit;
} else {
return omit_test_14538;
}
})();
var marshalled_zoom_factor_14533_14549 = (function (){var omit_test_14539 = zoom_factor;
if(cljs.core.keyword_identical_QMARK_(omit_test_14539,cljs.core.cst$kw$omit)){
return cljs.core.cst$kw$omit;
} else {
return omit_test_14539;
}
})();
var marshalled_callback_14534_14550 = (function (){var config__6143__auto__ = config;
var handler_key__6144__auto__ = cljs.core.cst$kw$callback_DASH_fn_DASH_factory;
var handler__6145__auto__ = handler_key__6144__auto__.cljs$core$IFn$_invoke$arity$1(config__6143__auto__);

var G__14540 = config__6143__auto__;
var G__14541 = new cljs.core.PersistentArrayMap(null, 6, [cljs.core.cst$kw$id,cljs.core.cst$kw$chromex$ext$tabs_SLASH_set_DASH_zoom,cljs.core.cst$kw$name,"setZoom",cljs.core.cst$kw$since,"42",cljs.core.cst$kw$callback_QMARK_,true,cljs.core.cst$kw$params,new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentArrayMap(null, 3, [cljs.core.cst$kw$name,"tab-id",cljs.core.cst$kw$optional_QMARK_,true,cljs.core.cst$kw$type,"integer"], null),new cljs.core.PersistentArrayMap(null, 2, [cljs.core.cst$kw$name,"zoom-factor",cljs.core.cst$kw$type,"double"], null),new cljs.core.PersistentArrayMap(null, 3, [cljs.core.cst$kw$name,"callback",cljs.core.cst$kw$optional_QMARK_,true,cljs.core.cst$kw$type,cljs.core.cst$kw$callback], null)], null),cljs.core.cst$kw$function_QMARK_,true], null);
var G__14542 = callback_chan_14530;
return (handler__6145__auto__.cljs$core$IFn$_invoke$arity$3 ? handler__6145__auto__.cljs$core$IFn$_invoke$arity$3(G__14540,G__14541,G__14542) : handler__6145__auto__.call(null,G__14540,G__14541,G__14542));
})();
var result_14531_14551 = (function (){var final_args_array_14535 = chromex.support.prepare_final_args_array(new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_tab_id_14532_14548,"tab-id",true], null),new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_zoom_factor_14533_14549,"zoom-factor",null], null),new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_callback_14534_14550,"callback",true], null)], null),"chrome.tabs.setZoom");
var ns_14536 = (function (){var target_obj_14543 = cljs.core.cst$kw$root.cljs$core$IFn$_invoke$arity$1(config);
var next_obj_14544 = (target_obj_14543["chrome"]);
var next_obj_14545 = (next_obj_14544["tabs"]);
return next_obj_14545;
})();
var config__6181__auto___14552 = config;
var api_check_fn__6182__auto___14553 = cljs.core.cst$kw$missing_DASH_api_DASH_check_DASH_fn.cljs$core$IFn$_invoke$arity$1(config__6181__auto___14552);

(api_check_fn__6182__auto___14553.cljs$core$IFn$_invoke$arity$3 ? api_check_fn__6182__auto___14553.cljs$core$IFn$_invoke$arity$3("chrome.tabs.setZoom",ns_14536,"setZoom") : api_check_fn__6182__auto___14553.call(null,"chrome.tabs.setZoom",ns_14536,"setZoom"));


var target_14537 = (function (){var target_obj_14546 = ns_14536;
var next_obj_14547 = (target_obj_14546["setZoom"]);
if((!((next_obj_14547 == null)))){
return next_obj_14547;
} else {
return null;
}
})();
return target_14537.apply(ns_14536,final_args_array_14535);
})();

return callback_chan_14530;
});
chromex.ext.tabs.get_zoom_STAR_ = (function chromex$ext$tabs$get_zoom_STAR_(config,tab_id){
var callback_chan_14554 = (function (){var config__6143__auto__ = config;
var handler_key__6144__auto__ = cljs.core.cst$kw$callback_DASH_channel_DASH_factory;
var handler__6145__auto__ = handler_key__6144__auto__.cljs$core$IFn$_invoke$arity$1(config__6143__auto__);

return (handler__6145__auto__.cljs$core$IFn$_invoke$arity$1 ? handler__6145__auto__.cljs$core$IFn$_invoke$arity$1(config__6143__auto__) : handler__6145__auto__.call(null,config__6143__auto__));
})();
var marshalled_tab_id_14556_14575 = (function (){var omit_test_14561 = tab_id;
if(cljs.core.keyword_identical_QMARK_(omit_test_14561,cljs.core.cst$kw$omit)){
return cljs.core.cst$kw$omit;
} else {
return omit_test_14561;
}
})();
var marshalled_callback_14557_14576 = ((function (marshalled_tab_id_14556_14575,callback_chan_14554){
return (function (cb_zoom_factor_14562){
var fexpr__14566 = (function (){var config__6143__auto__ = config;
var handler_key__6144__auto__ = cljs.core.cst$kw$callback_DASH_fn_DASH_factory;
var handler__6145__auto__ = handler_key__6144__auto__.cljs$core$IFn$_invoke$arity$1(config__6143__auto__);

var G__14567 = config__6143__auto__;
var G__14568 = new cljs.core.PersistentArrayMap(null, 6, [cljs.core.cst$kw$id,cljs.core.cst$kw$chromex$ext$tabs_SLASH_get_DASH_zoom,cljs.core.cst$kw$name,"getZoom",cljs.core.cst$kw$since,"42",cljs.core.cst$kw$callback_QMARK_,true,cljs.core.cst$kw$params,new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentArrayMap(null, 3, [cljs.core.cst$kw$name,"tab-id",cljs.core.cst$kw$optional_QMARK_,true,cljs.core.cst$kw$type,"integer"], null),new cljs.core.PersistentArrayMap(null, 3, [cljs.core.cst$kw$name,"callback",cljs.core.cst$kw$type,cljs.core.cst$kw$callback,cljs.core.cst$kw$callback,new cljs.core.PersistentArrayMap(null, 1, [cljs.core.cst$kw$params,new cljs.core.PersistentVector(null, 1, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentArrayMap(null, 2, [cljs.core.cst$kw$name,"zoom-factor",cljs.core.cst$kw$type,"double"], null)], null)], null)], null)], null),cljs.core.cst$kw$function_QMARK_,true], null);
var G__14569 = callback_chan_14554;
return (handler__6145__auto__.cljs$core$IFn$_invoke$arity$3 ? handler__6145__auto__.cljs$core$IFn$_invoke$arity$3(G__14567,G__14568,G__14569) : handler__6145__auto__.call(null,G__14567,G__14568,G__14569));
})();
return (fexpr__14566.cljs$core$IFn$_invoke$arity$1 ? fexpr__14566.cljs$core$IFn$_invoke$arity$1(cb_zoom_factor_14562) : fexpr__14566.call(null,cb_zoom_factor_14562));
});})(marshalled_tab_id_14556_14575,callback_chan_14554))
;
var result_14555_14577 = (function (){var final_args_array_14558 = chromex.support.prepare_final_args_array(new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_tab_id_14556_14575,"tab-id",true], null),new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_callback_14557_14576,"callback",null], null)], null),"chrome.tabs.getZoom");
var ns_14559 = (function (){var target_obj_14570 = cljs.core.cst$kw$root.cljs$core$IFn$_invoke$arity$1(config);
var next_obj_14571 = (target_obj_14570["chrome"]);
var next_obj_14572 = (next_obj_14571["tabs"]);
return next_obj_14572;
})();
var config__6181__auto___14578 = config;
var api_check_fn__6182__auto___14579 = cljs.core.cst$kw$missing_DASH_api_DASH_check_DASH_fn.cljs$core$IFn$_invoke$arity$1(config__6181__auto___14578);

(api_check_fn__6182__auto___14579.cljs$core$IFn$_invoke$arity$3 ? api_check_fn__6182__auto___14579.cljs$core$IFn$_invoke$arity$3("chrome.tabs.getZoom",ns_14559,"getZoom") : api_check_fn__6182__auto___14579.call(null,"chrome.tabs.getZoom",ns_14559,"getZoom"));


var target_14560 = (function (){var target_obj_14573 = ns_14559;
var next_obj_14574 = (target_obj_14573["getZoom"]);
if((!((next_obj_14574 == null)))){
return next_obj_14574;
} else {
return null;
}
})();
return target_14560.apply(ns_14559,final_args_array_14558);
})();

return callback_chan_14554;
});
chromex.ext.tabs.set_zoom_settings_STAR_ = (function chromex$ext$tabs$set_zoom_settings_STAR_(config,tab_id,zoom_settings){
var callback_chan_14580 = (function (){var config__6143__auto__ = config;
var handler_key__6144__auto__ = cljs.core.cst$kw$callback_DASH_channel_DASH_factory;
var handler__6145__auto__ = handler_key__6144__auto__.cljs$core$IFn$_invoke$arity$1(config__6143__auto__);

return (handler__6145__auto__.cljs$core$IFn$_invoke$arity$1 ? handler__6145__auto__.cljs$core$IFn$_invoke$arity$1(config__6143__auto__) : handler__6145__auto__.call(null,config__6143__auto__));
})();
var marshalled_tab_id_14582_14598 = (function (){var omit_test_14588 = tab_id;
if(cljs.core.keyword_identical_QMARK_(omit_test_14588,cljs.core.cst$kw$omit)){
return cljs.core.cst$kw$omit;
} else {
return omit_test_14588;
}
})();
var marshalled_zoom_settings_14583_14599 = (function (){var omit_test_14589 = zoom_settings;
if(cljs.core.keyword_identical_QMARK_(omit_test_14589,cljs.core.cst$kw$omit)){
return cljs.core.cst$kw$omit;
} else {
return omit_test_14589;
}
})();
var marshalled_callback_14584_14600 = (function (){var config__6143__auto__ = config;
var handler_key__6144__auto__ = cljs.core.cst$kw$callback_DASH_fn_DASH_factory;
var handler__6145__auto__ = handler_key__6144__auto__.cljs$core$IFn$_invoke$arity$1(config__6143__auto__);

var G__14590 = config__6143__auto__;
var G__14591 = new cljs.core.PersistentArrayMap(null, 6, [cljs.core.cst$kw$id,cljs.core.cst$kw$chromex$ext$tabs_SLASH_set_DASH_zoom_DASH_settings,cljs.core.cst$kw$name,"setZoomSettings",cljs.core.cst$kw$since,"42",cljs.core.cst$kw$callback_QMARK_,true,cljs.core.cst$kw$params,new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentArrayMap(null, 3, [cljs.core.cst$kw$name,"tab-id",cljs.core.cst$kw$optional_QMARK_,true,cljs.core.cst$kw$type,"integer"], null),new cljs.core.PersistentArrayMap(null, 2, [cljs.core.cst$kw$name,"zoom-settings",cljs.core.cst$kw$type,"tabs.ZoomSettings"], null),new cljs.core.PersistentArrayMap(null, 3, [cljs.core.cst$kw$name,"callback",cljs.core.cst$kw$optional_QMARK_,true,cljs.core.cst$kw$type,cljs.core.cst$kw$callback], null)], null),cljs.core.cst$kw$function_QMARK_,true], null);
var G__14592 = callback_chan_14580;
return (handler__6145__auto__.cljs$core$IFn$_invoke$arity$3 ? handler__6145__auto__.cljs$core$IFn$_invoke$arity$3(G__14590,G__14591,G__14592) : handler__6145__auto__.call(null,G__14590,G__14591,G__14592));
})();
var result_14581_14601 = (function (){var final_args_array_14585 = chromex.support.prepare_final_args_array(new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_tab_id_14582_14598,"tab-id",true], null),new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_zoom_settings_14583_14599,"zoom-settings",null], null),new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_callback_14584_14600,"callback",true], null)], null),"chrome.tabs.setZoomSettings");
var ns_14586 = (function (){var target_obj_14593 = cljs.core.cst$kw$root.cljs$core$IFn$_invoke$arity$1(config);
var next_obj_14594 = (target_obj_14593["chrome"]);
var next_obj_14595 = (next_obj_14594["tabs"]);
return next_obj_14595;
})();
var config__6181__auto___14602 = config;
var api_check_fn__6182__auto___14603 = cljs.core.cst$kw$missing_DASH_api_DASH_check_DASH_fn.cljs$core$IFn$_invoke$arity$1(config__6181__auto___14602);

(api_check_fn__6182__auto___14603.cljs$core$IFn$_invoke$arity$3 ? api_check_fn__6182__auto___14603.cljs$core$IFn$_invoke$arity$3("chrome.tabs.setZoomSettings",ns_14586,"setZoomSettings") : api_check_fn__6182__auto___14603.call(null,"chrome.tabs.setZoomSettings",ns_14586,"setZoomSettings"));


var target_14587 = (function (){var target_obj_14596 = ns_14586;
var next_obj_14597 = (target_obj_14596["setZoomSettings"]);
if((!((next_obj_14597 == null)))){
return next_obj_14597;
} else {
return null;
}
})();
return target_14587.apply(ns_14586,final_args_array_14585);
})();

return callback_chan_14580;
});
chromex.ext.tabs.get_zoom_settings_STAR_ = (function chromex$ext$tabs$get_zoom_settings_STAR_(config,tab_id){
var callback_chan_14604 = (function (){var config__6143__auto__ = config;
var handler_key__6144__auto__ = cljs.core.cst$kw$callback_DASH_channel_DASH_factory;
var handler__6145__auto__ = handler_key__6144__auto__.cljs$core$IFn$_invoke$arity$1(config__6143__auto__);

return (handler__6145__auto__.cljs$core$IFn$_invoke$arity$1 ? handler__6145__auto__.cljs$core$IFn$_invoke$arity$1(config__6143__auto__) : handler__6145__auto__.call(null,config__6143__auto__));
})();
var marshalled_tab_id_14606_14625 = (function (){var omit_test_14611 = tab_id;
if(cljs.core.keyword_identical_QMARK_(omit_test_14611,cljs.core.cst$kw$omit)){
return cljs.core.cst$kw$omit;
} else {
return omit_test_14611;
}
})();
var marshalled_callback_14607_14626 = ((function (marshalled_tab_id_14606_14625,callback_chan_14604){
return (function (cb_zoom_settings_14612){
var fexpr__14616 = (function (){var config__6143__auto__ = config;
var handler_key__6144__auto__ = cljs.core.cst$kw$callback_DASH_fn_DASH_factory;
var handler__6145__auto__ = handler_key__6144__auto__.cljs$core$IFn$_invoke$arity$1(config__6143__auto__);

var G__14617 = config__6143__auto__;
var G__14618 = new cljs.core.PersistentArrayMap(null, 6, [cljs.core.cst$kw$id,cljs.core.cst$kw$chromex$ext$tabs_SLASH_get_DASH_zoom_DASH_settings,cljs.core.cst$kw$name,"getZoomSettings",cljs.core.cst$kw$since,"42",cljs.core.cst$kw$callback_QMARK_,true,cljs.core.cst$kw$params,new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentArrayMap(null, 3, [cljs.core.cst$kw$name,"tab-id",cljs.core.cst$kw$optional_QMARK_,true,cljs.core.cst$kw$type,"integer"], null),new cljs.core.PersistentArrayMap(null, 3, [cljs.core.cst$kw$name,"callback",cljs.core.cst$kw$type,cljs.core.cst$kw$callback,cljs.core.cst$kw$callback,new cljs.core.PersistentArrayMap(null, 1, [cljs.core.cst$kw$params,new cljs.core.PersistentVector(null, 1, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentArrayMap(null, 2, [cljs.core.cst$kw$name,"zoom-settings",cljs.core.cst$kw$type,"tabs.ZoomSettings"], null)], null)], null)], null)], null),cljs.core.cst$kw$function_QMARK_,true], null);
var G__14619 = callback_chan_14604;
return (handler__6145__auto__.cljs$core$IFn$_invoke$arity$3 ? handler__6145__auto__.cljs$core$IFn$_invoke$arity$3(G__14617,G__14618,G__14619) : handler__6145__auto__.call(null,G__14617,G__14618,G__14619));
})();
return (fexpr__14616.cljs$core$IFn$_invoke$arity$1 ? fexpr__14616.cljs$core$IFn$_invoke$arity$1(cb_zoom_settings_14612) : fexpr__14616.call(null,cb_zoom_settings_14612));
});})(marshalled_tab_id_14606_14625,callback_chan_14604))
;
var result_14605_14627 = (function (){var final_args_array_14608 = chromex.support.prepare_final_args_array(new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_tab_id_14606_14625,"tab-id",true], null),new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_callback_14607_14626,"callback",null], null)], null),"chrome.tabs.getZoomSettings");
var ns_14609 = (function (){var target_obj_14620 = cljs.core.cst$kw$root.cljs$core$IFn$_invoke$arity$1(config);
var next_obj_14621 = (target_obj_14620["chrome"]);
var next_obj_14622 = (next_obj_14621["tabs"]);
return next_obj_14622;
})();
var config__6181__auto___14628 = config;
var api_check_fn__6182__auto___14629 = cljs.core.cst$kw$missing_DASH_api_DASH_check_DASH_fn.cljs$core$IFn$_invoke$arity$1(config__6181__auto___14628);

(api_check_fn__6182__auto___14629.cljs$core$IFn$_invoke$arity$3 ? api_check_fn__6182__auto___14629.cljs$core$IFn$_invoke$arity$3("chrome.tabs.getZoomSettings",ns_14609,"getZoomSettings") : api_check_fn__6182__auto___14629.call(null,"chrome.tabs.getZoomSettings",ns_14609,"getZoomSettings"));


var target_14610 = (function (){var target_obj_14623 = ns_14609;
var next_obj_14624 = (target_obj_14623["getZoomSettings"]);
if((!((next_obj_14624 == null)))){
return next_obj_14624;
} else {
return null;
}
})();
return target_14610.apply(ns_14609,final_args_array_14608);
})();

return callback_chan_14604;
});
chromex.ext.tabs.discard_STAR_ = (function chromex$ext$tabs$discard_STAR_(config,tab_id){
var callback_chan_14630 = (function (){var config__6143__auto__ = config;
var handler_key__6144__auto__ = cljs.core.cst$kw$callback_DASH_channel_DASH_factory;
var handler__6145__auto__ = handler_key__6144__auto__.cljs$core$IFn$_invoke$arity$1(config__6143__auto__);

return (handler__6145__auto__.cljs$core$IFn$_invoke$arity$1 ? handler__6145__auto__.cljs$core$IFn$_invoke$arity$1(config__6143__auto__) : handler__6145__auto__.call(null,config__6143__auto__));
})();
var marshalled_tab_id_14632_14651 = (function (){var omit_test_14637 = tab_id;
if(cljs.core.keyword_identical_QMARK_(omit_test_14637,cljs.core.cst$kw$omit)){
return cljs.core.cst$kw$omit;
} else {
return omit_test_14637;
}
})();
var marshalled_callback_14633_14652 = ((function (marshalled_tab_id_14632_14651,callback_chan_14630){
return (function (cb_tab_14638){
var fexpr__14642 = (function (){var config__6143__auto__ = config;
var handler_key__6144__auto__ = cljs.core.cst$kw$callback_DASH_fn_DASH_factory;
var handler__6145__auto__ = handler_key__6144__auto__.cljs$core$IFn$_invoke$arity$1(config__6143__auto__);

var G__14643 = config__6143__auto__;
var G__14644 = new cljs.core.PersistentArrayMap(null, 6, [cljs.core.cst$kw$id,cljs.core.cst$kw$chromex$ext$tabs_SLASH_discard,cljs.core.cst$kw$name,"discard",cljs.core.cst$kw$since,"54",cljs.core.cst$kw$callback_QMARK_,true,cljs.core.cst$kw$params,new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentArrayMap(null, 3, [cljs.core.cst$kw$name,"tab-id",cljs.core.cst$kw$optional_QMARK_,true,cljs.core.cst$kw$type,"integer"], null),new cljs.core.PersistentArrayMap(null, 4, [cljs.core.cst$kw$name,"callback",cljs.core.cst$kw$optional_QMARK_,true,cljs.core.cst$kw$type,cljs.core.cst$kw$callback,cljs.core.cst$kw$callback,new cljs.core.PersistentArrayMap(null, 1, [cljs.core.cst$kw$params,new cljs.core.PersistentVector(null, 1, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentArrayMap(null, 3, [cljs.core.cst$kw$name,"tab",cljs.core.cst$kw$optional_QMARK_,true,cljs.core.cst$kw$type,"tabs.Tab"], null)], null)], null)], null)], null),cljs.core.cst$kw$function_QMARK_,true], null);
var G__14645 = callback_chan_14630;
return (handler__6145__auto__.cljs$core$IFn$_invoke$arity$3 ? handler__6145__auto__.cljs$core$IFn$_invoke$arity$3(G__14643,G__14644,G__14645) : handler__6145__auto__.call(null,G__14643,G__14644,G__14645));
})();
return (fexpr__14642.cljs$core$IFn$_invoke$arity$1 ? fexpr__14642.cljs$core$IFn$_invoke$arity$1(cb_tab_14638) : fexpr__14642.call(null,cb_tab_14638));
});})(marshalled_tab_id_14632_14651,callback_chan_14630))
;
var result_14631_14653 = (function (){var final_args_array_14634 = chromex.support.prepare_final_args_array(new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_tab_id_14632_14651,"tab-id",true], null),new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_callback_14633_14652,"callback",true], null)], null),"chrome.tabs.discard");
var ns_14635 = (function (){var target_obj_14646 = cljs.core.cst$kw$root.cljs$core$IFn$_invoke$arity$1(config);
var next_obj_14647 = (target_obj_14646["chrome"]);
var next_obj_14648 = (next_obj_14647["tabs"]);
return next_obj_14648;
})();
var config__6181__auto___14654 = config;
var api_check_fn__6182__auto___14655 = cljs.core.cst$kw$missing_DASH_api_DASH_check_DASH_fn.cljs$core$IFn$_invoke$arity$1(config__6181__auto___14654);

(api_check_fn__6182__auto___14655.cljs$core$IFn$_invoke$arity$3 ? api_check_fn__6182__auto___14655.cljs$core$IFn$_invoke$arity$3("chrome.tabs.discard",ns_14635,"discard") : api_check_fn__6182__auto___14655.call(null,"chrome.tabs.discard",ns_14635,"discard"));


var target_14636 = (function (){var target_obj_14649 = ns_14635;
var next_obj_14650 = (target_obj_14649["discard"]);
if((!((next_obj_14650 == null)))){
return next_obj_14650;
} else {
return null;
}
})();
return target_14636.apply(ns_14635,final_args_array_14634);
})();

return callback_chan_14630;
});
chromex.ext.tabs.go_forward_STAR_ = (function chromex$ext$tabs$go_forward_STAR_(config,tab_id){
var callback_chan_14656 = (function (){var config__6143__auto__ = config;
var handler_key__6144__auto__ = cljs.core.cst$kw$callback_DASH_channel_DASH_factory;
var handler__6145__auto__ = handler_key__6144__auto__.cljs$core$IFn$_invoke$arity$1(config__6143__auto__);

return (handler__6145__auto__.cljs$core$IFn$_invoke$arity$1 ? handler__6145__auto__.cljs$core$IFn$_invoke$arity$1(config__6143__auto__) : handler__6145__auto__.call(null,config__6143__auto__));
})();
var marshalled_tab_id_14658_14672 = (function (){var omit_test_14663 = tab_id;
if(cljs.core.keyword_identical_QMARK_(omit_test_14663,cljs.core.cst$kw$omit)){
return cljs.core.cst$kw$omit;
} else {
return omit_test_14663;
}
})();
var marshalled_callback_14659_14673 = (function (){var config__6143__auto__ = config;
var handler_key__6144__auto__ = cljs.core.cst$kw$callback_DASH_fn_DASH_factory;
var handler__6145__auto__ = handler_key__6144__auto__.cljs$core$IFn$_invoke$arity$1(config__6143__auto__);

var G__14664 = config__6143__auto__;
var G__14665 = new cljs.core.PersistentArrayMap(null, 6, [cljs.core.cst$kw$id,cljs.core.cst$kw$chromex$ext$tabs_SLASH_go_DASH_forward,cljs.core.cst$kw$name,"goForward",cljs.core.cst$kw$since,"72",cljs.core.cst$kw$callback_QMARK_,true,cljs.core.cst$kw$params,new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentArrayMap(null, 3, [cljs.core.cst$kw$name,"tab-id",cljs.core.cst$kw$optional_QMARK_,true,cljs.core.cst$kw$type,"integer"], null),new cljs.core.PersistentArrayMap(null, 3, [cljs.core.cst$kw$name,"callback",cljs.core.cst$kw$optional_QMARK_,true,cljs.core.cst$kw$type,cljs.core.cst$kw$callback], null)], null),cljs.core.cst$kw$function_QMARK_,true], null);
var G__14666 = callback_chan_14656;
return (handler__6145__auto__.cljs$core$IFn$_invoke$arity$3 ? handler__6145__auto__.cljs$core$IFn$_invoke$arity$3(G__14664,G__14665,G__14666) : handler__6145__auto__.call(null,G__14664,G__14665,G__14666));
})();
var result_14657_14674 = (function (){var final_args_array_14660 = chromex.support.prepare_final_args_array(new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_tab_id_14658_14672,"tab-id",true], null),new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_callback_14659_14673,"callback",true], null)], null),"chrome.tabs.goForward");
var ns_14661 = (function (){var target_obj_14667 = cljs.core.cst$kw$root.cljs$core$IFn$_invoke$arity$1(config);
var next_obj_14668 = (target_obj_14667["chrome"]);
var next_obj_14669 = (next_obj_14668["tabs"]);
return next_obj_14669;
})();
var config__6181__auto___14675 = config;
var api_check_fn__6182__auto___14676 = cljs.core.cst$kw$missing_DASH_api_DASH_check_DASH_fn.cljs$core$IFn$_invoke$arity$1(config__6181__auto___14675);

(api_check_fn__6182__auto___14676.cljs$core$IFn$_invoke$arity$3 ? api_check_fn__6182__auto___14676.cljs$core$IFn$_invoke$arity$3("chrome.tabs.goForward",ns_14661,"goForward") : api_check_fn__6182__auto___14676.call(null,"chrome.tabs.goForward",ns_14661,"goForward"));


var target_14662 = (function (){var target_obj_14670 = ns_14661;
var next_obj_14671 = (target_obj_14670["goForward"]);
if((!((next_obj_14671 == null)))){
return next_obj_14671;
} else {
return null;
}
})();
return target_14662.apply(ns_14661,final_args_array_14660);
})();

return callback_chan_14656;
});
chromex.ext.tabs.go_back_STAR_ = (function chromex$ext$tabs$go_back_STAR_(config,tab_id){
var callback_chan_14677 = (function (){var config__6143__auto__ = config;
var handler_key__6144__auto__ = cljs.core.cst$kw$callback_DASH_channel_DASH_factory;
var handler__6145__auto__ = handler_key__6144__auto__.cljs$core$IFn$_invoke$arity$1(config__6143__auto__);

return (handler__6145__auto__.cljs$core$IFn$_invoke$arity$1 ? handler__6145__auto__.cljs$core$IFn$_invoke$arity$1(config__6143__auto__) : handler__6145__auto__.call(null,config__6143__auto__));
})();
var marshalled_tab_id_14679_14693 = (function (){var omit_test_14684 = tab_id;
if(cljs.core.keyword_identical_QMARK_(omit_test_14684,cljs.core.cst$kw$omit)){
return cljs.core.cst$kw$omit;
} else {
return omit_test_14684;
}
})();
var marshalled_callback_14680_14694 = (function (){var config__6143__auto__ = config;
var handler_key__6144__auto__ = cljs.core.cst$kw$callback_DASH_fn_DASH_factory;
var handler__6145__auto__ = handler_key__6144__auto__.cljs$core$IFn$_invoke$arity$1(config__6143__auto__);

var G__14685 = config__6143__auto__;
var G__14686 = new cljs.core.PersistentArrayMap(null, 6, [cljs.core.cst$kw$id,cljs.core.cst$kw$chromex$ext$tabs_SLASH_go_DASH_back,cljs.core.cst$kw$name,"goBack",cljs.core.cst$kw$since,"72",cljs.core.cst$kw$callback_QMARK_,true,cljs.core.cst$kw$params,new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentArrayMap(null, 3, [cljs.core.cst$kw$name,"tab-id",cljs.core.cst$kw$optional_QMARK_,true,cljs.core.cst$kw$type,"integer"], null),new cljs.core.PersistentArrayMap(null, 3, [cljs.core.cst$kw$name,"callback",cljs.core.cst$kw$optional_QMARK_,true,cljs.core.cst$kw$type,cljs.core.cst$kw$callback], null)], null),cljs.core.cst$kw$function_QMARK_,true], null);
var G__14687 = callback_chan_14677;
return (handler__6145__auto__.cljs$core$IFn$_invoke$arity$3 ? handler__6145__auto__.cljs$core$IFn$_invoke$arity$3(G__14685,G__14686,G__14687) : handler__6145__auto__.call(null,G__14685,G__14686,G__14687));
})();
var result_14678_14695 = (function (){var final_args_array_14681 = chromex.support.prepare_final_args_array(new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_tab_id_14679_14693,"tab-id",true], null),new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_callback_14680_14694,"callback",true], null)], null),"chrome.tabs.goBack");
var ns_14682 = (function (){var target_obj_14688 = cljs.core.cst$kw$root.cljs$core$IFn$_invoke$arity$1(config);
var next_obj_14689 = (target_obj_14688["chrome"]);
var next_obj_14690 = (next_obj_14689["tabs"]);
return next_obj_14690;
})();
var config__6181__auto___14696 = config;
var api_check_fn__6182__auto___14697 = cljs.core.cst$kw$missing_DASH_api_DASH_check_DASH_fn.cljs$core$IFn$_invoke$arity$1(config__6181__auto___14696);

(api_check_fn__6182__auto___14697.cljs$core$IFn$_invoke$arity$3 ? api_check_fn__6182__auto___14697.cljs$core$IFn$_invoke$arity$3("chrome.tabs.goBack",ns_14682,"goBack") : api_check_fn__6182__auto___14697.call(null,"chrome.tabs.goBack",ns_14682,"goBack"));


var target_14683 = (function (){var target_obj_14691 = ns_14682;
var next_obj_14692 = (target_obj_14691["goBack"]);
if((!((next_obj_14692 == null)))){
return next_obj_14692;
} else {
return null;
}
})();
return target_14683.apply(ns_14682,final_args_array_14681);
})();

return callback_chan_14677;
});
chromex.ext.tabs.on_created_STAR_ = (function chromex$ext$tabs$on_created_STAR_(var_args){
var args__4647__auto__ = [];
var len__4641__auto___14717 = arguments.length;
var i__4642__auto___14718 = (0);
while(true){
if((i__4642__auto___14718 < len__4641__auto___14717)){
args__4647__auto__.push((arguments[i__4642__auto___14718]));

var G__14719 = (i__4642__auto___14718 + (1));
i__4642__auto___14718 = G__14719;
continue;
} else {
}
break;
}

var argseq__4648__auto__ = ((((2) < args__4647__auto__.length))?(new cljs.core.IndexedSeq(args__4647__auto__.slice((2)),(0),null)):null);
return chromex.ext.tabs.on_created_STAR_.cljs$core$IFn$_invoke$arity$variadic((arguments[(0)]),(arguments[(1)]),argseq__4648__auto__);
});

chromex.ext.tabs.on_created_STAR_.cljs$core$IFn$_invoke$arity$variadic = (function (config,channel,args){
var event_fn_14701 = (function (){var config__6143__auto__ = config;
var handler_key__6144__auto__ = cljs.core.cst$kw$event_DASH_listener_DASH_factory;
var handler__6145__auto__ = handler_key__6144__auto__.cljs$core$IFn$_invoke$arity$1(config__6143__auto__);

var G__14709 = config__6143__auto__;
var G__14710 = cljs.core.cst$kw$chromex$ext$tabs_SLASH_on_DASH_created;
var G__14711 = channel;
return (handler__6145__auto__.cljs$core$IFn$_invoke$arity$3 ? handler__6145__auto__.cljs$core$IFn$_invoke$arity$3(G__14709,G__14710,G__14711) : handler__6145__auto__.call(null,G__14709,G__14710,G__14711));
})();
var handler_fn_14702 = ((function (event_fn_14701){
return (function (cb_tab_14707){
return (event_fn_14701.cljs$core$IFn$_invoke$arity$1 ? event_fn_14701.cljs$core$IFn$_invoke$arity$1(cb_tab_14707) : event_fn_14701.call(null,cb_tab_14707));
});})(event_fn_14701))
;
var logging_fn_14703 = ((function (event_fn_14701,handler_fn_14702){
return (function (cb_param_tab_14708){

return handler_fn_14702(cb_param_tab_14708);
});})(event_fn_14701,handler_fn_14702))
;
var ns_obj_14706 = (function (){var target_obj_14712 = cljs.core.cst$kw$root.cljs$core$IFn$_invoke$arity$1(config);
var next_obj_14713 = (target_obj_14712["chrome"]);
var next_obj_14714 = (next_obj_14713["tabs"]);
return next_obj_14714;
})();
var config__6181__auto___14720 = config;
var api_check_fn__6182__auto___14721 = cljs.core.cst$kw$missing_DASH_api_DASH_check_DASH_fn.cljs$core$IFn$_invoke$arity$1(config__6181__auto___14720);

(api_check_fn__6182__auto___14721.cljs$core$IFn$_invoke$arity$3 ? api_check_fn__6182__auto___14721.cljs$core$IFn$_invoke$arity$3("chrome.tabs.onCreated",ns_obj_14706,"onCreated") : api_check_fn__6182__auto___14721.call(null,"chrome.tabs.onCreated",ns_obj_14706,"onCreated"));

var event_obj_14704 = (function (){var target_obj_14715 = ns_obj_14706;
var next_obj_14716 = (target_obj_14715["onCreated"]);
return next_obj_14716;
})();
var result_14705 = chromex.chrome_event_subscription.make_chrome_event_subscription(event_obj_14704,logging_fn_14703,channel);
result_14705.chromex$protocols$chrome_event_subscription$IChromeEventSubscription$subscribe_BANG_$arity$2(null,args);

return result_14705;
});

chromex.ext.tabs.on_created_STAR_.cljs$lang$maxFixedArity = (2);

/** @this {Function} */
chromex.ext.tabs.on_created_STAR_.cljs$lang$applyTo = (function (seq14698){
var G__14699 = cljs.core.first(seq14698);
var seq14698__$1 = cljs.core.next(seq14698);
var G__14700 = cljs.core.first(seq14698__$1);
var seq14698__$2 = cljs.core.next(seq14698__$1);
var self__4628__auto__ = this;
return self__4628__auto__.cljs$core$IFn$_invoke$arity$variadic(G__14699,G__14700,seq14698__$2);
});

chromex.ext.tabs.on_updated_STAR_ = (function chromex$ext$tabs$on_updated_STAR_(var_args){
var args__4647__auto__ = [];
var len__4641__auto___14745 = arguments.length;
var i__4642__auto___14746 = (0);
while(true){
if((i__4642__auto___14746 < len__4641__auto___14745)){
args__4647__auto__.push((arguments[i__4642__auto___14746]));

var G__14747 = (i__4642__auto___14746 + (1));
i__4642__auto___14746 = G__14747;
continue;
} else {
}
break;
}

var argseq__4648__auto__ = ((((2) < args__4647__auto__.length))?(new cljs.core.IndexedSeq(args__4647__auto__.slice((2)),(0),null)):null);
return chromex.ext.tabs.on_updated_STAR_.cljs$core$IFn$_invoke$arity$variadic((arguments[(0)]),(arguments[(1)]),argseq__4648__auto__);
});

chromex.ext.tabs.on_updated_STAR_.cljs$core$IFn$_invoke$arity$variadic = (function (config,channel,args){
var event_fn_14725 = (function (){var config__6143__auto__ = config;
var handler_key__6144__auto__ = cljs.core.cst$kw$event_DASH_listener_DASH_factory;
var handler__6145__auto__ = handler_key__6144__auto__.cljs$core$IFn$_invoke$arity$1(config__6143__auto__);

var G__14737 = config__6143__auto__;
var G__14738 = cljs.core.cst$kw$chromex$ext$tabs_SLASH_on_DASH_updated;
var G__14739 = channel;
return (handler__6145__auto__.cljs$core$IFn$_invoke$arity$3 ? handler__6145__auto__.cljs$core$IFn$_invoke$arity$3(G__14737,G__14738,G__14739) : handler__6145__auto__.call(null,G__14737,G__14738,G__14739));
})();
var handler_fn_14726 = ((function (event_fn_14725){
return (function (cb_tab_id_14731,cb_change_info_14732,cb_tab_14733){
return (event_fn_14725.cljs$core$IFn$_invoke$arity$3 ? event_fn_14725.cljs$core$IFn$_invoke$arity$3(cb_tab_id_14731,cb_change_info_14732,cb_tab_14733) : event_fn_14725.call(null,cb_tab_id_14731,cb_change_info_14732,cb_tab_14733));
});})(event_fn_14725))
;
var logging_fn_14727 = ((function (event_fn_14725,handler_fn_14726){
return (function (cb_param_tab_id_14734,cb_param_change_info_14735,cb_param_tab_14736){

return handler_fn_14726(cb_param_tab_id_14734,cb_param_change_info_14735,cb_param_tab_14736);
});})(event_fn_14725,handler_fn_14726))
;
var ns_obj_14730 = (function (){var target_obj_14740 = cljs.core.cst$kw$root.cljs$core$IFn$_invoke$arity$1(config);
var next_obj_14741 = (target_obj_14740["chrome"]);
var next_obj_14742 = (next_obj_14741["tabs"]);
return next_obj_14742;
})();
var config__6181__auto___14748 = config;
var api_check_fn__6182__auto___14749 = cljs.core.cst$kw$missing_DASH_api_DASH_check_DASH_fn.cljs$core$IFn$_invoke$arity$1(config__6181__auto___14748);

(api_check_fn__6182__auto___14749.cljs$core$IFn$_invoke$arity$3 ? api_check_fn__6182__auto___14749.cljs$core$IFn$_invoke$arity$3("chrome.tabs.onUpdated",ns_obj_14730,"onUpdated") : api_check_fn__6182__auto___14749.call(null,"chrome.tabs.onUpdated",ns_obj_14730,"onUpdated"));

var event_obj_14728 = (function (){var target_obj_14743 = ns_obj_14730;
var next_obj_14744 = (target_obj_14743["onUpdated"]);
return next_obj_14744;
})();
var result_14729 = chromex.chrome_event_subscription.make_chrome_event_subscription(event_obj_14728,logging_fn_14727,channel);
result_14729.chromex$protocols$chrome_event_subscription$IChromeEventSubscription$subscribe_BANG_$arity$2(null,args);

return result_14729;
});

chromex.ext.tabs.on_updated_STAR_.cljs$lang$maxFixedArity = (2);

/** @this {Function} */
chromex.ext.tabs.on_updated_STAR_.cljs$lang$applyTo = (function (seq14722){
var G__14723 = cljs.core.first(seq14722);
var seq14722__$1 = cljs.core.next(seq14722);
var G__14724 = cljs.core.first(seq14722__$1);
var seq14722__$2 = cljs.core.next(seq14722__$1);
var self__4628__auto__ = this;
return self__4628__auto__.cljs$core$IFn$_invoke$arity$variadic(G__14723,G__14724,seq14722__$2);
});

chromex.ext.tabs.on_moved_STAR_ = (function chromex$ext$tabs$on_moved_STAR_(var_args){
var args__4647__auto__ = [];
var len__4641__auto___14771 = arguments.length;
var i__4642__auto___14772 = (0);
while(true){
if((i__4642__auto___14772 < len__4641__auto___14771)){
args__4647__auto__.push((arguments[i__4642__auto___14772]));

var G__14773 = (i__4642__auto___14772 + (1));
i__4642__auto___14772 = G__14773;
continue;
} else {
}
break;
}

var argseq__4648__auto__ = ((((2) < args__4647__auto__.length))?(new cljs.core.IndexedSeq(args__4647__auto__.slice((2)),(0),null)):null);
return chromex.ext.tabs.on_moved_STAR_.cljs$core$IFn$_invoke$arity$variadic((arguments[(0)]),(arguments[(1)]),argseq__4648__auto__);
});

chromex.ext.tabs.on_moved_STAR_.cljs$core$IFn$_invoke$arity$variadic = (function (config,channel,args){
var event_fn_14753 = (function (){var config__6143__auto__ = config;
var handler_key__6144__auto__ = cljs.core.cst$kw$event_DASH_listener_DASH_factory;
var handler__6145__auto__ = handler_key__6144__auto__.cljs$core$IFn$_invoke$arity$1(config__6143__auto__);

var G__14763 = config__6143__auto__;
var G__14764 = cljs.core.cst$kw$chromex$ext$tabs_SLASH_on_DASH_moved;
var G__14765 = channel;
return (handler__6145__auto__.cljs$core$IFn$_invoke$arity$3 ? handler__6145__auto__.cljs$core$IFn$_invoke$arity$3(G__14763,G__14764,G__14765) : handler__6145__auto__.call(null,G__14763,G__14764,G__14765));
})();
var handler_fn_14754 = ((function (event_fn_14753){
return (function (cb_tab_id_14759,cb_move_info_14760){
return (event_fn_14753.cljs$core$IFn$_invoke$arity$2 ? event_fn_14753.cljs$core$IFn$_invoke$arity$2(cb_tab_id_14759,cb_move_info_14760) : event_fn_14753.call(null,cb_tab_id_14759,cb_move_info_14760));
});})(event_fn_14753))
;
var logging_fn_14755 = ((function (event_fn_14753,handler_fn_14754){
return (function (cb_param_tab_id_14761,cb_param_move_info_14762){

return handler_fn_14754(cb_param_tab_id_14761,cb_param_move_info_14762);
});})(event_fn_14753,handler_fn_14754))
;
var ns_obj_14758 = (function (){var target_obj_14766 = cljs.core.cst$kw$root.cljs$core$IFn$_invoke$arity$1(config);
var next_obj_14767 = (target_obj_14766["chrome"]);
var next_obj_14768 = (next_obj_14767["tabs"]);
return next_obj_14768;
})();
var config__6181__auto___14774 = config;
var api_check_fn__6182__auto___14775 = cljs.core.cst$kw$missing_DASH_api_DASH_check_DASH_fn.cljs$core$IFn$_invoke$arity$1(config__6181__auto___14774);

(api_check_fn__6182__auto___14775.cljs$core$IFn$_invoke$arity$3 ? api_check_fn__6182__auto___14775.cljs$core$IFn$_invoke$arity$3("chrome.tabs.onMoved",ns_obj_14758,"onMoved") : api_check_fn__6182__auto___14775.call(null,"chrome.tabs.onMoved",ns_obj_14758,"onMoved"));

var event_obj_14756 = (function (){var target_obj_14769 = ns_obj_14758;
var next_obj_14770 = (target_obj_14769["onMoved"]);
return next_obj_14770;
})();
var result_14757 = chromex.chrome_event_subscription.make_chrome_event_subscription(event_obj_14756,logging_fn_14755,channel);
result_14757.chromex$protocols$chrome_event_subscription$IChromeEventSubscription$subscribe_BANG_$arity$2(null,args);

return result_14757;
});

chromex.ext.tabs.on_moved_STAR_.cljs$lang$maxFixedArity = (2);

/** @this {Function} */
chromex.ext.tabs.on_moved_STAR_.cljs$lang$applyTo = (function (seq14750){
var G__14751 = cljs.core.first(seq14750);
var seq14750__$1 = cljs.core.next(seq14750);
var G__14752 = cljs.core.first(seq14750__$1);
var seq14750__$2 = cljs.core.next(seq14750__$1);
var self__4628__auto__ = this;
return self__4628__auto__.cljs$core$IFn$_invoke$arity$variadic(G__14751,G__14752,seq14750__$2);
});

chromex.ext.tabs.on_selection_changed_STAR_ = (function chromex$ext$tabs$on_selection_changed_STAR_(var_args){
var args__4647__auto__ = [];
var len__4641__auto___14797 = arguments.length;
var i__4642__auto___14798 = (0);
while(true){
if((i__4642__auto___14798 < len__4641__auto___14797)){
args__4647__auto__.push((arguments[i__4642__auto___14798]));

var G__14799 = (i__4642__auto___14798 + (1));
i__4642__auto___14798 = G__14799;
continue;
} else {
}
break;
}

var argseq__4648__auto__ = ((((2) < args__4647__auto__.length))?(new cljs.core.IndexedSeq(args__4647__auto__.slice((2)),(0),null)):null);
return chromex.ext.tabs.on_selection_changed_STAR_.cljs$core$IFn$_invoke$arity$variadic((arguments[(0)]),(arguments[(1)]),argseq__4648__auto__);
});

chromex.ext.tabs.on_selection_changed_STAR_.cljs$core$IFn$_invoke$arity$variadic = (function (config,channel,args){
var event_fn_14779 = (function (){var config__6143__auto__ = config;
var handler_key__6144__auto__ = cljs.core.cst$kw$event_DASH_listener_DASH_factory;
var handler__6145__auto__ = handler_key__6144__auto__.cljs$core$IFn$_invoke$arity$1(config__6143__auto__);

var G__14789 = config__6143__auto__;
var G__14790 = cljs.core.cst$kw$chromex$ext$tabs_SLASH_on_DASH_selection_DASH_changed;
var G__14791 = channel;
return (handler__6145__auto__.cljs$core$IFn$_invoke$arity$3 ? handler__6145__auto__.cljs$core$IFn$_invoke$arity$3(G__14789,G__14790,G__14791) : handler__6145__auto__.call(null,G__14789,G__14790,G__14791));
})();
var handler_fn_14780 = ((function (event_fn_14779){
return (function (cb_tab_id_14785,cb_select_info_14786){
return (event_fn_14779.cljs$core$IFn$_invoke$arity$2 ? event_fn_14779.cljs$core$IFn$_invoke$arity$2(cb_tab_id_14785,cb_select_info_14786) : event_fn_14779.call(null,cb_tab_id_14785,cb_select_info_14786));
});})(event_fn_14779))
;
var logging_fn_14781 = ((function (event_fn_14779,handler_fn_14780){
return (function (cb_param_tab_id_14787,cb_param_select_info_14788){

return handler_fn_14780(cb_param_tab_id_14787,cb_param_select_info_14788);
});})(event_fn_14779,handler_fn_14780))
;
var ns_obj_14784 = (function (){var target_obj_14792 = cljs.core.cst$kw$root.cljs$core$IFn$_invoke$arity$1(config);
var next_obj_14793 = (target_obj_14792["chrome"]);
var next_obj_14794 = (next_obj_14793["tabs"]);
return next_obj_14794;
})();
var config__6181__auto___14800 = config;
var api_check_fn__6182__auto___14801 = cljs.core.cst$kw$missing_DASH_api_DASH_check_DASH_fn.cljs$core$IFn$_invoke$arity$1(config__6181__auto___14800);

(api_check_fn__6182__auto___14801.cljs$core$IFn$_invoke$arity$3 ? api_check_fn__6182__auto___14801.cljs$core$IFn$_invoke$arity$3("chrome.tabs.onSelectionChanged",ns_obj_14784,"onSelectionChanged") : api_check_fn__6182__auto___14801.call(null,"chrome.tabs.onSelectionChanged",ns_obj_14784,"onSelectionChanged"));

var event_obj_14782 = (function (){var target_obj_14795 = ns_obj_14784;
var next_obj_14796 = (target_obj_14795["onSelectionChanged"]);
return next_obj_14796;
})();
var result_14783 = chromex.chrome_event_subscription.make_chrome_event_subscription(event_obj_14782,logging_fn_14781,channel);
result_14783.chromex$protocols$chrome_event_subscription$IChromeEventSubscription$subscribe_BANG_$arity$2(null,args);

return result_14783;
});

chromex.ext.tabs.on_selection_changed_STAR_.cljs$lang$maxFixedArity = (2);

/** @this {Function} */
chromex.ext.tabs.on_selection_changed_STAR_.cljs$lang$applyTo = (function (seq14776){
var G__14777 = cljs.core.first(seq14776);
var seq14776__$1 = cljs.core.next(seq14776);
var G__14778 = cljs.core.first(seq14776__$1);
var seq14776__$2 = cljs.core.next(seq14776__$1);
var self__4628__auto__ = this;
return self__4628__auto__.cljs$core$IFn$_invoke$arity$variadic(G__14777,G__14778,seq14776__$2);
});

chromex.ext.tabs.on_active_changed_STAR_ = (function chromex$ext$tabs$on_active_changed_STAR_(var_args){
var args__4647__auto__ = [];
var len__4641__auto___14823 = arguments.length;
var i__4642__auto___14824 = (0);
while(true){
if((i__4642__auto___14824 < len__4641__auto___14823)){
args__4647__auto__.push((arguments[i__4642__auto___14824]));

var G__14825 = (i__4642__auto___14824 + (1));
i__4642__auto___14824 = G__14825;
continue;
} else {
}
break;
}

var argseq__4648__auto__ = ((((2) < args__4647__auto__.length))?(new cljs.core.IndexedSeq(args__4647__auto__.slice((2)),(0),null)):null);
return chromex.ext.tabs.on_active_changed_STAR_.cljs$core$IFn$_invoke$arity$variadic((arguments[(0)]),(arguments[(1)]),argseq__4648__auto__);
});

chromex.ext.tabs.on_active_changed_STAR_.cljs$core$IFn$_invoke$arity$variadic = (function (config,channel,args){
var event_fn_14805 = (function (){var config__6143__auto__ = config;
var handler_key__6144__auto__ = cljs.core.cst$kw$event_DASH_listener_DASH_factory;
var handler__6145__auto__ = handler_key__6144__auto__.cljs$core$IFn$_invoke$arity$1(config__6143__auto__);

var G__14815 = config__6143__auto__;
var G__14816 = cljs.core.cst$kw$chromex$ext$tabs_SLASH_on_DASH_active_DASH_changed;
var G__14817 = channel;
return (handler__6145__auto__.cljs$core$IFn$_invoke$arity$3 ? handler__6145__auto__.cljs$core$IFn$_invoke$arity$3(G__14815,G__14816,G__14817) : handler__6145__auto__.call(null,G__14815,G__14816,G__14817));
})();
var handler_fn_14806 = ((function (event_fn_14805){
return (function (cb_tab_id_14811,cb_select_info_14812){
return (event_fn_14805.cljs$core$IFn$_invoke$arity$2 ? event_fn_14805.cljs$core$IFn$_invoke$arity$2(cb_tab_id_14811,cb_select_info_14812) : event_fn_14805.call(null,cb_tab_id_14811,cb_select_info_14812));
});})(event_fn_14805))
;
var logging_fn_14807 = ((function (event_fn_14805,handler_fn_14806){
return (function (cb_param_tab_id_14813,cb_param_select_info_14814){

return handler_fn_14806(cb_param_tab_id_14813,cb_param_select_info_14814);
});})(event_fn_14805,handler_fn_14806))
;
var ns_obj_14810 = (function (){var target_obj_14818 = cljs.core.cst$kw$root.cljs$core$IFn$_invoke$arity$1(config);
var next_obj_14819 = (target_obj_14818["chrome"]);
var next_obj_14820 = (next_obj_14819["tabs"]);
return next_obj_14820;
})();
var config__6181__auto___14826 = config;
var api_check_fn__6182__auto___14827 = cljs.core.cst$kw$missing_DASH_api_DASH_check_DASH_fn.cljs$core$IFn$_invoke$arity$1(config__6181__auto___14826);

(api_check_fn__6182__auto___14827.cljs$core$IFn$_invoke$arity$3 ? api_check_fn__6182__auto___14827.cljs$core$IFn$_invoke$arity$3("chrome.tabs.onActiveChanged",ns_obj_14810,"onActiveChanged") : api_check_fn__6182__auto___14827.call(null,"chrome.tabs.onActiveChanged",ns_obj_14810,"onActiveChanged"));

var event_obj_14808 = (function (){var target_obj_14821 = ns_obj_14810;
var next_obj_14822 = (target_obj_14821["onActiveChanged"]);
return next_obj_14822;
})();
var result_14809 = chromex.chrome_event_subscription.make_chrome_event_subscription(event_obj_14808,logging_fn_14807,channel);
result_14809.chromex$protocols$chrome_event_subscription$IChromeEventSubscription$subscribe_BANG_$arity$2(null,args);

return result_14809;
});

chromex.ext.tabs.on_active_changed_STAR_.cljs$lang$maxFixedArity = (2);

/** @this {Function} */
chromex.ext.tabs.on_active_changed_STAR_.cljs$lang$applyTo = (function (seq14802){
var G__14803 = cljs.core.first(seq14802);
var seq14802__$1 = cljs.core.next(seq14802);
var G__14804 = cljs.core.first(seq14802__$1);
var seq14802__$2 = cljs.core.next(seq14802__$1);
var self__4628__auto__ = this;
return self__4628__auto__.cljs$core$IFn$_invoke$arity$variadic(G__14803,G__14804,seq14802__$2);
});

chromex.ext.tabs.on_activated_STAR_ = (function chromex$ext$tabs$on_activated_STAR_(var_args){
var args__4647__auto__ = [];
var len__4641__auto___14847 = arguments.length;
var i__4642__auto___14848 = (0);
while(true){
if((i__4642__auto___14848 < len__4641__auto___14847)){
args__4647__auto__.push((arguments[i__4642__auto___14848]));

var G__14849 = (i__4642__auto___14848 + (1));
i__4642__auto___14848 = G__14849;
continue;
} else {
}
break;
}

var argseq__4648__auto__ = ((((2) < args__4647__auto__.length))?(new cljs.core.IndexedSeq(args__4647__auto__.slice((2)),(0),null)):null);
return chromex.ext.tabs.on_activated_STAR_.cljs$core$IFn$_invoke$arity$variadic((arguments[(0)]),(arguments[(1)]),argseq__4648__auto__);
});

chromex.ext.tabs.on_activated_STAR_.cljs$core$IFn$_invoke$arity$variadic = (function (config,channel,args){
var event_fn_14831 = (function (){var config__6143__auto__ = config;
var handler_key__6144__auto__ = cljs.core.cst$kw$event_DASH_listener_DASH_factory;
var handler__6145__auto__ = handler_key__6144__auto__.cljs$core$IFn$_invoke$arity$1(config__6143__auto__);

var G__14839 = config__6143__auto__;
var G__14840 = cljs.core.cst$kw$chromex$ext$tabs_SLASH_on_DASH_activated;
var G__14841 = channel;
return (handler__6145__auto__.cljs$core$IFn$_invoke$arity$3 ? handler__6145__auto__.cljs$core$IFn$_invoke$arity$3(G__14839,G__14840,G__14841) : handler__6145__auto__.call(null,G__14839,G__14840,G__14841));
})();
var handler_fn_14832 = ((function (event_fn_14831){
return (function (cb_active_info_14837){
return (event_fn_14831.cljs$core$IFn$_invoke$arity$1 ? event_fn_14831.cljs$core$IFn$_invoke$arity$1(cb_active_info_14837) : event_fn_14831.call(null,cb_active_info_14837));
});})(event_fn_14831))
;
var logging_fn_14833 = ((function (event_fn_14831,handler_fn_14832){
return (function (cb_param_active_info_14838){

return handler_fn_14832(cb_param_active_info_14838);
});})(event_fn_14831,handler_fn_14832))
;
var ns_obj_14836 = (function (){var target_obj_14842 = cljs.core.cst$kw$root.cljs$core$IFn$_invoke$arity$1(config);
var next_obj_14843 = (target_obj_14842["chrome"]);
var next_obj_14844 = (next_obj_14843["tabs"]);
return next_obj_14844;
})();
var config__6181__auto___14850 = config;
var api_check_fn__6182__auto___14851 = cljs.core.cst$kw$missing_DASH_api_DASH_check_DASH_fn.cljs$core$IFn$_invoke$arity$1(config__6181__auto___14850);

(api_check_fn__6182__auto___14851.cljs$core$IFn$_invoke$arity$3 ? api_check_fn__6182__auto___14851.cljs$core$IFn$_invoke$arity$3("chrome.tabs.onActivated",ns_obj_14836,"onActivated") : api_check_fn__6182__auto___14851.call(null,"chrome.tabs.onActivated",ns_obj_14836,"onActivated"));

var event_obj_14834 = (function (){var target_obj_14845 = ns_obj_14836;
var next_obj_14846 = (target_obj_14845["onActivated"]);
return next_obj_14846;
})();
var result_14835 = chromex.chrome_event_subscription.make_chrome_event_subscription(event_obj_14834,logging_fn_14833,channel);
result_14835.chromex$protocols$chrome_event_subscription$IChromeEventSubscription$subscribe_BANG_$arity$2(null,args);

return result_14835;
});

chromex.ext.tabs.on_activated_STAR_.cljs$lang$maxFixedArity = (2);

/** @this {Function} */
chromex.ext.tabs.on_activated_STAR_.cljs$lang$applyTo = (function (seq14828){
var G__14829 = cljs.core.first(seq14828);
var seq14828__$1 = cljs.core.next(seq14828);
var G__14830 = cljs.core.first(seq14828__$1);
var seq14828__$2 = cljs.core.next(seq14828__$1);
var self__4628__auto__ = this;
return self__4628__auto__.cljs$core$IFn$_invoke$arity$variadic(G__14829,G__14830,seq14828__$2);
});

chromex.ext.tabs.on_highlight_changed_STAR_ = (function chromex$ext$tabs$on_highlight_changed_STAR_(var_args){
var args__4647__auto__ = [];
var len__4641__auto___14871 = arguments.length;
var i__4642__auto___14872 = (0);
while(true){
if((i__4642__auto___14872 < len__4641__auto___14871)){
args__4647__auto__.push((arguments[i__4642__auto___14872]));

var G__14873 = (i__4642__auto___14872 + (1));
i__4642__auto___14872 = G__14873;
continue;
} else {
}
break;
}

var argseq__4648__auto__ = ((((2) < args__4647__auto__.length))?(new cljs.core.IndexedSeq(args__4647__auto__.slice((2)),(0),null)):null);
return chromex.ext.tabs.on_highlight_changed_STAR_.cljs$core$IFn$_invoke$arity$variadic((arguments[(0)]),(arguments[(1)]),argseq__4648__auto__);
});

chromex.ext.tabs.on_highlight_changed_STAR_.cljs$core$IFn$_invoke$arity$variadic = (function (config,channel,args){
var event_fn_14855 = (function (){var config__6143__auto__ = config;
var handler_key__6144__auto__ = cljs.core.cst$kw$event_DASH_listener_DASH_factory;
var handler__6145__auto__ = handler_key__6144__auto__.cljs$core$IFn$_invoke$arity$1(config__6143__auto__);

var G__14863 = config__6143__auto__;
var G__14864 = cljs.core.cst$kw$chromex$ext$tabs_SLASH_on_DASH_highlight_DASH_changed;
var G__14865 = channel;
return (handler__6145__auto__.cljs$core$IFn$_invoke$arity$3 ? handler__6145__auto__.cljs$core$IFn$_invoke$arity$3(G__14863,G__14864,G__14865) : handler__6145__auto__.call(null,G__14863,G__14864,G__14865));
})();
var handler_fn_14856 = ((function (event_fn_14855){
return (function (cb_select_info_14861){
return (event_fn_14855.cljs$core$IFn$_invoke$arity$1 ? event_fn_14855.cljs$core$IFn$_invoke$arity$1(cb_select_info_14861) : event_fn_14855.call(null,cb_select_info_14861));
});})(event_fn_14855))
;
var logging_fn_14857 = ((function (event_fn_14855,handler_fn_14856){
return (function (cb_param_select_info_14862){

return handler_fn_14856(cb_param_select_info_14862);
});})(event_fn_14855,handler_fn_14856))
;
var ns_obj_14860 = (function (){var target_obj_14866 = cljs.core.cst$kw$root.cljs$core$IFn$_invoke$arity$1(config);
var next_obj_14867 = (target_obj_14866["chrome"]);
var next_obj_14868 = (next_obj_14867["tabs"]);
return next_obj_14868;
})();
var config__6181__auto___14874 = config;
var api_check_fn__6182__auto___14875 = cljs.core.cst$kw$missing_DASH_api_DASH_check_DASH_fn.cljs$core$IFn$_invoke$arity$1(config__6181__auto___14874);

(api_check_fn__6182__auto___14875.cljs$core$IFn$_invoke$arity$3 ? api_check_fn__6182__auto___14875.cljs$core$IFn$_invoke$arity$3("chrome.tabs.onHighlightChanged",ns_obj_14860,"onHighlightChanged") : api_check_fn__6182__auto___14875.call(null,"chrome.tabs.onHighlightChanged",ns_obj_14860,"onHighlightChanged"));

var event_obj_14858 = (function (){var target_obj_14869 = ns_obj_14860;
var next_obj_14870 = (target_obj_14869["onHighlightChanged"]);
return next_obj_14870;
})();
var result_14859 = chromex.chrome_event_subscription.make_chrome_event_subscription(event_obj_14858,logging_fn_14857,channel);
result_14859.chromex$protocols$chrome_event_subscription$IChromeEventSubscription$subscribe_BANG_$arity$2(null,args);

return result_14859;
});

chromex.ext.tabs.on_highlight_changed_STAR_.cljs$lang$maxFixedArity = (2);

/** @this {Function} */
chromex.ext.tabs.on_highlight_changed_STAR_.cljs$lang$applyTo = (function (seq14852){
var G__14853 = cljs.core.first(seq14852);
var seq14852__$1 = cljs.core.next(seq14852);
var G__14854 = cljs.core.first(seq14852__$1);
var seq14852__$2 = cljs.core.next(seq14852__$1);
var self__4628__auto__ = this;
return self__4628__auto__.cljs$core$IFn$_invoke$arity$variadic(G__14853,G__14854,seq14852__$2);
});

chromex.ext.tabs.on_highlighted_STAR_ = (function chromex$ext$tabs$on_highlighted_STAR_(var_args){
var args__4647__auto__ = [];
var len__4641__auto___14895 = arguments.length;
var i__4642__auto___14896 = (0);
while(true){
if((i__4642__auto___14896 < len__4641__auto___14895)){
args__4647__auto__.push((arguments[i__4642__auto___14896]));

var G__14897 = (i__4642__auto___14896 + (1));
i__4642__auto___14896 = G__14897;
continue;
} else {
}
break;
}

var argseq__4648__auto__ = ((((2) < args__4647__auto__.length))?(new cljs.core.IndexedSeq(args__4647__auto__.slice((2)),(0),null)):null);
return chromex.ext.tabs.on_highlighted_STAR_.cljs$core$IFn$_invoke$arity$variadic((arguments[(0)]),(arguments[(1)]),argseq__4648__auto__);
});

chromex.ext.tabs.on_highlighted_STAR_.cljs$core$IFn$_invoke$arity$variadic = (function (config,channel,args){
var event_fn_14879 = (function (){var config__6143__auto__ = config;
var handler_key__6144__auto__ = cljs.core.cst$kw$event_DASH_listener_DASH_factory;
var handler__6145__auto__ = handler_key__6144__auto__.cljs$core$IFn$_invoke$arity$1(config__6143__auto__);

var G__14887 = config__6143__auto__;
var G__14888 = cljs.core.cst$kw$chromex$ext$tabs_SLASH_on_DASH_highlighted;
var G__14889 = channel;
return (handler__6145__auto__.cljs$core$IFn$_invoke$arity$3 ? handler__6145__auto__.cljs$core$IFn$_invoke$arity$3(G__14887,G__14888,G__14889) : handler__6145__auto__.call(null,G__14887,G__14888,G__14889));
})();
var handler_fn_14880 = ((function (event_fn_14879){
return (function (cb_highlight_info_14885){
return (event_fn_14879.cljs$core$IFn$_invoke$arity$1 ? event_fn_14879.cljs$core$IFn$_invoke$arity$1(cb_highlight_info_14885) : event_fn_14879.call(null,cb_highlight_info_14885));
});})(event_fn_14879))
;
var logging_fn_14881 = ((function (event_fn_14879,handler_fn_14880){
return (function (cb_param_highlight_info_14886){

return handler_fn_14880(cb_param_highlight_info_14886);
});})(event_fn_14879,handler_fn_14880))
;
var ns_obj_14884 = (function (){var target_obj_14890 = cljs.core.cst$kw$root.cljs$core$IFn$_invoke$arity$1(config);
var next_obj_14891 = (target_obj_14890["chrome"]);
var next_obj_14892 = (next_obj_14891["tabs"]);
return next_obj_14892;
})();
var config__6181__auto___14898 = config;
var api_check_fn__6182__auto___14899 = cljs.core.cst$kw$missing_DASH_api_DASH_check_DASH_fn.cljs$core$IFn$_invoke$arity$1(config__6181__auto___14898);

(api_check_fn__6182__auto___14899.cljs$core$IFn$_invoke$arity$3 ? api_check_fn__6182__auto___14899.cljs$core$IFn$_invoke$arity$3("chrome.tabs.onHighlighted",ns_obj_14884,"onHighlighted") : api_check_fn__6182__auto___14899.call(null,"chrome.tabs.onHighlighted",ns_obj_14884,"onHighlighted"));

var event_obj_14882 = (function (){var target_obj_14893 = ns_obj_14884;
var next_obj_14894 = (target_obj_14893["onHighlighted"]);
return next_obj_14894;
})();
var result_14883 = chromex.chrome_event_subscription.make_chrome_event_subscription(event_obj_14882,logging_fn_14881,channel);
result_14883.chromex$protocols$chrome_event_subscription$IChromeEventSubscription$subscribe_BANG_$arity$2(null,args);

return result_14883;
});

chromex.ext.tabs.on_highlighted_STAR_.cljs$lang$maxFixedArity = (2);

/** @this {Function} */
chromex.ext.tabs.on_highlighted_STAR_.cljs$lang$applyTo = (function (seq14876){
var G__14877 = cljs.core.first(seq14876);
var seq14876__$1 = cljs.core.next(seq14876);
var G__14878 = cljs.core.first(seq14876__$1);
var seq14876__$2 = cljs.core.next(seq14876__$1);
var self__4628__auto__ = this;
return self__4628__auto__.cljs$core$IFn$_invoke$arity$variadic(G__14877,G__14878,seq14876__$2);
});

chromex.ext.tabs.on_detached_STAR_ = (function chromex$ext$tabs$on_detached_STAR_(var_args){
var args__4647__auto__ = [];
var len__4641__auto___14921 = arguments.length;
var i__4642__auto___14922 = (0);
while(true){
if((i__4642__auto___14922 < len__4641__auto___14921)){
args__4647__auto__.push((arguments[i__4642__auto___14922]));

var G__14923 = (i__4642__auto___14922 + (1));
i__4642__auto___14922 = G__14923;
continue;
} else {
}
break;
}

var argseq__4648__auto__ = ((((2) < args__4647__auto__.length))?(new cljs.core.IndexedSeq(args__4647__auto__.slice((2)),(0),null)):null);
return chromex.ext.tabs.on_detached_STAR_.cljs$core$IFn$_invoke$arity$variadic((arguments[(0)]),(arguments[(1)]),argseq__4648__auto__);
});

chromex.ext.tabs.on_detached_STAR_.cljs$core$IFn$_invoke$arity$variadic = (function (config,channel,args){
var event_fn_14903 = (function (){var config__6143__auto__ = config;
var handler_key__6144__auto__ = cljs.core.cst$kw$event_DASH_listener_DASH_factory;
var handler__6145__auto__ = handler_key__6144__auto__.cljs$core$IFn$_invoke$arity$1(config__6143__auto__);

var G__14913 = config__6143__auto__;
var G__14914 = cljs.core.cst$kw$chromex$ext$tabs_SLASH_on_DASH_detached;
var G__14915 = channel;
return (handler__6145__auto__.cljs$core$IFn$_invoke$arity$3 ? handler__6145__auto__.cljs$core$IFn$_invoke$arity$3(G__14913,G__14914,G__14915) : handler__6145__auto__.call(null,G__14913,G__14914,G__14915));
})();
var handler_fn_14904 = ((function (event_fn_14903){
return (function (cb_tab_id_14909,cb_detach_info_14910){
return (event_fn_14903.cljs$core$IFn$_invoke$arity$2 ? event_fn_14903.cljs$core$IFn$_invoke$arity$2(cb_tab_id_14909,cb_detach_info_14910) : event_fn_14903.call(null,cb_tab_id_14909,cb_detach_info_14910));
});})(event_fn_14903))
;
var logging_fn_14905 = ((function (event_fn_14903,handler_fn_14904){
return (function (cb_param_tab_id_14911,cb_param_detach_info_14912){

return handler_fn_14904(cb_param_tab_id_14911,cb_param_detach_info_14912);
});})(event_fn_14903,handler_fn_14904))
;
var ns_obj_14908 = (function (){var target_obj_14916 = cljs.core.cst$kw$root.cljs$core$IFn$_invoke$arity$1(config);
var next_obj_14917 = (target_obj_14916["chrome"]);
var next_obj_14918 = (next_obj_14917["tabs"]);
return next_obj_14918;
})();
var config__6181__auto___14924 = config;
var api_check_fn__6182__auto___14925 = cljs.core.cst$kw$missing_DASH_api_DASH_check_DASH_fn.cljs$core$IFn$_invoke$arity$1(config__6181__auto___14924);

(api_check_fn__6182__auto___14925.cljs$core$IFn$_invoke$arity$3 ? api_check_fn__6182__auto___14925.cljs$core$IFn$_invoke$arity$3("chrome.tabs.onDetached",ns_obj_14908,"onDetached") : api_check_fn__6182__auto___14925.call(null,"chrome.tabs.onDetached",ns_obj_14908,"onDetached"));

var event_obj_14906 = (function (){var target_obj_14919 = ns_obj_14908;
var next_obj_14920 = (target_obj_14919["onDetached"]);
return next_obj_14920;
})();
var result_14907 = chromex.chrome_event_subscription.make_chrome_event_subscription(event_obj_14906,logging_fn_14905,channel);
result_14907.chromex$protocols$chrome_event_subscription$IChromeEventSubscription$subscribe_BANG_$arity$2(null,args);

return result_14907;
});

chromex.ext.tabs.on_detached_STAR_.cljs$lang$maxFixedArity = (2);

/** @this {Function} */
chromex.ext.tabs.on_detached_STAR_.cljs$lang$applyTo = (function (seq14900){
var G__14901 = cljs.core.first(seq14900);
var seq14900__$1 = cljs.core.next(seq14900);
var G__14902 = cljs.core.first(seq14900__$1);
var seq14900__$2 = cljs.core.next(seq14900__$1);
var self__4628__auto__ = this;
return self__4628__auto__.cljs$core$IFn$_invoke$arity$variadic(G__14901,G__14902,seq14900__$2);
});

chromex.ext.tabs.on_attached_STAR_ = (function chromex$ext$tabs$on_attached_STAR_(var_args){
var args__4647__auto__ = [];
var len__4641__auto___14947 = arguments.length;
var i__4642__auto___14948 = (0);
while(true){
if((i__4642__auto___14948 < len__4641__auto___14947)){
args__4647__auto__.push((arguments[i__4642__auto___14948]));

var G__14949 = (i__4642__auto___14948 + (1));
i__4642__auto___14948 = G__14949;
continue;
} else {
}
break;
}

var argseq__4648__auto__ = ((((2) < args__4647__auto__.length))?(new cljs.core.IndexedSeq(args__4647__auto__.slice((2)),(0),null)):null);
return chromex.ext.tabs.on_attached_STAR_.cljs$core$IFn$_invoke$arity$variadic((arguments[(0)]),(arguments[(1)]),argseq__4648__auto__);
});

chromex.ext.tabs.on_attached_STAR_.cljs$core$IFn$_invoke$arity$variadic = (function (config,channel,args){
var event_fn_14929 = (function (){var config__6143__auto__ = config;
var handler_key__6144__auto__ = cljs.core.cst$kw$event_DASH_listener_DASH_factory;
var handler__6145__auto__ = handler_key__6144__auto__.cljs$core$IFn$_invoke$arity$1(config__6143__auto__);

var G__14939 = config__6143__auto__;
var G__14940 = cljs.core.cst$kw$chromex$ext$tabs_SLASH_on_DASH_attached;
var G__14941 = channel;
return (handler__6145__auto__.cljs$core$IFn$_invoke$arity$3 ? handler__6145__auto__.cljs$core$IFn$_invoke$arity$3(G__14939,G__14940,G__14941) : handler__6145__auto__.call(null,G__14939,G__14940,G__14941));
})();
var handler_fn_14930 = ((function (event_fn_14929){
return (function (cb_tab_id_14935,cb_attach_info_14936){
return (event_fn_14929.cljs$core$IFn$_invoke$arity$2 ? event_fn_14929.cljs$core$IFn$_invoke$arity$2(cb_tab_id_14935,cb_attach_info_14936) : event_fn_14929.call(null,cb_tab_id_14935,cb_attach_info_14936));
});})(event_fn_14929))
;
var logging_fn_14931 = ((function (event_fn_14929,handler_fn_14930){
return (function (cb_param_tab_id_14937,cb_param_attach_info_14938){

return handler_fn_14930(cb_param_tab_id_14937,cb_param_attach_info_14938);
});})(event_fn_14929,handler_fn_14930))
;
var ns_obj_14934 = (function (){var target_obj_14942 = cljs.core.cst$kw$root.cljs$core$IFn$_invoke$arity$1(config);
var next_obj_14943 = (target_obj_14942["chrome"]);
var next_obj_14944 = (next_obj_14943["tabs"]);
return next_obj_14944;
})();
var config__6181__auto___14950 = config;
var api_check_fn__6182__auto___14951 = cljs.core.cst$kw$missing_DASH_api_DASH_check_DASH_fn.cljs$core$IFn$_invoke$arity$1(config__6181__auto___14950);

(api_check_fn__6182__auto___14951.cljs$core$IFn$_invoke$arity$3 ? api_check_fn__6182__auto___14951.cljs$core$IFn$_invoke$arity$3("chrome.tabs.onAttached",ns_obj_14934,"onAttached") : api_check_fn__6182__auto___14951.call(null,"chrome.tabs.onAttached",ns_obj_14934,"onAttached"));

var event_obj_14932 = (function (){var target_obj_14945 = ns_obj_14934;
var next_obj_14946 = (target_obj_14945["onAttached"]);
return next_obj_14946;
})();
var result_14933 = chromex.chrome_event_subscription.make_chrome_event_subscription(event_obj_14932,logging_fn_14931,channel);
result_14933.chromex$protocols$chrome_event_subscription$IChromeEventSubscription$subscribe_BANG_$arity$2(null,args);

return result_14933;
});

chromex.ext.tabs.on_attached_STAR_.cljs$lang$maxFixedArity = (2);

/** @this {Function} */
chromex.ext.tabs.on_attached_STAR_.cljs$lang$applyTo = (function (seq14926){
var G__14927 = cljs.core.first(seq14926);
var seq14926__$1 = cljs.core.next(seq14926);
var G__14928 = cljs.core.first(seq14926__$1);
var seq14926__$2 = cljs.core.next(seq14926__$1);
var self__4628__auto__ = this;
return self__4628__auto__.cljs$core$IFn$_invoke$arity$variadic(G__14927,G__14928,seq14926__$2);
});

chromex.ext.tabs.on_removed_STAR_ = (function chromex$ext$tabs$on_removed_STAR_(var_args){
var args__4647__auto__ = [];
var len__4641__auto___14973 = arguments.length;
var i__4642__auto___14974 = (0);
while(true){
if((i__4642__auto___14974 < len__4641__auto___14973)){
args__4647__auto__.push((arguments[i__4642__auto___14974]));

var G__14975 = (i__4642__auto___14974 + (1));
i__4642__auto___14974 = G__14975;
continue;
} else {
}
break;
}

var argseq__4648__auto__ = ((((2) < args__4647__auto__.length))?(new cljs.core.IndexedSeq(args__4647__auto__.slice((2)),(0),null)):null);
return chromex.ext.tabs.on_removed_STAR_.cljs$core$IFn$_invoke$arity$variadic((arguments[(0)]),(arguments[(1)]),argseq__4648__auto__);
});

chromex.ext.tabs.on_removed_STAR_.cljs$core$IFn$_invoke$arity$variadic = (function (config,channel,args){
var event_fn_14955 = (function (){var config__6143__auto__ = config;
var handler_key__6144__auto__ = cljs.core.cst$kw$event_DASH_listener_DASH_factory;
var handler__6145__auto__ = handler_key__6144__auto__.cljs$core$IFn$_invoke$arity$1(config__6143__auto__);

var G__14965 = config__6143__auto__;
var G__14966 = cljs.core.cst$kw$chromex$ext$tabs_SLASH_on_DASH_removed;
var G__14967 = channel;
return (handler__6145__auto__.cljs$core$IFn$_invoke$arity$3 ? handler__6145__auto__.cljs$core$IFn$_invoke$arity$3(G__14965,G__14966,G__14967) : handler__6145__auto__.call(null,G__14965,G__14966,G__14967));
})();
var handler_fn_14956 = ((function (event_fn_14955){
return (function (cb_tab_id_14961,cb_remove_info_14962){
return (event_fn_14955.cljs$core$IFn$_invoke$arity$2 ? event_fn_14955.cljs$core$IFn$_invoke$arity$2(cb_tab_id_14961,cb_remove_info_14962) : event_fn_14955.call(null,cb_tab_id_14961,cb_remove_info_14962));
});})(event_fn_14955))
;
var logging_fn_14957 = ((function (event_fn_14955,handler_fn_14956){
return (function (cb_param_tab_id_14963,cb_param_remove_info_14964){

return handler_fn_14956(cb_param_tab_id_14963,cb_param_remove_info_14964);
});})(event_fn_14955,handler_fn_14956))
;
var ns_obj_14960 = (function (){var target_obj_14968 = cljs.core.cst$kw$root.cljs$core$IFn$_invoke$arity$1(config);
var next_obj_14969 = (target_obj_14968["chrome"]);
var next_obj_14970 = (next_obj_14969["tabs"]);
return next_obj_14970;
})();
var config__6181__auto___14976 = config;
var api_check_fn__6182__auto___14977 = cljs.core.cst$kw$missing_DASH_api_DASH_check_DASH_fn.cljs$core$IFn$_invoke$arity$1(config__6181__auto___14976);

(api_check_fn__6182__auto___14977.cljs$core$IFn$_invoke$arity$3 ? api_check_fn__6182__auto___14977.cljs$core$IFn$_invoke$arity$3("chrome.tabs.onRemoved",ns_obj_14960,"onRemoved") : api_check_fn__6182__auto___14977.call(null,"chrome.tabs.onRemoved",ns_obj_14960,"onRemoved"));

var event_obj_14958 = (function (){var target_obj_14971 = ns_obj_14960;
var next_obj_14972 = (target_obj_14971["onRemoved"]);
return next_obj_14972;
})();
var result_14959 = chromex.chrome_event_subscription.make_chrome_event_subscription(event_obj_14958,logging_fn_14957,channel);
result_14959.chromex$protocols$chrome_event_subscription$IChromeEventSubscription$subscribe_BANG_$arity$2(null,args);

return result_14959;
});

chromex.ext.tabs.on_removed_STAR_.cljs$lang$maxFixedArity = (2);

/** @this {Function} */
chromex.ext.tabs.on_removed_STAR_.cljs$lang$applyTo = (function (seq14952){
var G__14953 = cljs.core.first(seq14952);
var seq14952__$1 = cljs.core.next(seq14952);
var G__14954 = cljs.core.first(seq14952__$1);
var seq14952__$2 = cljs.core.next(seq14952__$1);
var self__4628__auto__ = this;
return self__4628__auto__.cljs$core$IFn$_invoke$arity$variadic(G__14953,G__14954,seq14952__$2);
});

chromex.ext.tabs.on_replaced_STAR_ = (function chromex$ext$tabs$on_replaced_STAR_(var_args){
var args__4647__auto__ = [];
var len__4641__auto___14999 = arguments.length;
var i__4642__auto___15000 = (0);
while(true){
if((i__4642__auto___15000 < len__4641__auto___14999)){
args__4647__auto__.push((arguments[i__4642__auto___15000]));

var G__15001 = (i__4642__auto___15000 + (1));
i__4642__auto___15000 = G__15001;
continue;
} else {
}
break;
}

var argseq__4648__auto__ = ((((2) < args__4647__auto__.length))?(new cljs.core.IndexedSeq(args__4647__auto__.slice((2)),(0),null)):null);
return chromex.ext.tabs.on_replaced_STAR_.cljs$core$IFn$_invoke$arity$variadic((arguments[(0)]),(arguments[(1)]),argseq__4648__auto__);
});

chromex.ext.tabs.on_replaced_STAR_.cljs$core$IFn$_invoke$arity$variadic = (function (config,channel,args){
var event_fn_14981 = (function (){var config__6143__auto__ = config;
var handler_key__6144__auto__ = cljs.core.cst$kw$event_DASH_listener_DASH_factory;
var handler__6145__auto__ = handler_key__6144__auto__.cljs$core$IFn$_invoke$arity$1(config__6143__auto__);

var G__14991 = config__6143__auto__;
var G__14992 = cljs.core.cst$kw$chromex$ext$tabs_SLASH_on_DASH_replaced;
var G__14993 = channel;
return (handler__6145__auto__.cljs$core$IFn$_invoke$arity$3 ? handler__6145__auto__.cljs$core$IFn$_invoke$arity$3(G__14991,G__14992,G__14993) : handler__6145__auto__.call(null,G__14991,G__14992,G__14993));
})();
var handler_fn_14982 = ((function (event_fn_14981){
return (function (cb_added_tab_id_14987,cb_removed_tab_id_14988){
return (event_fn_14981.cljs$core$IFn$_invoke$arity$2 ? event_fn_14981.cljs$core$IFn$_invoke$arity$2(cb_added_tab_id_14987,cb_removed_tab_id_14988) : event_fn_14981.call(null,cb_added_tab_id_14987,cb_removed_tab_id_14988));
});})(event_fn_14981))
;
var logging_fn_14983 = ((function (event_fn_14981,handler_fn_14982){
return (function (cb_param_added_tab_id_14989,cb_param_removed_tab_id_14990){

return handler_fn_14982(cb_param_added_tab_id_14989,cb_param_removed_tab_id_14990);
});})(event_fn_14981,handler_fn_14982))
;
var ns_obj_14986 = (function (){var target_obj_14994 = cljs.core.cst$kw$root.cljs$core$IFn$_invoke$arity$1(config);
var next_obj_14995 = (target_obj_14994["chrome"]);
var next_obj_14996 = (next_obj_14995["tabs"]);
return next_obj_14996;
})();
var config__6181__auto___15002 = config;
var api_check_fn__6182__auto___15003 = cljs.core.cst$kw$missing_DASH_api_DASH_check_DASH_fn.cljs$core$IFn$_invoke$arity$1(config__6181__auto___15002);

(api_check_fn__6182__auto___15003.cljs$core$IFn$_invoke$arity$3 ? api_check_fn__6182__auto___15003.cljs$core$IFn$_invoke$arity$3("chrome.tabs.onReplaced",ns_obj_14986,"onReplaced") : api_check_fn__6182__auto___15003.call(null,"chrome.tabs.onReplaced",ns_obj_14986,"onReplaced"));

var event_obj_14984 = (function (){var target_obj_14997 = ns_obj_14986;
var next_obj_14998 = (target_obj_14997["onReplaced"]);
return next_obj_14998;
})();
var result_14985 = chromex.chrome_event_subscription.make_chrome_event_subscription(event_obj_14984,logging_fn_14983,channel);
result_14985.chromex$protocols$chrome_event_subscription$IChromeEventSubscription$subscribe_BANG_$arity$2(null,args);

return result_14985;
});

chromex.ext.tabs.on_replaced_STAR_.cljs$lang$maxFixedArity = (2);

/** @this {Function} */
chromex.ext.tabs.on_replaced_STAR_.cljs$lang$applyTo = (function (seq14978){
var G__14979 = cljs.core.first(seq14978);
var seq14978__$1 = cljs.core.next(seq14978);
var G__14980 = cljs.core.first(seq14978__$1);
var seq14978__$2 = cljs.core.next(seq14978__$1);
var self__4628__auto__ = this;
return self__4628__auto__.cljs$core$IFn$_invoke$arity$variadic(G__14979,G__14980,seq14978__$2);
});

chromex.ext.tabs.on_zoom_change_STAR_ = (function chromex$ext$tabs$on_zoom_change_STAR_(var_args){
var args__4647__auto__ = [];
var len__4641__auto___15023 = arguments.length;
var i__4642__auto___15024 = (0);
while(true){
if((i__4642__auto___15024 < len__4641__auto___15023)){
args__4647__auto__.push((arguments[i__4642__auto___15024]));

var G__15025 = (i__4642__auto___15024 + (1));
i__4642__auto___15024 = G__15025;
continue;
} else {
}
break;
}

var argseq__4648__auto__ = ((((2) < args__4647__auto__.length))?(new cljs.core.IndexedSeq(args__4647__auto__.slice((2)),(0),null)):null);
return chromex.ext.tabs.on_zoom_change_STAR_.cljs$core$IFn$_invoke$arity$variadic((arguments[(0)]),(arguments[(1)]),argseq__4648__auto__);
});

chromex.ext.tabs.on_zoom_change_STAR_.cljs$core$IFn$_invoke$arity$variadic = (function (config,channel,args){
var event_fn_15007 = (function (){var config__6143__auto__ = config;
var handler_key__6144__auto__ = cljs.core.cst$kw$event_DASH_listener_DASH_factory;
var handler__6145__auto__ = handler_key__6144__auto__.cljs$core$IFn$_invoke$arity$1(config__6143__auto__);

var G__15015 = config__6143__auto__;
var G__15016 = cljs.core.cst$kw$chromex$ext$tabs_SLASH_on_DASH_zoom_DASH_change;
var G__15017 = channel;
return (handler__6145__auto__.cljs$core$IFn$_invoke$arity$3 ? handler__6145__auto__.cljs$core$IFn$_invoke$arity$3(G__15015,G__15016,G__15017) : handler__6145__auto__.call(null,G__15015,G__15016,G__15017));
})();
var handler_fn_15008 = ((function (event_fn_15007){
return (function (cb_zoom_change_info_15013){
return (event_fn_15007.cljs$core$IFn$_invoke$arity$1 ? event_fn_15007.cljs$core$IFn$_invoke$arity$1(cb_zoom_change_info_15013) : event_fn_15007.call(null,cb_zoom_change_info_15013));
});})(event_fn_15007))
;
var logging_fn_15009 = ((function (event_fn_15007,handler_fn_15008){
return (function (cb_param_zoom_change_info_15014){

return handler_fn_15008(cb_param_zoom_change_info_15014);
});})(event_fn_15007,handler_fn_15008))
;
var ns_obj_15012 = (function (){var target_obj_15018 = cljs.core.cst$kw$root.cljs$core$IFn$_invoke$arity$1(config);
var next_obj_15019 = (target_obj_15018["chrome"]);
var next_obj_15020 = (next_obj_15019["tabs"]);
return next_obj_15020;
})();
var config__6181__auto___15026 = config;
var api_check_fn__6182__auto___15027 = cljs.core.cst$kw$missing_DASH_api_DASH_check_DASH_fn.cljs$core$IFn$_invoke$arity$1(config__6181__auto___15026);

(api_check_fn__6182__auto___15027.cljs$core$IFn$_invoke$arity$3 ? api_check_fn__6182__auto___15027.cljs$core$IFn$_invoke$arity$3("chrome.tabs.onZoomChange",ns_obj_15012,"onZoomChange") : api_check_fn__6182__auto___15027.call(null,"chrome.tabs.onZoomChange",ns_obj_15012,"onZoomChange"));

var event_obj_15010 = (function (){var target_obj_15021 = ns_obj_15012;
var next_obj_15022 = (target_obj_15021["onZoomChange"]);
return next_obj_15022;
})();
var result_15011 = chromex.chrome_event_subscription.make_chrome_event_subscription(event_obj_15010,logging_fn_15009,channel);
result_15011.chromex$protocols$chrome_event_subscription$IChromeEventSubscription$subscribe_BANG_$arity$2(null,args);

return result_15011;
});

chromex.ext.tabs.on_zoom_change_STAR_.cljs$lang$maxFixedArity = (2);

/** @this {Function} */
chromex.ext.tabs.on_zoom_change_STAR_.cljs$lang$applyTo = (function (seq15004){
var G__15005 = cljs.core.first(seq15004);
var seq15004__$1 = cljs.core.next(seq15004);
var G__15006 = cljs.core.first(seq15004__$1);
var seq15004__$2 = cljs.core.next(seq15004__$1);
var self__4628__auto__ = this;
return self__4628__auto__.cljs$core$IFn$_invoke$arity$variadic(G__15005,G__15006,seq15004__$2);
});

