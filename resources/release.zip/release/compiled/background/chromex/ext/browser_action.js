// Compiled by ClojureScript 1.10.439 {:static-fns true, :optimize-constants true, :elide-asserts true}
goog.provide('chromex.ext.browser_action');
goog.require('cljs.core');
goog.require('cljs.core.constants');
goog.require('chromex.core');
chromex.ext.browser_action.set_title_STAR_ = (function chromex$ext$browser_action$set_title_STAR_(config,details){
var callback_chan_13530 = (function (){var config__6143__auto__ = config;
var handler_key__6144__auto__ = cljs.core.cst$kw$callback_DASH_channel_DASH_factory;
var handler__6145__auto__ = handler_key__6144__auto__.cljs$core$IFn$_invoke$arity$1(config__6143__auto__);

return (handler__6145__auto__.cljs$core$IFn$_invoke$arity$1 ? handler__6145__auto__.cljs$core$IFn$_invoke$arity$1(config__6143__auto__) : handler__6145__auto__.call(null,config__6143__auto__));
})();
var marshalled_details_13532_13546 = (function (){var omit_test_13537 = details;
if(cljs.core.keyword_identical_QMARK_(omit_test_13537,cljs.core.cst$kw$omit)){
return cljs.core.cst$kw$omit;
} else {
return omit_test_13537;
}
})();
var marshalled_callback_13533_13547 = (function (){var config__6143__auto__ = config;
var handler_key__6144__auto__ = cljs.core.cst$kw$callback_DASH_fn_DASH_factory;
var handler__6145__auto__ = handler_key__6144__auto__.cljs$core$IFn$_invoke$arity$1(config__6143__auto__);

var G__13538 = config__6143__auto__;
var G__13539 = new cljs.core.PersistentArrayMap(null, 5, [cljs.core.cst$kw$id,cljs.core.cst$kw$chromex$ext$browser_DASH_action_SLASH_set_DASH_title,cljs.core.cst$kw$name,"setTitle",cljs.core.cst$kw$callback_QMARK_,true,cljs.core.cst$kw$params,new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentArrayMap(null, 2, [cljs.core.cst$kw$name,"details",cljs.core.cst$kw$type,"object"], null),new cljs.core.PersistentArrayMap(null, 3, [cljs.core.cst$kw$name,"callback",cljs.core.cst$kw$optional_QMARK_,true,cljs.core.cst$kw$type,cljs.core.cst$kw$callback], null)], null),cljs.core.cst$kw$function_QMARK_,true], null);
var G__13540 = callback_chan_13530;
return (handler__6145__auto__.cljs$core$IFn$_invoke$arity$3 ? handler__6145__auto__.cljs$core$IFn$_invoke$arity$3(G__13538,G__13539,G__13540) : handler__6145__auto__.call(null,G__13538,G__13539,G__13540));
})();
var result_13531_13548 = (function (){var final_args_array_13534 = chromex.support.prepare_final_args_array(new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_details_13532_13546,"details",null], null),new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_callback_13533_13547,"callback",true], null)], null),"chrome.browserAction.setTitle");
var ns_13535 = (function (){var target_obj_13541 = cljs.core.cst$kw$root.cljs$core$IFn$_invoke$arity$1(config);
var next_obj_13542 = (target_obj_13541["chrome"]);
var next_obj_13543 = (next_obj_13542["browserAction"]);
return next_obj_13543;
})();
var config__6181__auto___13549 = config;
var api_check_fn__6182__auto___13550 = cljs.core.cst$kw$missing_DASH_api_DASH_check_DASH_fn.cljs$core$IFn$_invoke$arity$1(config__6181__auto___13549);

(api_check_fn__6182__auto___13550.cljs$core$IFn$_invoke$arity$3 ? api_check_fn__6182__auto___13550.cljs$core$IFn$_invoke$arity$3("chrome.browserAction.setTitle",ns_13535,"setTitle") : api_check_fn__6182__auto___13550.call(null,"chrome.browserAction.setTitle",ns_13535,"setTitle"));


var target_13536 = (function (){var target_obj_13544 = ns_13535;
var next_obj_13545 = (target_obj_13544["setTitle"]);
if((!((next_obj_13545 == null)))){
return next_obj_13545;
} else {
return null;
}
})();
return target_13536.apply(ns_13535,final_args_array_13534);
})();

return callback_chan_13530;
});
chromex.ext.browser_action.get_title_STAR_ = (function chromex$ext$browser_action$get_title_STAR_(config,details){
var callback_chan_13551 = (function (){var config__6143__auto__ = config;
var handler_key__6144__auto__ = cljs.core.cst$kw$callback_DASH_channel_DASH_factory;
var handler__6145__auto__ = handler_key__6144__auto__.cljs$core$IFn$_invoke$arity$1(config__6143__auto__);

return (handler__6145__auto__.cljs$core$IFn$_invoke$arity$1 ? handler__6145__auto__.cljs$core$IFn$_invoke$arity$1(config__6143__auto__) : handler__6145__auto__.call(null,config__6143__auto__));
})();
var marshalled_details_13553_13572 = (function (){var omit_test_13558 = details;
if(cljs.core.keyword_identical_QMARK_(omit_test_13558,cljs.core.cst$kw$omit)){
return cljs.core.cst$kw$omit;
} else {
return omit_test_13558;
}
})();
var marshalled_callback_13554_13573 = ((function (marshalled_details_13553_13572,callback_chan_13551){
return (function (cb_result_13559){
var fexpr__13563 = (function (){var config__6143__auto__ = config;
var handler_key__6144__auto__ = cljs.core.cst$kw$callback_DASH_fn_DASH_factory;
var handler__6145__auto__ = handler_key__6144__auto__.cljs$core$IFn$_invoke$arity$1(config__6143__auto__);

var G__13564 = config__6143__auto__;
var G__13565 = new cljs.core.PersistentArrayMap(null, 5, [cljs.core.cst$kw$id,cljs.core.cst$kw$chromex$ext$browser_DASH_action_SLASH_get_DASH_title,cljs.core.cst$kw$name,"getTitle",cljs.core.cst$kw$callback_QMARK_,true,cljs.core.cst$kw$params,new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentArrayMap(null, 2, [cljs.core.cst$kw$name,"details",cljs.core.cst$kw$type,"object"], null),new cljs.core.PersistentArrayMap(null, 3, [cljs.core.cst$kw$name,"callback",cljs.core.cst$kw$type,cljs.core.cst$kw$callback,cljs.core.cst$kw$callback,new cljs.core.PersistentArrayMap(null, 1, [cljs.core.cst$kw$params,new cljs.core.PersistentVector(null, 1, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentArrayMap(null, 2, [cljs.core.cst$kw$name,"result",cljs.core.cst$kw$type,"string"], null)], null)], null)], null)], null),cljs.core.cst$kw$function_QMARK_,true], null);
var G__13566 = callback_chan_13551;
return (handler__6145__auto__.cljs$core$IFn$_invoke$arity$3 ? handler__6145__auto__.cljs$core$IFn$_invoke$arity$3(G__13564,G__13565,G__13566) : handler__6145__auto__.call(null,G__13564,G__13565,G__13566));
})();
return (fexpr__13563.cljs$core$IFn$_invoke$arity$1 ? fexpr__13563.cljs$core$IFn$_invoke$arity$1(cb_result_13559) : fexpr__13563.call(null,cb_result_13559));
});})(marshalled_details_13553_13572,callback_chan_13551))
;
var result_13552_13574 = (function (){var final_args_array_13555 = chromex.support.prepare_final_args_array(new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_details_13553_13572,"details",null], null),new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_callback_13554_13573,"callback",null], null)], null),"chrome.browserAction.getTitle");
var ns_13556 = (function (){var target_obj_13567 = cljs.core.cst$kw$root.cljs$core$IFn$_invoke$arity$1(config);
var next_obj_13568 = (target_obj_13567["chrome"]);
var next_obj_13569 = (next_obj_13568["browserAction"]);
return next_obj_13569;
})();
var config__6181__auto___13575 = config;
var api_check_fn__6182__auto___13576 = cljs.core.cst$kw$missing_DASH_api_DASH_check_DASH_fn.cljs$core$IFn$_invoke$arity$1(config__6181__auto___13575);

(api_check_fn__6182__auto___13576.cljs$core$IFn$_invoke$arity$3 ? api_check_fn__6182__auto___13576.cljs$core$IFn$_invoke$arity$3("chrome.browserAction.getTitle",ns_13556,"getTitle") : api_check_fn__6182__auto___13576.call(null,"chrome.browserAction.getTitle",ns_13556,"getTitle"));


var target_13557 = (function (){var target_obj_13570 = ns_13556;
var next_obj_13571 = (target_obj_13570["getTitle"]);
if((!((next_obj_13571 == null)))){
return next_obj_13571;
} else {
return null;
}
})();
return target_13557.apply(ns_13556,final_args_array_13555);
})();

return callback_chan_13551;
});
chromex.ext.browser_action.set_icon_STAR_ = (function chromex$ext$browser_action$set_icon_STAR_(config,details){
var callback_chan_13577 = (function (){var config__6143__auto__ = config;
var handler_key__6144__auto__ = cljs.core.cst$kw$callback_DASH_channel_DASH_factory;
var handler__6145__auto__ = handler_key__6144__auto__.cljs$core$IFn$_invoke$arity$1(config__6143__auto__);

return (handler__6145__auto__.cljs$core$IFn$_invoke$arity$1 ? handler__6145__auto__.cljs$core$IFn$_invoke$arity$1(config__6143__auto__) : handler__6145__auto__.call(null,config__6143__auto__));
})();
var marshalled_details_13579_13593 = (function (){var omit_test_13584 = details;
if(cljs.core.keyword_identical_QMARK_(omit_test_13584,cljs.core.cst$kw$omit)){
return cljs.core.cst$kw$omit;
} else {
return omit_test_13584;
}
})();
var marshalled_callback_13580_13594 = (function (){var config__6143__auto__ = config;
var handler_key__6144__auto__ = cljs.core.cst$kw$callback_DASH_fn_DASH_factory;
var handler__6145__auto__ = handler_key__6144__auto__.cljs$core$IFn$_invoke$arity$1(config__6143__auto__);

var G__13585 = config__6143__auto__;
var G__13586 = new cljs.core.PersistentArrayMap(null, 5, [cljs.core.cst$kw$id,cljs.core.cst$kw$chromex$ext$browser_DASH_action_SLASH_set_DASH_icon,cljs.core.cst$kw$name,"setIcon",cljs.core.cst$kw$callback_QMARK_,true,cljs.core.cst$kw$params,new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentArrayMap(null, 2, [cljs.core.cst$kw$name,"details",cljs.core.cst$kw$type,"object"], null),new cljs.core.PersistentArrayMap(null, 3, [cljs.core.cst$kw$name,"callback",cljs.core.cst$kw$optional_QMARK_,true,cljs.core.cst$kw$type,cljs.core.cst$kw$callback], null)], null),cljs.core.cst$kw$function_QMARK_,true], null);
var G__13587 = callback_chan_13577;
return (handler__6145__auto__.cljs$core$IFn$_invoke$arity$3 ? handler__6145__auto__.cljs$core$IFn$_invoke$arity$3(G__13585,G__13586,G__13587) : handler__6145__auto__.call(null,G__13585,G__13586,G__13587));
})();
var result_13578_13595 = (function (){var final_args_array_13581 = chromex.support.prepare_final_args_array(new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_details_13579_13593,"details",null], null),new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_callback_13580_13594,"callback",true], null)], null),"chrome.browserAction.setIcon");
var ns_13582 = (function (){var target_obj_13588 = cljs.core.cst$kw$root.cljs$core$IFn$_invoke$arity$1(config);
var next_obj_13589 = (target_obj_13588["chrome"]);
var next_obj_13590 = (next_obj_13589["browserAction"]);
return next_obj_13590;
})();
var config__6181__auto___13596 = config;
var api_check_fn__6182__auto___13597 = cljs.core.cst$kw$missing_DASH_api_DASH_check_DASH_fn.cljs$core$IFn$_invoke$arity$1(config__6181__auto___13596);

(api_check_fn__6182__auto___13597.cljs$core$IFn$_invoke$arity$3 ? api_check_fn__6182__auto___13597.cljs$core$IFn$_invoke$arity$3("chrome.browserAction.setIcon",ns_13582,"setIcon") : api_check_fn__6182__auto___13597.call(null,"chrome.browserAction.setIcon",ns_13582,"setIcon"));


var target_13583 = (function (){var target_obj_13591 = ns_13582;
var next_obj_13592 = (target_obj_13591["setIcon"]);
if((!((next_obj_13592 == null)))){
return next_obj_13592;
} else {
return null;
}
})();
return target_13583.apply(ns_13582,final_args_array_13581);
})();

return callback_chan_13577;
});
chromex.ext.browser_action.set_popup_STAR_ = (function chromex$ext$browser_action$set_popup_STAR_(config,details){
var callback_chan_13598 = (function (){var config__6143__auto__ = config;
var handler_key__6144__auto__ = cljs.core.cst$kw$callback_DASH_channel_DASH_factory;
var handler__6145__auto__ = handler_key__6144__auto__.cljs$core$IFn$_invoke$arity$1(config__6143__auto__);

return (handler__6145__auto__.cljs$core$IFn$_invoke$arity$1 ? handler__6145__auto__.cljs$core$IFn$_invoke$arity$1(config__6143__auto__) : handler__6145__auto__.call(null,config__6143__auto__));
})();
var marshalled_details_13600_13614 = (function (){var omit_test_13605 = details;
if(cljs.core.keyword_identical_QMARK_(omit_test_13605,cljs.core.cst$kw$omit)){
return cljs.core.cst$kw$omit;
} else {
return omit_test_13605;
}
})();
var marshalled_callback_13601_13615 = (function (){var config__6143__auto__ = config;
var handler_key__6144__auto__ = cljs.core.cst$kw$callback_DASH_fn_DASH_factory;
var handler__6145__auto__ = handler_key__6144__auto__.cljs$core$IFn$_invoke$arity$1(config__6143__auto__);

var G__13606 = config__6143__auto__;
var G__13607 = new cljs.core.PersistentArrayMap(null, 5, [cljs.core.cst$kw$id,cljs.core.cst$kw$chromex$ext$browser_DASH_action_SLASH_set_DASH_popup,cljs.core.cst$kw$name,"setPopup",cljs.core.cst$kw$callback_QMARK_,true,cljs.core.cst$kw$params,new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentArrayMap(null, 2, [cljs.core.cst$kw$name,"details",cljs.core.cst$kw$type,"object"], null),new cljs.core.PersistentArrayMap(null, 3, [cljs.core.cst$kw$name,"callback",cljs.core.cst$kw$optional_QMARK_,true,cljs.core.cst$kw$type,cljs.core.cst$kw$callback], null)], null),cljs.core.cst$kw$function_QMARK_,true], null);
var G__13608 = callback_chan_13598;
return (handler__6145__auto__.cljs$core$IFn$_invoke$arity$3 ? handler__6145__auto__.cljs$core$IFn$_invoke$arity$3(G__13606,G__13607,G__13608) : handler__6145__auto__.call(null,G__13606,G__13607,G__13608));
})();
var result_13599_13616 = (function (){var final_args_array_13602 = chromex.support.prepare_final_args_array(new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_details_13600_13614,"details",null], null),new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_callback_13601_13615,"callback",true], null)], null),"chrome.browserAction.setPopup");
var ns_13603 = (function (){var target_obj_13609 = cljs.core.cst$kw$root.cljs$core$IFn$_invoke$arity$1(config);
var next_obj_13610 = (target_obj_13609["chrome"]);
var next_obj_13611 = (next_obj_13610["browserAction"]);
return next_obj_13611;
})();
var config__6181__auto___13617 = config;
var api_check_fn__6182__auto___13618 = cljs.core.cst$kw$missing_DASH_api_DASH_check_DASH_fn.cljs$core$IFn$_invoke$arity$1(config__6181__auto___13617);

(api_check_fn__6182__auto___13618.cljs$core$IFn$_invoke$arity$3 ? api_check_fn__6182__auto___13618.cljs$core$IFn$_invoke$arity$3("chrome.browserAction.setPopup",ns_13603,"setPopup") : api_check_fn__6182__auto___13618.call(null,"chrome.browserAction.setPopup",ns_13603,"setPopup"));


var target_13604 = (function (){var target_obj_13612 = ns_13603;
var next_obj_13613 = (target_obj_13612["setPopup"]);
if((!((next_obj_13613 == null)))){
return next_obj_13613;
} else {
return null;
}
})();
return target_13604.apply(ns_13603,final_args_array_13602);
})();

return callback_chan_13598;
});
chromex.ext.browser_action.get_popup_STAR_ = (function chromex$ext$browser_action$get_popup_STAR_(config,details){
var callback_chan_13619 = (function (){var config__6143__auto__ = config;
var handler_key__6144__auto__ = cljs.core.cst$kw$callback_DASH_channel_DASH_factory;
var handler__6145__auto__ = handler_key__6144__auto__.cljs$core$IFn$_invoke$arity$1(config__6143__auto__);

return (handler__6145__auto__.cljs$core$IFn$_invoke$arity$1 ? handler__6145__auto__.cljs$core$IFn$_invoke$arity$1(config__6143__auto__) : handler__6145__auto__.call(null,config__6143__auto__));
})();
var marshalled_details_13621_13640 = (function (){var omit_test_13626 = details;
if(cljs.core.keyword_identical_QMARK_(omit_test_13626,cljs.core.cst$kw$omit)){
return cljs.core.cst$kw$omit;
} else {
return omit_test_13626;
}
})();
var marshalled_callback_13622_13641 = ((function (marshalled_details_13621_13640,callback_chan_13619){
return (function (cb_result_13627){
var fexpr__13631 = (function (){var config__6143__auto__ = config;
var handler_key__6144__auto__ = cljs.core.cst$kw$callback_DASH_fn_DASH_factory;
var handler__6145__auto__ = handler_key__6144__auto__.cljs$core$IFn$_invoke$arity$1(config__6143__auto__);

var G__13632 = config__6143__auto__;
var G__13633 = new cljs.core.PersistentArrayMap(null, 5, [cljs.core.cst$kw$id,cljs.core.cst$kw$chromex$ext$browser_DASH_action_SLASH_get_DASH_popup,cljs.core.cst$kw$name,"getPopup",cljs.core.cst$kw$callback_QMARK_,true,cljs.core.cst$kw$params,new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentArrayMap(null, 2, [cljs.core.cst$kw$name,"details",cljs.core.cst$kw$type,"object"], null),new cljs.core.PersistentArrayMap(null, 3, [cljs.core.cst$kw$name,"callback",cljs.core.cst$kw$type,cljs.core.cst$kw$callback,cljs.core.cst$kw$callback,new cljs.core.PersistentArrayMap(null, 1, [cljs.core.cst$kw$params,new cljs.core.PersistentVector(null, 1, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentArrayMap(null, 2, [cljs.core.cst$kw$name,"result",cljs.core.cst$kw$type,"string"], null)], null)], null)], null)], null),cljs.core.cst$kw$function_QMARK_,true], null);
var G__13634 = callback_chan_13619;
return (handler__6145__auto__.cljs$core$IFn$_invoke$arity$3 ? handler__6145__auto__.cljs$core$IFn$_invoke$arity$3(G__13632,G__13633,G__13634) : handler__6145__auto__.call(null,G__13632,G__13633,G__13634));
})();
return (fexpr__13631.cljs$core$IFn$_invoke$arity$1 ? fexpr__13631.cljs$core$IFn$_invoke$arity$1(cb_result_13627) : fexpr__13631.call(null,cb_result_13627));
});})(marshalled_details_13621_13640,callback_chan_13619))
;
var result_13620_13642 = (function (){var final_args_array_13623 = chromex.support.prepare_final_args_array(new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_details_13621_13640,"details",null], null),new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_callback_13622_13641,"callback",null], null)], null),"chrome.browserAction.getPopup");
var ns_13624 = (function (){var target_obj_13635 = cljs.core.cst$kw$root.cljs$core$IFn$_invoke$arity$1(config);
var next_obj_13636 = (target_obj_13635["chrome"]);
var next_obj_13637 = (next_obj_13636["browserAction"]);
return next_obj_13637;
})();
var config__6181__auto___13643 = config;
var api_check_fn__6182__auto___13644 = cljs.core.cst$kw$missing_DASH_api_DASH_check_DASH_fn.cljs$core$IFn$_invoke$arity$1(config__6181__auto___13643);

(api_check_fn__6182__auto___13644.cljs$core$IFn$_invoke$arity$3 ? api_check_fn__6182__auto___13644.cljs$core$IFn$_invoke$arity$3("chrome.browserAction.getPopup",ns_13624,"getPopup") : api_check_fn__6182__auto___13644.call(null,"chrome.browserAction.getPopup",ns_13624,"getPopup"));


var target_13625 = (function (){var target_obj_13638 = ns_13624;
var next_obj_13639 = (target_obj_13638["getPopup"]);
if((!((next_obj_13639 == null)))){
return next_obj_13639;
} else {
return null;
}
})();
return target_13625.apply(ns_13624,final_args_array_13623);
})();

return callback_chan_13619;
});
chromex.ext.browser_action.set_badge_text_STAR_ = (function chromex$ext$browser_action$set_badge_text_STAR_(config,details){
var callback_chan_13645 = (function (){var config__6143__auto__ = config;
var handler_key__6144__auto__ = cljs.core.cst$kw$callback_DASH_channel_DASH_factory;
var handler__6145__auto__ = handler_key__6144__auto__.cljs$core$IFn$_invoke$arity$1(config__6143__auto__);

return (handler__6145__auto__.cljs$core$IFn$_invoke$arity$1 ? handler__6145__auto__.cljs$core$IFn$_invoke$arity$1(config__6143__auto__) : handler__6145__auto__.call(null,config__6143__auto__));
})();
var marshalled_details_13647_13661 = (function (){var omit_test_13652 = details;
if(cljs.core.keyword_identical_QMARK_(omit_test_13652,cljs.core.cst$kw$omit)){
return cljs.core.cst$kw$omit;
} else {
return omit_test_13652;
}
})();
var marshalled_callback_13648_13662 = (function (){var config__6143__auto__ = config;
var handler_key__6144__auto__ = cljs.core.cst$kw$callback_DASH_fn_DASH_factory;
var handler__6145__auto__ = handler_key__6144__auto__.cljs$core$IFn$_invoke$arity$1(config__6143__auto__);

var G__13653 = config__6143__auto__;
var G__13654 = new cljs.core.PersistentArrayMap(null, 5, [cljs.core.cst$kw$id,cljs.core.cst$kw$chromex$ext$browser_DASH_action_SLASH_set_DASH_badge_DASH_text,cljs.core.cst$kw$name,"setBadgeText",cljs.core.cst$kw$callback_QMARK_,true,cljs.core.cst$kw$params,new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentArrayMap(null, 2, [cljs.core.cst$kw$name,"details",cljs.core.cst$kw$type,"object"], null),new cljs.core.PersistentArrayMap(null, 3, [cljs.core.cst$kw$name,"callback",cljs.core.cst$kw$optional_QMARK_,true,cljs.core.cst$kw$type,cljs.core.cst$kw$callback], null)], null),cljs.core.cst$kw$function_QMARK_,true], null);
var G__13655 = callback_chan_13645;
return (handler__6145__auto__.cljs$core$IFn$_invoke$arity$3 ? handler__6145__auto__.cljs$core$IFn$_invoke$arity$3(G__13653,G__13654,G__13655) : handler__6145__auto__.call(null,G__13653,G__13654,G__13655));
})();
var result_13646_13663 = (function (){var final_args_array_13649 = chromex.support.prepare_final_args_array(new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_details_13647_13661,"details",null], null),new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_callback_13648_13662,"callback",true], null)], null),"chrome.browserAction.setBadgeText");
var ns_13650 = (function (){var target_obj_13656 = cljs.core.cst$kw$root.cljs$core$IFn$_invoke$arity$1(config);
var next_obj_13657 = (target_obj_13656["chrome"]);
var next_obj_13658 = (next_obj_13657["browserAction"]);
return next_obj_13658;
})();
var config__6181__auto___13664 = config;
var api_check_fn__6182__auto___13665 = cljs.core.cst$kw$missing_DASH_api_DASH_check_DASH_fn.cljs$core$IFn$_invoke$arity$1(config__6181__auto___13664);

(api_check_fn__6182__auto___13665.cljs$core$IFn$_invoke$arity$3 ? api_check_fn__6182__auto___13665.cljs$core$IFn$_invoke$arity$3("chrome.browserAction.setBadgeText",ns_13650,"setBadgeText") : api_check_fn__6182__auto___13665.call(null,"chrome.browserAction.setBadgeText",ns_13650,"setBadgeText"));


var target_13651 = (function (){var target_obj_13659 = ns_13650;
var next_obj_13660 = (target_obj_13659["setBadgeText"]);
if((!((next_obj_13660 == null)))){
return next_obj_13660;
} else {
return null;
}
})();
return target_13651.apply(ns_13650,final_args_array_13649);
})();

return callback_chan_13645;
});
chromex.ext.browser_action.get_badge_text_STAR_ = (function chromex$ext$browser_action$get_badge_text_STAR_(config,details){
var callback_chan_13666 = (function (){var config__6143__auto__ = config;
var handler_key__6144__auto__ = cljs.core.cst$kw$callback_DASH_channel_DASH_factory;
var handler__6145__auto__ = handler_key__6144__auto__.cljs$core$IFn$_invoke$arity$1(config__6143__auto__);

return (handler__6145__auto__.cljs$core$IFn$_invoke$arity$1 ? handler__6145__auto__.cljs$core$IFn$_invoke$arity$1(config__6143__auto__) : handler__6145__auto__.call(null,config__6143__auto__));
})();
var marshalled_details_13668_13687 = (function (){var omit_test_13673 = details;
if(cljs.core.keyword_identical_QMARK_(omit_test_13673,cljs.core.cst$kw$omit)){
return cljs.core.cst$kw$omit;
} else {
return omit_test_13673;
}
})();
var marshalled_callback_13669_13688 = ((function (marshalled_details_13668_13687,callback_chan_13666){
return (function (cb_result_13674){
var fexpr__13678 = (function (){var config__6143__auto__ = config;
var handler_key__6144__auto__ = cljs.core.cst$kw$callback_DASH_fn_DASH_factory;
var handler__6145__auto__ = handler_key__6144__auto__.cljs$core$IFn$_invoke$arity$1(config__6143__auto__);

var G__13679 = config__6143__auto__;
var G__13680 = new cljs.core.PersistentArrayMap(null, 5, [cljs.core.cst$kw$id,cljs.core.cst$kw$chromex$ext$browser_DASH_action_SLASH_get_DASH_badge_DASH_text,cljs.core.cst$kw$name,"getBadgeText",cljs.core.cst$kw$callback_QMARK_,true,cljs.core.cst$kw$params,new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentArrayMap(null, 2, [cljs.core.cst$kw$name,"details",cljs.core.cst$kw$type,"object"], null),new cljs.core.PersistentArrayMap(null, 3, [cljs.core.cst$kw$name,"callback",cljs.core.cst$kw$type,cljs.core.cst$kw$callback,cljs.core.cst$kw$callback,new cljs.core.PersistentArrayMap(null, 1, [cljs.core.cst$kw$params,new cljs.core.PersistentVector(null, 1, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentArrayMap(null, 2, [cljs.core.cst$kw$name,"result",cljs.core.cst$kw$type,"string"], null)], null)], null)], null)], null),cljs.core.cst$kw$function_QMARK_,true], null);
var G__13681 = callback_chan_13666;
return (handler__6145__auto__.cljs$core$IFn$_invoke$arity$3 ? handler__6145__auto__.cljs$core$IFn$_invoke$arity$3(G__13679,G__13680,G__13681) : handler__6145__auto__.call(null,G__13679,G__13680,G__13681));
})();
return (fexpr__13678.cljs$core$IFn$_invoke$arity$1 ? fexpr__13678.cljs$core$IFn$_invoke$arity$1(cb_result_13674) : fexpr__13678.call(null,cb_result_13674));
});})(marshalled_details_13668_13687,callback_chan_13666))
;
var result_13667_13689 = (function (){var final_args_array_13670 = chromex.support.prepare_final_args_array(new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_details_13668_13687,"details",null], null),new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_callback_13669_13688,"callback",null], null)], null),"chrome.browserAction.getBadgeText");
var ns_13671 = (function (){var target_obj_13682 = cljs.core.cst$kw$root.cljs$core$IFn$_invoke$arity$1(config);
var next_obj_13683 = (target_obj_13682["chrome"]);
var next_obj_13684 = (next_obj_13683["browserAction"]);
return next_obj_13684;
})();
var config__6181__auto___13690 = config;
var api_check_fn__6182__auto___13691 = cljs.core.cst$kw$missing_DASH_api_DASH_check_DASH_fn.cljs$core$IFn$_invoke$arity$1(config__6181__auto___13690);

(api_check_fn__6182__auto___13691.cljs$core$IFn$_invoke$arity$3 ? api_check_fn__6182__auto___13691.cljs$core$IFn$_invoke$arity$3("chrome.browserAction.getBadgeText",ns_13671,"getBadgeText") : api_check_fn__6182__auto___13691.call(null,"chrome.browserAction.getBadgeText",ns_13671,"getBadgeText"));


var target_13672 = (function (){var target_obj_13685 = ns_13671;
var next_obj_13686 = (target_obj_13685["getBadgeText"]);
if((!((next_obj_13686 == null)))){
return next_obj_13686;
} else {
return null;
}
})();
return target_13672.apply(ns_13671,final_args_array_13670);
})();

return callback_chan_13666;
});
chromex.ext.browser_action.set_badge_background_color_STAR_ = (function chromex$ext$browser_action$set_badge_background_color_STAR_(config,details){
var callback_chan_13692 = (function (){var config__6143__auto__ = config;
var handler_key__6144__auto__ = cljs.core.cst$kw$callback_DASH_channel_DASH_factory;
var handler__6145__auto__ = handler_key__6144__auto__.cljs$core$IFn$_invoke$arity$1(config__6143__auto__);

return (handler__6145__auto__.cljs$core$IFn$_invoke$arity$1 ? handler__6145__auto__.cljs$core$IFn$_invoke$arity$1(config__6143__auto__) : handler__6145__auto__.call(null,config__6143__auto__));
})();
var marshalled_details_13694_13708 = (function (){var omit_test_13699 = details;
if(cljs.core.keyword_identical_QMARK_(omit_test_13699,cljs.core.cst$kw$omit)){
return cljs.core.cst$kw$omit;
} else {
return omit_test_13699;
}
})();
var marshalled_callback_13695_13709 = (function (){var config__6143__auto__ = config;
var handler_key__6144__auto__ = cljs.core.cst$kw$callback_DASH_fn_DASH_factory;
var handler__6145__auto__ = handler_key__6144__auto__.cljs$core$IFn$_invoke$arity$1(config__6143__auto__);

var G__13700 = config__6143__auto__;
var G__13701 = new cljs.core.PersistentArrayMap(null, 5, [cljs.core.cst$kw$id,cljs.core.cst$kw$chromex$ext$browser_DASH_action_SLASH_set_DASH_badge_DASH_background_DASH_color,cljs.core.cst$kw$name,"setBadgeBackgroundColor",cljs.core.cst$kw$callback_QMARK_,true,cljs.core.cst$kw$params,new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentArrayMap(null, 2, [cljs.core.cst$kw$name,"details",cljs.core.cst$kw$type,"object"], null),new cljs.core.PersistentArrayMap(null, 3, [cljs.core.cst$kw$name,"callback",cljs.core.cst$kw$optional_QMARK_,true,cljs.core.cst$kw$type,cljs.core.cst$kw$callback], null)], null),cljs.core.cst$kw$function_QMARK_,true], null);
var G__13702 = callback_chan_13692;
return (handler__6145__auto__.cljs$core$IFn$_invoke$arity$3 ? handler__6145__auto__.cljs$core$IFn$_invoke$arity$3(G__13700,G__13701,G__13702) : handler__6145__auto__.call(null,G__13700,G__13701,G__13702));
})();
var result_13693_13710 = (function (){var final_args_array_13696 = chromex.support.prepare_final_args_array(new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_details_13694_13708,"details",null], null),new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_callback_13695_13709,"callback",true], null)], null),"chrome.browserAction.setBadgeBackgroundColor");
var ns_13697 = (function (){var target_obj_13703 = cljs.core.cst$kw$root.cljs$core$IFn$_invoke$arity$1(config);
var next_obj_13704 = (target_obj_13703["chrome"]);
var next_obj_13705 = (next_obj_13704["browserAction"]);
return next_obj_13705;
})();
var config__6181__auto___13711 = config;
var api_check_fn__6182__auto___13712 = cljs.core.cst$kw$missing_DASH_api_DASH_check_DASH_fn.cljs$core$IFn$_invoke$arity$1(config__6181__auto___13711);

(api_check_fn__6182__auto___13712.cljs$core$IFn$_invoke$arity$3 ? api_check_fn__6182__auto___13712.cljs$core$IFn$_invoke$arity$3("chrome.browserAction.setBadgeBackgroundColor",ns_13697,"setBadgeBackgroundColor") : api_check_fn__6182__auto___13712.call(null,"chrome.browserAction.setBadgeBackgroundColor",ns_13697,"setBadgeBackgroundColor"));


var target_13698 = (function (){var target_obj_13706 = ns_13697;
var next_obj_13707 = (target_obj_13706["setBadgeBackgroundColor"]);
if((!((next_obj_13707 == null)))){
return next_obj_13707;
} else {
return null;
}
})();
return target_13698.apply(ns_13697,final_args_array_13696);
})();

return callback_chan_13692;
});
chromex.ext.browser_action.get_badge_background_color_STAR_ = (function chromex$ext$browser_action$get_badge_background_color_STAR_(config,details){
var callback_chan_13713 = (function (){var config__6143__auto__ = config;
var handler_key__6144__auto__ = cljs.core.cst$kw$callback_DASH_channel_DASH_factory;
var handler__6145__auto__ = handler_key__6144__auto__.cljs$core$IFn$_invoke$arity$1(config__6143__auto__);

return (handler__6145__auto__.cljs$core$IFn$_invoke$arity$1 ? handler__6145__auto__.cljs$core$IFn$_invoke$arity$1(config__6143__auto__) : handler__6145__auto__.call(null,config__6143__auto__));
})();
var marshalled_details_13715_13734 = (function (){var omit_test_13720 = details;
if(cljs.core.keyword_identical_QMARK_(omit_test_13720,cljs.core.cst$kw$omit)){
return cljs.core.cst$kw$omit;
} else {
return omit_test_13720;
}
})();
var marshalled_callback_13716_13735 = ((function (marshalled_details_13715_13734,callback_chan_13713){
return (function (cb_result_13721){
var fexpr__13725 = (function (){var config__6143__auto__ = config;
var handler_key__6144__auto__ = cljs.core.cst$kw$callback_DASH_fn_DASH_factory;
var handler__6145__auto__ = handler_key__6144__auto__.cljs$core$IFn$_invoke$arity$1(config__6143__auto__);

var G__13726 = config__6143__auto__;
var G__13727 = new cljs.core.PersistentArrayMap(null, 5, [cljs.core.cst$kw$id,cljs.core.cst$kw$chromex$ext$browser_DASH_action_SLASH_get_DASH_badge_DASH_background_DASH_color,cljs.core.cst$kw$name,"getBadgeBackgroundColor",cljs.core.cst$kw$callback_QMARK_,true,cljs.core.cst$kw$params,new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentArrayMap(null, 2, [cljs.core.cst$kw$name,"details",cljs.core.cst$kw$type,"object"], null),new cljs.core.PersistentArrayMap(null, 3, [cljs.core.cst$kw$name,"callback",cljs.core.cst$kw$type,cljs.core.cst$kw$callback,cljs.core.cst$kw$callback,new cljs.core.PersistentArrayMap(null, 1, [cljs.core.cst$kw$params,new cljs.core.PersistentVector(null, 1, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentArrayMap(null, 2, [cljs.core.cst$kw$name,"result",cljs.core.cst$kw$type,"browserAction.ColorArray"], null)], null)], null)], null)], null),cljs.core.cst$kw$function_QMARK_,true], null);
var G__13728 = callback_chan_13713;
return (handler__6145__auto__.cljs$core$IFn$_invoke$arity$3 ? handler__6145__auto__.cljs$core$IFn$_invoke$arity$3(G__13726,G__13727,G__13728) : handler__6145__auto__.call(null,G__13726,G__13727,G__13728));
})();
return (fexpr__13725.cljs$core$IFn$_invoke$arity$1 ? fexpr__13725.cljs$core$IFn$_invoke$arity$1(cb_result_13721) : fexpr__13725.call(null,cb_result_13721));
});})(marshalled_details_13715_13734,callback_chan_13713))
;
var result_13714_13736 = (function (){var final_args_array_13717 = chromex.support.prepare_final_args_array(new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_details_13715_13734,"details",null], null),new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_callback_13716_13735,"callback",null], null)], null),"chrome.browserAction.getBadgeBackgroundColor");
var ns_13718 = (function (){var target_obj_13729 = cljs.core.cst$kw$root.cljs$core$IFn$_invoke$arity$1(config);
var next_obj_13730 = (target_obj_13729["chrome"]);
var next_obj_13731 = (next_obj_13730["browserAction"]);
return next_obj_13731;
})();
var config__6181__auto___13737 = config;
var api_check_fn__6182__auto___13738 = cljs.core.cst$kw$missing_DASH_api_DASH_check_DASH_fn.cljs$core$IFn$_invoke$arity$1(config__6181__auto___13737);

(api_check_fn__6182__auto___13738.cljs$core$IFn$_invoke$arity$3 ? api_check_fn__6182__auto___13738.cljs$core$IFn$_invoke$arity$3("chrome.browserAction.getBadgeBackgroundColor",ns_13718,"getBadgeBackgroundColor") : api_check_fn__6182__auto___13738.call(null,"chrome.browserAction.getBadgeBackgroundColor",ns_13718,"getBadgeBackgroundColor"));


var target_13719 = (function (){var target_obj_13732 = ns_13718;
var next_obj_13733 = (target_obj_13732["getBadgeBackgroundColor"]);
if((!((next_obj_13733 == null)))){
return next_obj_13733;
} else {
return null;
}
})();
return target_13719.apply(ns_13718,final_args_array_13717);
})();

return callback_chan_13713;
});
chromex.ext.browser_action.enable_STAR_ = (function chromex$ext$browser_action$enable_STAR_(config,tab_id){
var callback_chan_13739 = (function (){var config__6143__auto__ = config;
var handler_key__6144__auto__ = cljs.core.cst$kw$callback_DASH_channel_DASH_factory;
var handler__6145__auto__ = handler_key__6144__auto__.cljs$core$IFn$_invoke$arity$1(config__6143__auto__);

return (handler__6145__auto__.cljs$core$IFn$_invoke$arity$1 ? handler__6145__auto__.cljs$core$IFn$_invoke$arity$1(config__6143__auto__) : handler__6145__auto__.call(null,config__6143__auto__));
})();
var marshalled_tab_id_13741_13755 = (function (){var omit_test_13746 = tab_id;
if(cljs.core.keyword_identical_QMARK_(omit_test_13746,cljs.core.cst$kw$omit)){
return cljs.core.cst$kw$omit;
} else {
return omit_test_13746;
}
})();
var marshalled_callback_13742_13756 = (function (){var config__6143__auto__ = config;
var handler_key__6144__auto__ = cljs.core.cst$kw$callback_DASH_fn_DASH_factory;
var handler__6145__auto__ = handler_key__6144__auto__.cljs$core$IFn$_invoke$arity$1(config__6143__auto__);

var G__13747 = config__6143__auto__;
var G__13748 = new cljs.core.PersistentArrayMap(null, 5, [cljs.core.cst$kw$id,cljs.core.cst$kw$chromex$ext$browser_DASH_action_SLASH_enable,cljs.core.cst$kw$name,"enable",cljs.core.cst$kw$callback_QMARK_,true,cljs.core.cst$kw$params,new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentArrayMap(null, 3, [cljs.core.cst$kw$name,"tab-id",cljs.core.cst$kw$optional_QMARK_,true,cljs.core.cst$kw$type,"integer"], null),new cljs.core.PersistentArrayMap(null, 3, [cljs.core.cst$kw$name,"callback",cljs.core.cst$kw$optional_QMARK_,true,cljs.core.cst$kw$type,cljs.core.cst$kw$callback], null)], null),cljs.core.cst$kw$function_QMARK_,true], null);
var G__13749 = callback_chan_13739;
return (handler__6145__auto__.cljs$core$IFn$_invoke$arity$3 ? handler__6145__auto__.cljs$core$IFn$_invoke$arity$3(G__13747,G__13748,G__13749) : handler__6145__auto__.call(null,G__13747,G__13748,G__13749));
})();
var result_13740_13757 = (function (){var final_args_array_13743 = chromex.support.prepare_final_args_array(new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_tab_id_13741_13755,"tab-id",true], null),new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_callback_13742_13756,"callback",true], null)], null),"chrome.browserAction.enable");
var ns_13744 = (function (){var target_obj_13750 = cljs.core.cst$kw$root.cljs$core$IFn$_invoke$arity$1(config);
var next_obj_13751 = (target_obj_13750["chrome"]);
var next_obj_13752 = (next_obj_13751["browserAction"]);
return next_obj_13752;
})();
var config__6181__auto___13758 = config;
var api_check_fn__6182__auto___13759 = cljs.core.cst$kw$missing_DASH_api_DASH_check_DASH_fn.cljs$core$IFn$_invoke$arity$1(config__6181__auto___13758);

(api_check_fn__6182__auto___13759.cljs$core$IFn$_invoke$arity$3 ? api_check_fn__6182__auto___13759.cljs$core$IFn$_invoke$arity$3("chrome.browserAction.enable",ns_13744,"enable") : api_check_fn__6182__auto___13759.call(null,"chrome.browserAction.enable",ns_13744,"enable"));


var target_13745 = (function (){var target_obj_13753 = ns_13744;
var next_obj_13754 = (target_obj_13753["enable"]);
if((!((next_obj_13754 == null)))){
return next_obj_13754;
} else {
return null;
}
})();
return target_13745.apply(ns_13744,final_args_array_13743);
})();

return callback_chan_13739;
});
chromex.ext.browser_action.disable_STAR_ = (function chromex$ext$browser_action$disable_STAR_(config,tab_id){
var callback_chan_13760 = (function (){var config__6143__auto__ = config;
var handler_key__6144__auto__ = cljs.core.cst$kw$callback_DASH_channel_DASH_factory;
var handler__6145__auto__ = handler_key__6144__auto__.cljs$core$IFn$_invoke$arity$1(config__6143__auto__);

return (handler__6145__auto__.cljs$core$IFn$_invoke$arity$1 ? handler__6145__auto__.cljs$core$IFn$_invoke$arity$1(config__6143__auto__) : handler__6145__auto__.call(null,config__6143__auto__));
})();
var marshalled_tab_id_13762_13776 = (function (){var omit_test_13767 = tab_id;
if(cljs.core.keyword_identical_QMARK_(omit_test_13767,cljs.core.cst$kw$omit)){
return cljs.core.cst$kw$omit;
} else {
return omit_test_13767;
}
})();
var marshalled_callback_13763_13777 = (function (){var config__6143__auto__ = config;
var handler_key__6144__auto__ = cljs.core.cst$kw$callback_DASH_fn_DASH_factory;
var handler__6145__auto__ = handler_key__6144__auto__.cljs$core$IFn$_invoke$arity$1(config__6143__auto__);

var G__13768 = config__6143__auto__;
var G__13769 = new cljs.core.PersistentArrayMap(null, 5, [cljs.core.cst$kw$id,cljs.core.cst$kw$chromex$ext$browser_DASH_action_SLASH_disable,cljs.core.cst$kw$name,"disable",cljs.core.cst$kw$callback_QMARK_,true,cljs.core.cst$kw$params,new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentArrayMap(null, 3, [cljs.core.cst$kw$name,"tab-id",cljs.core.cst$kw$optional_QMARK_,true,cljs.core.cst$kw$type,"integer"], null),new cljs.core.PersistentArrayMap(null, 3, [cljs.core.cst$kw$name,"callback",cljs.core.cst$kw$optional_QMARK_,true,cljs.core.cst$kw$type,cljs.core.cst$kw$callback], null)], null),cljs.core.cst$kw$function_QMARK_,true], null);
var G__13770 = callback_chan_13760;
return (handler__6145__auto__.cljs$core$IFn$_invoke$arity$3 ? handler__6145__auto__.cljs$core$IFn$_invoke$arity$3(G__13768,G__13769,G__13770) : handler__6145__auto__.call(null,G__13768,G__13769,G__13770));
})();
var result_13761_13778 = (function (){var final_args_array_13764 = chromex.support.prepare_final_args_array(new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_tab_id_13762_13776,"tab-id",true], null),new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_callback_13763_13777,"callback",true], null)], null),"chrome.browserAction.disable");
var ns_13765 = (function (){var target_obj_13771 = cljs.core.cst$kw$root.cljs$core$IFn$_invoke$arity$1(config);
var next_obj_13772 = (target_obj_13771["chrome"]);
var next_obj_13773 = (next_obj_13772["browserAction"]);
return next_obj_13773;
})();
var config__6181__auto___13779 = config;
var api_check_fn__6182__auto___13780 = cljs.core.cst$kw$missing_DASH_api_DASH_check_DASH_fn.cljs$core$IFn$_invoke$arity$1(config__6181__auto___13779);

(api_check_fn__6182__auto___13780.cljs$core$IFn$_invoke$arity$3 ? api_check_fn__6182__auto___13780.cljs$core$IFn$_invoke$arity$3("chrome.browserAction.disable",ns_13765,"disable") : api_check_fn__6182__auto___13780.call(null,"chrome.browserAction.disable",ns_13765,"disable"));


var target_13766 = (function (){var target_obj_13774 = ns_13765;
var next_obj_13775 = (target_obj_13774["disable"]);
if((!((next_obj_13775 == null)))){
return next_obj_13775;
} else {
return null;
}
})();
return target_13766.apply(ns_13765,final_args_array_13764);
})();

return callback_chan_13760;
});
chromex.ext.browser_action.on_clicked_STAR_ = (function chromex$ext$browser_action$on_clicked_STAR_(var_args){
var args__4647__auto__ = [];
var len__4641__auto___13800 = arguments.length;
var i__4642__auto___13801 = (0);
while(true){
if((i__4642__auto___13801 < len__4641__auto___13800)){
args__4647__auto__.push((arguments[i__4642__auto___13801]));

var G__13802 = (i__4642__auto___13801 + (1));
i__4642__auto___13801 = G__13802;
continue;
} else {
}
break;
}

var argseq__4648__auto__ = ((((2) < args__4647__auto__.length))?(new cljs.core.IndexedSeq(args__4647__auto__.slice((2)),(0),null)):null);
return chromex.ext.browser_action.on_clicked_STAR_.cljs$core$IFn$_invoke$arity$variadic((arguments[(0)]),(arguments[(1)]),argseq__4648__auto__);
});

chromex.ext.browser_action.on_clicked_STAR_.cljs$core$IFn$_invoke$arity$variadic = (function (config,channel,args){
var event_fn_13784 = (function (){var config__6143__auto__ = config;
var handler_key__6144__auto__ = cljs.core.cst$kw$event_DASH_listener_DASH_factory;
var handler__6145__auto__ = handler_key__6144__auto__.cljs$core$IFn$_invoke$arity$1(config__6143__auto__);

var G__13792 = config__6143__auto__;
var G__13793 = cljs.core.cst$kw$chromex$ext$browser_DASH_action_SLASH_on_DASH_clicked;
var G__13794 = channel;
return (handler__6145__auto__.cljs$core$IFn$_invoke$arity$3 ? handler__6145__auto__.cljs$core$IFn$_invoke$arity$3(G__13792,G__13793,G__13794) : handler__6145__auto__.call(null,G__13792,G__13793,G__13794));
})();
var handler_fn_13785 = ((function (event_fn_13784){
return (function (cb_tab_13790){
return (event_fn_13784.cljs$core$IFn$_invoke$arity$1 ? event_fn_13784.cljs$core$IFn$_invoke$arity$1(cb_tab_13790) : event_fn_13784.call(null,cb_tab_13790));
});})(event_fn_13784))
;
var logging_fn_13786 = ((function (event_fn_13784,handler_fn_13785){
return (function (cb_param_tab_13791){

return handler_fn_13785(cb_param_tab_13791);
});})(event_fn_13784,handler_fn_13785))
;
var ns_obj_13789 = (function (){var target_obj_13795 = cljs.core.cst$kw$root.cljs$core$IFn$_invoke$arity$1(config);
var next_obj_13796 = (target_obj_13795["chrome"]);
var next_obj_13797 = (next_obj_13796["browserAction"]);
return next_obj_13797;
})();
var config__6181__auto___13803 = config;
var api_check_fn__6182__auto___13804 = cljs.core.cst$kw$missing_DASH_api_DASH_check_DASH_fn.cljs$core$IFn$_invoke$arity$1(config__6181__auto___13803);

(api_check_fn__6182__auto___13804.cljs$core$IFn$_invoke$arity$3 ? api_check_fn__6182__auto___13804.cljs$core$IFn$_invoke$arity$3("chrome.browserAction.onClicked",ns_obj_13789,"onClicked") : api_check_fn__6182__auto___13804.call(null,"chrome.browserAction.onClicked",ns_obj_13789,"onClicked"));

var event_obj_13787 = (function (){var target_obj_13798 = ns_obj_13789;
var next_obj_13799 = (target_obj_13798["onClicked"]);
return next_obj_13799;
})();
var result_13788 = chromex.chrome_event_subscription.make_chrome_event_subscription(event_obj_13787,logging_fn_13786,channel);
result_13788.chromex$protocols$chrome_event_subscription$IChromeEventSubscription$subscribe_BANG_$arity$2(null,args);

return result_13788;
});

chromex.ext.browser_action.on_clicked_STAR_.cljs$lang$maxFixedArity = (2);

/** @this {Function} */
chromex.ext.browser_action.on_clicked_STAR_.cljs$lang$applyTo = (function (seq13781){
var G__13782 = cljs.core.first(seq13781);
var seq13781__$1 = cljs.core.next(seq13781);
var G__13783 = cljs.core.first(seq13781__$1);
var seq13781__$2 = cljs.core.next(seq13781__$1);
var self__4628__auto__ = this;
return self__4628__auto__.cljs$core$IFn$_invoke$arity$variadic(G__13782,G__13783,seq13781__$2);
});

