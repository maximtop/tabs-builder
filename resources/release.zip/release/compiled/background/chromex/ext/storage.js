// Compiled by ClojureScript 1.10.439 {:static-fns true, :optimize-constants true, :elide-asserts true}
goog.provide('chromex.ext.storage');
goog.require('cljs.core');
goog.require('cljs.core.constants');
goog.require('chromex.core');
chromex.ext.storage.sync_STAR_ = (function chromex$ext$storage$sync_STAR_(config){
var result_13259 = (function (){var final_args_array_13260 = chromex.support.prepare_final_args_array(cljs.core.PersistentVector.EMPTY,"chrome.storage.sync");
var ns_13261 = (function (){var target_obj_13263 = cljs.core.cst$kw$root.cljs$core$IFn$_invoke$arity$1(config);
var next_obj_13264 = (target_obj_13263["chrome"]);
var next_obj_13265 = (next_obj_13264["storage"]);
return next_obj_13265;
})();


var target_13262 = (function (){var target_obj_13266 = ns_13261;
var next_obj_13267 = (target_obj_13266["sync"]);
if((!((next_obj_13267 == null)))){
return next_obj_13267;
} else {
return null;
}
})();
return target_13262;
})();
return chromex.marshalling.from_native_chrome_storage_area(config,result_13259);
});
chromex.ext.storage.local_STAR_ = (function chromex$ext$storage$local_STAR_(config){
var result_13268 = (function (){var final_args_array_13269 = chromex.support.prepare_final_args_array(cljs.core.PersistentVector.EMPTY,"chrome.storage.local");
var ns_13270 = (function (){var target_obj_13272 = cljs.core.cst$kw$root.cljs$core$IFn$_invoke$arity$1(config);
var next_obj_13273 = (target_obj_13272["chrome"]);
var next_obj_13274 = (next_obj_13273["storage"]);
return next_obj_13274;
})();


var target_13271 = (function (){var target_obj_13275 = ns_13270;
var next_obj_13276 = (target_obj_13275["local"]);
if((!((next_obj_13276 == null)))){
return next_obj_13276;
} else {
return null;
}
})();
return target_13271;
})();
return chromex.marshalling.from_native_chrome_storage_area(config,result_13268);
});
chromex.ext.storage.managed_STAR_ = (function chromex$ext$storage$managed_STAR_(config){
var result_13277 = (function (){var final_args_array_13278 = chromex.support.prepare_final_args_array(cljs.core.PersistentVector.EMPTY,"chrome.storage.managed");
var ns_13279 = (function (){var target_obj_13281 = cljs.core.cst$kw$root.cljs$core$IFn$_invoke$arity$1(config);
var next_obj_13282 = (target_obj_13281["chrome"]);
var next_obj_13283 = (next_obj_13282["storage"]);
return next_obj_13283;
})();


var target_13280 = (function (){var target_obj_13284 = ns_13279;
var next_obj_13285 = (target_obj_13284["managed"]);
if((!((next_obj_13285 == null)))){
return next_obj_13285;
} else {
return null;
}
})();
return target_13280;
})();
return chromex.marshalling.from_native_chrome_storage_area(config,result_13277);
});
chromex.ext.storage.on_changed_STAR_ = (function chromex$ext$storage$on_changed_STAR_(var_args){
var args__4647__auto__ = [];
var len__4641__auto___13307 = arguments.length;
var i__4642__auto___13308 = (0);
while(true){
if((i__4642__auto___13308 < len__4641__auto___13307)){
args__4647__auto__.push((arguments[i__4642__auto___13308]));

var G__13309 = (i__4642__auto___13308 + (1));
i__4642__auto___13308 = G__13309;
continue;
} else {
}
break;
}

var argseq__4648__auto__ = ((((2) < args__4647__auto__.length))?(new cljs.core.IndexedSeq(args__4647__auto__.slice((2)),(0),null)):null);
return chromex.ext.storage.on_changed_STAR_.cljs$core$IFn$_invoke$arity$variadic((arguments[(0)]),(arguments[(1)]),argseq__4648__auto__);
});

chromex.ext.storage.on_changed_STAR_.cljs$core$IFn$_invoke$arity$variadic = (function (config,channel,args){
var event_fn_13289 = (function (){var config__6143__auto__ = config;
var handler_key__6144__auto__ = cljs.core.cst$kw$event_DASH_listener_DASH_factory;
var handler__6145__auto__ = handler_key__6144__auto__.cljs$core$IFn$_invoke$arity$1(config__6143__auto__);

var G__13299 = config__6143__auto__;
var G__13300 = cljs.core.cst$kw$chromex$ext$storage_SLASH_on_DASH_changed;
var G__13301 = channel;
return (handler__6145__auto__.cljs$core$IFn$_invoke$arity$3 ? handler__6145__auto__.cljs$core$IFn$_invoke$arity$3(G__13299,G__13300,G__13301) : handler__6145__auto__.call(null,G__13299,G__13300,G__13301));
})();
var handler_fn_13290 = ((function (event_fn_13289){
return (function (cb_changes_13295,cb_area_name_13296){
return (event_fn_13289.cljs$core$IFn$_invoke$arity$2 ? event_fn_13289.cljs$core$IFn$_invoke$arity$2(cb_changes_13295,cb_area_name_13296) : event_fn_13289.call(null,cb_changes_13295,cb_area_name_13296));
});})(event_fn_13289))
;
var logging_fn_13291 = ((function (event_fn_13289,handler_fn_13290){
return (function (cb_param_changes_13297,cb_param_area_name_13298){

return handler_fn_13290(cb_param_changes_13297,cb_param_area_name_13298);
});})(event_fn_13289,handler_fn_13290))
;
var ns_obj_13294 = (function (){var target_obj_13302 = cljs.core.cst$kw$root.cljs$core$IFn$_invoke$arity$1(config);
var next_obj_13303 = (target_obj_13302["chrome"]);
var next_obj_13304 = (next_obj_13303["storage"]);
return next_obj_13304;
})();
var config__6181__auto___13310 = config;
var api_check_fn__6182__auto___13311 = cljs.core.cst$kw$missing_DASH_api_DASH_check_DASH_fn.cljs$core$IFn$_invoke$arity$1(config__6181__auto___13310);

(api_check_fn__6182__auto___13311.cljs$core$IFn$_invoke$arity$3 ? api_check_fn__6182__auto___13311.cljs$core$IFn$_invoke$arity$3("chrome.storage.onChanged",ns_obj_13294,"onChanged") : api_check_fn__6182__auto___13311.call(null,"chrome.storage.onChanged",ns_obj_13294,"onChanged"));

var event_obj_13292 = (function (){var target_obj_13305 = ns_obj_13294;
var next_obj_13306 = (target_obj_13305["onChanged"]);
return next_obj_13306;
})();
var result_13293 = chromex.chrome_event_subscription.make_chrome_event_subscription(event_obj_13292,logging_fn_13291,channel);
result_13293.chromex$protocols$chrome_event_subscription$IChromeEventSubscription$subscribe_BANG_$arity$2(null,args);

return result_13293;
});

chromex.ext.storage.on_changed_STAR_.cljs$lang$maxFixedArity = (2);

/** @this {Function} */
chromex.ext.storage.on_changed_STAR_.cljs$lang$applyTo = (function (seq13286){
var G__13287 = cljs.core.first(seq13286);
var seq13286__$1 = cljs.core.next(seq13286);
var G__13288 = cljs.core.first(seq13286__$1);
var seq13286__$2 = cljs.core.next(seq13286__$1);
var self__4628__auto__ = this;
return self__4628__auto__.cljs$core$IFn$_invoke$arity$variadic(G__13287,G__13288,seq13286__$2);
});

