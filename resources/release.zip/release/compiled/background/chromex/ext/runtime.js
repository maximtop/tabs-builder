// Compiled by ClojureScript 1.10.439 {:static-fns true, :optimize-constants true, :elide-asserts true}
goog.provide('chromex.ext.runtime');
goog.require('cljs.core');
goog.require('cljs.core.constants');
goog.require('chromex.core');
chromex.ext.runtime.last_error_STAR_ = (function chromex$ext$runtime$last_error_STAR_(config){
var result_12580 = (function (){var final_args_array_12581 = chromex.support.prepare_final_args_array(cljs.core.PersistentVector.EMPTY,"chrome.runtime.lastError");
var ns_12582 = (function (){var target_obj_12584 = cljs.core.cst$kw$root.cljs$core$IFn$_invoke$arity$1(config);
var next_obj_12585 = (target_obj_12584["chrome"]);
var next_obj_12586 = (next_obj_12585["runtime"]);
return next_obj_12586;
})();


var target_12583 = (function (){var target_obj_12587 = ns_12582;
var next_obj_12588 = (target_obj_12587["lastError"]);
if((!((next_obj_12588 == null)))){
return next_obj_12588;
} else {
return null;
}
})();
return target_12583;
})();
return result_12580;
});
chromex.ext.runtime.id_STAR_ = (function chromex$ext$runtime$id_STAR_(config){
var result_12589 = (function (){var final_args_array_12590 = chromex.support.prepare_final_args_array(cljs.core.PersistentVector.EMPTY,"chrome.runtime.id");
var ns_12591 = (function (){var target_obj_12593 = cljs.core.cst$kw$root.cljs$core$IFn$_invoke$arity$1(config);
var next_obj_12594 = (target_obj_12593["chrome"]);
var next_obj_12595 = (next_obj_12594["runtime"]);
return next_obj_12595;
})();


var target_12592 = (function (){var target_obj_12596 = ns_12591;
var next_obj_12597 = (target_obj_12596["id"]);
if((!((next_obj_12597 == null)))){
return next_obj_12597;
} else {
return null;
}
})();
return target_12592;
})();
return result_12589;
});
chromex.ext.runtime.get_background_page_STAR_ = (function chromex$ext$runtime$get_background_page_STAR_(config){
var callback_chan_12598 = (function (){var config__6143__auto__ = config;
var handler_key__6144__auto__ = cljs.core.cst$kw$callback_DASH_channel_DASH_factory;
var handler__6145__auto__ = handler_key__6144__auto__.cljs$core$IFn$_invoke$arity$1(config__6143__auto__);

return (handler__6145__auto__.cljs$core$IFn$_invoke$arity$1 ? handler__6145__auto__.cljs$core$IFn$_invoke$arity$1(config__6143__auto__) : handler__6145__auto__.call(null,config__6143__auto__));
})();
var marshalled_callback_12600_12617 = ((function (callback_chan_12598){
return (function (cb_background_page_12604){
var fexpr__12608 = (function (){var config__6143__auto__ = config;
var handler_key__6144__auto__ = cljs.core.cst$kw$callback_DASH_fn_DASH_factory;
var handler__6145__auto__ = handler_key__6144__auto__.cljs$core$IFn$_invoke$arity$1(config__6143__auto__);

var G__12609 = config__6143__auto__;
var G__12610 = new cljs.core.PersistentArrayMap(null, 5, [cljs.core.cst$kw$id,cljs.core.cst$kw$chromex$ext$runtime_SLASH_get_DASH_background_DASH_page,cljs.core.cst$kw$name,"getBackgroundPage",cljs.core.cst$kw$callback_QMARK_,true,cljs.core.cst$kw$params,new cljs.core.PersistentVector(null, 1, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentArrayMap(null, 3, [cljs.core.cst$kw$name,"callback",cljs.core.cst$kw$type,cljs.core.cst$kw$callback,cljs.core.cst$kw$callback,new cljs.core.PersistentArrayMap(null, 1, [cljs.core.cst$kw$params,new cljs.core.PersistentVector(null, 1, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentArrayMap(null, 3, [cljs.core.cst$kw$name,"background-page",cljs.core.cst$kw$optional_QMARK_,true,cljs.core.cst$kw$type,"Window"], null)], null)], null)], null)], null),cljs.core.cst$kw$function_QMARK_,true], null);
var G__12611 = callback_chan_12598;
return (handler__6145__auto__.cljs$core$IFn$_invoke$arity$3 ? handler__6145__auto__.cljs$core$IFn$_invoke$arity$3(G__12609,G__12610,G__12611) : handler__6145__auto__.call(null,G__12609,G__12610,G__12611));
})();
return (fexpr__12608.cljs$core$IFn$_invoke$arity$1 ? fexpr__12608.cljs$core$IFn$_invoke$arity$1(cb_background_page_12604) : fexpr__12608.call(null,cb_background_page_12604));
});})(callback_chan_12598))
;
var result_12599_12618 = (function (){var final_args_array_12601 = chromex.support.prepare_final_args_array(new cljs.core.PersistentVector(null, 1, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_callback_12600_12617,"callback",null], null)], null),"chrome.runtime.getBackgroundPage");
var ns_12602 = (function (){var target_obj_12612 = cljs.core.cst$kw$root.cljs$core$IFn$_invoke$arity$1(config);
var next_obj_12613 = (target_obj_12612["chrome"]);
var next_obj_12614 = (next_obj_12613["runtime"]);
return next_obj_12614;
})();
var config__6181__auto___12619 = config;
var api_check_fn__6182__auto___12620 = cljs.core.cst$kw$missing_DASH_api_DASH_check_DASH_fn.cljs$core$IFn$_invoke$arity$1(config__6181__auto___12619);

(api_check_fn__6182__auto___12620.cljs$core$IFn$_invoke$arity$3 ? api_check_fn__6182__auto___12620.cljs$core$IFn$_invoke$arity$3("chrome.runtime.getBackgroundPage",ns_12602,"getBackgroundPage") : api_check_fn__6182__auto___12620.call(null,"chrome.runtime.getBackgroundPage",ns_12602,"getBackgroundPage"));


var target_12603 = (function (){var target_obj_12615 = ns_12602;
var next_obj_12616 = (target_obj_12615["getBackgroundPage"]);
if((!((next_obj_12616 == null)))){
return next_obj_12616;
} else {
return null;
}
})();
return target_12603.apply(ns_12602,final_args_array_12601);
})();

return callback_chan_12598;
});
chromex.ext.runtime.open_options_page_STAR_ = (function chromex$ext$runtime$open_options_page_STAR_(config){
var callback_chan_12621 = (function (){var config__6143__auto__ = config;
var handler_key__6144__auto__ = cljs.core.cst$kw$callback_DASH_channel_DASH_factory;
var handler__6145__auto__ = handler_key__6144__auto__.cljs$core$IFn$_invoke$arity$1(config__6143__auto__);

return (handler__6145__auto__.cljs$core$IFn$_invoke$arity$1 ? handler__6145__auto__.cljs$core$IFn$_invoke$arity$1(config__6143__auto__) : handler__6145__auto__.call(null,config__6143__auto__));
})();
var marshalled_callback_12623_12635 = (function (){var config__6143__auto__ = config;
var handler_key__6144__auto__ = cljs.core.cst$kw$callback_DASH_fn_DASH_factory;
var handler__6145__auto__ = handler_key__6144__auto__.cljs$core$IFn$_invoke$arity$1(config__6143__auto__);

var G__12627 = config__6143__auto__;
var G__12628 = new cljs.core.PersistentArrayMap(null, 6, [cljs.core.cst$kw$id,cljs.core.cst$kw$chromex$ext$runtime_SLASH_open_DASH_options_DASH_page,cljs.core.cst$kw$name,"openOptionsPage",cljs.core.cst$kw$since,"42",cljs.core.cst$kw$callback_QMARK_,true,cljs.core.cst$kw$params,new cljs.core.PersistentVector(null, 1, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentArrayMap(null, 3, [cljs.core.cst$kw$name,"callback",cljs.core.cst$kw$optional_QMARK_,true,cljs.core.cst$kw$type,cljs.core.cst$kw$callback], null)], null),cljs.core.cst$kw$function_QMARK_,true], null);
var G__12629 = callback_chan_12621;
return (handler__6145__auto__.cljs$core$IFn$_invoke$arity$3 ? handler__6145__auto__.cljs$core$IFn$_invoke$arity$3(G__12627,G__12628,G__12629) : handler__6145__auto__.call(null,G__12627,G__12628,G__12629));
})();
var result_12622_12636 = (function (){var final_args_array_12624 = chromex.support.prepare_final_args_array(new cljs.core.PersistentVector(null, 1, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_callback_12623_12635,"callback",true], null)], null),"chrome.runtime.openOptionsPage");
var ns_12625 = (function (){var target_obj_12630 = cljs.core.cst$kw$root.cljs$core$IFn$_invoke$arity$1(config);
var next_obj_12631 = (target_obj_12630["chrome"]);
var next_obj_12632 = (next_obj_12631["runtime"]);
return next_obj_12632;
})();
var config__6181__auto___12637 = config;
var api_check_fn__6182__auto___12638 = cljs.core.cst$kw$missing_DASH_api_DASH_check_DASH_fn.cljs$core$IFn$_invoke$arity$1(config__6181__auto___12637);

(api_check_fn__6182__auto___12638.cljs$core$IFn$_invoke$arity$3 ? api_check_fn__6182__auto___12638.cljs$core$IFn$_invoke$arity$3("chrome.runtime.openOptionsPage",ns_12625,"openOptionsPage") : api_check_fn__6182__auto___12638.call(null,"chrome.runtime.openOptionsPage",ns_12625,"openOptionsPage"));


var target_12626 = (function (){var target_obj_12633 = ns_12625;
var next_obj_12634 = (target_obj_12633["openOptionsPage"]);
if((!((next_obj_12634 == null)))){
return next_obj_12634;
} else {
return null;
}
})();
return target_12626.apply(ns_12625,final_args_array_12624);
})();

return callback_chan_12621;
});
chromex.ext.runtime.get_manifest_STAR_ = (function chromex$ext$runtime$get_manifest_STAR_(config){
var result_12639 = (function (){var final_args_array_12640 = chromex.support.prepare_final_args_array(cljs.core.PersistentVector.EMPTY,"chrome.runtime.getManifest");
var ns_12641 = (function (){var target_obj_12643 = cljs.core.cst$kw$root.cljs$core$IFn$_invoke$arity$1(config);
var next_obj_12644 = (target_obj_12643["chrome"]);
var next_obj_12645 = (next_obj_12644["runtime"]);
return next_obj_12645;
})();
var config__6181__auto___12648 = config;
var api_check_fn__6182__auto___12649 = cljs.core.cst$kw$missing_DASH_api_DASH_check_DASH_fn.cljs$core$IFn$_invoke$arity$1(config__6181__auto___12648);

(api_check_fn__6182__auto___12649.cljs$core$IFn$_invoke$arity$3 ? api_check_fn__6182__auto___12649.cljs$core$IFn$_invoke$arity$3("chrome.runtime.getManifest",ns_12641,"getManifest") : api_check_fn__6182__auto___12649.call(null,"chrome.runtime.getManifest",ns_12641,"getManifest"));


var target_12642 = (function (){var target_obj_12646 = ns_12641;
var next_obj_12647 = (target_obj_12646["getManifest"]);
if((!((next_obj_12647 == null)))){
return next_obj_12647;
} else {
return null;
}
})();
return target_12642.apply(ns_12641,final_args_array_12640);
})();
return result_12639;
});
chromex.ext.runtime.get_url_STAR_ = (function chromex$ext$runtime$get_url_STAR_(config,path){
var marshalled_path_12651 = (function (){var omit_test_12655 = path;
if(cljs.core.keyword_identical_QMARK_(omit_test_12655,cljs.core.cst$kw$omit)){
return cljs.core.cst$kw$omit;
} else {
return omit_test_12655;
}
})();
var result_12650 = (function (){var final_args_array_12652 = chromex.support.prepare_final_args_array(new cljs.core.PersistentVector(null, 1, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_path_12651,"path",null], null)], null),"chrome.runtime.getURL");
var ns_12653 = (function (){var target_obj_12656 = cljs.core.cst$kw$root.cljs$core$IFn$_invoke$arity$1(config);
var next_obj_12657 = (target_obj_12656["chrome"]);
var next_obj_12658 = (next_obj_12657["runtime"]);
return next_obj_12658;
})();
var config__6181__auto___12661 = config;
var api_check_fn__6182__auto___12662 = cljs.core.cst$kw$missing_DASH_api_DASH_check_DASH_fn.cljs$core$IFn$_invoke$arity$1(config__6181__auto___12661);

(api_check_fn__6182__auto___12662.cljs$core$IFn$_invoke$arity$3 ? api_check_fn__6182__auto___12662.cljs$core$IFn$_invoke$arity$3("chrome.runtime.getURL",ns_12653,"getURL") : api_check_fn__6182__auto___12662.call(null,"chrome.runtime.getURL",ns_12653,"getURL"));


var target_12654 = (function (){var target_obj_12659 = ns_12653;
var next_obj_12660 = (target_obj_12659["getURL"]);
if((!((next_obj_12660 == null)))){
return next_obj_12660;
} else {
return null;
}
})();
return target_12654.apply(ns_12653,final_args_array_12652);
})();
return result_12650;
});
chromex.ext.runtime.set_uninstall_url_STAR_ = (function chromex$ext$runtime$set_uninstall_url_STAR_(config,url){
var callback_chan_12663 = (function (){var config__6143__auto__ = config;
var handler_key__6144__auto__ = cljs.core.cst$kw$callback_DASH_channel_DASH_factory;
var handler__6145__auto__ = handler_key__6144__auto__.cljs$core$IFn$_invoke$arity$1(config__6143__auto__);

return (handler__6145__auto__.cljs$core$IFn$_invoke$arity$1 ? handler__6145__auto__.cljs$core$IFn$_invoke$arity$1(config__6143__auto__) : handler__6145__auto__.call(null,config__6143__auto__));
})();
var marshalled_url_12665_12679 = (function (){var omit_test_12670 = url;
if(cljs.core.keyword_identical_QMARK_(omit_test_12670,cljs.core.cst$kw$omit)){
return cljs.core.cst$kw$omit;
} else {
return omit_test_12670;
}
})();
var marshalled_callback_12666_12680 = (function (){var config__6143__auto__ = config;
var handler_key__6144__auto__ = cljs.core.cst$kw$callback_DASH_fn_DASH_factory;
var handler__6145__auto__ = handler_key__6144__auto__.cljs$core$IFn$_invoke$arity$1(config__6143__auto__);

var G__12671 = config__6143__auto__;
var G__12672 = new cljs.core.PersistentArrayMap(null, 6, [cljs.core.cst$kw$id,cljs.core.cst$kw$chromex$ext$runtime_SLASH_set_DASH_uninstall_DASH_url,cljs.core.cst$kw$name,"setUninstallURL",cljs.core.cst$kw$since,"41",cljs.core.cst$kw$callback_QMARK_,true,cljs.core.cst$kw$params,new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentArrayMap(null, 2, [cljs.core.cst$kw$name,"url",cljs.core.cst$kw$type,"string"], null),new cljs.core.PersistentArrayMap(null, 3, [cljs.core.cst$kw$name,"callback",cljs.core.cst$kw$optional_QMARK_,true,cljs.core.cst$kw$type,cljs.core.cst$kw$callback], null)], null),cljs.core.cst$kw$function_QMARK_,true], null);
var G__12673 = callback_chan_12663;
return (handler__6145__auto__.cljs$core$IFn$_invoke$arity$3 ? handler__6145__auto__.cljs$core$IFn$_invoke$arity$3(G__12671,G__12672,G__12673) : handler__6145__auto__.call(null,G__12671,G__12672,G__12673));
})();
var result_12664_12681 = (function (){var final_args_array_12667 = chromex.support.prepare_final_args_array(new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_url_12665_12679,"url",null], null),new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_callback_12666_12680,"callback",true], null)], null),"chrome.runtime.setUninstallURL");
var ns_12668 = (function (){var target_obj_12674 = cljs.core.cst$kw$root.cljs$core$IFn$_invoke$arity$1(config);
var next_obj_12675 = (target_obj_12674["chrome"]);
var next_obj_12676 = (next_obj_12675["runtime"]);
return next_obj_12676;
})();
var config__6181__auto___12682 = config;
var api_check_fn__6182__auto___12683 = cljs.core.cst$kw$missing_DASH_api_DASH_check_DASH_fn.cljs$core$IFn$_invoke$arity$1(config__6181__auto___12682);

(api_check_fn__6182__auto___12683.cljs$core$IFn$_invoke$arity$3 ? api_check_fn__6182__auto___12683.cljs$core$IFn$_invoke$arity$3("chrome.runtime.setUninstallURL",ns_12668,"setUninstallURL") : api_check_fn__6182__auto___12683.call(null,"chrome.runtime.setUninstallURL",ns_12668,"setUninstallURL"));


var target_12669 = (function (){var target_obj_12677 = ns_12668;
var next_obj_12678 = (target_obj_12677["setUninstallURL"]);
if((!((next_obj_12678 == null)))){
return next_obj_12678;
} else {
return null;
}
})();
return target_12669.apply(ns_12668,final_args_array_12667);
})();

return callback_chan_12663;
});
chromex.ext.runtime.reload_STAR_ = (function chromex$ext$runtime$reload_STAR_(config){
var result_12684 = (function (){var final_args_array_12685 = chromex.support.prepare_final_args_array(cljs.core.PersistentVector.EMPTY,"chrome.runtime.reload");
var ns_12686 = (function (){var target_obj_12688 = cljs.core.cst$kw$root.cljs$core$IFn$_invoke$arity$1(config);
var next_obj_12689 = (target_obj_12688["chrome"]);
var next_obj_12690 = (next_obj_12689["runtime"]);
return next_obj_12690;
})();
var config__6181__auto___12693 = config;
var api_check_fn__6182__auto___12694 = cljs.core.cst$kw$missing_DASH_api_DASH_check_DASH_fn.cljs$core$IFn$_invoke$arity$1(config__6181__auto___12693);

(api_check_fn__6182__auto___12694.cljs$core$IFn$_invoke$arity$3 ? api_check_fn__6182__auto___12694.cljs$core$IFn$_invoke$arity$3("chrome.runtime.reload",ns_12686,"reload") : api_check_fn__6182__auto___12694.call(null,"chrome.runtime.reload",ns_12686,"reload"));


var target_12687 = (function (){var target_obj_12691 = ns_12686;
var next_obj_12692 = (target_obj_12691["reload"]);
if((!((next_obj_12692 == null)))){
return next_obj_12692;
} else {
return null;
}
})();
return target_12687.apply(ns_12686,final_args_array_12685);
})();
return result_12684;
});
chromex.ext.runtime.request_update_check_STAR_ = (function chromex$ext$runtime$request_update_check_STAR_(config){
var callback_chan_12695 = (function (){var config__6143__auto__ = config;
var handler_key__6144__auto__ = cljs.core.cst$kw$callback_DASH_channel_DASH_factory;
var handler__6145__auto__ = handler_key__6144__auto__.cljs$core$IFn$_invoke$arity$1(config__6143__auto__);

return (handler__6145__auto__.cljs$core$IFn$_invoke$arity$1 ? handler__6145__auto__.cljs$core$IFn$_invoke$arity$1(config__6143__auto__) : handler__6145__auto__.call(null,config__6143__auto__));
})();
var marshalled_callback_12697_12715 = ((function (callback_chan_12695){
return (function (cb_status_12701,cb_details_12702){
var fexpr__12706 = (function (){var config__6143__auto__ = config;
var handler_key__6144__auto__ = cljs.core.cst$kw$callback_DASH_fn_DASH_factory;
var handler__6145__auto__ = handler_key__6144__auto__.cljs$core$IFn$_invoke$arity$1(config__6143__auto__);

var G__12707 = config__6143__auto__;
var G__12708 = new cljs.core.PersistentArrayMap(null, 5, [cljs.core.cst$kw$id,cljs.core.cst$kw$chromex$ext$runtime_SLASH_request_DASH_update_DASH_check,cljs.core.cst$kw$name,"requestUpdateCheck",cljs.core.cst$kw$callback_QMARK_,true,cljs.core.cst$kw$params,new cljs.core.PersistentVector(null, 1, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentArrayMap(null, 3, [cljs.core.cst$kw$name,"callback",cljs.core.cst$kw$type,cljs.core.cst$kw$callback,cljs.core.cst$kw$callback,new cljs.core.PersistentArrayMap(null, 1, [cljs.core.cst$kw$params,new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentArrayMap(null, 2, [cljs.core.cst$kw$name,"status",cljs.core.cst$kw$type,"runtime.RequestUpdateCheckStatus"], null),new cljs.core.PersistentArrayMap(null, 3, [cljs.core.cst$kw$name,"details",cljs.core.cst$kw$optional_QMARK_,true,cljs.core.cst$kw$type,"object"], null)], null)], null)], null)], null),cljs.core.cst$kw$function_QMARK_,true], null);
var G__12709 = callback_chan_12695;
return (handler__6145__auto__.cljs$core$IFn$_invoke$arity$3 ? handler__6145__auto__.cljs$core$IFn$_invoke$arity$3(G__12707,G__12708,G__12709) : handler__6145__auto__.call(null,G__12707,G__12708,G__12709));
})();
return (fexpr__12706.cljs$core$IFn$_invoke$arity$2 ? fexpr__12706.cljs$core$IFn$_invoke$arity$2(cb_status_12701,cb_details_12702) : fexpr__12706.call(null,cb_status_12701,cb_details_12702));
});})(callback_chan_12695))
;
var result_12696_12716 = (function (){var final_args_array_12698 = chromex.support.prepare_final_args_array(new cljs.core.PersistentVector(null, 1, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_callback_12697_12715,"callback",null], null)], null),"chrome.runtime.requestUpdateCheck");
var ns_12699 = (function (){var target_obj_12710 = cljs.core.cst$kw$root.cljs$core$IFn$_invoke$arity$1(config);
var next_obj_12711 = (target_obj_12710["chrome"]);
var next_obj_12712 = (next_obj_12711["runtime"]);
return next_obj_12712;
})();
var config__6181__auto___12717 = config;
var api_check_fn__6182__auto___12718 = cljs.core.cst$kw$missing_DASH_api_DASH_check_DASH_fn.cljs$core$IFn$_invoke$arity$1(config__6181__auto___12717);

(api_check_fn__6182__auto___12718.cljs$core$IFn$_invoke$arity$3 ? api_check_fn__6182__auto___12718.cljs$core$IFn$_invoke$arity$3("chrome.runtime.requestUpdateCheck",ns_12699,"requestUpdateCheck") : api_check_fn__6182__auto___12718.call(null,"chrome.runtime.requestUpdateCheck",ns_12699,"requestUpdateCheck"));


var target_12700 = (function (){var target_obj_12713 = ns_12699;
var next_obj_12714 = (target_obj_12713["requestUpdateCheck"]);
if((!((next_obj_12714 == null)))){
return next_obj_12714;
} else {
return null;
}
})();
return target_12700.apply(ns_12699,final_args_array_12698);
})();

return callback_chan_12695;
});
chromex.ext.runtime.restart_STAR_ = (function chromex$ext$runtime$restart_STAR_(config){
var result_12719 = (function (){var final_args_array_12720 = chromex.support.prepare_final_args_array(cljs.core.PersistentVector.EMPTY,"chrome.runtime.restart");
var ns_12721 = (function (){var target_obj_12723 = cljs.core.cst$kw$root.cljs$core$IFn$_invoke$arity$1(config);
var next_obj_12724 = (target_obj_12723["chrome"]);
var next_obj_12725 = (next_obj_12724["runtime"]);
return next_obj_12725;
})();
var config__6181__auto___12728 = config;
var api_check_fn__6182__auto___12729 = cljs.core.cst$kw$missing_DASH_api_DASH_check_DASH_fn.cljs$core$IFn$_invoke$arity$1(config__6181__auto___12728);

(api_check_fn__6182__auto___12729.cljs$core$IFn$_invoke$arity$3 ? api_check_fn__6182__auto___12729.cljs$core$IFn$_invoke$arity$3("chrome.runtime.restart",ns_12721,"restart") : api_check_fn__6182__auto___12729.call(null,"chrome.runtime.restart",ns_12721,"restart"));


var target_12722 = (function (){var target_obj_12726 = ns_12721;
var next_obj_12727 = (target_obj_12726["restart"]);
if((!((next_obj_12727 == null)))){
return next_obj_12727;
} else {
return null;
}
})();
return target_12722.apply(ns_12721,final_args_array_12720);
})();
return result_12719;
});
chromex.ext.runtime.restart_after_delay_STAR_ = (function chromex$ext$runtime$restart_after_delay_STAR_(config,seconds){
var callback_chan_12730 = (function (){var config__6143__auto__ = config;
var handler_key__6144__auto__ = cljs.core.cst$kw$callback_DASH_channel_DASH_factory;
var handler__6145__auto__ = handler_key__6144__auto__.cljs$core$IFn$_invoke$arity$1(config__6143__auto__);

return (handler__6145__auto__.cljs$core$IFn$_invoke$arity$1 ? handler__6145__auto__.cljs$core$IFn$_invoke$arity$1(config__6143__auto__) : handler__6145__auto__.call(null,config__6143__auto__));
})();
var marshalled_seconds_12732_12746 = (function (){var omit_test_12737 = seconds;
if(cljs.core.keyword_identical_QMARK_(omit_test_12737,cljs.core.cst$kw$omit)){
return cljs.core.cst$kw$omit;
} else {
return omit_test_12737;
}
})();
var marshalled_callback_12733_12747 = (function (){var config__6143__auto__ = config;
var handler_key__6144__auto__ = cljs.core.cst$kw$callback_DASH_fn_DASH_factory;
var handler__6145__auto__ = handler_key__6144__auto__.cljs$core$IFn$_invoke$arity$1(config__6143__auto__);

var G__12738 = config__6143__auto__;
var G__12739 = new cljs.core.PersistentArrayMap(null, 6, [cljs.core.cst$kw$id,cljs.core.cst$kw$chromex$ext$runtime_SLASH_restart_DASH_after_DASH_delay,cljs.core.cst$kw$name,"restartAfterDelay",cljs.core.cst$kw$since,"53",cljs.core.cst$kw$callback_QMARK_,true,cljs.core.cst$kw$params,new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentArrayMap(null, 2, [cljs.core.cst$kw$name,"seconds",cljs.core.cst$kw$type,"integer"], null),new cljs.core.PersistentArrayMap(null, 3, [cljs.core.cst$kw$name,"callback",cljs.core.cst$kw$optional_QMARK_,true,cljs.core.cst$kw$type,cljs.core.cst$kw$callback], null)], null),cljs.core.cst$kw$function_QMARK_,true], null);
var G__12740 = callback_chan_12730;
return (handler__6145__auto__.cljs$core$IFn$_invoke$arity$3 ? handler__6145__auto__.cljs$core$IFn$_invoke$arity$3(G__12738,G__12739,G__12740) : handler__6145__auto__.call(null,G__12738,G__12739,G__12740));
})();
var result_12731_12748 = (function (){var final_args_array_12734 = chromex.support.prepare_final_args_array(new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_seconds_12732_12746,"seconds",null], null),new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_callback_12733_12747,"callback",true], null)], null),"chrome.runtime.restartAfterDelay");
var ns_12735 = (function (){var target_obj_12741 = cljs.core.cst$kw$root.cljs$core$IFn$_invoke$arity$1(config);
var next_obj_12742 = (target_obj_12741["chrome"]);
var next_obj_12743 = (next_obj_12742["runtime"]);
return next_obj_12743;
})();
var config__6181__auto___12749 = config;
var api_check_fn__6182__auto___12750 = cljs.core.cst$kw$missing_DASH_api_DASH_check_DASH_fn.cljs$core$IFn$_invoke$arity$1(config__6181__auto___12749);

(api_check_fn__6182__auto___12750.cljs$core$IFn$_invoke$arity$3 ? api_check_fn__6182__auto___12750.cljs$core$IFn$_invoke$arity$3("chrome.runtime.restartAfterDelay",ns_12735,"restartAfterDelay") : api_check_fn__6182__auto___12750.call(null,"chrome.runtime.restartAfterDelay",ns_12735,"restartAfterDelay"));


var target_12736 = (function (){var target_obj_12744 = ns_12735;
var next_obj_12745 = (target_obj_12744["restartAfterDelay"]);
if((!((next_obj_12745 == null)))){
return next_obj_12745;
} else {
return null;
}
})();
return target_12736.apply(ns_12735,final_args_array_12734);
})();

return callback_chan_12730;
});
chromex.ext.runtime.connect_STAR_ = (function chromex$ext$runtime$connect_STAR_(config,extension_id,connect_info){
var marshalled_extension_id_12752 = (function (){var omit_test_12757 = extension_id;
if(cljs.core.keyword_identical_QMARK_(omit_test_12757,cljs.core.cst$kw$omit)){
return cljs.core.cst$kw$omit;
} else {
return omit_test_12757;
}
})();
var marshalled_connect_info_12753 = (function (){var omit_test_12758 = connect_info;
if(cljs.core.keyword_identical_QMARK_(omit_test_12758,cljs.core.cst$kw$omit)){
return cljs.core.cst$kw$omit;
} else {
return omit_test_12758;
}
})();
var result_12751 = (function (){var final_args_array_12754 = chromex.support.prepare_final_args_array(new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_extension_id_12752,"extension-id",true], null),new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_connect_info_12753,"connect-info",true], null)], null),"chrome.runtime.connect");
var ns_12755 = (function (){var target_obj_12759 = cljs.core.cst$kw$root.cljs$core$IFn$_invoke$arity$1(config);
var next_obj_12760 = (target_obj_12759["chrome"]);
var next_obj_12761 = (next_obj_12760["runtime"]);
return next_obj_12761;
})();
var config__6181__auto___12764 = config;
var api_check_fn__6182__auto___12765 = cljs.core.cst$kw$missing_DASH_api_DASH_check_DASH_fn.cljs$core$IFn$_invoke$arity$1(config__6181__auto___12764);

(api_check_fn__6182__auto___12765.cljs$core$IFn$_invoke$arity$3 ? api_check_fn__6182__auto___12765.cljs$core$IFn$_invoke$arity$3("chrome.runtime.connect",ns_12755,"connect") : api_check_fn__6182__auto___12765.call(null,"chrome.runtime.connect",ns_12755,"connect"));


var target_12756 = (function (){var target_obj_12762 = ns_12755;
var next_obj_12763 = (target_obj_12762["connect"]);
if((!((next_obj_12763 == null)))){
return next_obj_12763;
} else {
return null;
}
})();
return target_12756.apply(ns_12755,final_args_array_12754);
})();
return chromex.marshalling.from_native_chrome_port(config,result_12751);
});
chromex.ext.runtime.connect_native_STAR_ = (function chromex$ext$runtime$connect_native_STAR_(config,application){
var marshalled_application_12767 = (function (){var omit_test_12771 = application;
if(cljs.core.keyword_identical_QMARK_(omit_test_12771,cljs.core.cst$kw$omit)){
return cljs.core.cst$kw$omit;
} else {
return omit_test_12771;
}
})();
var result_12766 = (function (){var final_args_array_12768 = chromex.support.prepare_final_args_array(new cljs.core.PersistentVector(null, 1, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_application_12767,"application",null], null)], null),"chrome.runtime.connectNative");
var ns_12769 = (function (){var target_obj_12772 = cljs.core.cst$kw$root.cljs$core$IFn$_invoke$arity$1(config);
var next_obj_12773 = (target_obj_12772["chrome"]);
var next_obj_12774 = (next_obj_12773["runtime"]);
return next_obj_12774;
})();
var config__6181__auto___12777 = config;
var api_check_fn__6182__auto___12778 = cljs.core.cst$kw$missing_DASH_api_DASH_check_DASH_fn.cljs$core$IFn$_invoke$arity$1(config__6181__auto___12777);

(api_check_fn__6182__auto___12778.cljs$core$IFn$_invoke$arity$3 ? api_check_fn__6182__auto___12778.cljs$core$IFn$_invoke$arity$3("chrome.runtime.connectNative",ns_12769,"connectNative") : api_check_fn__6182__auto___12778.call(null,"chrome.runtime.connectNative",ns_12769,"connectNative"));


var target_12770 = (function (){var target_obj_12775 = ns_12769;
var next_obj_12776 = (target_obj_12775["connectNative"]);
if((!((next_obj_12776 == null)))){
return next_obj_12776;
} else {
return null;
}
})();
return target_12770.apply(ns_12769,final_args_array_12768);
})();
return chromex.marshalling.from_native_chrome_port(config,result_12766);
});
chromex.ext.runtime.send_message_STAR_ = (function chromex$ext$runtime$send_message_STAR_(config,extension_id,message,options){
var callback_chan_12779 = (function (){var config__6143__auto__ = config;
var handler_key__6144__auto__ = cljs.core.cst$kw$callback_DASH_channel_DASH_factory;
var handler__6145__auto__ = handler_key__6144__auto__.cljs$core$IFn$_invoke$arity$1(config__6143__auto__);

return (handler__6145__auto__.cljs$core$IFn$_invoke$arity$1 ? handler__6145__auto__.cljs$core$IFn$_invoke$arity$1(config__6143__auto__) : handler__6145__auto__.call(null,config__6143__auto__));
})();
var marshalled_extension_id_12781_12804 = (function (){var omit_test_12788 = extension_id;
if(cljs.core.keyword_identical_QMARK_(omit_test_12788,cljs.core.cst$kw$omit)){
return cljs.core.cst$kw$omit;
} else {
return omit_test_12788;
}
})();
var marshalled_message_12782_12805 = (function (){var omit_test_12789 = message;
if(cljs.core.keyword_identical_QMARK_(omit_test_12789,cljs.core.cst$kw$omit)){
return cljs.core.cst$kw$omit;
} else {
return omit_test_12789;
}
})();
var marshalled_options_12783_12806 = (function (){var omit_test_12790 = options;
if(cljs.core.keyword_identical_QMARK_(omit_test_12790,cljs.core.cst$kw$omit)){
return cljs.core.cst$kw$omit;
} else {
return omit_test_12790;
}
})();
var marshalled_response_callback_12784_12807 = ((function (marshalled_extension_id_12781_12804,marshalled_message_12782_12805,marshalled_options_12783_12806,callback_chan_12779){
return (function (cb_response_12791){
var fexpr__12795 = (function (){var config__6143__auto__ = config;
var handler_key__6144__auto__ = cljs.core.cst$kw$callback_DASH_fn_DASH_factory;
var handler__6145__auto__ = handler_key__6144__auto__.cljs$core$IFn$_invoke$arity$1(config__6143__auto__);

var G__12796 = config__6143__auto__;
var G__12797 = new cljs.core.PersistentArrayMap(null, 5, [cljs.core.cst$kw$id,cljs.core.cst$kw$chromex$ext$runtime_SLASH_send_DASH_message,cljs.core.cst$kw$name,"sendMessage",cljs.core.cst$kw$callback_QMARK_,true,cljs.core.cst$kw$params,new cljs.core.PersistentVector(null, 4, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentArrayMap(null, 3, [cljs.core.cst$kw$name,"extension-id",cljs.core.cst$kw$optional_QMARK_,true,cljs.core.cst$kw$type,"string"], null),new cljs.core.PersistentArrayMap(null, 2, [cljs.core.cst$kw$name,"message",cljs.core.cst$kw$type,"any"], null),new cljs.core.PersistentArrayMap(null, 3, [cljs.core.cst$kw$name,"options",cljs.core.cst$kw$optional_QMARK_,true,cljs.core.cst$kw$type,"object"], null),new cljs.core.PersistentArrayMap(null, 4, [cljs.core.cst$kw$name,"response-callback",cljs.core.cst$kw$optional_QMARK_,true,cljs.core.cst$kw$type,cljs.core.cst$kw$callback,cljs.core.cst$kw$callback,new cljs.core.PersistentArrayMap(null, 1, [cljs.core.cst$kw$params,new cljs.core.PersistentVector(null, 1, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentArrayMap(null, 2, [cljs.core.cst$kw$name,"response",cljs.core.cst$kw$type,"any"], null)], null)], null)], null)], null),cljs.core.cst$kw$function_QMARK_,true], null);
var G__12798 = callback_chan_12779;
return (handler__6145__auto__.cljs$core$IFn$_invoke$arity$3 ? handler__6145__auto__.cljs$core$IFn$_invoke$arity$3(G__12796,G__12797,G__12798) : handler__6145__auto__.call(null,G__12796,G__12797,G__12798));
})();
return (fexpr__12795.cljs$core$IFn$_invoke$arity$1 ? fexpr__12795.cljs$core$IFn$_invoke$arity$1(cb_response_12791) : fexpr__12795.call(null,cb_response_12791));
});})(marshalled_extension_id_12781_12804,marshalled_message_12782_12805,marshalled_options_12783_12806,callback_chan_12779))
;
var result_12780_12808 = (function (){var final_args_array_12785 = chromex.support.prepare_final_args_array(new cljs.core.PersistentVector(null, 4, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_extension_id_12781_12804,"extension-id",true], null),new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_message_12782_12805,"message",null], null),new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_options_12783_12806,"options",true], null),new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_response_callback_12784_12807,"response-callback",true], null)], null),"chrome.runtime.sendMessage");
var ns_12786 = (function (){var target_obj_12799 = cljs.core.cst$kw$root.cljs$core$IFn$_invoke$arity$1(config);
var next_obj_12800 = (target_obj_12799["chrome"]);
var next_obj_12801 = (next_obj_12800["runtime"]);
return next_obj_12801;
})();
var config__6181__auto___12809 = config;
var api_check_fn__6182__auto___12810 = cljs.core.cst$kw$missing_DASH_api_DASH_check_DASH_fn.cljs$core$IFn$_invoke$arity$1(config__6181__auto___12809);

(api_check_fn__6182__auto___12810.cljs$core$IFn$_invoke$arity$3 ? api_check_fn__6182__auto___12810.cljs$core$IFn$_invoke$arity$3("chrome.runtime.sendMessage",ns_12786,"sendMessage") : api_check_fn__6182__auto___12810.call(null,"chrome.runtime.sendMessage",ns_12786,"sendMessage"));


var target_12787 = (function (){var target_obj_12802 = ns_12786;
var next_obj_12803 = (target_obj_12802["sendMessage"]);
if((!((next_obj_12803 == null)))){
return next_obj_12803;
} else {
return null;
}
})();
return target_12787.apply(ns_12786,final_args_array_12785);
})();

return callback_chan_12779;
});
chromex.ext.runtime.send_native_message_STAR_ = (function chromex$ext$runtime$send_native_message_STAR_(config,application,message){
var callback_chan_12811 = (function (){var config__6143__auto__ = config;
var handler_key__6144__auto__ = cljs.core.cst$kw$callback_DASH_channel_DASH_factory;
var handler__6145__auto__ = handler_key__6144__auto__.cljs$core$IFn$_invoke$arity$1(config__6143__auto__);

return (handler__6145__auto__.cljs$core$IFn$_invoke$arity$1 ? handler__6145__auto__.cljs$core$IFn$_invoke$arity$1(config__6143__auto__) : handler__6145__auto__.call(null,config__6143__auto__));
})();
var marshalled_application_12813_12834 = (function (){var omit_test_12819 = application;
if(cljs.core.keyword_identical_QMARK_(omit_test_12819,cljs.core.cst$kw$omit)){
return cljs.core.cst$kw$omit;
} else {
return omit_test_12819;
}
})();
var marshalled_message_12814_12835 = (function (){var omit_test_12820 = message;
if(cljs.core.keyword_identical_QMARK_(omit_test_12820,cljs.core.cst$kw$omit)){
return cljs.core.cst$kw$omit;
} else {
return omit_test_12820;
}
})();
var marshalled_response_callback_12815_12836 = ((function (marshalled_application_12813_12834,marshalled_message_12814_12835,callback_chan_12811){
return (function (cb_response_12821){
var fexpr__12825 = (function (){var config__6143__auto__ = config;
var handler_key__6144__auto__ = cljs.core.cst$kw$callback_DASH_fn_DASH_factory;
var handler__6145__auto__ = handler_key__6144__auto__.cljs$core$IFn$_invoke$arity$1(config__6143__auto__);

var G__12826 = config__6143__auto__;
var G__12827 = new cljs.core.PersistentArrayMap(null, 6, [cljs.core.cst$kw$id,cljs.core.cst$kw$chromex$ext$runtime_SLASH_send_DASH_native_DASH_message,cljs.core.cst$kw$name,"sendNativeMessage",cljs.core.cst$kw$since,"28",cljs.core.cst$kw$callback_QMARK_,true,cljs.core.cst$kw$params,new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentArrayMap(null, 2, [cljs.core.cst$kw$name,"application",cljs.core.cst$kw$type,"string"], null),new cljs.core.PersistentArrayMap(null, 2, [cljs.core.cst$kw$name,"message",cljs.core.cst$kw$type,"object"], null),new cljs.core.PersistentArrayMap(null, 4, [cljs.core.cst$kw$name,"response-callback",cljs.core.cst$kw$optional_QMARK_,true,cljs.core.cst$kw$type,cljs.core.cst$kw$callback,cljs.core.cst$kw$callback,new cljs.core.PersistentArrayMap(null, 1, [cljs.core.cst$kw$params,new cljs.core.PersistentVector(null, 1, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentArrayMap(null, 2, [cljs.core.cst$kw$name,"response",cljs.core.cst$kw$type,"any"], null)], null)], null)], null)], null),cljs.core.cst$kw$function_QMARK_,true], null);
var G__12828 = callback_chan_12811;
return (handler__6145__auto__.cljs$core$IFn$_invoke$arity$3 ? handler__6145__auto__.cljs$core$IFn$_invoke$arity$3(G__12826,G__12827,G__12828) : handler__6145__auto__.call(null,G__12826,G__12827,G__12828));
})();
return (fexpr__12825.cljs$core$IFn$_invoke$arity$1 ? fexpr__12825.cljs$core$IFn$_invoke$arity$1(cb_response_12821) : fexpr__12825.call(null,cb_response_12821));
});})(marshalled_application_12813_12834,marshalled_message_12814_12835,callback_chan_12811))
;
var result_12812_12837 = (function (){var final_args_array_12816 = chromex.support.prepare_final_args_array(new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_application_12813_12834,"application",null], null),new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_message_12814_12835,"message",null], null),new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_response_callback_12815_12836,"response-callback",true], null)], null),"chrome.runtime.sendNativeMessage");
var ns_12817 = (function (){var target_obj_12829 = cljs.core.cst$kw$root.cljs$core$IFn$_invoke$arity$1(config);
var next_obj_12830 = (target_obj_12829["chrome"]);
var next_obj_12831 = (next_obj_12830["runtime"]);
return next_obj_12831;
})();
var config__6181__auto___12838 = config;
var api_check_fn__6182__auto___12839 = cljs.core.cst$kw$missing_DASH_api_DASH_check_DASH_fn.cljs$core$IFn$_invoke$arity$1(config__6181__auto___12838);

(api_check_fn__6182__auto___12839.cljs$core$IFn$_invoke$arity$3 ? api_check_fn__6182__auto___12839.cljs$core$IFn$_invoke$arity$3("chrome.runtime.sendNativeMessage",ns_12817,"sendNativeMessage") : api_check_fn__6182__auto___12839.call(null,"chrome.runtime.sendNativeMessage",ns_12817,"sendNativeMessage"));


var target_12818 = (function (){var target_obj_12832 = ns_12817;
var next_obj_12833 = (target_obj_12832["sendNativeMessage"]);
if((!((next_obj_12833 == null)))){
return next_obj_12833;
} else {
return null;
}
})();
return target_12818.apply(ns_12817,final_args_array_12816);
})();

return callback_chan_12811;
});
chromex.ext.runtime.get_platform_info_STAR_ = (function chromex$ext$runtime$get_platform_info_STAR_(config){
var callback_chan_12840 = (function (){var config__6143__auto__ = config;
var handler_key__6144__auto__ = cljs.core.cst$kw$callback_DASH_channel_DASH_factory;
var handler__6145__auto__ = handler_key__6144__auto__.cljs$core$IFn$_invoke$arity$1(config__6143__auto__);

return (handler__6145__auto__.cljs$core$IFn$_invoke$arity$1 ? handler__6145__auto__.cljs$core$IFn$_invoke$arity$1(config__6143__auto__) : handler__6145__auto__.call(null,config__6143__auto__));
})();
var marshalled_callback_12842_12859 = ((function (callback_chan_12840){
return (function (cb_platform_info_12846){
var fexpr__12850 = (function (){var config__6143__auto__ = config;
var handler_key__6144__auto__ = cljs.core.cst$kw$callback_DASH_fn_DASH_factory;
var handler__6145__auto__ = handler_key__6144__auto__.cljs$core$IFn$_invoke$arity$1(config__6143__auto__);

var G__12851 = config__6143__auto__;
var G__12852 = new cljs.core.PersistentArrayMap(null, 6, [cljs.core.cst$kw$id,cljs.core.cst$kw$chromex$ext$runtime_SLASH_get_DASH_platform_DASH_info,cljs.core.cst$kw$name,"getPlatformInfo",cljs.core.cst$kw$since,"29",cljs.core.cst$kw$callback_QMARK_,true,cljs.core.cst$kw$params,new cljs.core.PersistentVector(null, 1, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentArrayMap(null, 3, [cljs.core.cst$kw$name,"callback",cljs.core.cst$kw$type,cljs.core.cst$kw$callback,cljs.core.cst$kw$callback,new cljs.core.PersistentArrayMap(null, 1, [cljs.core.cst$kw$params,new cljs.core.PersistentVector(null, 1, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentArrayMap(null, 2, [cljs.core.cst$kw$name,"platform-info",cljs.core.cst$kw$type,"runtime.PlatformInfo"], null)], null)], null)], null)], null),cljs.core.cst$kw$function_QMARK_,true], null);
var G__12853 = callback_chan_12840;
return (handler__6145__auto__.cljs$core$IFn$_invoke$arity$3 ? handler__6145__auto__.cljs$core$IFn$_invoke$arity$3(G__12851,G__12852,G__12853) : handler__6145__auto__.call(null,G__12851,G__12852,G__12853));
})();
return (fexpr__12850.cljs$core$IFn$_invoke$arity$1 ? fexpr__12850.cljs$core$IFn$_invoke$arity$1(cb_platform_info_12846) : fexpr__12850.call(null,cb_platform_info_12846));
});})(callback_chan_12840))
;
var result_12841_12860 = (function (){var final_args_array_12843 = chromex.support.prepare_final_args_array(new cljs.core.PersistentVector(null, 1, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_callback_12842_12859,"callback",null], null)], null),"chrome.runtime.getPlatformInfo");
var ns_12844 = (function (){var target_obj_12854 = cljs.core.cst$kw$root.cljs$core$IFn$_invoke$arity$1(config);
var next_obj_12855 = (target_obj_12854["chrome"]);
var next_obj_12856 = (next_obj_12855["runtime"]);
return next_obj_12856;
})();
var config__6181__auto___12861 = config;
var api_check_fn__6182__auto___12862 = cljs.core.cst$kw$missing_DASH_api_DASH_check_DASH_fn.cljs$core$IFn$_invoke$arity$1(config__6181__auto___12861);

(api_check_fn__6182__auto___12862.cljs$core$IFn$_invoke$arity$3 ? api_check_fn__6182__auto___12862.cljs$core$IFn$_invoke$arity$3("chrome.runtime.getPlatformInfo",ns_12844,"getPlatformInfo") : api_check_fn__6182__auto___12862.call(null,"chrome.runtime.getPlatformInfo",ns_12844,"getPlatformInfo"));


var target_12845 = (function (){var target_obj_12857 = ns_12844;
var next_obj_12858 = (target_obj_12857["getPlatformInfo"]);
if((!((next_obj_12858 == null)))){
return next_obj_12858;
} else {
return null;
}
})();
return target_12845.apply(ns_12844,final_args_array_12843);
})();

return callback_chan_12840;
});
chromex.ext.runtime.get_package_directory_entry_STAR_ = (function chromex$ext$runtime$get_package_directory_entry_STAR_(config){
var callback_chan_12863 = (function (){var config__6143__auto__ = config;
var handler_key__6144__auto__ = cljs.core.cst$kw$callback_DASH_channel_DASH_factory;
var handler__6145__auto__ = handler_key__6144__auto__.cljs$core$IFn$_invoke$arity$1(config__6143__auto__);

return (handler__6145__auto__.cljs$core$IFn$_invoke$arity$1 ? handler__6145__auto__.cljs$core$IFn$_invoke$arity$1(config__6143__auto__) : handler__6145__auto__.call(null,config__6143__auto__));
})();
var marshalled_callback_12865_12882 = ((function (callback_chan_12863){
return (function (cb_directory_entry_12869){
var fexpr__12873 = (function (){var config__6143__auto__ = config;
var handler_key__6144__auto__ = cljs.core.cst$kw$callback_DASH_fn_DASH_factory;
var handler__6145__auto__ = handler_key__6144__auto__.cljs$core$IFn$_invoke$arity$1(config__6143__auto__);

var G__12874 = config__6143__auto__;
var G__12875 = new cljs.core.PersistentArrayMap(null, 6, [cljs.core.cst$kw$id,cljs.core.cst$kw$chromex$ext$runtime_SLASH_get_DASH_package_DASH_directory_DASH_entry,cljs.core.cst$kw$name,"getPackageDirectoryEntry",cljs.core.cst$kw$since,"29",cljs.core.cst$kw$callback_QMARK_,true,cljs.core.cst$kw$params,new cljs.core.PersistentVector(null, 1, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentArrayMap(null, 3, [cljs.core.cst$kw$name,"callback",cljs.core.cst$kw$type,cljs.core.cst$kw$callback,cljs.core.cst$kw$callback,new cljs.core.PersistentArrayMap(null, 1, [cljs.core.cst$kw$params,new cljs.core.PersistentVector(null, 1, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentArrayMap(null, 2, [cljs.core.cst$kw$name,"directory-entry",cljs.core.cst$kw$type,"DirectoryEntry"], null)], null)], null)], null)], null),cljs.core.cst$kw$function_QMARK_,true], null);
var G__12876 = callback_chan_12863;
return (handler__6145__auto__.cljs$core$IFn$_invoke$arity$3 ? handler__6145__auto__.cljs$core$IFn$_invoke$arity$3(G__12874,G__12875,G__12876) : handler__6145__auto__.call(null,G__12874,G__12875,G__12876));
})();
return (fexpr__12873.cljs$core$IFn$_invoke$arity$1 ? fexpr__12873.cljs$core$IFn$_invoke$arity$1(cb_directory_entry_12869) : fexpr__12873.call(null,cb_directory_entry_12869));
});})(callback_chan_12863))
;
var result_12864_12883 = (function (){var final_args_array_12866 = chromex.support.prepare_final_args_array(new cljs.core.PersistentVector(null, 1, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_callback_12865_12882,"callback",null], null)], null),"chrome.runtime.getPackageDirectoryEntry");
var ns_12867 = (function (){var target_obj_12877 = cljs.core.cst$kw$root.cljs$core$IFn$_invoke$arity$1(config);
var next_obj_12878 = (target_obj_12877["chrome"]);
var next_obj_12879 = (next_obj_12878["runtime"]);
return next_obj_12879;
})();
var config__6181__auto___12884 = config;
var api_check_fn__6182__auto___12885 = cljs.core.cst$kw$missing_DASH_api_DASH_check_DASH_fn.cljs$core$IFn$_invoke$arity$1(config__6181__auto___12884);

(api_check_fn__6182__auto___12885.cljs$core$IFn$_invoke$arity$3 ? api_check_fn__6182__auto___12885.cljs$core$IFn$_invoke$arity$3("chrome.runtime.getPackageDirectoryEntry",ns_12867,"getPackageDirectoryEntry") : api_check_fn__6182__auto___12885.call(null,"chrome.runtime.getPackageDirectoryEntry",ns_12867,"getPackageDirectoryEntry"));


var target_12868 = (function (){var target_obj_12880 = ns_12867;
var next_obj_12881 = (target_obj_12880["getPackageDirectoryEntry"]);
if((!((next_obj_12881 == null)))){
return next_obj_12881;
} else {
return null;
}
})();
return target_12868.apply(ns_12867,final_args_array_12866);
})();

return callback_chan_12863;
});
chromex.ext.runtime.on_startup_STAR_ = (function chromex$ext$runtime$on_startup_STAR_(var_args){
var args__4647__auto__ = [];
var len__4641__auto___12903 = arguments.length;
var i__4642__auto___12904 = (0);
while(true){
if((i__4642__auto___12904 < len__4641__auto___12903)){
args__4647__auto__.push((arguments[i__4642__auto___12904]));

var G__12905 = (i__4642__auto___12904 + (1));
i__4642__auto___12904 = G__12905;
continue;
} else {
}
break;
}

var argseq__4648__auto__ = ((((2) < args__4647__auto__.length))?(new cljs.core.IndexedSeq(args__4647__auto__.slice((2)),(0),null)):null);
return chromex.ext.runtime.on_startup_STAR_.cljs$core$IFn$_invoke$arity$variadic((arguments[(0)]),(arguments[(1)]),argseq__4648__auto__);
});

chromex.ext.runtime.on_startup_STAR_.cljs$core$IFn$_invoke$arity$variadic = (function (config,channel,args){
var event_fn_12889 = (function (){var config__6143__auto__ = config;
var handler_key__6144__auto__ = cljs.core.cst$kw$event_DASH_listener_DASH_factory;
var handler__6145__auto__ = handler_key__6144__auto__.cljs$core$IFn$_invoke$arity$1(config__6143__auto__);

var G__12895 = config__6143__auto__;
var G__12896 = cljs.core.cst$kw$chromex$ext$runtime_SLASH_on_DASH_startup;
var G__12897 = channel;
return (handler__6145__auto__.cljs$core$IFn$_invoke$arity$3 ? handler__6145__auto__.cljs$core$IFn$_invoke$arity$3(G__12895,G__12896,G__12897) : handler__6145__auto__.call(null,G__12895,G__12896,G__12897));
})();
var handler_fn_12890 = event_fn_12889;
var logging_fn_12891 = ((function (event_fn_12889,handler_fn_12890){
return (function (){

return (handler_fn_12890.cljs$core$IFn$_invoke$arity$0 ? handler_fn_12890.cljs$core$IFn$_invoke$arity$0() : handler_fn_12890.call(null));
});})(event_fn_12889,handler_fn_12890))
;
var ns_obj_12894 = (function (){var target_obj_12898 = cljs.core.cst$kw$root.cljs$core$IFn$_invoke$arity$1(config);
var next_obj_12899 = (target_obj_12898["chrome"]);
var next_obj_12900 = (next_obj_12899["runtime"]);
return next_obj_12900;
})();
var config__6181__auto___12906 = config;
var api_check_fn__6182__auto___12907 = cljs.core.cst$kw$missing_DASH_api_DASH_check_DASH_fn.cljs$core$IFn$_invoke$arity$1(config__6181__auto___12906);

(api_check_fn__6182__auto___12907.cljs$core$IFn$_invoke$arity$3 ? api_check_fn__6182__auto___12907.cljs$core$IFn$_invoke$arity$3("chrome.runtime.onStartup",ns_obj_12894,"onStartup") : api_check_fn__6182__auto___12907.call(null,"chrome.runtime.onStartup",ns_obj_12894,"onStartup"));

var event_obj_12892 = (function (){var target_obj_12901 = ns_obj_12894;
var next_obj_12902 = (target_obj_12901["onStartup"]);
return next_obj_12902;
})();
var result_12893 = chromex.chrome_event_subscription.make_chrome_event_subscription(event_obj_12892,logging_fn_12891,channel);
result_12893.chromex$protocols$chrome_event_subscription$IChromeEventSubscription$subscribe_BANG_$arity$2(null,args);

return result_12893;
});

chromex.ext.runtime.on_startup_STAR_.cljs$lang$maxFixedArity = (2);

/** @this {Function} */
chromex.ext.runtime.on_startup_STAR_.cljs$lang$applyTo = (function (seq12886){
var G__12887 = cljs.core.first(seq12886);
var seq12886__$1 = cljs.core.next(seq12886);
var G__12888 = cljs.core.first(seq12886__$1);
var seq12886__$2 = cljs.core.next(seq12886__$1);
var self__4628__auto__ = this;
return self__4628__auto__.cljs$core$IFn$_invoke$arity$variadic(G__12887,G__12888,seq12886__$2);
});

chromex.ext.runtime.on_installed_STAR_ = (function chromex$ext$runtime$on_installed_STAR_(var_args){
var args__4647__auto__ = [];
var len__4641__auto___12927 = arguments.length;
var i__4642__auto___12928 = (0);
while(true){
if((i__4642__auto___12928 < len__4641__auto___12927)){
args__4647__auto__.push((arguments[i__4642__auto___12928]));

var G__12929 = (i__4642__auto___12928 + (1));
i__4642__auto___12928 = G__12929;
continue;
} else {
}
break;
}

var argseq__4648__auto__ = ((((2) < args__4647__auto__.length))?(new cljs.core.IndexedSeq(args__4647__auto__.slice((2)),(0),null)):null);
return chromex.ext.runtime.on_installed_STAR_.cljs$core$IFn$_invoke$arity$variadic((arguments[(0)]),(arguments[(1)]),argseq__4648__auto__);
});

chromex.ext.runtime.on_installed_STAR_.cljs$core$IFn$_invoke$arity$variadic = (function (config,channel,args){
var event_fn_12911 = (function (){var config__6143__auto__ = config;
var handler_key__6144__auto__ = cljs.core.cst$kw$event_DASH_listener_DASH_factory;
var handler__6145__auto__ = handler_key__6144__auto__.cljs$core$IFn$_invoke$arity$1(config__6143__auto__);

var G__12919 = config__6143__auto__;
var G__12920 = cljs.core.cst$kw$chromex$ext$runtime_SLASH_on_DASH_installed;
var G__12921 = channel;
return (handler__6145__auto__.cljs$core$IFn$_invoke$arity$3 ? handler__6145__auto__.cljs$core$IFn$_invoke$arity$3(G__12919,G__12920,G__12921) : handler__6145__auto__.call(null,G__12919,G__12920,G__12921));
})();
var handler_fn_12912 = ((function (event_fn_12911){
return (function (cb_details_12917){
return (event_fn_12911.cljs$core$IFn$_invoke$arity$1 ? event_fn_12911.cljs$core$IFn$_invoke$arity$1(cb_details_12917) : event_fn_12911.call(null,cb_details_12917));
});})(event_fn_12911))
;
var logging_fn_12913 = ((function (event_fn_12911,handler_fn_12912){
return (function (cb_param_details_12918){

return handler_fn_12912(cb_param_details_12918);
});})(event_fn_12911,handler_fn_12912))
;
var ns_obj_12916 = (function (){var target_obj_12922 = cljs.core.cst$kw$root.cljs$core$IFn$_invoke$arity$1(config);
var next_obj_12923 = (target_obj_12922["chrome"]);
var next_obj_12924 = (next_obj_12923["runtime"]);
return next_obj_12924;
})();
var config__6181__auto___12930 = config;
var api_check_fn__6182__auto___12931 = cljs.core.cst$kw$missing_DASH_api_DASH_check_DASH_fn.cljs$core$IFn$_invoke$arity$1(config__6181__auto___12930);

(api_check_fn__6182__auto___12931.cljs$core$IFn$_invoke$arity$3 ? api_check_fn__6182__auto___12931.cljs$core$IFn$_invoke$arity$3("chrome.runtime.onInstalled",ns_obj_12916,"onInstalled") : api_check_fn__6182__auto___12931.call(null,"chrome.runtime.onInstalled",ns_obj_12916,"onInstalled"));

var event_obj_12914 = (function (){var target_obj_12925 = ns_obj_12916;
var next_obj_12926 = (target_obj_12925["onInstalled"]);
return next_obj_12926;
})();
var result_12915 = chromex.chrome_event_subscription.make_chrome_event_subscription(event_obj_12914,logging_fn_12913,channel);
result_12915.chromex$protocols$chrome_event_subscription$IChromeEventSubscription$subscribe_BANG_$arity$2(null,args);

return result_12915;
});

chromex.ext.runtime.on_installed_STAR_.cljs$lang$maxFixedArity = (2);

/** @this {Function} */
chromex.ext.runtime.on_installed_STAR_.cljs$lang$applyTo = (function (seq12908){
var G__12909 = cljs.core.first(seq12908);
var seq12908__$1 = cljs.core.next(seq12908);
var G__12910 = cljs.core.first(seq12908__$1);
var seq12908__$2 = cljs.core.next(seq12908__$1);
var self__4628__auto__ = this;
return self__4628__auto__.cljs$core$IFn$_invoke$arity$variadic(G__12909,G__12910,seq12908__$2);
});

chromex.ext.runtime.on_suspend_STAR_ = (function chromex$ext$runtime$on_suspend_STAR_(var_args){
var args__4647__auto__ = [];
var len__4641__auto___12949 = arguments.length;
var i__4642__auto___12950 = (0);
while(true){
if((i__4642__auto___12950 < len__4641__auto___12949)){
args__4647__auto__.push((arguments[i__4642__auto___12950]));

var G__12951 = (i__4642__auto___12950 + (1));
i__4642__auto___12950 = G__12951;
continue;
} else {
}
break;
}

var argseq__4648__auto__ = ((((2) < args__4647__auto__.length))?(new cljs.core.IndexedSeq(args__4647__auto__.slice((2)),(0),null)):null);
return chromex.ext.runtime.on_suspend_STAR_.cljs$core$IFn$_invoke$arity$variadic((arguments[(0)]),(arguments[(1)]),argseq__4648__auto__);
});

chromex.ext.runtime.on_suspend_STAR_.cljs$core$IFn$_invoke$arity$variadic = (function (config,channel,args){
var event_fn_12935 = (function (){var config__6143__auto__ = config;
var handler_key__6144__auto__ = cljs.core.cst$kw$event_DASH_listener_DASH_factory;
var handler__6145__auto__ = handler_key__6144__auto__.cljs$core$IFn$_invoke$arity$1(config__6143__auto__);

var G__12941 = config__6143__auto__;
var G__12942 = cljs.core.cst$kw$chromex$ext$runtime_SLASH_on_DASH_suspend;
var G__12943 = channel;
return (handler__6145__auto__.cljs$core$IFn$_invoke$arity$3 ? handler__6145__auto__.cljs$core$IFn$_invoke$arity$3(G__12941,G__12942,G__12943) : handler__6145__auto__.call(null,G__12941,G__12942,G__12943));
})();
var handler_fn_12936 = event_fn_12935;
var logging_fn_12937 = ((function (event_fn_12935,handler_fn_12936){
return (function (){

return (handler_fn_12936.cljs$core$IFn$_invoke$arity$0 ? handler_fn_12936.cljs$core$IFn$_invoke$arity$0() : handler_fn_12936.call(null));
});})(event_fn_12935,handler_fn_12936))
;
var ns_obj_12940 = (function (){var target_obj_12944 = cljs.core.cst$kw$root.cljs$core$IFn$_invoke$arity$1(config);
var next_obj_12945 = (target_obj_12944["chrome"]);
var next_obj_12946 = (next_obj_12945["runtime"]);
return next_obj_12946;
})();
var config__6181__auto___12952 = config;
var api_check_fn__6182__auto___12953 = cljs.core.cst$kw$missing_DASH_api_DASH_check_DASH_fn.cljs$core$IFn$_invoke$arity$1(config__6181__auto___12952);

(api_check_fn__6182__auto___12953.cljs$core$IFn$_invoke$arity$3 ? api_check_fn__6182__auto___12953.cljs$core$IFn$_invoke$arity$3("chrome.runtime.onSuspend",ns_obj_12940,"onSuspend") : api_check_fn__6182__auto___12953.call(null,"chrome.runtime.onSuspend",ns_obj_12940,"onSuspend"));

var event_obj_12938 = (function (){var target_obj_12947 = ns_obj_12940;
var next_obj_12948 = (target_obj_12947["onSuspend"]);
return next_obj_12948;
})();
var result_12939 = chromex.chrome_event_subscription.make_chrome_event_subscription(event_obj_12938,logging_fn_12937,channel);
result_12939.chromex$protocols$chrome_event_subscription$IChromeEventSubscription$subscribe_BANG_$arity$2(null,args);

return result_12939;
});

chromex.ext.runtime.on_suspend_STAR_.cljs$lang$maxFixedArity = (2);

/** @this {Function} */
chromex.ext.runtime.on_suspend_STAR_.cljs$lang$applyTo = (function (seq12932){
var G__12933 = cljs.core.first(seq12932);
var seq12932__$1 = cljs.core.next(seq12932);
var G__12934 = cljs.core.first(seq12932__$1);
var seq12932__$2 = cljs.core.next(seq12932__$1);
var self__4628__auto__ = this;
return self__4628__auto__.cljs$core$IFn$_invoke$arity$variadic(G__12933,G__12934,seq12932__$2);
});

chromex.ext.runtime.on_suspend_canceled_STAR_ = (function chromex$ext$runtime$on_suspend_canceled_STAR_(var_args){
var args__4647__auto__ = [];
var len__4641__auto___12971 = arguments.length;
var i__4642__auto___12972 = (0);
while(true){
if((i__4642__auto___12972 < len__4641__auto___12971)){
args__4647__auto__.push((arguments[i__4642__auto___12972]));

var G__12973 = (i__4642__auto___12972 + (1));
i__4642__auto___12972 = G__12973;
continue;
} else {
}
break;
}

var argseq__4648__auto__ = ((((2) < args__4647__auto__.length))?(new cljs.core.IndexedSeq(args__4647__auto__.slice((2)),(0),null)):null);
return chromex.ext.runtime.on_suspend_canceled_STAR_.cljs$core$IFn$_invoke$arity$variadic((arguments[(0)]),(arguments[(1)]),argseq__4648__auto__);
});

chromex.ext.runtime.on_suspend_canceled_STAR_.cljs$core$IFn$_invoke$arity$variadic = (function (config,channel,args){
var event_fn_12957 = (function (){var config__6143__auto__ = config;
var handler_key__6144__auto__ = cljs.core.cst$kw$event_DASH_listener_DASH_factory;
var handler__6145__auto__ = handler_key__6144__auto__.cljs$core$IFn$_invoke$arity$1(config__6143__auto__);

var G__12963 = config__6143__auto__;
var G__12964 = cljs.core.cst$kw$chromex$ext$runtime_SLASH_on_DASH_suspend_DASH_canceled;
var G__12965 = channel;
return (handler__6145__auto__.cljs$core$IFn$_invoke$arity$3 ? handler__6145__auto__.cljs$core$IFn$_invoke$arity$3(G__12963,G__12964,G__12965) : handler__6145__auto__.call(null,G__12963,G__12964,G__12965));
})();
var handler_fn_12958 = event_fn_12957;
var logging_fn_12959 = ((function (event_fn_12957,handler_fn_12958){
return (function (){

return (handler_fn_12958.cljs$core$IFn$_invoke$arity$0 ? handler_fn_12958.cljs$core$IFn$_invoke$arity$0() : handler_fn_12958.call(null));
});})(event_fn_12957,handler_fn_12958))
;
var ns_obj_12962 = (function (){var target_obj_12966 = cljs.core.cst$kw$root.cljs$core$IFn$_invoke$arity$1(config);
var next_obj_12967 = (target_obj_12966["chrome"]);
var next_obj_12968 = (next_obj_12967["runtime"]);
return next_obj_12968;
})();
var config__6181__auto___12974 = config;
var api_check_fn__6182__auto___12975 = cljs.core.cst$kw$missing_DASH_api_DASH_check_DASH_fn.cljs$core$IFn$_invoke$arity$1(config__6181__auto___12974);

(api_check_fn__6182__auto___12975.cljs$core$IFn$_invoke$arity$3 ? api_check_fn__6182__auto___12975.cljs$core$IFn$_invoke$arity$3("chrome.runtime.onSuspendCanceled",ns_obj_12962,"onSuspendCanceled") : api_check_fn__6182__auto___12975.call(null,"chrome.runtime.onSuspendCanceled",ns_obj_12962,"onSuspendCanceled"));

var event_obj_12960 = (function (){var target_obj_12969 = ns_obj_12962;
var next_obj_12970 = (target_obj_12969["onSuspendCanceled"]);
return next_obj_12970;
})();
var result_12961 = chromex.chrome_event_subscription.make_chrome_event_subscription(event_obj_12960,logging_fn_12959,channel);
result_12961.chromex$protocols$chrome_event_subscription$IChromeEventSubscription$subscribe_BANG_$arity$2(null,args);

return result_12961;
});

chromex.ext.runtime.on_suspend_canceled_STAR_.cljs$lang$maxFixedArity = (2);

/** @this {Function} */
chromex.ext.runtime.on_suspend_canceled_STAR_.cljs$lang$applyTo = (function (seq12954){
var G__12955 = cljs.core.first(seq12954);
var seq12954__$1 = cljs.core.next(seq12954);
var G__12956 = cljs.core.first(seq12954__$1);
var seq12954__$2 = cljs.core.next(seq12954__$1);
var self__4628__auto__ = this;
return self__4628__auto__.cljs$core$IFn$_invoke$arity$variadic(G__12955,G__12956,seq12954__$2);
});

chromex.ext.runtime.on_update_available_STAR_ = (function chromex$ext$runtime$on_update_available_STAR_(var_args){
var args__4647__auto__ = [];
var len__4641__auto___12995 = arguments.length;
var i__4642__auto___12996 = (0);
while(true){
if((i__4642__auto___12996 < len__4641__auto___12995)){
args__4647__auto__.push((arguments[i__4642__auto___12996]));

var G__12997 = (i__4642__auto___12996 + (1));
i__4642__auto___12996 = G__12997;
continue;
} else {
}
break;
}

var argseq__4648__auto__ = ((((2) < args__4647__auto__.length))?(new cljs.core.IndexedSeq(args__4647__auto__.slice((2)),(0),null)):null);
return chromex.ext.runtime.on_update_available_STAR_.cljs$core$IFn$_invoke$arity$variadic((arguments[(0)]),(arguments[(1)]),argseq__4648__auto__);
});

chromex.ext.runtime.on_update_available_STAR_.cljs$core$IFn$_invoke$arity$variadic = (function (config,channel,args){
var event_fn_12979 = (function (){var config__6143__auto__ = config;
var handler_key__6144__auto__ = cljs.core.cst$kw$event_DASH_listener_DASH_factory;
var handler__6145__auto__ = handler_key__6144__auto__.cljs$core$IFn$_invoke$arity$1(config__6143__auto__);

var G__12987 = config__6143__auto__;
var G__12988 = cljs.core.cst$kw$chromex$ext$runtime_SLASH_on_DASH_update_DASH_available;
var G__12989 = channel;
return (handler__6145__auto__.cljs$core$IFn$_invoke$arity$3 ? handler__6145__auto__.cljs$core$IFn$_invoke$arity$3(G__12987,G__12988,G__12989) : handler__6145__auto__.call(null,G__12987,G__12988,G__12989));
})();
var handler_fn_12980 = ((function (event_fn_12979){
return (function (cb_details_12985){
return (event_fn_12979.cljs$core$IFn$_invoke$arity$1 ? event_fn_12979.cljs$core$IFn$_invoke$arity$1(cb_details_12985) : event_fn_12979.call(null,cb_details_12985));
});})(event_fn_12979))
;
var logging_fn_12981 = ((function (event_fn_12979,handler_fn_12980){
return (function (cb_param_details_12986){

return handler_fn_12980(cb_param_details_12986);
});})(event_fn_12979,handler_fn_12980))
;
var ns_obj_12984 = (function (){var target_obj_12990 = cljs.core.cst$kw$root.cljs$core$IFn$_invoke$arity$1(config);
var next_obj_12991 = (target_obj_12990["chrome"]);
var next_obj_12992 = (next_obj_12991["runtime"]);
return next_obj_12992;
})();
var config__6181__auto___12998 = config;
var api_check_fn__6182__auto___12999 = cljs.core.cst$kw$missing_DASH_api_DASH_check_DASH_fn.cljs$core$IFn$_invoke$arity$1(config__6181__auto___12998);

(api_check_fn__6182__auto___12999.cljs$core$IFn$_invoke$arity$3 ? api_check_fn__6182__auto___12999.cljs$core$IFn$_invoke$arity$3("chrome.runtime.onUpdateAvailable",ns_obj_12984,"onUpdateAvailable") : api_check_fn__6182__auto___12999.call(null,"chrome.runtime.onUpdateAvailable",ns_obj_12984,"onUpdateAvailable"));

var event_obj_12982 = (function (){var target_obj_12993 = ns_obj_12984;
var next_obj_12994 = (target_obj_12993["onUpdateAvailable"]);
return next_obj_12994;
})();
var result_12983 = chromex.chrome_event_subscription.make_chrome_event_subscription(event_obj_12982,logging_fn_12981,channel);
result_12983.chromex$protocols$chrome_event_subscription$IChromeEventSubscription$subscribe_BANG_$arity$2(null,args);

return result_12983;
});

chromex.ext.runtime.on_update_available_STAR_.cljs$lang$maxFixedArity = (2);

/** @this {Function} */
chromex.ext.runtime.on_update_available_STAR_.cljs$lang$applyTo = (function (seq12976){
var G__12977 = cljs.core.first(seq12976);
var seq12976__$1 = cljs.core.next(seq12976);
var G__12978 = cljs.core.first(seq12976__$1);
var seq12976__$2 = cljs.core.next(seq12976__$1);
var self__4628__auto__ = this;
return self__4628__auto__.cljs$core$IFn$_invoke$arity$variadic(G__12977,G__12978,seq12976__$2);
});

chromex.ext.runtime.on_browser_update_available_STAR_ = (function chromex$ext$runtime$on_browser_update_available_STAR_(var_args){
var args__4647__auto__ = [];
var len__4641__auto___13017 = arguments.length;
var i__4642__auto___13018 = (0);
while(true){
if((i__4642__auto___13018 < len__4641__auto___13017)){
args__4647__auto__.push((arguments[i__4642__auto___13018]));

var G__13019 = (i__4642__auto___13018 + (1));
i__4642__auto___13018 = G__13019;
continue;
} else {
}
break;
}

var argseq__4648__auto__ = ((((2) < args__4647__auto__.length))?(new cljs.core.IndexedSeq(args__4647__auto__.slice((2)),(0),null)):null);
return chromex.ext.runtime.on_browser_update_available_STAR_.cljs$core$IFn$_invoke$arity$variadic((arguments[(0)]),(arguments[(1)]),argseq__4648__auto__);
});

chromex.ext.runtime.on_browser_update_available_STAR_.cljs$core$IFn$_invoke$arity$variadic = (function (config,channel,args){
var event_fn_13003 = (function (){var config__6143__auto__ = config;
var handler_key__6144__auto__ = cljs.core.cst$kw$event_DASH_listener_DASH_factory;
var handler__6145__auto__ = handler_key__6144__auto__.cljs$core$IFn$_invoke$arity$1(config__6143__auto__);

var G__13009 = config__6143__auto__;
var G__13010 = cljs.core.cst$kw$chromex$ext$runtime_SLASH_on_DASH_browser_DASH_update_DASH_available;
var G__13011 = channel;
return (handler__6145__auto__.cljs$core$IFn$_invoke$arity$3 ? handler__6145__auto__.cljs$core$IFn$_invoke$arity$3(G__13009,G__13010,G__13011) : handler__6145__auto__.call(null,G__13009,G__13010,G__13011));
})();
var handler_fn_13004 = event_fn_13003;
var logging_fn_13005 = ((function (event_fn_13003,handler_fn_13004){
return (function (){

return (handler_fn_13004.cljs$core$IFn$_invoke$arity$0 ? handler_fn_13004.cljs$core$IFn$_invoke$arity$0() : handler_fn_13004.call(null));
});})(event_fn_13003,handler_fn_13004))
;
var ns_obj_13008 = (function (){var target_obj_13012 = cljs.core.cst$kw$root.cljs$core$IFn$_invoke$arity$1(config);
var next_obj_13013 = (target_obj_13012["chrome"]);
var next_obj_13014 = (next_obj_13013["runtime"]);
return next_obj_13014;
})();
var config__6181__auto___13020 = config;
var api_check_fn__6182__auto___13021 = cljs.core.cst$kw$missing_DASH_api_DASH_check_DASH_fn.cljs$core$IFn$_invoke$arity$1(config__6181__auto___13020);

(api_check_fn__6182__auto___13021.cljs$core$IFn$_invoke$arity$3 ? api_check_fn__6182__auto___13021.cljs$core$IFn$_invoke$arity$3("chrome.runtime.onBrowserUpdateAvailable",ns_obj_13008,"onBrowserUpdateAvailable") : api_check_fn__6182__auto___13021.call(null,"chrome.runtime.onBrowserUpdateAvailable",ns_obj_13008,"onBrowserUpdateAvailable"));

var event_obj_13006 = (function (){var target_obj_13015 = ns_obj_13008;
var next_obj_13016 = (target_obj_13015["onBrowserUpdateAvailable"]);
return next_obj_13016;
})();
var result_13007 = chromex.chrome_event_subscription.make_chrome_event_subscription(event_obj_13006,logging_fn_13005,channel);
result_13007.chromex$protocols$chrome_event_subscription$IChromeEventSubscription$subscribe_BANG_$arity$2(null,args);

return result_13007;
});

chromex.ext.runtime.on_browser_update_available_STAR_.cljs$lang$maxFixedArity = (2);

/** @this {Function} */
chromex.ext.runtime.on_browser_update_available_STAR_.cljs$lang$applyTo = (function (seq13000){
var G__13001 = cljs.core.first(seq13000);
var seq13000__$1 = cljs.core.next(seq13000);
var G__13002 = cljs.core.first(seq13000__$1);
var seq13000__$2 = cljs.core.next(seq13000__$1);
var self__4628__auto__ = this;
return self__4628__auto__.cljs$core$IFn$_invoke$arity$variadic(G__13001,G__13002,seq13000__$2);
});

chromex.ext.runtime.on_connect_STAR_ = (function chromex$ext$runtime$on_connect_STAR_(var_args){
var args__4647__auto__ = [];
var len__4641__auto___13042 = arguments.length;
var i__4642__auto___13043 = (0);
while(true){
if((i__4642__auto___13043 < len__4641__auto___13042)){
args__4647__auto__.push((arguments[i__4642__auto___13043]));

var G__13044 = (i__4642__auto___13043 + (1));
i__4642__auto___13043 = G__13044;
continue;
} else {
}
break;
}

var argseq__4648__auto__ = ((((2) < args__4647__auto__.length))?(new cljs.core.IndexedSeq(args__4647__auto__.slice((2)),(0),null)):null);
return chromex.ext.runtime.on_connect_STAR_.cljs$core$IFn$_invoke$arity$variadic((arguments[(0)]),(arguments[(1)]),argseq__4648__auto__);
});

chromex.ext.runtime.on_connect_STAR_.cljs$core$IFn$_invoke$arity$variadic = (function (config,channel,args){
var event_fn_13025 = (function (){var config__6143__auto__ = config;
var handler_key__6144__auto__ = cljs.core.cst$kw$event_DASH_listener_DASH_factory;
var handler__6145__auto__ = handler_key__6144__auto__.cljs$core$IFn$_invoke$arity$1(config__6143__auto__);

var G__13033 = config__6143__auto__;
var G__13034 = cljs.core.cst$kw$chromex$ext$runtime_SLASH_on_DASH_connect;
var G__13035 = channel;
return (handler__6145__auto__.cljs$core$IFn$_invoke$arity$3 ? handler__6145__auto__.cljs$core$IFn$_invoke$arity$3(G__13033,G__13034,G__13035) : handler__6145__auto__.call(null,G__13033,G__13034,G__13035));
})();
var handler_fn_13026 = ((function (event_fn_13025){
return (function (cb_port_13031){
var G__13036 = chromex.marshalling.from_native_chrome_port(config,cb_port_13031);
return (event_fn_13025.cljs$core$IFn$_invoke$arity$1 ? event_fn_13025.cljs$core$IFn$_invoke$arity$1(G__13036) : event_fn_13025.call(null,G__13036));
});})(event_fn_13025))
;
var logging_fn_13027 = ((function (event_fn_13025,handler_fn_13026){
return (function (cb_param_port_13032){

return handler_fn_13026(cb_param_port_13032);
});})(event_fn_13025,handler_fn_13026))
;
var ns_obj_13030 = (function (){var target_obj_13037 = cljs.core.cst$kw$root.cljs$core$IFn$_invoke$arity$1(config);
var next_obj_13038 = (target_obj_13037["chrome"]);
var next_obj_13039 = (next_obj_13038["runtime"]);
return next_obj_13039;
})();
var config__6181__auto___13045 = config;
var api_check_fn__6182__auto___13046 = cljs.core.cst$kw$missing_DASH_api_DASH_check_DASH_fn.cljs$core$IFn$_invoke$arity$1(config__6181__auto___13045);

(api_check_fn__6182__auto___13046.cljs$core$IFn$_invoke$arity$3 ? api_check_fn__6182__auto___13046.cljs$core$IFn$_invoke$arity$3("chrome.runtime.onConnect",ns_obj_13030,"onConnect") : api_check_fn__6182__auto___13046.call(null,"chrome.runtime.onConnect",ns_obj_13030,"onConnect"));

var event_obj_13028 = (function (){var target_obj_13040 = ns_obj_13030;
var next_obj_13041 = (target_obj_13040["onConnect"]);
return next_obj_13041;
})();
var result_13029 = chromex.chrome_event_subscription.make_chrome_event_subscription(event_obj_13028,logging_fn_13027,channel);
result_13029.chromex$protocols$chrome_event_subscription$IChromeEventSubscription$subscribe_BANG_$arity$2(null,args);

return result_13029;
});

chromex.ext.runtime.on_connect_STAR_.cljs$lang$maxFixedArity = (2);

/** @this {Function} */
chromex.ext.runtime.on_connect_STAR_.cljs$lang$applyTo = (function (seq13022){
var G__13023 = cljs.core.first(seq13022);
var seq13022__$1 = cljs.core.next(seq13022);
var G__13024 = cljs.core.first(seq13022__$1);
var seq13022__$2 = cljs.core.next(seq13022__$1);
var self__4628__auto__ = this;
return self__4628__auto__.cljs$core$IFn$_invoke$arity$variadic(G__13023,G__13024,seq13022__$2);
});

chromex.ext.runtime.on_connect_external_STAR_ = (function chromex$ext$runtime$on_connect_external_STAR_(var_args){
var args__4647__auto__ = [];
var len__4641__auto___13067 = arguments.length;
var i__4642__auto___13068 = (0);
while(true){
if((i__4642__auto___13068 < len__4641__auto___13067)){
args__4647__auto__.push((arguments[i__4642__auto___13068]));

var G__13069 = (i__4642__auto___13068 + (1));
i__4642__auto___13068 = G__13069;
continue;
} else {
}
break;
}

var argseq__4648__auto__ = ((((2) < args__4647__auto__.length))?(new cljs.core.IndexedSeq(args__4647__auto__.slice((2)),(0),null)):null);
return chromex.ext.runtime.on_connect_external_STAR_.cljs$core$IFn$_invoke$arity$variadic((arguments[(0)]),(arguments[(1)]),argseq__4648__auto__);
});

chromex.ext.runtime.on_connect_external_STAR_.cljs$core$IFn$_invoke$arity$variadic = (function (config,channel,args){
var event_fn_13050 = (function (){var config__6143__auto__ = config;
var handler_key__6144__auto__ = cljs.core.cst$kw$event_DASH_listener_DASH_factory;
var handler__6145__auto__ = handler_key__6144__auto__.cljs$core$IFn$_invoke$arity$1(config__6143__auto__);

var G__13058 = config__6143__auto__;
var G__13059 = cljs.core.cst$kw$chromex$ext$runtime_SLASH_on_DASH_connect_DASH_external;
var G__13060 = channel;
return (handler__6145__auto__.cljs$core$IFn$_invoke$arity$3 ? handler__6145__auto__.cljs$core$IFn$_invoke$arity$3(G__13058,G__13059,G__13060) : handler__6145__auto__.call(null,G__13058,G__13059,G__13060));
})();
var handler_fn_13051 = ((function (event_fn_13050){
return (function (cb_port_13056){
var G__13061 = chromex.marshalling.from_native_chrome_port(config,cb_port_13056);
return (event_fn_13050.cljs$core$IFn$_invoke$arity$1 ? event_fn_13050.cljs$core$IFn$_invoke$arity$1(G__13061) : event_fn_13050.call(null,G__13061));
});})(event_fn_13050))
;
var logging_fn_13052 = ((function (event_fn_13050,handler_fn_13051){
return (function (cb_param_port_13057){

return handler_fn_13051(cb_param_port_13057);
});})(event_fn_13050,handler_fn_13051))
;
var ns_obj_13055 = (function (){var target_obj_13062 = cljs.core.cst$kw$root.cljs$core$IFn$_invoke$arity$1(config);
var next_obj_13063 = (target_obj_13062["chrome"]);
var next_obj_13064 = (next_obj_13063["runtime"]);
return next_obj_13064;
})();
var config__6181__auto___13070 = config;
var api_check_fn__6182__auto___13071 = cljs.core.cst$kw$missing_DASH_api_DASH_check_DASH_fn.cljs$core$IFn$_invoke$arity$1(config__6181__auto___13070);

(api_check_fn__6182__auto___13071.cljs$core$IFn$_invoke$arity$3 ? api_check_fn__6182__auto___13071.cljs$core$IFn$_invoke$arity$3("chrome.runtime.onConnectExternal",ns_obj_13055,"onConnectExternal") : api_check_fn__6182__auto___13071.call(null,"chrome.runtime.onConnectExternal",ns_obj_13055,"onConnectExternal"));

var event_obj_13053 = (function (){var target_obj_13065 = ns_obj_13055;
var next_obj_13066 = (target_obj_13065["onConnectExternal"]);
return next_obj_13066;
})();
var result_13054 = chromex.chrome_event_subscription.make_chrome_event_subscription(event_obj_13053,logging_fn_13052,channel);
result_13054.chromex$protocols$chrome_event_subscription$IChromeEventSubscription$subscribe_BANG_$arity$2(null,args);

return result_13054;
});

chromex.ext.runtime.on_connect_external_STAR_.cljs$lang$maxFixedArity = (2);

/** @this {Function} */
chromex.ext.runtime.on_connect_external_STAR_.cljs$lang$applyTo = (function (seq13047){
var G__13048 = cljs.core.first(seq13047);
var seq13047__$1 = cljs.core.next(seq13047);
var G__13049 = cljs.core.first(seq13047__$1);
var seq13047__$2 = cljs.core.next(seq13047__$1);
var self__4628__auto__ = this;
return self__4628__auto__.cljs$core$IFn$_invoke$arity$variadic(G__13048,G__13049,seq13047__$2);
});

chromex.ext.runtime.on_message_STAR_ = (function chromex$ext$runtime$on_message_STAR_(var_args){
var args__4647__auto__ = [];
var len__4641__auto___13095 = arguments.length;
var i__4642__auto___13096 = (0);
while(true){
if((i__4642__auto___13096 < len__4641__auto___13095)){
args__4647__auto__.push((arguments[i__4642__auto___13096]));

var G__13097 = (i__4642__auto___13096 + (1));
i__4642__auto___13096 = G__13097;
continue;
} else {
}
break;
}

var argseq__4648__auto__ = ((((2) < args__4647__auto__.length))?(new cljs.core.IndexedSeq(args__4647__auto__.slice((2)),(0),null)):null);
return chromex.ext.runtime.on_message_STAR_.cljs$core$IFn$_invoke$arity$variadic((arguments[(0)]),(arguments[(1)]),argseq__4648__auto__);
});

chromex.ext.runtime.on_message_STAR_.cljs$core$IFn$_invoke$arity$variadic = (function (config,channel,args){
var event_fn_13075 = (function (){var config__6143__auto__ = config;
var handler_key__6144__auto__ = cljs.core.cst$kw$event_DASH_listener_DASH_factory;
var handler__6145__auto__ = handler_key__6144__auto__.cljs$core$IFn$_invoke$arity$1(config__6143__auto__);

var G__13087 = config__6143__auto__;
var G__13088 = cljs.core.cst$kw$chromex$ext$runtime_SLASH_on_DASH_message;
var G__13089 = channel;
return (handler__6145__auto__.cljs$core$IFn$_invoke$arity$3 ? handler__6145__auto__.cljs$core$IFn$_invoke$arity$3(G__13087,G__13088,G__13089) : handler__6145__auto__.call(null,G__13087,G__13088,G__13089));
})();
var handler_fn_13076 = ((function (event_fn_13075){
return (function (cb_message_13081,cb_sender_13082,cb_send_response_13083){
return (event_fn_13075.cljs$core$IFn$_invoke$arity$3 ? event_fn_13075.cljs$core$IFn$_invoke$arity$3(cb_message_13081,cb_sender_13082,cb_send_response_13083) : event_fn_13075.call(null,cb_message_13081,cb_sender_13082,cb_send_response_13083));
});})(event_fn_13075))
;
var logging_fn_13077 = ((function (event_fn_13075,handler_fn_13076){
return (function (cb_param_message_13084,cb_param_sender_13085,cb_param_send_response_13086){

return handler_fn_13076(cb_param_message_13084,cb_param_sender_13085,cb_param_send_response_13086);
});})(event_fn_13075,handler_fn_13076))
;
var ns_obj_13080 = (function (){var target_obj_13090 = cljs.core.cst$kw$root.cljs$core$IFn$_invoke$arity$1(config);
var next_obj_13091 = (target_obj_13090["chrome"]);
var next_obj_13092 = (next_obj_13091["runtime"]);
return next_obj_13092;
})();
var config__6181__auto___13098 = config;
var api_check_fn__6182__auto___13099 = cljs.core.cst$kw$missing_DASH_api_DASH_check_DASH_fn.cljs$core$IFn$_invoke$arity$1(config__6181__auto___13098);

(api_check_fn__6182__auto___13099.cljs$core$IFn$_invoke$arity$3 ? api_check_fn__6182__auto___13099.cljs$core$IFn$_invoke$arity$3("chrome.runtime.onMessage",ns_obj_13080,"onMessage") : api_check_fn__6182__auto___13099.call(null,"chrome.runtime.onMessage",ns_obj_13080,"onMessage"));

var event_obj_13078 = (function (){var target_obj_13093 = ns_obj_13080;
var next_obj_13094 = (target_obj_13093["onMessage"]);
return next_obj_13094;
})();
var result_13079 = chromex.chrome_event_subscription.make_chrome_event_subscription(event_obj_13078,logging_fn_13077,channel);
result_13079.chromex$protocols$chrome_event_subscription$IChromeEventSubscription$subscribe_BANG_$arity$2(null,args);

return result_13079;
});

chromex.ext.runtime.on_message_STAR_.cljs$lang$maxFixedArity = (2);

/** @this {Function} */
chromex.ext.runtime.on_message_STAR_.cljs$lang$applyTo = (function (seq13072){
var G__13073 = cljs.core.first(seq13072);
var seq13072__$1 = cljs.core.next(seq13072);
var G__13074 = cljs.core.first(seq13072__$1);
var seq13072__$2 = cljs.core.next(seq13072__$1);
var self__4628__auto__ = this;
return self__4628__auto__.cljs$core$IFn$_invoke$arity$variadic(G__13073,G__13074,seq13072__$2);
});

chromex.ext.runtime.on_message_external_STAR_ = (function chromex$ext$runtime$on_message_external_STAR_(var_args){
var args__4647__auto__ = [];
var len__4641__auto___13123 = arguments.length;
var i__4642__auto___13124 = (0);
while(true){
if((i__4642__auto___13124 < len__4641__auto___13123)){
args__4647__auto__.push((arguments[i__4642__auto___13124]));

var G__13125 = (i__4642__auto___13124 + (1));
i__4642__auto___13124 = G__13125;
continue;
} else {
}
break;
}

var argseq__4648__auto__ = ((((2) < args__4647__auto__.length))?(new cljs.core.IndexedSeq(args__4647__auto__.slice((2)),(0),null)):null);
return chromex.ext.runtime.on_message_external_STAR_.cljs$core$IFn$_invoke$arity$variadic((arguments[(0)]),(arguments[(1)]),argseq__4648__auto__);
});

chromex.ext.runtime.on_message_external_STAR_.cljs$core$IFn$_invoke$arity$variadic = (function (config,channel,args){
var event_fn_13103 = (function (){var config__6143__auto__ = config;
var handler_key__6144__auto__ = cljs.core.cst$kw$event_DASH_listener_DASH_factory;
var handler__6145__auto__ = handler_key__6144__auto__.cljs$core$IFn$_invoke$arity$1(config__6143__auto__);

var G__13115 = config__6143__auto__;
var G__13116 = cljs.core.cst$kw$chromex$ext$runtime_SLASH_on_DASH_message_DASH_external;
var G__13117 = channel;
return (handler__6145__auto__.cljs$core$IFn$_invoke$arity$3 ? handler__6145__auto__.cljs$core$IFn$_invoke$arity$3(G__13115,G__13116,G__13117) : handler__6145__auto__.call(null,G__13115,G__13116,G__13117));
})();
var handler_fn_13104 = ((function (event_fn_13103){
return (function (cb_message_13109,cb_sender_13110,cb_send_response_13111){
return (event_fn_13103.cljs$core$IFn$_invoke$arity$3 ? event_fn_13103.cljs$core$IFn$_invoke$arity$3(cb_message_13109,cb_sender_13110,cb_send_response_13111) : event_fn_13103.call(null,cb_message_13109,cb_sender_13110,cb_send_response_13111));
});})(event_fn_13103))
;
var logging_fn_13105 = ((function (event_fn_13103,handler_fn_13104){
return (function (cb_param_message_13112,cb_param_sender_13113,cb_param_send_response_13114){

return handler_fn_13104(cb_param_message_13112,cb_param_sender_13113,cb_param_send_response_13114);
});})(event_fn_13103,handler_fn_13104))
;
var ns_obj_13108 = (function (){var target_obj_13118 = cljs.core.cst$kw$root.cljs$core$IFn$_invoke$arity$1(config);
var next_obj_13119 = (target_obj_13118["chrome"]);
var next_obj_13120 = (next_obj_13119["runtime"]);
return next_obj_13120;
})();
var config__6181__auto___13126 = config;
var api_check_fn__6182__auto___13127 = cljs.core.cst$kw$missing_DASH_api_DASH_check_DASH_fn.cljs$core$IFn$_invoke$arity$1(config__6181__auto___13126);

(api_check_fn__6182__auto___13127.cljs$core$IFn$_invoke$arity$3 ? api_check_fn__6182__auto___13127.cljs$core$IFn$_invoke$arity$3("chrome.runtime.onMessageExternal",ns_obj_13108,"onMessageExternal") : api_check_fn__6182__auto___13127.call(null,"chrome.runtime.onMessageExternal",ns_obj_13108,"onMessageExternal"));

var event_obj_13106 = (function (){var target_obj_13121 = ns_obj_13108;
var next_obj_13122 = (target_obj_13121["onMessageExternal"]);
return next_obj_13122;
})();
var result_13107 = chromex.chrome_event_subscription.make_chrome_event_subscription(event_obj_13106,logging_fn_13105,channel);
result_13107.chromex$protocols$chrome_event_subscription$IChromeEventSubscription$subscribe_BANG_$arity$2(null,args);

return result_13107;
});

chromex.ext.runtime.on_message_external_STAR_.cljs$lang$maxFixedArity = (2);

/** @this {Function} */
chromex.ext.runtime.on_message_external_STAR_.cljs$lang$applyTo = (function (seq13100){
var G__13101 = cljs.core.first(seq13100);
var seq13100__$1 = cljs.core.next(seq13100);
var G__13102 = cljs.core.first(seq13100__$1);
var seq13100__$2 = cljs.core.next(seq13100__$1);
var self__4628__auto__ = this;
return self__4628__auto__.cljs$core$IFn$_invoke$arity$variadic(G__13101,G__13102,seq13100__$2);
});

chromex.ext.runtime.on_restart_required_STAR_ = (function chromex$ext$runtime$on_restart_required_STAR_(var_args){
var args__4647__auto__ = [];
var len__4641__auto___13147 = arguments.length;
var i__4642__auto___13148 = (0);
while(true){
if((i__4642__auto___13148 < len__4641__auto___13147)){
args__4647__auto__.push((arguments[i__4642__auto___13148]));

var G__13149 = (i__4642__auto___13148 + (1));
i__4642__auto___13148 = G__13149;
continue;
} else {
}
break;
}

var argseq__4648__auto__ = ((((2) < args__4647__auto__.length))?(new cljs.core.IndexedSeq(args__4647__auto__.slice((2)),(0),null)):null);
return chromex.ext.runtime.on_restart_required_STAR_.cljs$core$IFn$_invoke$arity$variadic((arguments[(0)]),(arguments[(1)]),argseq__4648__auto__);
});

chromex.ext.runtime.on_restart_required_STAR_.cljs$core$IFn$_invoke$arity$variadic = (function (config,channel,args){
var event_fn_13131 = (function (){var config__6143__auto__ = config;
var handler_key__6144__auto__ = cljs.core.cst$kw$event_DASH_listener_DASH_factory;
var handler__6145__auto__ = handler_key__6144__auto__.cljs$core$IFn$_invoke$arity$1(config__6143__auto__);

var G__13139 = config__6143__auto__;
var G__13140 = cljs.core.cst$kw$chromex$ext$runtime_SLASH_on_DASH_restart_DASH_required;
var G__13141 = channel;
return (handler__6145__auto__.cljs$core$IFn$_invoke$arity$3 ? handler__6145__auto__.cljs$core$IFn$_invoke$arity$3(G__13139,G__13140,G__13141) : handler__6145__auto__.call(null,G__13139,G__13140,G__13141));
})();
var handler_fn_13132 = ((function (event_fn_13131){
return (function (cb_reason_13137){
return (event_fn_13131.cljs$core$IFn$_invoke$arity$1 ? event_fn_13131.cljs$core$IFn$_invoke$arity$1(cb_reason_13137) : event_fn_13131.call(null,cb_reason_13137));
});})(event_fn_13131))
;
var logging_fn_13133 = ((function (event_fn_13131,handler_fn_13132){
return (function (cb_param_reason_13138){

return handler_fn_13132(cb_param_reason_13138);
});})(event_fn_13131,handler_fn_13132))
;
var ns_obj_13136 = (function (){var target_obj_13142 = cljs.core.cst$kw$root.cljs$core$IFn$_invoke$arity$1(config);
var next_obj_13143 = (target_obj_13142["chrome"]);
var next_obj_13144 = (next_obj_13143["runtime"]);
return next_obj_13144;
})();
var config__6181__auto___13150 = config;
var api_check_fn__6182__auto___13151 = cljs.core.cst$kw$missing_DASH_api_DASH_check_DASH_fn.cljs$core$IFn$_invoke$arity$1(config__6181__auto___13150);

(api_check_fn__6182__auto___13151.cljs$core$IFn$_invoke$arity$3 ? api_check_fn__6182__auto___13151.cljs$core$IFn$_invoke$arity$3("chrome.runtime.onRestartRequired",ns_obj_13136,"onRestartRequired") : api_check_fn__6182__auto___13151.call(null,"chrome.runtime.onRestartRequired",ns_obj_13136,"onRestartRequired"));

var event_obj_13134 = (function (){var target_obj_13145 = ns_obj_13136;
var next_obj_13146 = (target_obj_13145["onRestartRequired"]);
return next_obj_13146;
})();
var result_13135 = chromex.chrome_event_subscription.make_chrome_event_subscription(event_obj_13134,logging_fn_13133,channel);
result_13135.chromex$protocols$chrome_event_subscription$IChromeEventSubscription$subscribe_BANG_$arity$2(null,args);

return result_13135;
});

chromex.ext.runtime.on_restart_required_STAR_.cljs$lang$maxFixedArity = (2);

/** @this {Function} */
chromex.ext.runtime.on_restart_required_STAR_.cljs$lang$applyTo = (function (seq13128){
var G__13129 = cljs.core.first(seq13128);
var seq13128__$1 = cljs.core.next(seq13128);
var G__13130 = cljs.core.first(seq13128__$1);
var seq13128__$2 = cljs.core.next(seq13128__$1);
var self__4628__auto__ = this;
return self__4628__auto__.cljs$core$IFn$_invoke$arity$variadic(G__13129,G__13130,seq13128__$2);
});

