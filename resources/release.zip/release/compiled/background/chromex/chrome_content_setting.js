// Compiled by ClojureScript 1.10.439 {:static-fns true, :optimize-constants true, :elide-asserts true}
goog.provide('chromex.chrome_content_setting');
goog.require('cljs.core');
goog.require('cljs.core.constants');
goog.require('chromex.support');
goog.require('oops.core');
goog.require('chromex.protocols.chrome_content_setting');

/**
* @constructor
 * @implements {chromex.protocols.chrome_content_setting.IChromeContentSetting}
*/
chromex.chrome_content_setting.ChromeContentSetting = (function (native_chrome_content_setting,channel_factory,callback_factory){
this.native_chrome_content_setting = native_chrome_content_setting;
this.channel_factory = channel_factory;
this.callback_factory = callback_factory;
});
chromex.chrome_content_setting.ChromeContentSetting.prototype.chromex$protocols$chrome_content_setting$IChromeContentSetting$ = cljs.core.PROTOCOL_SENTINEL;

chromex.chrome_content_setting.ChromeContentSetting.prototype.chromex$protocols$chrome_content_setting$IChromeContentSetting$get_native_content_setting$arity$1 = (function (_this){
var self__ = this;
var _this__$1 = this;
return self__.native_chrome_content_setting;
});

chromex.chrome_content_setting.ChromeContentSetting.prototype.chromex$protocols$chrome_content_setting$IChromeContentSetting$get$arity$2 = (function (_this,details){
var self__ = this;
var _this__$1 = this;
var channel = (self__.channel_factory.cljs$core$IFn$_invoke$arity$0 ? self__.channel_factory.cljs$core$IFn$_invoke$arity$0() : self__.channel_factory.call(null));
var target_obj_12180_12196 = self__.native_chrome_content_setting;
var call_info_12182_12197 = [target_obj_12180_12196,(function (){var next_obj_12183 = (target_obj_12180_12196["get"]);
return next_obj_12183;
})()];
var fn_12181_12198 = (call_info_12182_12197[(1)]);
if((!((fn_12181_12198 == null)))){
fn_12181_12198.call((call_info_12182_12197[(0)]),details,(self__.callback_factory.cljs$core$IFn$_invoke$arity$1 ? self__.callback_factory.cljs$core$IFn$_invoke$arity$1(channel) : self__.callback_factory.call(null,channel)));
} else {
}

return channel;
});

chromex.chrome_content_setting.ChromeContentSetting.prototype.chromex$protocols$chrome_content_setting$IChromeContentSetting$set$arity$2 = (function (_this,details){
var self__ = this;
var _this__$1 = this;
var channel = (self__.channel_factory.cljs$core$IFn$_invoke$arity$0 ? self__.channel_factory.cljs$core$IFn$_invoke$arity$0() : self__.channel_factory.call(null));
var target_obj_12184_12199 = self__.native_chrome_content_setting;
var call_info_12186_12200 = [target_obj_12184_12199,(function (){var next_obj_12187 = (target_obj_12184_12199["set"]);
return next_obj_12187;
})()];
var fn_12185_12201 = (call_info_12186_12200[(1)]);
if((!((fn_12185_12201 == null)))){
fn_12185_12201.call((call_info_12186_12200[(0)]),details,(self__.callback_factory.cljs$core$IFn$_invoke$arity$1 ? self__.callback_factory.cljs$core$IFn$_invoke$arity$1(channel) : self__.callback_factory.call(null,channel)));
} else {
}

return channel;
});

chromex.chrome_content_setting.ChromeContentSetting.prototype.chromex$protocols$chrome_content_setting$IChromeContentSetting$clear$arity$2 = (function (_this,details){
var self__ = this;
var _this__$1 = this;
var channel = (self__.channel_factory.cljs$core$IFn$_invoke$arity$0 ? self__.channel_factory.cljs$core$IFn$_invoke$arity$0() : self__.channel_factory.call(null));
var target_obj_12188_12202 = self__.native_chrome_content_setting;
var call_info_12190_12203 = [target_obj_12188_12202,(function (){var next_obj_12191 = (target_obj_12188_12202["clear"]);
return next_obj_12191;
})()];
var fn_12189_12204 = (call_info_12190_12203[(1)]);
if((!((fn_12189_12204 == null)))){
fn_12189_12204.call((call_info_12190_12203[(0)]),details,(self__.callback_factory.cljs$core$IFn$_invoke$arity$1 ? self__.callback_factory.cljs$core$IFn$_invoke$arity$1(channel) : self__.callback_factory.call(null,channel)));
} else {
}

return channel;
});

chromex.chrome_content_setting.ChromeContentSetting.prototype.chromex$protocols$chrome_content_setting$IChromeContentSetting$get_resource_identifiers$arity$1 = (function (_this){
var self__ = this;
var _this__$1 = this;
var channel = (self__.channel_factory.cljs$core$IFn$_invoke$arity$0 ? self__.channel_factory.cljs$core$IFn$_invoke$arity$0() : self__.channel_factory.call(null));
var target_obj_12192_12205 = self__.native_chrome_content_setting;
var call_info_12194_12206 = [target_obj_12192_12205,(function (){var next_obj_12195 = (target_obj_12192_12205["getResourceIdentifiers"]);
return next_obj_12195;
})()];
var fn_12193_12207 = (call_info_12194_12206[(1)]);
if((!((fn_12193_12207 == null)))){
fn_12193_12207.call((call_info_12194_12206[(0)]),(self__.callback_factory.cljs$core$IFn$_invoke$arity$1 ? self__.callback_factory.cljs$core$IFn$_invoke$arity$1(channel) : self__.callback_factory.call(null,channel)));
} else {
}

return channel;
});

chromex.chrome_content_setting.ChromeContentSetting.getBasis = (function (){
return new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [cljs.core.cst$sym$native_DASH_chrome_DASH_content_DASH_setting,cljs.core.cst$sym$channel_DASH_factory,cljs.core.cst$sym$callback_DASH_factory], null);
});

chromex.chrome_content_setting.ChromeContentSetting.cljs$lang$type = true;

chromex.chrome_content_setting.ChromeContentSetting.cljs$lang$ctorStr = "chromex.chrome-content-setting/ChromeContentSetting";

chromex.chrome_content_setting.ChromeContentSetting.cljs$lang$ctorPrWriter = (function (this__4290__auto__,writer__4291__auto__,opt__4292__auto__){
return cljs.core._write(writer__4291__auto__,"chromex.chrome-content-setting/ChromeContentSetting");
});

/**
 * Positional factory function for chromex.chrome-content-setting/ChromeContentSetting.
 */
chromex.chrome_content_setting.__GT_ChromeContentSetting = (function chromex$chrome_content_setting$__GT_ChromeContentSetting(native_chrome_content_setting,channel_factory,callback_factory){
return (new chromex.chrome_content_setting.ChromeContentSetting(native_chrome_content_setting,channel_factory,callback_factory));
});

chromex.chrome_content_setting.make_chrome_content_setting = (function chromex$chrome_content_setting$make_chrome_content_setting(config,native_chrome_content_setting){

return (new chromex.chrome_content_setting.ChromeContentSetting(native_chrome_content_setting,(function (){var config__6152__auto__ = config;
var handler_key__6153__auto__ = cljs.core.cst$kw$chrome_DASH_content_DASH_setting_DASH_callback_DASH_channel_DASH_factory;
var handler__6154__auto__ = handler_key__6153__auto__.cljs$core$IFn$_invoke$arity$1(config__6152__auto__);

return cljs.core.partial.cljs$core$IFn$_invoke$arity$2(handler__6154__auto__,config__6152__auto__);
})(),(function (){var config__6152__auto__ = config;
var handler_key__6153__auto__ = cljs.core.cst$kw$chrome_DASH_content_DASH_setting_DASH_callback_DASH_fn_DASH_factory;
var handler__6154__auto__ = handler_key__6153__auto__.cljs$core$IFn$_invoke$arity$1(config__6152__auto__);

return cljs.core.partial.cljs$core$IFn$_invoke$arity$2(handler__6154__auto__,config__6152__auto__);
})()));
});
