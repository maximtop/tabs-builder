// Compiled by ClojureScript 1.10.439 {:static-fns true, :optimize-constants true, :elide-asserts true}
goog.provide('chromex.protocols.chrome_event_channel');
goog.require('cljs.core');
goog.require('cljs.core.constants');

/**
 * @interface
 */
chromex.protocols.chrome_event_channel.IChromeEventChannel = function(){};

chromex.protocols.chrome_event_channel.register_BANG_ = (function chromex$protocols$chrome_event_channel$register_BANG_(this$,subscription){
if((((!((this$ == null)))) && ((!((this$.chromex$protocols$chrome_event_channel$IChromeEventChannel$register_BANG_$arity$2 == null)))))){
return this$.chromex$protocols$chrome_event_channel$IChromeEventChannel$register_BANG_$arity$2(this$,subscription);
} else {
var x__4347__auto__ = (((this$ == null))?null:this$);
var m__4348__auto__ = (chromex.protocols.chrome_event_channel.register_BANG_[goog.typeOf(x__4347__auto__)]);
if((!((m__4348__auto__ == null)))){
return (m__4348__auto__.cljs$core$IFn$_invoke$arity$2 ? m__4348__auto__.cljs$core$IFn$_invoke$arity$2(this$,subscription) : m__4348__auto__.call(null,this$,subscription));
} else {
var m__4348__auto____$1 = (chromex.protocols.chrome_event_channel.register_BANG_["_"]);
if((!((m__4348__auto____$1 == null)))){
return (m__4348__auto____$1.cljs$core$IFn$_invoke$arity$2 ? m__4348__auto____$1.cljs$core$IFn$_invoke$arity$2(this$,subscription) : m__4348__auto____$1.call(null,this$,subscription));
} else {
throw cljs.core.missing_protocol("IChromeEventChannel.register!",this$);
}
}
}
});

chromex.protocols.chrome_event_channel.unregister_BANG_ = (function chromex$protocols$chrome_event_channel$unregister_BANG_(this$,subscription){
if((((!((this$ == null)))) && ((!((this$.chromex$protocols$chrome_event_channel$IChromeEventChannel$unregister_BANG_$arity$2 == null)))))){
return this$.chromex$protocols$chrome_event_channel$IChromeEventChannel$unregister_BANG_$arity$2(this$,subscription);
} else {
var x__4347__auto__ = (((this$ == null))?null:this$);
var m__4348__auto__ = (chromex.protocols.chrome_event_channel.unregister_BANG_[goog.typeOf(x__4347__auto__)]);
if((!((m__4348__auto__ == null)))){
return (m__4348__auto__.cljs$core$IFn$_invoke$arity$2 ? m__4348__auto__.cljs$core$IFn$_invoke$arity$2(this$,subscription) : m__4348__auto__.call(null,this$,subscription));
} else {
var m__4348__auto____$1 = (chromex.protocols.chrome_event_channel.unregister_BANG_["_"]);
if((!((m__4348__auto____$1 == null)))){
return (m__4348__auto____$1.cljs$core$IFn$_invoke$arity$2 ? m__4348__auto____$1.cljs$core$IFn$_invoke$arity$2(this$,subscription) : m__4348__auto____$1.call(null,this$,subscription));
} else {
throw cljs.core.missing_protocol("IChromeEventChannel.unregister!",this$);
}
}
}
});

chromex.protocols.chrome_event_channel.unsubscribe_all_BANG_ = (function chromex$protocols$chrome_event_channel$unsubscribe_all_BANG_(this$){
if((((!((this$ == null)))) && ((!((this$.chromex$protocols$chrome_event_channel$IChromeEventChannel$unsubscribe_all_BANG_$arity$1 == null)))))){
return this$.chromex$protocols$chrome_event_channel$IChromeEventChannel$unsubscribe_all_BANG_$arity$1(this$);
} else {
var x__4347__auto__ = (((this$ == null))?null:this$);
var m__4348__auto__ = (chromex.protocols.chrome_event_channel.unsubscribe_all_BANG_[goog.typeOf(x__4347__auto__)]);
if((!((m__4348__auto__ == null)))){
return (m__4348__auto__.cljs$core$IFn$_invoke$arity$1 ? m__4348__auto__.cljs$core$IFn$_invoke$arity$1(this$) : m__4348__auto__.call(null,this$));
} else {
var m__4348__auto____$1 = (chromex.protocols.chrome_event_channel.unsubscribe_all_BANG_["_"]);
if((!((m__4348__auto____$1 == null)))){
return (m__4348__auto____$1.cljs$core$IFn$_invoke$arity$1 ? m__4348__auto____$1.cljs$core$IFn$_invoke$arity$1(this$) : m__4348__auto____$1.call(null,this$));
} else {
throw cljs.core.missing_protocol("IChromeEventChannel.unsubscribe-all!",this$);
}
}
}
});

