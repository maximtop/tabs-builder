// Compiled by ClojureScript 1.10.439 {:static-fns true, :optimize-constants true, :elide-asserts true}
goog.provide('chromex.protocols.chrome_event_subscription');
goog.require('cljs.core');
goog.require('cljs.core.constants');

/**
 * @interface
 */
chromex.protocols.chrome_event_subscription.IChromeEventSubscription = function(){};

chromex.protocols.chrome_event_subscription.subscribe_BANG_ = (function chromex$protocols$chrome_event_subscription$subscribe_BANG_(var_args){
var G__11961 = arguments.length;
switch (G__11961) {
case 1:
return chromex.protocols.chrome_event_subscription.subscribe_BANG_.cljs$core$IFn$_invoke$arity$1((arguments[(0)]));

break;
case 2:
return chromex.protocols.chrome_event_subscription.subscribe_BANG_.cljs$core$IFn$_invoke$arity$2((arguments[(0)]),(arguments[(1)]));

break;
default:
throw (new Error(["Invalid arity: ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(arguments.length)].join('')));

}
});

chromex.protocols.chrome_event_subscription.subscribe_BANG_.cljs$core$IFn$_invoke$arity$1 = (function (this$){
if((((!((this$ == null)))) && ((!((this$.chromex$protocols$chrome_event_subscription$IChromeEventSubscription$subscribe_BANG_$arity$1 == null)))))){
return this$.chromex$protocols$chrome_event_subscription$IChromeEventSubscription$subscribe_BANG_$arity$1(this$);
} else {
var x__4347__auto__ = (((this$ == null))?null:this$);
var m__4348__auto__ = (chromex.protocols.chrome_event_subscription.subscribe_BANG_[goog.typeOf(x__4347__auto__)]);
if((!((m__4348__auto__ == null)))){
return (m__4348__auto__.cljs$core$IFn$_invoke$arity$1 ? m__4348__auto__.cljs$core$IFn$_invoke$arity$1(this$) : m__4348__auto__.call(null,this$));
} else {
var m__4348__auto____$1 = (chromex.protocols.chrome_event_subscription.subscribe_BANG_["_"]);
if((!((m__4348__auto____$1 == null)))){
return (m__4348__auto____$1.cljs$core$IFn$_invoke$arity$1 ? m__4348__auto____$1.cljs$core$IFn$_invoke$arity$1(this$) : m__4348__auto____$1.call(null,this$));
} else {
throw cljs.core.missing_protocol("IChromeEventSubscription.subscribe!",this$);
}
}
}
});

chromex.protocols.chrome_event_subscription.subscribe_BANG_.cljs$core$IFn$_invoke$arity$2 = (function (this$,extra_args){
if((((!((this$ == null)))) && ((!((this$.chromex$protocols$chrome_event_subscription$IChromeEventSubscription$subscribe_BANG_$arity$2 == null)))))){
return this$.chromex$protocols$chrome_event_subscription$IChromeEventSubscription$subscribe_BANG_$arity$2(this$,extra_args);
} else {
var x__4347__auto__ = (((this$ == null))?null:this$);
var m__4348__auto__ = (chromex.protocols.chrome_event_subscription.subscribe_BANG_[goog.typeOf(x__4347__auto__)]);
if((!((m__4348__auto__ == null)))){
return (m__4348__auto__.cljs$core$IFn$_invoke$arity$2 ? m__4348__auto__.cljs$core$IFn$_invoke$arity$2(this$,extra_args) : m__4348__auto__.call(null,this$,extra_args));
} else {
var m__4348__auto____$1 = (chromex.protocols.chrome_event_subscription.subscribe_BANG_["_"]);
if((!((m__4348__auto____$1 == null)))){
return (m__4348__auto____$1.cljs$core$IFn$_invoke$arity$2 ? m__4348__auto____$1.cljs$core$IFn$_invoke$arity$2(this$,extra_args) : m__4348__auto____$1.call(null,this$,extra_args));
} else {
throw cljs.core.missing_protocol("IChromeEventSubscription.subscribe!",this$);
}
}
}
});

chromex.protocols.chrome_event_subscription.subscribe_BANG_.cljs$lang$maxFixedArity = 2;


chromex.protocols.chrome_event_subscription.unsubscribe_BANG_ = (function chromex$protocols$chrome_event_subscription$unsubscribe_BANG_(this$){
if((((!((this$ == null)))) && ((!((this$.chromex$protocols$chrome_event_subscription$IChromeEventSubscription$unsubscribe_BANG_$arity$1 == null)))))){
return this$.chromex$protocols$chrome_event_subscription$IChromeEventSubscription$unsubscribe_BANG_$arity$1(this$);
} else {
var x__4347__auto__ = (((this$ == null))?null:this$);
var m__4348__auto__ = (chromex.protocols.chrome_event_subscription.unsubscribe_BANG_[goog.typeOf(x__4347__auto__)]);
if((!((m__4348__auto__ == null)))){
return (m__4348__auto__.cljs$core$IFn$_invoke$arity$1 ? m__4348__auto__.cljs$core$IFn$_invoke$arity$1(this$) : m__4348__auto__.call(null,this$));
} else {
var m__4348__auto____$1 = (chromex.protocols.chrome_event_subscription.unsubscribe_BANG_["_"]);
if((!((m__4348__auto____$1 == null)))){
return (m__4348__auto____$1.cljs$core$IFn$_invoke$arity$1 ? m__4348__auto____$1.cljs$core$IFn$_invoke$arity$1(this$) : m__4348__auto____$1.call(null,this$));
} else {
throw cljs.core.missing_protocol("IChromeEventSubscription.unsubscribe!",this$);
}
}
}
});

