// Compiled by ClojureScript 1.10.439 {:static-fns true, :optimize-constants true, :elide-asserts true}
goog.provide('chromex.chrome_event_channel');
goog.require('cljs.core');
goog.require('cljs.core.constants');
goog.require('cljs.core.async.impl.protocols');
goog.require('chromex.protocols.chrome_event_subscription');
goog.require('chromex.protocols.chrome_event_channel');

/**
* @constructor
 * @implements {cljs.core.async.impl.protocols.Channel}
 * @implements {cljs.core.async.impl.protocols.WritePort}
 * @implements {cljs.core.async.impl.protocols.ReadPort}
 * @implements {chromex.protocols.chrome_event_channel.IChromeEventChannel}
*/
chromex.chrome_event_channel.ChromeEventChannel = (function (chan,subscriptions){
this.chan = chan;
this.subscriptions = subscriptions;
});
chromex.chrome_event_channel.ChromeEventChannel.prototype.chromex$protocols$chrome_event_channel$IChromeEventChannel$ = cljs.core.PROTOCOL_SENTINEL;

chromex.chrome_event_channel.ChromeEventChannel.prototype.chromex$protocols$chrome_event_channel$IChromeEventChannel$register_BANG_$arity$2 = (function (_this,subscription){
var self__ = this;
var _this__$1 = this;
return self__.subscriptions = cljs.core.conj.cljs$core$IFn$_invoke$arity$2(self__.subscriptions,subscription);
});

chromex.chrome_event_channel.ChromeEventChannel.prototype.chromex$protocols$chrome_event_channel$IChromeEventChannel$unregister_BANG_$arity$2 = (function (_this,subscription){
var self__ = this;
var _this__$1 = this;
return self__.subscriptions = cljs.core.disj.cljs$core$IFn$_invoke$arity$2(self__.subscriptions,subscription);
});

chromex.chrome_event_channel.ChromeEventChannel.prototype.chromex$protocols$chrome_event_channel$IChromeEventChannel$unsubscribe_all_BANG_$arity$1 = (function (_this){
var self__ = this;
var _this__$1 = this;
var seq__11965_11969 = cljs.core.seq(self__.subscriptions);
var chunk__11966_11970 = null;
var count__11967_11971 = (0);
var i__11968_11972 = (0);
while(true){
if((i__11968_11972 < count__11967_11971)){
var subscription_11973 = chunk__11966_11970.cljs$core$IIndexed$_nth$arity$2(null,i__11968_11972);
chromex.protocols.chrome_event_subscription.unsubscribe_BANG_(subscription_11973);


var G__11974 = seq__11965_11969;
var G__11975 = chunk__11966_11970;
var G__11976 = count__11967_11971;
var G__11977 = (i__11968_11972 + (1));
seq__11965_11969 = G__11974;
chunk__11966_11970 = G__11975;
count__11967_11971 = G__11976;
i__11968_11972 = G__11977;
continue;
} else {
var temp__5457__auto___11978 = cljs.core.seq(seq__11965_11969);
if(temp__5457__auto___11978){
var seq__11965_11979__$1 = temp__5457__auto___11978;
if(cljs.core.chunked_seq_QMARK_(seq__11965_11979__$1)){
var c__4461__auto___11980 = cljs.core.chunk_first(seq__11965_11979__$1);
var G__11981 = cljs.core.chunk_rest(seq__11965_11979__$1);
var G__11982 = c__4461__auto___11980;
var G__11983 = cljs.core.count(c__4461__auto___11980);
var G__11984 = (0);
seq__11965_11969 = G__11981;
chunk__11966_11970 = G__11982;
count__11967_11971 = G__11983;
i__11968_11972 = G__11984;
continue;
} else {
var subscription_11985 = cljs.core.first(seq__11965_11979__$1);
chromex.protocols.chrome_event_subscription.unsubscribe_BANG_(subscription_11985);


var G__11986 = cljs.core.next(seq__11965_11979__$1);
var G__11987 = null;
var G__11988 = (0);
var G__11989 = (0);
seq__11965_11969 = G__11986;
chunk__11966_11970 = G__11987;
count__11967_11971 = G__11988;
i__11968_11972 = G__11989;
continue;
}
} else {
}
}
break;
}

return self__.subscriptions = cljs.core.PersistentHashSet.EMPTY;
});

chromex.chrome_event_channel.ChromeEventChannel.prototype.cljs$core$async$impl$protocols$WritePort$ = cljs.core.PROTOCOL_SENTINEL;

chromex.chrome_event_channel.ChromeEventChannel.prototype.cljs$core$async$impl$protocols$WritePort$put_BANG_$arity$3 = (function (_this,val,handler){
var self__ = this;
var _this__$1 = this;
return cljs.core.async.impl.protocols.put_BANG_(self__.chan,val,handler);
});

chromex.chrome_event_channel.ChromeEventChannel.prototype.cljs$core$async$impl$protocols$ReadPort$ = cljs.core.PROTOCOL_SENTINEL;

chromex.chrome_event_channel.ChromeEventChannel.prototype.cljs$core$async$impl$protocols$ReadPort$take_BANG_$arity$2 = (function (_this,handler){
var self__ = this;
var _this__$1 = this;
return cljs.core.async.impl.protocols.take_BANG_(self__.chan,handler);
});

chromex.chrome_event_channel.ChromeEventChannel.prototype.cljs$core$async$impl$protocols$Channel$ = cljs.core.PROTOCOL_SENTINEL;

chromex.chrome_event_channel.ChromeEventChannel.prototype.cljs$core$async$impl$protocols$Channel$closed_QMARK_$arity$1 = (function (_this){
var self__ = this;
var _this__$1 = this;
return cljs.core.async.impl.protocols.closed_QMARK_(self__.chan);
});

chromex.chrome_event_channel.ChromeEventChannel.prototype.cljs$core$async$impl$protocols$Channel$close_BANG_$arity$1 = (function (this$){
var self__ = this;
var this$__$1 = this;
this$__$1.chromex$protocols$chrome_event_channel$IChromeEventChannel$unsubscribe_all_BANG_$arity$1(null);

return cljs.core.async.impl.protocols.close_BANG_(self__.chan);
});

chromex.chrome_event_channel.ChromeEventChannel.getBasis = (function (){
return new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [cljs.core.cst$sym$chan,cljs.core.with_meta(cljs.core.cst$sym$subscriptions,new cljs.core.PersistentArrayMap(null, 1, [cljs.core.cst$kw$mutable,true], null))], null);
});

chromex.chrome_event_channel.ChromeEventChannel.cljs$lang$type = true;

chromex.chrome_event_channel.ChromeEventChannel.cljs$lang$ctorStr = "chromex.chrome-event-channel/ChromeEventChannel";

chromex.chrome_event_channel.ChromeEventChannel.cljs$lang$ctorPrWriter = (function (this__4290__auto__,writer__4291__auto__,opt__4292__auto__){
return cljs.core._write(writer__4291__auto__,"chromex.chrome-event-channel/ChromeEventChannel");
});

/**
 * Positional factory function for chromex.chrome-event-channel/ChromeEventChannel.
 */
chromex.chrome_event_channel.__GT_ChromeEventChannel = (function chromex$chrome_event_channel$__GT_ChromeEventChannel(chan,subscriptions){
return (new chromex.chrome_event_channel.ChromeEventChannel(chan,subscriptions));
});

chromex.chrome_event_channel.make_chrome_event_channel = (function chromex$chrome_event_channel$make_chrome_event_channel(chan){
return (new chromex.chrome_event_channel.ChromeEventChannel(chan,cljs.core.PersistentHashSet.EMPTY));
});
