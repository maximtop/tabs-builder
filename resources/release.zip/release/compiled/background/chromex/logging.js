// Compiled by ClojureScript 1.10.439 {:static-fns true, :optimize-constants true, :elide-asserts true}
goog.provide('chromex.logging');
goog.require('cljs.core');
goog.require('cljs.core.constants');
