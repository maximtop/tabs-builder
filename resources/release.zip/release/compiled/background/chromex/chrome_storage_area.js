// Compiled by ClojureScript 1.10.439 {:static-fns true, :optimize-constants true, :elide-asserts true}
goog.provide('chromex.chrome_storage_area');
goog.require('cljs.core');
goog.require('cljs.core.constants');
goog.require('chromex.support');
goog.require('oops.core');
goog.require('chromex.protocols.chrome_storage_area');

/**
* @constructor
 * @implements {chromex.protocols.chrome_storage_area.IChromeStorageArea}
*/
chromex.chrome_storage_area.ChromeStorageArea = (function (native_chrome_storage_area,channel_factory,callback_factory){
this.native_chrome_storage_area = native_chrome_storage_area;
this.channel_factory = channel_factory;
this.callback_factory = callback_factory;
});
chromex.chrome_storage_area.ChromeStorageArea.prototype.chromex$protocols$chrome_storage_area$IChromeStorageArea$ = cljs.core.PROTOCOL_SENTINEL;

chromex.chrome_storage_area.ChromeStorageArea.prototype.chromex$protocols$chrome_storage_area$IChromeStorageArea$get_native_storage_area$arity$1 = (function (_this){
var self__ = this;
var _this__$1 = this;
return self__.native_chrome_storage_area;
});

chromex.chrome_storage_area.ChromeStorageArea.prototype.chromex$protocols$chrome_storage_area$IChromeStorageArea$get$arity$1 = (function (this$){
var self__ = this;
var this$__$1 = this;
return this$__$1.chromex$protocols$chrome_storage_area$IChromeStorageArea$get$arity$2(null,null);
});

chromex.chrome_storage_area.ChromeStorageArea.prototype.chromex$protocols$chrome_storage_area$IChromeStorageArea$get$arity$2 = (function (_this,keys){
var self__ = this;
var _this__$1 = this;
var channel = (self__.channel_factory.cljs$core$IFn$_invoke$arity$0 ? self__.channel_factory.cljs$core$IFn$_invoke$arity$0() : self__.channel_factory.call(null));
var target_obj_12210_12230 = self__.native_chrome_storage_area;
var call_info_12212_12231 = [target_obj_12210_12230,(function (){var next_obj_12213 = (target_obj_12210_12230["get"]);
return next_obj_12213;
})()];
var fn_12211_12232 = (call_info_12212_12231[(1)]);
if((!((fn_12211_12232 == null)))){
fn_12211_12232.call((call_info_12212_12231[(0)]),keys,(self__.callback_factory.cljs$core$IFn$_invoke$arity$1 ? self__.callback_factory.cljs$core$IFn$_invoke$arity$1(channel) : self__.callback_factory.call(null,channel)));
} else {
}

return channel;
});

chromex.chrome_storage_area.ChromeStorageArea.prototype.chromex$protocols$chrome_storage_area$IChromeStorageArea$get_bytes_in_use$arity$1 = (function (this$){
var self__ = this;
var this$__$1 = this;
return this$__$1.chromex$protocols$chrome_storage_area$IChromeStorageArea$get_bytes_in_use$arity$2(null,null);
});

chromex.chrome_storage_area.ChromeStorageArea.prototype.chromex$protocols$chrome_storage_area$IChromeStorageArea$get_bytes_in_use$arity$2 = (function (_this,keys){
var self__ = this;
var _this__$1 = this;
var channel = (self__.channel_factory.cljs$core$IFn$_invoke$arity$0 ? self__.channel_factory.cljs$core$IFn$_invoke$arity$0() : self__.channel_factory.call(null));
var target_obj_12214_12233 = self__.native_chrome_storage_area;
var call_info_12216_12234 = [target_obj_12214_12233,(function (){var next_obj_12217 = (target_obj_12214_12233["getBytesInUse"]);
return next_obj_12217;
})()];
var fn_12215_12235 = (call_info_12216_12234[(1)]);
if((!((fn_12215_12235 == null)))){
fn_12215_12235.call((call_info_12216_12234[(0)]),keys,(self__.callback_factory.cljs$core$IFn$_invoke$arity$1 ? self__.callback_factory.cljs$core$IFn$_invoke$arity$1(channel) : self__.callback_factory.call(null,channel)));
} else {
}

return channel;
});

chromex.chrome_storage_area.ChromeStorageArea.prototype.chromex$protocols$chrome_storage_area$IChromeStorageArea$set$arity$2 = (function (_this,items){
var self__ = this;
var _this__$1 = this;
var channel = (self__.channel_factory.cljs$core$IFn$_invoke$arity$0 ? self__.channel_factory.cljs$core$IFn$_invoke$arity$0() : self__.channel_factory.call(null));
var target_obj_12218_12236 = self__.native_chrome_storage_area;
var call_info_12220_12237 = [target_obj_12218_12236,(function (){var next_obj_12221 = (target_obj_12218_12236["set"]);
return next_obj_12221;
})()];
var fn_12219_12238 = (call_info_12220_12237[(1)]);
if((!((fn_12219_12238 == null)))){
fn_12219_12238.call((call_info_12220_12237[(0)]),items,(self__.callback_factory.cljs$core$IFn$_invoke$arity$1 ? self__.callback_factory.cljs$core$IFn$_invoke$arity$1(channel) : self__.callback_factory.call(null,channel)));
} else {
}

return channel;
});

chromex.chrome_storage_area.ChromeStorageArea.prototype.chromex$protocols$chrome_storage_area$IChromeStorageArea$remove$arity$2 = (function (_this,keys){
var self__ = this;
var _this__$1 = this;
var channel = (self__.channel_factory.cljs$core$IFn$_invoke$arity$0 ? self__.channel_factory.cljs$core$IFn$_invoke$arity$0() : self__.channel_factory.call(null));
var target_obj_12222_12239 = self__.native_chrome_storage_area;
var call_info_12224_12240 = [target_obj_12222_12239,(function (){var next_obj_12225 = (target_obj_12222_12239["remove"]);
return next_obj_12225;
})()];
var fn_12223_12241 = (call_info_12224_12240[(1)]);
if((!((fn_12223_12241 == null)))){
fn_12223_12241.call((call_info_12224_12240[(0)]),keys,(self__.callback_factory.cljs$core$IFn$_invoke$arity$1 ? self__.callback_factory.cljs$core$IFn$_invoke$arity$1(channel) : self__.callback_factory.call(null,channel)));
} else {
}

return channel;
});

chromex.chrome_storage_area.ChromeStorageArea.prototype.chromex$protocols$chrome_storage_area$IChromeStorageArea$clear$arity$1 = (function (_this){
var self__ = this;
var _this__$1 = this;
var channel = (self__.channel_factory.cljs$core$IFn$_invoke$arity$0 ? self__.channel_factory.cljs$core$IFn$_invoke$arity$0() : self__.channel_factory.call(null));
var target_obj_12226_12242 = self__.native_chrome_storage_area;
var call_info_12228_12243 = [target_obj_12226_12242,(function (){var next_obj_12229 = (target_obj_12226_12242["clear"]);
return next_obj_12229;
})()];
var fn_12227_12244 = (call_info_12228_12243[(1)]);
if((!((fn_12227_12244 == null)))){
fn_12227_12244.call((call_info_12228_12243[(0)]),(self__.callback_factory.cljs$core$IFn$_invoke$arity$1 ? self__.callback_factory.cljs$core$IFn$_invoke$arity$1(channel) : self__.callback_factory.call(null,channel)));
} else {
}

return channel;
});

chromex.chrome_storage_area.ChromeStorageArea.getBasis = (function (){
return new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [cljs.core.cst$sym$native_DASH_chrome_DASH_storage_DASH_area,cljs.core.cst$sym$channel_DASH_factory,cljs.core.cst$sym$callback_DASH_factory], null);
});

chromex.chrome_storage_area.ChromeStorageArea.cljs$lang$type = true;

chromex.chrome_storage_area.ChromeStorageArea.cljs$lang$ctorStr = "chromex.chrome-storage-area/ChromeStorageArea";

chromex.chrome_storage_area.ChromeStorageArea.cljs$lang$ctorPrWriter = (function (this__4290__auto__,writer__4291__auto__,opt__4292__auto__){
return cljs.core._write(writer__4291__auto__,"chromex.chrome-storage-area/ChromeStorageArea");
});

/**
 * Positional factory function for chromex.chrome-storage-area/ChromeStorageArea.
 */
chromex.chrome_storage_area.__GT_ChromeStorageArea = (function chromex$chrome_storage_area$__GT_ChromeStorageArea(native_chrome_storage_area,channel_factory,callback_factory){
return (new chromex.chrome_storage_area.ChromeStorageArea(native_chrome_storage_area,channel_factory,callback_factory));
});

chromex.chrome_storage_area.make_chrome_storage_area = (function chromex$chrome_storage_area$make_chrome_storage_area(config,native_chrome_storage_area){

return (new chromex.chrome_storage_area.ChromeStorageArea(native_chrome_storage_area,(function (){var config__6152__auto__ = config;
var handler_key__6153__auto__ = cljs.core.cst$kw$chrome_DASH_storage_DASH_area_DASH_callback_DASH_channel_DASH_factory;
var handler__6154__auto__ = handler_key__6153__auto__.cljs$core$IFn$_invoke$arity$1(config__6152__auto__);

return cljs.core.partial.cljs$core$IFn$_invoke$arity$2(handler__6154__auto__,config__6152__auto__);
})(),(function (){var config__6152__auto__ = config;
var handler_key__6153__auto__ = cljs.core.cst$kw$chrome_DASH_storage_DASH_area_DASH_callback_DASH_fn_DASH_factory;
var handler__6154__auto__ = handler_key__6153__auto__.cljs$core$IFn$_invoke$arity$1(config__6152__auto__);

return cljs.core.partial.cljs$core$IFn$_invoke$arity$2(handler__6154__auto__,config__6152__auto__);
})()));
});
