// Compiled by ClojureScript 1.10.439 {:static-fns true, :optimize-constants true, :elide-asserts true}
goog.provide('chromex.marshalling');
goog.require('cljs.core');
goog.require('cljs.core.constants');
goog.require('chromex.protocols.chrome_port');
goog.require('chromex.protocols.chrome_storage_area');
goog.require('chromex.protocols.chrome_content_setting');
goog.require('chromex.config');
goog.require('chromex.chrome_port');
goog.require('chromex.chrome_storage_area');
goog.require('chromex.chrome_content_setting');
chromex.marshalling.from_native_chrome_port = (function chromex$marshalling$from_native_chrome_port(config,native_chrome_port){
if((!((native_chrome_port == null)))){
return chromex.chrome_port.make_chrome_port(config,native_chrome_port);
} else {
return null;
}
});
chromex.marshalling.to_native_chrome_port = (function chromex$marshalling$to_native_chrome_port(_config,chrome_port){
if((!((chrome_port == null)))){

return chromex.protocols.chrome_port.get_native_port(chrome_port);
} else {
return null;
}
});
chromex.marshalling.from_native_chrome_storage_area = (function chromex$marshalling$from_native_chrome_storage_area(config,native_chrome_storage_area){
if((!((native_chrome_storage_area == null)))){
return chromex.chrome_storage_area.make_chrome_storage_area(config,native_chrome_storage_area);
} else {
return null;
}
});
chromex.marshalling.to_native_chrome_storage_area = (function chromex$marshalling$to_native_chrome_storage_area(_config,chrome_storage_area){
if((!((chrome_storage_area == null)))){
if((!((chrome_storage_area == null)))){
if(((false) || ((cljs.core.PROTOCOL_SENTINEL === chrome_storage_area.chromex$protocols$chrome_storage_area$IChromeStorageArea$)))){
} else {
if((!chrome_storage_area.cljs$lang$protocol_mask$partition$)){
cljs.core.native_satisfies_QMARK_(chromex.protocols.chrome_storage_area.IChromeStorageArea,chrome_storage_area);
} else {
}
}
} else {
cljs.core.native_satisfies_QMARK_(chromex.protocols.chrome_storage_area.IChromeStorageArea,chrome_storage_area);
}

return chromex.protocols.chrome_storage_area.get_native_storage_area(chrome_storage_area);
} else {
return null;
}
});
chromex.marshalling.from_native_chrome_content_setting = (function chromex$marshalling$from_native_chrome_content_setting(config,native_chrome_content_setting){
if((!((native_chrome_content_setting == null)))){
return chromex.chrome_content_setting.make_chrome_content_setting(config,native_chrome_content_setting);
} else {
return null;
}
});
chromex.marshalling.to_native_chrome_content_setting = (function chromex$marshalling$to_native_chrome_content_setting(_config,chrome_content_setting){
if((!((chrome_content_setting == null)))){
if((!((chrome_content_setting == null)))){
if(((false) || ((cljs.core.PROTOCOL_SENTINEL === chrome_content_setting.chromex$protocols$chrome_content_setting$IChromeContentSetting$)))){
} else {
if((!chrome_content_setting.cljs$lang$protocol_mask$partition$)){
cljs.core.native_satisfies_QMARK_(chromex.protocols.chrome_content_setting.IChromeContentSetting,chrome_content_setting);
} else {
}
}
} else {
cljs.core.native_satisfies_QMARK_(chromex.protocols.chrome_content_setting.IChromeContentSetting,chrome_content_setting);
}

return chromex.protocols.chrome_content_setting.get_native_content_setting(chrome_content_setting);
} else {
return null;
}
});
