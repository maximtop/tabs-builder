// Compiled by ClojureScript 1.10.439 {:static-fns true, :optimize-constants true, :elide-asserts true}
goog.provide('chromex.error');
goog.require('cljs.core');
goog.require('cljs.core.constants');
chromex.error.last_error = cljs.core.atom.cljs$core$IFn$_invoke$arity$1(null);
chromex.error.last_error_args = cljs.core.atom.cljs$core$IFn$_invoke$arity$1(null);
chromex.error.set_last_error_BANG_ = (function chromex$error$set_last_error_BANG_(error){
return cljs.core.reset_BANG_(chromex.error.last_error,error);
});
chromex.error.get_last_error = (function chromex$error$get_last_error(){
return cljs.core.deref(chromex.error.last_error);
});
chromex.error.set_last_error_args_BANG_ = (function chromex$error$set_last_error_args_BANG_(args){
return cljs.core.reset_BANG_(chromex.error.last_error_args,args);
});
chromex.error.get_last_error_args = (function chromex$error$get_last_error_args(){
return cljs.core.deref(chromex.error.last_error_args);
});
