// Compiled by ClojureScript 1.10.439 {:static-fns true, :optimize-constants true, :elide-asserts true}
goog.provide('cljs.core.async');
goog.require('cljs.core');
goog.require('cljs.core.constants');
goog.require('cljs.core.async.impl.protocols');
goog.require('cljs.core.async.impl.channels');
goog.require('cljs.core.async.impl.buffers');
goog.require('cljs.core.async.impl.timers');
goog.require('cljs.core.async.impl.dispatch');
goog.require('cljs.core.async.impl.ioc_helpers');
cljs.core.async.fn_handler = (function cljs$core$async$fn_handler(var_args){
var G__8052 = arguments.length;
switch (G__8052) {
case 1:
return cljs.core.async.fn_handler.cljs$core$IFn$_invoke$arity$1((arguments[(0)]));

break;
case 2:
return cljs.core.async.fn_handler.cljs$core$IFn$_invoke$arity$2((arguments[(0)]),(arguments[(1)]));

break;
default:
throw (new Error(["Invalid arity: ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(arguments.length)].join('')));

}
});

cljs.core.async.fn_handler.cljs$core$IFn$_invoke$arity$1 = (function (f){
return cljs.core.async.fn_handler.cljs$core$IFn$_invoke$arity$2(f,true);
});

cljs.core.async.fn_handler.cljs$core$IFn$_invoke$arity$2 = (function (f,blockable){
if((typeof cljs !== 'undefined') && (typeof cljs.core !== 'undefined') && (typeof cljs.core.async !== 'undefined') && (typeof cljs.core.async.t_cljs$core$async8053 !== 'undefined')){
} else {

/**
* @constructor
 * @implements {cljs.core.async.impl.protocols.Handler}
 * @implements {cljs.core.IMeta}
 * @implements {cljs.core.IWithMeta}
*/
cljs.core.async.t_cljs$core$async8053 = (function (f,blockable,meta8054){
this.f = f;
this.blockable = blockable;
this.meta8054 = meta8054;
this.cljs$lang$protocol_mask$partition0$ = 393216;
this.cljs$lang$protocol_mask$partition1$ = 0;
});
cljs.core.async.t_cljs$core$async8053.prototype.cljs$core$IWithMeta$_with_meta$arity$2 = (function (_8055,meta8054__$1){
var self__ = this;
var _8055__$1 = this;
return (new cljs.core.async.t_cljs$core$async8053(self__.f,self__.blockable,meta8054__$1));
});

cljs.core.async.t_cljs$core$async8053.prototype.cljs$core$IMeta$_meta$arity$1 = (function (_8055){
var self__ = this;
var _8055__$1 = this;
return self__.meta8054;
});

cljs.core.async.t_cljs$core$async8053.prototype.cljs$core$async$impl$protocols$Handler$ = cljs.core.PROTOCOL_SENTINEL;

cljs.core.async.t_cljs$core$async8053.prototype.cljs$core$async$impl$protocols$Handler$active_QMARK_$arity$1 = (function (_){
var self__ = this;
var ___$1 = this;
return true;
});

cljs.core.async.t_cljs$core$async8053.prototype.cljs$core$async$impl$protocols$Handler$blockable_QMARK_$arity$1 = (function (_){
var self__ = this;
var ___$1 = this;
return self__.blockable;
});

cljs.core.async.t_cljs$core$async8053.prototype.cljs$core$async$impl$protocols$Handler$commit$arity$1 = (function (_){
var self__ = this;
var ___$1 = this;
return self__.f;
});

cljs.core.async.t_cljs$core$async8053.getBasis = (function (){
return new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [cljs.core.cst$sym$f,cljs.core.cst$sym$blockable,cljs.core.cst$sym$meta8054], null);
});

cljs.core.async.t_cljs$core$async8053.cljs$lang$type = true;

cljs.core.async.t_cljs$core$async8053.cljs$lang$ctorStr = "cljs.core.async/t_cljs$core$async8053";

cljs.core.async.t_cljs$core$async8053.cljs$lang$ctorPrWriter = (function (this__4290__auto__,writer__4291__auto__,opt__4292__auto__){
return cljs.core._write(writer__4291__auto__,"cljs.core.async/t_cljs$core$async8053");
});

/**
 * Positional factory function for cljs.core.async/t_cljs$core$async8053.
 */
cljs.core.async.__GT_t_cljs$core$async8053 = (function cljs$core$async$__GT_t_cljs$core$async8053(f__$1,blockable__$1,meta8054){
return (new cljs.core.async.t_cljs$core$async8053(f__$1,blockable__$1,meta8054));
});

}

return (new cljs.core.async.t_cljs$core$async8053(f,blockable,cljs.core.PersistentArrayMap.EMPTY));
});

cljs.core.async.fn_handler.cljs$lang$maxFixedArity = 2;

/**
 * Returns a fixed buffer of size n. When full, puts will block/park.
 */
cljs.core.async.buffer = (function cljs$core$async$buffer(n){
return cljs.core.async.impl.buffers.fixed_buffer(n);
});
/**
 * Returns a buffer of size n. When full, puts will complete but
 *   val will be dropped (no transfer).
 */
cljs.core.async.dropping_buffer = (function cljs$core$async$dropping_buffer(n){
return cljs.core.async.impl.buffers.dropping_buffer(n);
});
/**
 * Returns a buffer of size n. When full, puts will complete, and be
 *   buffered, but oldest elements in buffer will be dropped (not
 *   transferred).
 */
cljs.core.async.sliding_buffer = (function cljs$core$async$sliding_buffer(n){
return cljs.core.async.impl.buffers.sliding_buffer(n);
});
/**
 * Returns true if a channel created with buff will never block. That is to say,
 * puts into this buffer will never cause the buffer to be full. 
 */
cljs.core.async.unblocking_buffer_QMARK_ = (function cljs$core$async$unblocking_buffer_QMARK_(buff){
if((!((buff == null)))){
if(((false) || ((cljs.core.PROTOCOL_SENTINEL === buff.cljs$core$async$impl$protocols$UnblockingBuffer$)))){
return true;
} else {
if((!buff.cljs$lang$protocol_mask$partition$)){
return cljs.core.native_satisfies_QMARK_(cljs.core.async.impl.protocols.UnblockingBuffer,buff);
} else {
return false;
}
}
} else {
return cljs.core.native_satisfies_QMARK_(cljs.core.async.impl.protocols.UnblockingBuffer,buff);
}
});
/**
 * Creates a channel with an optional buffer, an optional transducer (like (map f),
 *   (filter p) etc or a composition thereof), and an optional exception handler.
 *   If buf-or-n is a number, will create and use a fixed buffer of that size. If a
 *   transducer is supplied a buffer must be specified. ex-handler must be a
 *   fn of one argument - if an exception occurs during transformation it will be called
 *   with the thrown value as an argument, and any non-nil return value will be placed
 *   in the channel.
 */
cljs.core.async.chan = (function cljs$core$async$chan(var_args){
var G__8059 = arguments.length;
switch (G__8059) {
case 0:
return cljs.core.async.chan.cljs$core$IFn$_invoke$arity$0();

break;
case 1:
return cljs.core.async.chan.cljs$core$IFn$_invoke$arity$1((arguments[(0)]));

break;
case 2:
return cljs.core.async.chan.cljs$core$IFn$_invoke$arity$2((arguments[(0)]),(arguments[(1)]));

break;
case 3:
return cljs.core.async.chan.cljs$core$IFn$_invoke$arity$3((arguments[(0)]),(arguments[(1)]),(arguments[(2)]));

break;
default:
throw (new Error(["Invalid arity: ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(arguments.length)].join('')));

}
});

cljs.core.async.chan.cljs$core$IFn$_invoke$arity$0 = (function (){
return cljs.core.async.chan.cljs$core$IFn$_invoke$arity$1(null);
});

cljs.core.async.chan.cljs$core$IFn$_invoke$arity$1 = (function (buf_or_n){
return cljs.core.async.chan.cljs$core$IFn$_invoke$arity$3(buf_or_n,null,null);
});

cljs.core.async.chan.cljs$core$IFn$_invoke$arity$2 = (function (buf_or_n,xform){
return cljs.core.async.chan.cljs$core$IFn$_invoke$arity$3(buf_or_n,xform,null);
});

cljs.core.async.chan.cljs$core$IFn$_invoke$arity$3 = (function (buf_or_n,xform,ex_handler){
var buf_or_n__$1 = ((cljs.core._EQ_.cljs$core$IFn$_invoke$arity$2(buf_or_n,(0)))?null:buf_or_n);
if(cljs.core.truth_(xform)){
} else {
}

return cljs.core.async.impl.channels.chan.cljs$core$IFn$_invoke$arity$3(((typeof buf_or_n__$1 === 'number')?cljs.core.async.buffer(buf_or_n__$1):buf_or_n__$1),xform,ex_handler);
});

cljs.core.async.chan.cljs$lang$maxFixedArity = 3;

/**
 * Creates a promise channel with an optional transducer, and an optional
 *   exception-handler. A promise channel can take exactly one value that consumers
 *   will receive. Once full, puts complete but val is dropped (no transfer).
 *   Consumers will block until either a value is placed in the channel or the
 *   channel is closed. See chan for the semantics of xform and ex-handler.
 */
cljs.core.async.promise_chan = (function cljs$core$async$promise_chan(var_args){
var G__8062 = arguments.length;
switch (G__8062) {
case 0:
return cljs.core.async.promise_chan.cljs$core$IFn$_invoke$arity$0();

break;
case 1:
return cljs.core.async.promise_chan.cljs$core$IFn$_invoke$arity$1((arguments[(0)]));

break;
case 2:
return cljs.core.async.promise_chan.cljs$core$IFn$_invoke$arity$2((arguments[(0)]),(arguments[(1)]));

break;
default:
throw (new Error(["Invalid arity: ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(arguments.length)].join('')));

}
});

cljs.core.async.promise_chan.cljs$core$IFn$_invoke$arity$0 = (function (){
return cljs.core.async.promise_chan.cljs$core$IFn$_invoke$arity$1(null);
});

cljs.core.async.promise_chan.cljs$core$IFn$_invoke$arity$1 = (function (xform){
return cljs.core.async.promise_chan.cljs$core$IFn$_invoke$arity$2(xform,null);
});

cljs.core.async.promise_chan.cljs$core$IFn$_invoke$arity$2 = (function (xform,ex_handler){
return cljs.core.async.chan.cljs$core$IFn$_invoke$arity$3(cljs.core.async.impl.buffers.promise_buffer(),xform,ex_handler);
});

cljs.core.async.promise_chan.cljs$lang$maxFixedArity = 2;

/**
 * Returns a channel that will close after msecs
 */
cljs.core.async.timeout = (function cljs$core$async$timeout(msecs){
return cljs.core.async.impl.timers.timeout(msecs);
});
/**
 * takes a val from port. Must be called inside a (go ...) block. Will
 *   return nil if closed. Will park if nothing is available.
 *   Returns true unless port is already closed
 */
cljs.core.async._LT__BANG_ = (function cljs$core$async$_LT__BANG_(port){
throw (new Error("<! used not in (go ...) block"));
});
/**
 * Asynchronously takes a val from port, passing to fn1. Will pass nil
 * if closed. If on-caller? (default true) is true, and value is
 * immediately available, will call fn1 on calling thread.
 * Returns nil.
 */
cljs.core.async.take_BANG_ = (function cljs$core$async$take_BANG_(var_args){
var G__8065 = arguments.length;
switch (G__8065) {
case 2:
return cljs.core.async.take_BANG_.cljs$core$IFn$_invoke$arity$2((arguments[(0)]),(arguments[(1)]));

break;
case 3:
return cljs.core.async.take_BANG_.cljs$core$IFn$_invoke$arity$3((arguments[(0)]),(arguments[(1)]),(arguments[(2)]));

break;
default:
throw (new Error(["Invalid arity: ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(arguments.length)].join('')));

}
});

cljs.core.async.take_BANG_.cljs$core$IFn$_invoke$arity$2 = (function (port,fn1){
return cljs.core.async.take_BANG_.cljs$core$IFn$_invoke$arity$3(port,fn1,true);
});

cljs.core.async.take_BANG_.cljs$core$IFn$_invoke$arity$3 = (function (port,fn1,on_caller_QMARK_){
var ret = cljs.core.async.impl.protocols.take_BANG_(port,cljs.core.async.fn_handler.cljs$core$IFn$_invoke$arity$1(fn1));
if(cljs.core.truth_(ret)){
var val_8067 = cljs.core.deref(ret);
if(cljs.core.truth_(on_caller_QMARK_)){
(fn1.cljs$core$IFn$_invoke$arity$1 ? fn1.cljs$core$IFn$_invoke$arity$1(val_8067) : fn1.call(null,val_8067));
} else {
cljs.core.async.impl.dispatch.run(((function (val_8067,ret){
return (function (){
return (fn1.cljs$core$IFn$_invoke$arity$1 ? fn1.cljs$core$IFn$_invoke$arity$1(val_8067) : fn1.call(null,val_8067));
});})(val_8067,ret))
);
}
} else {
}

return null;
});

cljs.core.async.take_BANG_.cljs$lang$maxFixedArity = 3;

cljs.core.async.nop = (function cljs$core$async$nop(_){
return null;
});
cljs.core.async.fhnop = cljs.core.async.fn_handler.cljs$core$IFn$_invoke$arity$1(cljs.core.async.nop);
/**
 * puts a val into port. nil values are not allowed. Must be called
 *   inside a (go ...) block. Will park if no buffer space is available.
 *   Returns true unless port is already closed.
 */
cljs.core.async._GT__BANG_ = (function cljs$core$async$_GT__BANG_(port,val){
throw (new Error(">! used not in (go ...) block"));
});
/**
 * Asynchronously puts a val into port, calling fn1 (if supplied) when
 * complete. nil values are not allowed. Will throw if closed. If
 * on-caller? (default true) is true, and the put is immediately
 * accepted, will call fn1 on calling thread.  Returns nil.
 */
cljs.core.async.put_BANG_ = (function cljs$core$async$put_BANG_(var_args){
var G__8069 = arguments.length;
switch (G__8069) {
case 2:
return cljs.core.async.put_BANG_.cljs$core$IFn$_invoke$arity$2((arguments[(0)]),(arguments[(1)]));

break;
case 3:
return cljs.core.async.put_BANG_.cljs$core$IFn$_invoke$arity$3((arguments[(0)]),(arguments[(1)]),(arguments[(2)]));

break;
case 4:
return cljs.core.async.put_BANG_.cljs$core$IFn$_invoke$arity$4((arguments[(0)]),(arguments[(1)]),(arguments[(2)]),(arguments[(3)]));

break;
default:
throw (new Error(["Invalid arity: ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(arguments.length)].join('')));

}
});

cljs.core.async.put_BANG_.cljs$core$IFn$_invoke$arity$2 = (function (port,val){
var temp__5455__auto__ = cljs.core.async.impl.protocols.put_BANG_(port,val,cljs.core.async.fhnop);
if(cljs.core.truth_(temp__5455__auto__)){
var ret = temp__5455__auto__;
return cljs.core.deref(ret);
} else {
return true;
}
});

cljs.core.async.put_BANG_.cljs$core$IFn$_invoke$arity$3 = (function (port,val,fn1){
return cljs.core.async.put_BANG_.cljs$core$IFn$_invoke$arity$4(port,val,fn1,true);
});

cljs.core.async.put_BANG_.cljs$core$IFn$_invoke$arity$4 = (function (port,val,fn1,on_caller_QMARK_){
var temp__5455__auto__ = cljs.core.async.impl.protocols.put_BANG_(port,val,cljs.core.async.fn_handler.cljs$core$IFn$_invoke$arity$1(fn1));
if(cljs.core.truth_(temp__5455__auto__)){
var retb = temp__5455__auto__;
var ret = cljs.core.deref(retb);
if(cljs.core.truth_(on_caller_QMARK_)){
(fn1.cljs$core$IFn$_invoke$arity$1 ? fn1.cljs$core$IFn$_invoke$arity$1(ret) : fn1.call(null,ret));
} else {
cljs.core.async.impl.dispatch.run(((function (ret,retb,temp__5455__auto__){
return (function (){
return (fn1.cljs$core$IFn$_invoke$arity$1 ? fn1.cljs$core$IFn$_invoke$arity$1(ret) : fn1.call(null,ret));
});})(ret,retb,temp__5455__auto__))
);
}

return ret;
} else {
return true;
}
});

cljs.core.async.put_BANG_.cljs$lang$maxFixedArity = 4;

cljs.core.async.close_BANG_ = (function cljs$core$async$close_BANG_(port){
return cljs.core.async.impl.protocols.close_BANG_(port);
});
cljs.core.async.random_array = (function cljs$core$async$random_array(n){
var a = (new Array(n));
var n__4518__auto___8071 = n;
var x_8072 = (0);
while(true){
if((x_8072 < n__4518__auto___8071)){
(a[x_8072] = (0));

var G__8073 = (x_8072 + (1));
x_8072 = G__8073;
continue;
} else {
}
break;
}

var i = (1);
while(true){
if(cljs.core._EQ_.cljs$core$IFn$_invoke$arity$2(i,n)){
return a;
} else {
var j = cljs.core.rand_int(i);
(a[i] = (a[j]));

(a[j] = i);

var G__8074 = (i + (1));
i = G__8074;
continue;
}
break;
}
});
cljs.core.async.alt_flag = (function cljs$core$async$alt_flag(){
var flag = cljs.core.atom.cljs$core$IFn$_invoke$arity$1(true);
if((typeof cljs !== 'undefined') && (typeof cljs.core !== 'undefined') && (typeof cljs.core.async !== 'undefined') && (typeof cljs.core.async.t_cljs$core$async8075 !== 'undefined')){
} else {

/**
* @constructor
 * @implements {cljs.core.async.impl.protocols.Handler}
 * @implements {cljs.core.IMeta}
 * @implements {cljs.core.IWithMeta}
*/
cljs.core.async.t_cljs$core$async8075 = (function (flag,meta8076){
this.flag = flag;
this.meta8076 = meta8076;
this.cljs$lang$protocol_mask$partition0$ = 393216;
this.cljs$lang$protocol_mask$partition1$ = 0;
});
cljs.core.async.t_cljs$core$async8075.prototype.cljs$core$IWithMeta$_with_meta$arity$2 = ((function (flag){
return (function (_8077,meta8076__$1){
var self__ = this;
var _8077__$1 = this;
return (new cljs.core.async.t_cljs$core$async8075(self__.flag,meta8076__$1));
});})(flag))
;

cljs.core.async.t_cljs$core$async8075.prototype.cljs$core$IMeta$_meta$arity$1 = ((function (flag){
return (function (_8077){
var self__ = this;
var _8077__$1 = this;
return self__.meta8076;
});})(flag))
;

cljs.core.async.t_cljs$core$async8075.prototype.cljs$core$async$impl$protocols$Handler$ = cljs.core.PROTOCOL_SENTINEL;

cljs.core.async.t_cljs$core$async8075.prototype.cljs$core$async$impl$protocols$Handler$active_QMARK_$arity$1 = ((function (flag){
return (function (_){
var self__ = this;
var ___$1 = this;
return cljs.core.deref(self__.flag);
});})(flag))
;

cljs.core.async.t_cljs$core$async8075.prototype.cljs$core$async$impl$protocols$Handler$blockable_QMARK_$arity$1 = ((function (flag){
return (function (_){
var self__ = this;
var ___$1 = this;
return true;
});})(flag))
;

cljs.core.async.t_cljs$core$async8075.prototype.cljs$core$async$impl$protocols$Handler$commit$arity$1 = ((function (flag){
return (function (_){
var self__ = this;
var ___$1 = this;
cljs.core.reset_BANG_(self__.flag,null);

return true;
});})(flag))
;

cljs.core.async.t_cljs$core$async8075.getBasis = ((function (flag){
return (function (){
return new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [cljs.core.cst$sym$flag,cljs.core.cst$sym$meta8076], null);
});})(flag))
;

cljs.core.async.t_cljs$core$async8075.cljs$lang$type = true;

cljs.core.async.t_cljs$core$async8075.cljs$lang$ctorStr = "cljs.core.async/t_cljs$core$async8075";

cljs.core.async.t_cljs$core$async8075.cljs$lang$ctorPrWriter = ((function (flag){
return (function (this__4290__auto__,writer__4291__auto__,opt__4292__auto__){
return cljs.core._write(writer__4291__auto__,"cljs.core.async/t_cljs$core$async8075");
});})(flag))
;

/**
 * Positional factory function for cljs.core.async/t_cljs$core$async8075.
 */
cljs.core.async.__GT_t_cljs$core$async8075 = ((function (flag){
return (function cljs$core$async$alt_flag_$___GT_t_cljs$core$async8075(flag__$1,meta8076){
return (new cljs.core.async.t_cljs$core$async8075(flag__$1,meta8076));
});})(flag))
;

}

return (new cljs.core.async.t_cljs$core$async8075(flag,cljs.core.PersistentArrayMap.EMPTY));
});
cljs.core.async.alt_handler = (function cljs$core$async$alt_handler(flag,cb){
if((typeof cljs !== 'undefined') && (typeof cljs.core !== 'undefined') && (typeof cljs.core.async !== 'undefined') && (typeof cljs.core.async.t_cljs$core$async8078 !== 'undefined')){
} else {

/**
* @constructor
 * @implements {cljs.core.async.impl.protocols.Handler}
 * @implements {cljs.core.IMeta}
 * @implements {cljs.core.IWithMeta}
*/
cljs.core.async.t_cljs$core$async8078 = (function (flag,cb,meta8079){
this.flag = flag;
this.cb = cb;
this.meta8079 = meta8079;
this.cljs$lang$protocol_mask$partition0$ = 393216;
this.cljs$lang$protocol_mask$partition1$ = 0;
});
cljs.core.async.t_cljs$core$async8078.prototype.cljs$core$IWithMeta$_with_meta$arity$2 = (function (_8080,meta8079__$1){
var self__ = this;
var _8080__$1 = this;
return (new cljs.core.async.t_cljs$core$async8078(self__.flag,self__.cb,meta8079__$1));
});

cljs.core.async.t_cljs$core$async8078.prototype.cljs$core$IMeta$_meta$arity$1 = (function (_8080){
var self__ = this;
var _8080__$1 = this;
return self__.meta8079;
});

cljs.core.async.t_cljs$core$async8078.prototype.cljs$core$async$impl$protocols$Handler$ = cljs.core.PROTOCOL_SENTINEL;

cljs.core.async.t_cljs$core$async8078.prototype.cljs$core$async$impl$protocols$Handler$active_QMARK_$arity$1 = (function (_){
var self__ = this;
var ___$1 = this;
return cljs.core.async.impl.protocols.active_QMARK_(self__.flag);
});

cljs.core.async.t_cljs$core$async8078.prototype.cljs$core$async$impl$protocols$Handler$blockable_QMARK_$arity$1 = (function (_){
var self__ = this;
var ___$1 = this;
return true;
});

cljs.core.async.t_cljs$core$async8078.prototype.cljs$core$async$impl$protocols$Handler$commit$arity$1 = (function (_){
var self__ = this;
var ___$1 = this;
cljs.core.async.impl.protocols.commit(self__.flag);

return self__.cb;
});

cljs.core.async.t_cljs$core$async8078.getBasis = (function (){
return new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [cljs.core.cst$sym$flag,cljs.core.cst$sym$cb,cljs.core.cst$sym$meta8079], null);
});

cljs.core.async.t_cljs$core$async8078.cljs$lang$type = true;

cljs.core.async.t_cljs$core$async8078.cljs$lang$ctorStr = "cljs.core.async/t_cljs$core$async8078";

cljs.core.async.t_cljs$core$async8078.cljs$lang$ctorPrWriter = (function (this__4290__auto__,writer__4291__auto__,opt__4292__auto__){
return cljs.core._write(writer__4291__auto__,"cljs.core.async/t_cljs$core$async8078");
});

/**
 * Positional factory function for cljs.core.async/t_cljs$core$async8078.
 */
cljs.core.async.__GT_t_cljs$core$async8078 = (function cljs$core$async$alt_handler_$___GT_t_cljs$core$async8078(flag__$1,cb__$1,meta8079){
return (new cljs.core.async.t_cljs$core$async8078(flag__$1,cb__$1,meta8079));
});

}

return (new cljs.core.async.t_cljs$core$async8078(flag,cb,cljs.core.PersistentArrayMap.EMPTY));
});
/**
 * returns derefable [val port] if immediate, nil if enqueued
 */
cljs.core.async.do_alts = (function cljs$core$async$do_alts(fret,ports,opts){
var flag = cljs.core.async.alt_flag();
var n = cljs.core.count(ports);
var idxs = cljs.core.async.random_array(n);
var priority = cljs.core.cst$kw$priority.cljs$core$IFn$_invoke$arity$1(opts);
var ret = (function (){var i = (0);
while(true){
if((i < n)){
var idx = (cljs.core.truth_(priority)?i:(idxs[i]));
var port = cljs.core.nth.cljs$core$IFn$_invoke$arity$2(ports,idx);
var wport = ((cljs.core.vector_QMARK_(port))?(port.cljs$core$IFn$_invoke$arity$1 ? port.cljs$core$IFn$_invoke$arity$1((0)) : port.call(null,(0))):null);
var vbox = (cljs.core.truth_(wport)?(function (){var val = (port.cljs$core$IFn$_invoke$arity$1 ? port.cljs$core$IFn$_invoke$arity$1((1)) : port.call(null,(1)));
return cljs.core.async.impl.protocols.put_BANG_(wport,val,cljs.core.async.alt_handler(flag,((function (i,val,idx,port,wport,flag,n,idxs,priority){
return (function (p1__8081_SHARP_){
var G__8083 = new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [p1__8081_SHARP_,wport], null);
return (fret.cljs$core$IFn$_invoke$arity$1 ? fret.cljs$core$IFn$_invoke$arity$1(G__8083) : fret.call(null,G__8083));
});})(i,val,idx,port,wport,flag,n,idxs,priority))
));
})():cljs.core.async.impl.protocols.take_BANG_(port,cljs.core.async.alt_handler(flag,((function (i,idx,port,wport,flag,n,idxs,priority){
return (function (p1__8082_SHARP_){
var G__8084 = new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [p1__8082_SHARP_,port], null);
return (fret.cljs$core$IFn$_invoke$arity$1 ? fret.cljs$core$IFn$_invoke$arity$1(G__8084) : fret.call(null,G__8084));
});})(i,idx,port,wport,flag,n,idxs,priority))
)));
if(cljs.core.truth_(vbox)){
return cljs.core.async.impl.channels.box(new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [cljs.core.deref(vbox),(function (){var or__4047__auto__ = wport;
if(cljs.core.truth_(or__4047__auto__)){
return or__4047__auto__;
} else {
return port;
}
})()], null));
} else {
var G__8085 = (i + (1));
i = G__8085;
continue;
}
} else {
return null;
}
break;
}
})();
var or__4047__auto__ = ret;
if(cljs.core.truth_(or__4047__auto__)){
return or__4047__auto__;
} else {
if(cljs.core.contains_QMARK_(opts,cljs.core.cst$kw$default)){
var temp__5457__auto__ = (function (){var and__4036__auto__ = flag.cljs$core$async$impl$protocols$Handler$active_QMARK_$arity$1(null);
if(cljs.core.truth_(and__4036__auto__)){
return flag.cljs$core$async$impl$protocols$Handler$commit$arity$1(null);
} else {
return and__4036__auto__;
}
})();
if(cljs.core.truth_(temp__5457__auto__)){
var got = temp__5457__auto__;
return cljs.core.async.impl.channels.box(new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [cljs.core.cst$kw$default.cljs$core$IFn$_invoke$arity$1(opts),cljs.core.cst$kw$default], null));
} else {
return null;
}
} else {
return null;
}
}
});
/**
 * Completes at most one of several channel operations. Must be called
 * inside a (go ...) block. ports is a vector of channel endpoints,
 * which can be either a channel to take from or a vector of
 *   [channel-to-put-to val-to-put], in any combination. Takes will be
 *   made as if by <!, and puts will be made as if by >!. Unless
 *   the :priority option is true, if more than one port operation is
 *   ready a non-deterministic choice will be made. If no operation is
 *   ready and a :default value is supplied, [default-val :default] will
 *   be returned, otherwise alts! will park until the first operation to
 *   become ready completes. Returns [val port] of the completed
 *   operation, where val is the value taken for takes, and a
 *   boolean (true unless already closed, as per put!) for puts.
 * 
 *   opts are passed as :key val ... Supported options:
 * 
 *   :default val - the value to use if none of the operations are immediately ready
 *   :priority true - (default nil) when true, the operations will be tried in order.
 * 
 *   Note: there is no guarantee that the port exps or val exprs will be
 *   used, nor in what order should they be, so they should not be
 *   depended upon for side effects.
 */
cljs.core.async.alts_BANG_ = (function cljs$core$async$alts_BANG_(var_args){
var args__4647__auto__ = [];
var len__4641__auto___8091 = arguments.length;
var i__4642__auto___8092 = (0);
while(true){
if((i__4642__auto___8092 < len__4641__auto___8091)){
args__4647__auto__.push((arguments[i__4642__auto___8092]));

var G__8093 = (i__4642__auto___8092 + (1));
i__4642__auto___8092 = G__8093;
continue;
} else {
}
break;
}

var argseq__4648__auto__ = ((((1) < args__4647__auto__.length))?(new cljs.core.IndexedSeq(args__4647__auto__.slice((1)),(0),null)):null);
return cljs.core.async.alts_BANG_.cljs$core$IFn$_invoke$arity$variadic((arguments[(0)]),argseq__4648__auto__);
});

cljs.core.async.alts_BANG_.cljs$core$IFn$_invoke$arity$variadic = (function (ports,p__8088){
var map__8089 = p__8088;
var map__8089__$1 = (((((!((map__8089 == null))))?(((((map__8089.cljs$lang$protocol_mask$partition0$ & (64))) || ((cljs.core.PROTOCOL_SENTINEL === map__8089.cljs$core$ISeq$))))?true:false):false))?cljs.core.apply.cljs$core$IFn$_invoke$arity$2(cljs.core.hash_map,map__8089):map__8089);
var opts = map__8089__$1;
throw (new Error("alts! used not in (go ...) block"));
});

cljs.core.async.alts_BANG_.cljs$lang$maxFixedArity = (1);

/** @this {Function} */
cljs.core.async.alts_BANG_.cljs$lang$applyTo = (function (seq8086){
var G__8087 = cljs.core.first(seq8086);
var seq8086__$1 = cljs.core.next(seq8086);
var self__4628__auto__ = this;
return self__4628__auto__.cljs$core$IFn$_invoke$arity$variadic(G__8087,seq8086__$1);
});

/**
 * Puts a val into port if it's possible to do so immediately.
 *   nil values are not allowed. Never blocks. Returns true if offer succeeds.
 */
cljs.core.async.offer_BANG_ = (function cljs$core$async$offer_BANG_(port,val){
var ret = cljs.core.async.impl.protocols.put_BANG_(port,val,cljs.core.async.fn_handler.cljs$core$IFn$_invoke$arity$2(cljs.core.async.nop,false));
if(cljs.core.truth_(ret)){
return cljs.core.deref(ret);
} else {
return null;
}
});
/**
 * Takes a val from port if it's possible to do so immediately.
 *   Never blocks. Returns value if successful, nil otherwise.
 */
cljs.core.async.poll_BANG_ = (function cljs$core$async$poll_BANG_(port){
var ret = cljs.core.async.impl.protocols.take_BANG_(port,cljs.core.async.fn_handler.cljs$core$IFn$_invoke$arity$2(cljs.core.async.nop,false));
if(cljs.core.truth_(ret)){
return cljs.core.deref(ret);
} else {
return null;
}
});
/**
 * Takes elements from the from channel and supplies them to the to
 * channel. By default, the to channel will be closed when the from
 * channel closes, but can be determined by the close?  parameter. Will
 * stop consuming the from channel if the to channel closes
 */
cljs.core.async.pipe = (function cljs$core$async$pipe(var_args){
var G__8095 = arguments.length;
switch (G__8095) {
case 2:
return cljs.core.async.pipe.cljs$core$IFn$_invoke$arity$2((arguments[(0)]),(arguments[(1)]));

break;
case 3:
return cljs.core.async.pipe.cljs$core$IFn$_invoke$arity$3((arguments[(0)]),(arguments[(1)]),(arguments[(2)]));

break;
default:
throw (new Error(["Invalid arity: ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(arguments.length)].join('')));

}
});

cljs.core.async.pipe.cljs$core$IFn$_invoke$arity$2 = (function (from,to){
return cljs.core.async.pipe.cljs$core$IFn$_invoke$arity$3(from,to,true);
});

cljs.core.async.pipe.cljs$core$IFn$_invoke$arity$3 = (function (from,to,close_QMARK_){
var c__7992__auto___8141 = cljs.core.async.chan.cljs$core$IFn$_invoke$arity$1((1));
cljs.core.async.impl.dispatch.run(((function (c__7992__auto___8141){
return (function (){
var f__7993__auto__ = (function (){var switch__7885__auto__ = ((function (c__7992__auto___8141){
return (function (state_8119){
var state_val_8120 = (state_8119[(1)]);
if((state_val_8120 === (7))){
var inst_8115 = (state_8119[(2)]);
var state_8119__$1 = state_8119;
var statearr_8121_8142 = state_8119__$1;
(statearr_8121_8142[(2)] = inst_8115);

(statearr_8121_8142[(1)] = (3));


return cljs.core.cst$kw$recur;
} else {
if((state_val_8120 === (1))){
var state_8119__$1 = state_8119;
var statearr_8122_8143 = state_8119__$1;
(statearr_8122_8143[(2)] = null);

(statearr_8122_8143[(1)] = (2));


return cljs.core.cst$kw$recur;
} else {
if((state_val_8120 === (4))){
var inst_8098 = (state_8119[(7)]);
var inst_8098__$1 = (state_8119[(2)]);
var inst_8099 = (inst_8098__$1 == null);
var state_8119__$1 = (function (){var statearr_8123 = state_8119;
(statearr_8123[(7)] = inst_8098__$1);

return statearr_8123;
})();
if(cljs.core.truth_(inst_8099)){
var statearr_8124_8144 = state_8119__$1;
(statearr_8124_8144[(1)] = (5));

} else {
var statearr_8125_8145 = state_8119__$1;
(statearr_8125_8145[(1)] = (6));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_8120 === (13))){
var state_8119__$1 = state_8119;
var statearr_8126_8146 = state_8119__$1;
(statearr_8126_8146[(2)] = null);

(statearr_8126_8146[(1)] = (14));


return cljs.core.cst$kw$recur;
} else {
if((state_val_8120 === (6))){
var inst_8098 = (state_8119[(7)]);
var state_8119__$1 = state_8119;
return cljs.core.async.impl.ioc_helpers.put_BANG_(state_8119__$1,(11),to,inst_8098);
} else {
if((state_val_8120 === (3))){
var inst_8117 = (state_8119[(2)]);
var state_8119__$1 = state_8119;
return cljs.core.async.impl.ioc_helpers.return_chan(state_8119__$1,inst_8117);
} else {
if((state_val_8120 === (12))){
var state_8119__$1 = state_8119;
var statearr_8127_8147 = state_8119__$1;
(statearr_8127_8147[(2)] = null);

(statearr_8127_8147[(1)] = (2));


return cljs.core.cst$kw$recur;
} else {
if((state_val_8120 === (2))){
var state_8119__$1 = state_8119;
return cljs.core.async.impl.ioc_helpers.take_BANG_(state_8119__$1,(4),from);
} else {
if((state_val_8120 === (11))){
var inst_8108 = (state_8119[(2)]);
var state_8119__$1 = state_8119;
if(cljs.core.truth_(inst_8108)){
var statearr_8128_8148 = state_8119__$1;
(statearr_8128_8148[(1)] = (12));

} else {
var statearr_8129_8149 = state_8119__$1;
(statearr_8129_8149[(1)] = (13));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_8120 === (9))){
var state_8119__$1 = state_8119;
var statearr_8130_8150 = state_8119__$1;
(statearr_8130_8150[(2)] = null);

(statearr_8130_8150[(1)] = (10));


return cljs.core.cst$kw$recur;
} else {
if((state_val_8120 === (5))){
var state_8119__$1 = state_8119;
if(cljs.core.truth_(close_QMARK_)){
var statearr_8131_8151 = state_8119__$1;
(statearr_8131_8151[(1)] = (8));

} else {
var statearr_8132_8152 = state_8119__$1;
(statearr_8132_8152[(1)] = (9));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_8120 === (14))){
var inst_8113 = (state_8119[(2)]);
var state_8119__$1 = state_8119;
var statearr_8133_8153 = state_8119__$1;
(statearr_8133_8153[(2)] = inst_8113);

(statearr_8133_8153[(1)] = (7));


return cljs.core.cst$kw$recur;
} else {
if((state_val_8120 === (10))){
var inst_8105 = (state_8119[(2)]);
var state_8119__$1 = state_8119;
var statearr_8134_8154 = state_8119__$1;
(statearr_8134_8154[(2)] = inst_8105);

(statearr_8134_8154[(1)] = (7));


return cljs.core.cst$kw$recur;
} else {
if((state_val_8120 === (8))){
var inst_8102 = cljs.core.async.close_BANG_(to);
var state_8119__$1 = state_8119;
var statearr_8135_8155 = state_8119__$1;
(statearr_8135_8155[(2)] = inst_8102);

(statearr_8135_8155[(1)] = (10));


return cljs.core.cst$kw$recur;
} else {
return null;
}
}
}
}
}
}
}
}
}
}
}
}
}
}
});})(c__7992__auto___8141))
;
return ((function (switch__7885__auto__,c__7992__auto___8141){
return (function() {
var cljs$core$async$state_machine__7886__auto__ = null;
var cljs$core$async$state_machine__7886__auto____0 = (function (){
var statearr_8136 = [null,null,null,null,null,null,null,null];
(statearr_8136[(0)] = cljs$core$async$state_machine__7886__auto__);

(statearr_8136[(1)] = (1));

return statearr_8136;
});
var cljs$core$async$state_machine__7886__auto____1 = (function (state_8119){
while(true){
var ret_value__7887__auto__ = (function (){try{while(true){
var result__7888__auto__ = switch__7885__auto__(state_8119);
if(cljs.core.keyword_identical_QMARK_(result__7888__auto__,cljs.core.cst$kw$recur)){
continue;
} else {
return result__7888__auto__;
}
break;
}
}catch (e8137){if((e8137 instanceof Object)){
var ex__7889__auto__ = e8137;
var statearr_8138_8156 = state_8119;
(statearr_8138_8156[(5)] = ex__7889__auto__);


cljs.core.async.impl.ioc_helpers.process_exception(state_8119);

return cljs.core.cst$kw$recur;
} else {
throw e8137;

}
}})();
if(cljs.core.keyword_identical_QMARK_(ret_value__7887__auto__,cljs.core.cst$kw$recur)){
var G__8157 = state_8119;
state_8119 = G__8157;
continue;
} else {
return ret_value__7887__auto__;
}
break;
}
});
cljs$core$async$state_machine__7886__auto__ = function(state_8119){
switch(arguments.length){
case 0:
return cljs$core$async$state_machine__7886__auto____0.call(this);
case 1:
return cljs$core$async$state_machine__7886__auto____1.call(this,state_8119);
}
throw(new Error('Invalid arity: ' + arguments.length));
};
cljs$core$async$state_machine__7886__auto__.cljs$core$IFn$_invoke$arity$0 = cljs$core$async$state_machine__7886__auto____0;
cljs$core$async$state_machine__7886__auto__.cljs$core$IFn$_invoke$arity$1 = cljs$core$async$state_machine__7886__auto____1;
return cljs$core$async$state_machine__7886__auto__;
})()
;})(switch__7885__auto__,c__7992__auto___8141))
})();
var state__7994__auto__ = (function (){var statearr_8139 = (f__7993__auto__.cljs$core$IFn$_invoke$arity$0 ? f__7993__auto__.cljs$core$IFn$_invoke$arity$0() : f__7993__auto__.call(null));
(statearr_8139[(6)] = c__7992__auto___8141);

return statearr_8139;
})();
return cljs.core.async.impl.ioc_helpers.run_state_machine_wrapped(state__7994__auto__);
});})(c__7992__auto___8141))
);


return to;
});

cljs.core.async.pipe.cljs$lang$maxFixedArity = 3;

cljs.core.async.pipeline_STAR_ = (function cljs$core$async$pipeline_STAR_(n,to,xf,from,close_QMARK_,ex_handler,type){

var jobs = cljs.core.async.chan.cljs$core$IFn$_invoke$arity$1(n);
var results = cljs.core.async.chan.cljs$core$IFn$_invoke$arity$1(n);
var process = ((function (jobs,results){
return (function (p__8158){
var vec__8159 = p__8158;
var v = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(vec__8159,(0),null);
var p = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(vec__8159,(1),null);
var job = vec__8159;
if((job == null)){
cljs.core.async.close_BANG_(results);

return null;
} else {
var res = cljs.core.async.chan.cljs$core$IFn$_invoke$arity$3((1),xf,ex_handler);
var c__7992__auto___8330 = cljs.core.async.chan.cljs$core$IFn$_invoke$arity$1((1));
cljs.core.async.impl.dispatch.run(((function (c__7992__auto___8330,res,vec__8159,v,p,job,jobs,results){
return (function (){
var f__7993__auto__ = (function (){var switch__7885__auto__ = ((function (c__7992__auto___8330,res,vec__8159,v,p,job,jobs,results){
return (function (state_8166){
var state_val_8167 = (state_8166[(1)]);
if((state_val_8167 === (1))){
var state_8166__$1 = state_8166;
return cljs.core.async.impl.ioc_helpers.put_BANG_(state_8166__$1,(2),res,v);
} else {
if((state_val_8167 === (2))){
var inst_8163 = (state_8166[(2)]);
var inst_8164 = cljs.core.async.close_BANG_(res);
var state_8166__$1 = (function (){var statearr_8168 = state_8166;
(statearr_8168[(7)] = inst_8163);

return statearr_8168;
})();
return cljs.core.async.impl.ioc_helpers.return_chan(state_8166__$1,inst_8164);
} else {
return null;
}
}
});})(c__7992__auto___8330,res,vec__8159,v,p,job,jobs,results))
;
return ((function (switch__7885__auto__,c__7992__auto___8330,res,vec__8159,v,p,job,jobs,results){
return (function() {
var cljs$core$async$pipeline_STAR__$_state_machine__7886__auto__ = null;
var cljs$core$async$pipeline_STAR__$_state_machine__7886__auto____0 = (function (){
var statearr_8169 = [null,null,null,null,null,null,null,null];
(statearr_8169[(0)] = cljs$core$async$pipeline_STAR__$_state_machine__7886__auto__);

(statearr_8169[(1)] = (1));

return statearr_8169;
});
var cljs$core$async$pipeline_STAR__$_state_machine__7886__auto____1 = (function (state_8166){
while(true){
var ret_value__7887__auto__ = (function (){try{while(true){
var result__7888__auto__ = switch__7885__auto__(state_8166);
if(cljs.core.keyword_identical_QMARK_(result__7888__auto__,cljs.core.cst$kw$recur)){
continue;
} else {
return result__7888__auto__;
}
break;
}
}catch (e8170){if((e8170 instanceof Object)){
var ex__7889__auto__ = e8170;
var statearr_8171_8331 = state_8166;
(statearr_8171_8331[(5)] = ex__7889__auto__);


cljs.core.async.impl.ioc_helpers.process_exception(state_8166);

return cljs.core.cst$kw$recur;
} else {
throw e8170;

}
}})();
if(cljs.core.keyword_identical_QMARK_(ret_value__7887__auto__,cljs.core.cst$kw$recur)){
var G__8332 = state_8166;
state_8166 = G__8332;
continue;
} else {
return ret_value__7887__auto__;
}
break;
}
});
cljs$core$async$pipeline_STAR__$_state_machine__7886__auto__ = function(state_8166){
switch(arguments.length){
case 0:
return cljs$core$async$pipeline_STAR__$_state_machine__7886__auto____0.call(this);
case 1:
return cljs$core$async$pipeline_STAR__$_state_machine__7886__auto____1.call(this,state_8166);
}
throw(new Error('Invalid arity: ' + arguments.length));
};
cljs$core$async$pipeline_STAR__$_state_machine__7886__auto__.cljs$core$IFn$_invoke$arity$0 = cljs$core$async$pipeline_STAR__$_state_machine__7886__auto____0;
cljs$core$async$pipeline_STAR__$_state_machine__7886__auto__.cljs$core$IFn$_invoke$arity$1 = cljs$core$async$pipeline_STAR__$_state_machine__7886__auto____1;
return cljs$core$async$pipeline_STAR__$_state_machine__7886__auto__;
})()
;})(switch__7885__auto__,c__7992__auto___8330,res,vec__8159,v,p,job,jobs,results))
})();
var state__7994__auto__ = (function (){var statearr_8172 = (f__7993__auto__.cljs$core$IFn$_invoke$arity$0 ? f__7993__auto__.cljs$core$IFn$_invoke$arity$0() : f__7993__auto__.call(null));
(statearr_8172[(6)] = c__7992__auto___8330);

return statearr_8172;
})();
return cljs.core.async.impl.ioc_helpers.run_state_machine_wrapped(state__7994__auto__);
});})(c__7992__auto___8330,res,vec__8159,v,p,job,jobs,results))
);


cljs.core.async.put_BANG_.cljs$core$IFn$_invoke$arity$2(p,res);

return true;
}
});})(jobs,results))
;
var async = ((function (jobs,results,process){
return (function (p__8173){
var vec__8174 = p__8173;
var v = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(vec__8174,(0),null);
var p = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(vec__8174,(1),null);
var job = vec__8174;
if((job == null)){
cljs.core.async.close_BANG_(results);

return null;
} else {
var res = cljs.core.async.chan.cljs$core$IFn$_invoke$arity$1((1));
(xf.cljs$core$IFn$_invoke$arity$2 ? xf.cljs$core$IFn$_invoke$arity$2(v,res) : xf.call(null,v,res));

cljs.core.async.put_BANG_.cljs$core$IFn$_invoke$arity$2(p,res);

return true;
}
});})(jobs,results,process))
;
var n__4518__auto___8333 = n;
var __8334 = (0);
while(true){
if((__8334 < n__4518__auto___8333)){
var G__8177_8335 = type;
var G__8177_8336__$1 = (((G__8177_8335 instanceof cljs.core.Keyword))?G__8177_8335.fqn:null);
switch (G__8177_8336__$1) {
case "compute":
var c__7992__auto___8338 = cljs.core.async.chan.cljs$core$IFn$_invoke$arity$1((1));
cljs.core.async.impl.dispatch.run(((function (__8334,c__7992__auto___8338,G__8177_8335,G__8177_8336__$1,n__4518__auto___8333,jobs,results,process,async){
return (function (){
var f__7993__auto__ = (function (){var switch__7885__auto__ = ((function (__8334,c__7992__auto___8338,G__8177_8335,G__8177_8336__$1,n__4518__auto___8333,jobs,results,process,async){
return (function (state_8190){
var state_val_8191 = (state_8190[(1)]);
if((state_val_8191 === (1))){
var state_8190__$1 = state_8190;
var statearr_8192_8339 = state_8190__$1;
(statearr_8192_8339[(2)] = null);

(statearr_8192_8339[(1)] = (2));


return cljs.core.cst$kw$recur;
} else {
if((state_val_8191 === (2))){
var state_8190__$1 = state_8190;
return cljs.core.async.impl.ioc_helpers.take_BANG_(state_8190__$1,(4),jobs);
} else {
if((state_val_8191 === (3))){
var inst_8188 = (state_8190[(2)]);
var state_8190__$1 = state_8190;
return cljs.core.async.impl.ioc_helpers.return_chan(state_8190__$1,inst_8188);
} else {
if((state_val_8191 === (4))){
var inst_8180 = (state_8190[(2)]);
var inst_8181 = process(inst_8180);
var state_8190__$1 = state_8190;
if(cljs.core.truth_(inst_8181)){
var statearr_8193_8340 = state_8190__$1;
(statearr_8193_8340[(1)] = (5));

} else {
var statearr_8194_8341 = state_8190__$1;
(statearr_8194_8341[(1)] = (6));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_8191 === (5))){
var state_8190__$1 = state_8190;
var statearr_8195_8342 = state_8190__$1;
(statearr_8195_8342[(2)] = null);

(statearr_8195_8342[(1)] = (2));


return cljs.core.cst$kw$recur;
} else {
if((state_val_8191 === (6))){
var state_8190__$1 = state_8190;
var statearr_8196_8343 = state_8190__$1;
(statearr_8196_8343[(2)] = null);

(statearr_8196_8343[(1)] = (7));


return cljs.core.cst$kw$recur;
} else {
if((state_val_8191 === (7))){
var inst_8186 = (state_8190[(2)]);
var state_8190__$1 = state_8190;
var statearr_8197_8344 = state_8190__$1;
(statearr_8197_8344[(2)] = inst_8186);

(statearr_8197_8344[(1)] = (3));


return cljs.core.cst$kw$recur;
} else {
return null;
}
}
}
}
}
}
}
});})(__8334,c__7992__auto___8338,G__8177_8335,G__8177_8336__$1,n__4518__auto___8333,jobs,results,process,async))
;
return ((function (__8334,switch__7885__auto__,c__7992__auto___8338,G__8177_8335,G__8177_8336__$1,n__4518__auto___8333,jobs,results,process,async){
return (function() {
var cljs$core$async$pipeline_STAR__$_state_machine__7886__auto__ = null;
var cljs$core$async$pipeline_STAR__$_state_machine__7886__auto____0 = (function (){
var statearr_8198 = [null,null,null,null,null,null,null];
(statearr_8198[(0)] = cljs$core$async$pipeline_STAR__$_state_machine__7886__auto__);

(statearr_8198[(1)] = (1));

return statearr_8198;
});
var cljs$core$async$pipeline_STAR__$_state_machine__7886__auto____1 = (function (state_8190){
while(true){
var ret_value__7887__auto__ = (function (){try{while(true){
var result__7888__auto__ = switch__7885__auto__(state_8190);
if(cljs.core.keyword_identical_QMARK_(result__7888__auto__,cljs.core.cst$kw$recur)){
continue;
} else {
return result__7888__auto__;
}
break;
}
}catch (e8199){if((e8199 instanceof Object)){
var ex__7889__auto__ = e8199;
var statearr_8200_8345 = state_8190;
(statearr_8200_8345[(5)] = ex__7889__auto__);


cljs.core.async.impl.ioc_helpers.process_exception(state_8190);

return cljs.core.cst$kw$recur;
} else {
throw e8199;

}
}})();
if(cljs.core.keyword_identical_QMARK_(ret_value__7887__auto__,cljs.core.cst$kw$recur)){
var G__8346 = state_8190;
state_8190 = G__8346;
continue;
} else {
return ret_value__7887__auto__;
}
break;
}
});
cljs$core$async$pipeline_STAR__$_state_machine__7886__auto__ = function(state_8190){
switch(arguments.length){
case 0:
return cljs$core$async$pipeline_STAR__$_state_machine__7886__auto____0.call(this);
case 1:
return cljs$core$async$pipeline_STAR__$_state_machine__7886__auto____1.call(this,state_8190);
}
throw(new Error('Invalid arity: ' + arguments.length));
};
cljs$core$async$pipeline_STAR__$_state_machine__7886__auto__.cljs$core$IFn$_invoke$arity$0 = cljs$core$async$pipeline_STAR__$_state_machine__7886__auto____0;
cljs$core$async$pipeline_STAR__$_state_machine__7886__auto__.cljs$core$IFn$_invoke$arity$1 = cljs$core$async$pipeline_STAR__$_state_machine__7886__auto____1;
return cljs$core$async$pipeline_STAR__$_state_machine__7886__auto__;
})()
;})(__8334,switch__7885__auto__,c__7992__auto___8338,G__8177_8335,G__8177_8336__$1,n__4518__auto___8333,jobs,results,process,async))
})();
var state__7994__auto__ = (function (){var statearr_8201 = (f__7993__auto__.cljs$core$IFn$_invoke$arity$0 ? f__7993__auto__.cljs$core$IFn$_invoke$arity$0() : f__7993__auto__.call(null));
(statearr_8201[(6)] = c__7992__auto___8338);

return statearr_8201;
})();
return cljs.core.async.impl.ioc_helpers.run_state_machine_wrapped(state__7994__auto__);
});})(__8334,c__7992__auto___8338,G__8177_8335,G__8177_8336__$1,n__4518__auto___8333,jobs,results,process,async))
);


break;
case "async":
var c__7992__auto___8347 = cljs.core.async.chan.cljs$core$IFn$_invoke$arity$1((1));
cljs.core.async.impl.dispatch.run(((function (__8334,c__7992__auto___8347,G__8177_8335,G__8177_8336__$1,n__4518__auto___8333,jobs,results,process,async){
return (function (){
var f__7993__auto__ = (function (){var switch__7885__auto__ = ((function (__8334,c__7992__auto___8347,G__8177_8335,G__8177_8336__$1,n__4518__auto___8333,jobs,results,process,async){
return (function (state_8214){
var state_val_8215 = (state_8214[(1)]);
if((state_val_8215 === (1))){
var state_8214__$1 = state_8214;
var statearr_8216_8348 = state_8214__$1;
(statearr_8216_8348[(2)] = null);

(statearr_8216_8348[(1)] = (2));


return cljs.core.cst$kw$recur;
} else {
if((state_val_8215 === (2))){
var state_8214__$1 = state_8214;
return cljs.core.async.impl.ioc_helpers.take_BANG_(state_8214__$1,(4),jobs);
} else {
if((state_val_8215 === (3))){
var inst_8212 = (state_8214[(2)]);
var state_8214__$1 = state_8214;
return cljs.core.async.impl.ioc_helpers.return_chan(state_8214__$1,inst_8212);
} else {
if((state_val_8215 === (4))){
var inst_8204 = (state_8214[(2)]);
var inst_8205 = async(inst_8204);
var state_8214__$1 = state_8214;
if(cljs.core.truth_(inst_8205)){
var statearr_8217_8349 = state_8214__$1;
(statearr_8217_8349[(1)] = (5));

} else {
var statearr_8218_8350 = state_8214__$1;
(statearr_8218_8350[(1)] = (6));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_8215 === (5))){
var state_8214__$1 = state_8214;
var statearr_8219_8351 = state_8214__$1;
(statearr_8219_8351[(2)] = null);

(statearr_8219_8351[(1)] = (2));


return cljs.core.cst$kw$recur;
} else {
if((state_val_8215 === (6))){
var state_8214__$1 = state_8214;
var statearr_8220_8352 = state_8214__$1;
(statearr_8220_8352[(2)] = null);

(statearr_8220_8352[(1)] = (7));


return cljs.core.cst$kw$recur;
} else {
if((state_val_8215 === (7))){
var inst_8210 = (state_8214[(2)]);
var state_8214__$1 = state_8214;
var statearr_8221_8353 = state_8214__$1;
(statearr_8221_8353[(2)] = inst_8210);

(statearr_8221_8353[(1)] = (3));


return cljs.core.cst$kw$recur;
} else {
return null;
}
}
}
}
}
}
}
});})(__8334,c__7992__auto___8347,G__8177_8335,G__8177_8336__$1,n__4518__auto___8333,jobs,results,process,async))
;
return ((function (__8334,switch__7885__auto__,c__7992__auto___8347,G__8177_8335,G__8177_8336__$1,n__4518__auto___8333,jobs,results,process,async){
return (function() {
var cljs$core$async$pipeline_STAR__$_state_machine__7886__auto__ = null;
var cljs$core$async$pipeline_STAR__$_state_machine__7886__auto____0 = (function (){
var statearr_8222 = [null,null,null,null,null,null,null];
(statearr_8222[(0)] = cljs$core$async$pipeline_STAR__$_state_machine__7886__auto__);

(statearr_8222[(1)] = (1));

return statearr_8222;
});
var cljs$core$async$pipeline_STAR__$_state_machine__7886__auto____1 = (function (state_8214){
while(true){
var ret_value__7887__auto__ = (function (){try{while(true){
var result__7888__auto__ = switch__7885__auto__(state_8214);
if(cljs.core.keyword_identical_QMARK_(result__7888__auto__,cljs.core.cst$kw$recur)){
continue;
} else {
return result__7888__auto__;
}
break;
}
}catch (e8223){if((e8223 instanceof Object)){
var ex__7889__auto__ = e8223;
var statearr_8224_8354 = state_8214;
(statearr_8224_8354[(5)] = ex__7889__auto__);


cljs.core.async.impl.ioc_helpers.process_exception(state_8214);

return cljs.core.cst$kw$recur;
} else {
throw e8223;

}
}})();
if(cljs.core.keyword_identical_QMARK_(ret_value__7887__auto__,cljs.core.cst$kw$recur)){
var G__8355 = state_8214;
state_8214 = G__8355;
continue;
} else {
return ret_value__7887__auto__;
}
break;
}
});
cljs$core$async$pipeline_STAR__$_state_machine__7886__auto__ = function(state_8214){
switch(arguments.length){
case 0:
return cljs$core$async$pipeline_STAR__$_state_machine__7886__auto____0.call(this);
case 1:
return cljs$core$async$pipeline_STAR__$_state_machine__7886__auto____1.call(this,state_8214);
}
throw(new Error('Invalid arity: ' + arguments.length));
};
cljs$core$async$pipeline_STAR__$_state_machine__7886__auto__.cljs$core$IFn$_invoke$arity$0 = cljs$core$async$pipeline_STAR__$_state_machine__7886__auto____0;
cljs$core$async$pipeline_STAR__$_state_machine__7886__auto__.cljs$core$IFn$_invoke$arity$1 = cljs$core$async$pipeline_STAR__$_state_machine__7886__auto____1;
return cljs$core$async$pipeline_STAR__$_state_machine__7886__auto__;
})()
;})(__8334,switch__7885__auto__,c__7992__auto___8347,G__8177_8335,G__8177_8336__$1,n__4518__auto___8333,jobs,results,process,async))
})();
var state__7994__auto__ = (function (){var statearr_8225 = (f__7993__auto__.cljs$core$IFn$_invoke$arity$0 ? f__7993__auto__.cljs$core$IFn$_invoke$arity$0() : f__7993__auto__.call(null));
(statearr_8225[(6)] = c__7992__auto___8347);

return statearr_8225;
})();
return cljs.core.async.impl.ioc_helpers.run_state_machine_wrapped(state__7994__auto__);
});})(__8334,c__7992__auto___8347,G__8177_8335,G__8177_8336__$1,n__4518__auto___8333,jobs,results,process,async))
);


break;
default:
throw (new Error(["No matching clause: ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(G__8177_8336__$1)].join('')));

}

var G__8356 = (__8334 + (1));
__8334 = G__8356;
continue;
} else {
}
break;
}

var c__7992__auto___8357 = cljs.core.async.chan.cljs$core$IFn$_invoke$arity$1((1));
cljs.core.async.impl.dispatch.run(((function (c__7992__auto___8357,jobs,results,process,async){
return (function (){
var f__7993__auto__ = (function (){var switch__7885__auto__ = ((function (c__7992__auto___8357,jobs,results,process,async){
return (function (state_8247){
var state_val_8248 = (state_8247[(1)]);
if((state_val_8248 === (1))){
var state_8247__$1 = state_8247;
var statearr_8249_8358 = state_8247__$1;
(statearr_8249_8358[(2)] = null);

(statearr_8249_8358[(1)] = (2));


return cljs.core.cst$kw$recur;
} else {
if((state_val_8248 === (2))){
var state_8247__$1 = state_8247;
return cljs.core.async.impl.ioc_helpers.take_BANG_(state_8247__$1,(4),from);
} else {
if((state_val_8248 === (3))){
var inst_8245 = (state_8247[(2)]);
var state_8247__$1 = state_8247;
return cljs.core.async.impl.ioc_helpers.return_chan(state_8247__$1,inst_8245);
} else {
if((state_val_8248 === (4))){
var inst_8228 = (state_8247[(7)]);
var inst_8228__$1 = (state_8247[(2)]);
var inst_8229 = (inst_8228__$1 == null);
var state_8247__$1 = (function (){var statearr_8250 = state_8247;
(statearr_8250[(7)] = inst_8228__$1);

return statearr_8250;
})();
if(cljs.core.truth_(inst_8229)){
var statearr_8251_8359 = state_8247__$1;
(statearr_8251_8359[(1)] = (5));

} else {
var statearr_8252_8360 = state_8247__$1;
(statearr_8252_8360[(1)] = (6));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_8248 === (5))){
var inst_8231 = cljs.core.async.close_BANG_(jobs);
var state_8247__$1 = state_8247;
var statearr_8253_8361 = state_8247__$1;
(statearr_8253_8361[(2)] = inst_8231);

(statearr_8253_8361[(1)] = (7));


return cljs.core.cst$kw$recur;
} else {
if((state_val_8248 === (6))){
var inst_8233 = (state_8247[(8)]);
var inst_8228 = (state_8247[(7)]);
var inst_8233__$1 = cljs.core.async.chan.cljs$core$IFn$_invoke$arity$1((1));
var inst_8234 = cljs.core.PersistentVector.EMPTY_NODE;
var inst_8235 = [inst_8228,inst_8233__$1];
var inst_8236 = (new cljs.core.PersistentVector(null,2,(5),inst_8234,inst_8235,null));
var state_8247__$1 = (function (){var statearr_8254 = state_8247;
(statearr_8254[(8)] = inst_8233__$1);

return statearr_8254;
})();
return cljs.core.async.impl.ioc_helpers.put_BANG_(state_8247__$1,(8),jobs,inst_8236);
} else {
if((state_val_8248 === (7))){
var inst_8243 = (state_8247[(2)]);
var state_8247__$1 = state_8247;
var statearr_8255_8362 = state_8247__$1;
(statearr_8255_8362[(2)] = inst_8243);

(statearr_8255_8362[(1)] = (3));


return cljs.core.cst$kw$recur;
} else {
if((state_val_8248 === (8))){
var inst_8233 = (state_8247[(8)]);
var inst_8238 = (state_8247[(2)]);
var state_8247__$1 = (function (){var statearr_8256 = state_8247;
(statearr_8256[(9)] = inst_8238);

return statearr_8256;
})();
return cljs.core.async.impl.ioc_helpers.put_BANG_(state_8247__$1,(9),results,inst_8233);
} else {
if((state_val_8248 === (9))){
var inst_8240 = (state_8247[(2)]);
var state_8247__$1 = (function (){var statearr_8257 = state_8247;
(statearr_8257[(10)] = inst_8240);

return statearr_8257;
})();
var statearr_8258_8363 = state_8247__$1;
(statearr_8258_8363[(2)] = null);

(statearr_8258_8363[(1)] = (2));


return cljs.core.cst$kw$recur;
} else {
return null;
}
}
}
}
}
}
}
}
}
});})(c__7992__auto___8357,jobs,results,process,async))
;
return ((function (switch__7885__auto__,c__7992__auto___8357,jobs,results,process,async){
return (function() {
var cljs$core$async$pipeline_STAR__$_state_machine__7886__auto__ = null;
var cljs$core$async$pipeline_STAR__$_state_machine__7886__auto____0 = (function (){
var statearr_8259 = [null,null,null,null,null,null,null,null,null,null,null];
(statearr_8259[(0)] = cljs$core$async$pipeline_STAR__$_state_machine__7886__auto__);

(statearr_8259[(1)] = (1));

return statearr_8259;
});
var cljs$core$async$pipeline_STAR__$_state_machine__7886__auto____1 = (function (state_8247){
while(true){
var ret_value__7887__auto__ = (function (){try{while(true){
var result__7888__auto__ = switch__7885__auto__(state_8247);
if(cljs.core.keyword_identical_QMARK_(result__7888__auto__,cljs.core.cst$kw$recur)){
continue;
} else {
return result__7888__auto__;
}
break;
}
}catch (e8260){if((e8260 instanceof Object)){
var ex__7889__auto__ = e8260;
var statearr_8261_8364 = state_8247;
(statearr_8261_8364[(5)] = ex__7889__auto__);


cljs.core.async.impl.ioc_helpers.process_exception(state_8247);

return cljs.core.cst$kw$recur;
} else {
throw e8260;

}
}})();
if(cljs.core.keyword_identical_QMARK_(ret_value__7887__auto__,cljs.core.cst$kw$recur)){
var G__8365 = state_8247;
state_8247 = G__8365;
continue;
} else {
return ret_value__7887__auto__;
}
break;
}
});
cljs$core$async$pipeline_STAR__$_state_machine__7886__auto__ = function(state_8247){
switch(arguments.length){
case 0:
return cljs$core$async$pipeline_STAR__$_state_machine__7886__auto____0.call(this);
case 1:
return cljs$core$async$pipeline_STAR__$_state_machine__7886__auto____1.call(this,state_8247);
}
throw(new Error('Invalid arity: ' + arguments.length));
};
cljs$core$async$pipeline_STAR__$_state_machine__7886__auto__.cljs$core$IFn$_invoke$arity$0 = cljs$core$async$pipeline_STAR__$_state_machine__7886__auto____0;
cljs$core$async$pipeline_STAR__$_state_machine__7886__auto__.cljs$core$IFn$_invoke$arity$1 = cljs$core$async$pipeline_STAR__$_state_machine__7886__auto____1;
return cljs$core$async$pipeline_STAR__$_state_machine__7886__auto__;
})()
;})(switch__7885__auto__,c__7992__auto___8357,jobs,results,process,async))
})();
var state__7994__auto__ = (function (){var statearr_8262 = (f__7993__auto__.cljs$core$IFn$_invoke$arity$0 ? f__7993__auto__.cljs$core$IFn$_invoke$arity$0() : f__7993__auto__.call(null));
(statearr_8262[(6)] = c__7992__auto___8357);

return statearr_8262;
})();
return cljs.core.async.impl.ioc_helpers.run_state_machine_wrapped(state__7994__auto__);
});})(c__7992__auto___8357,jobs,results,process,async))
);


var c__7992__auto__ = cljs.core.async.chan.cljs$core$IFn$_invoke$arity$1((1));
cljs.core.async.impl.dispatch.run(((function (c__7992__auto__,jobs,results,process,async){
return (function (){
var f__7993__auto__ = (function (){var switch__7885__auto__ = ((function (c__7992__auto__,jobs,results,process,async){
return (function (state_8300){
var state_val_8301 = (state_8300[(1)]);
if((state_val_8301 === (7))){
var inst_8296 = (state_8300[(2)]);
var state_8300__$1 = state_8300;
var statearr_8302_8366 = state_8300__$1;
(statearr_8302_8366[(2)] = inst_8296);

(statearr_8302_8366[(1)] = (3));


return cljs.core.cst$kw$recur;
} else {
if((state_val_8301 === (20))){
var state_8300__$1 = state_8300;
var statearr_8303_8367 = state_8300__$1;
(statearr_8303_8367[(2)] = null);

(statearr_8303_8367[(1)] = (21));


return cljs.core.cst$kw$recur;
} else {
if((state_val_8301 === (1))){
var state_8300__$1 = state_8300;
var statearr_8304_8368 = state_8300__$1;
(statearr_8304_8368[(2)] = null);

(statearr_8304_8368[(1)] = (2));


return cljs.core.cst$kw$recur;
} else {
if((state_val_8301 === (4))){
var inst_8265 = (state_8300[(7)]);
var inst_8265__$1 = (state_8300[(2)]);
var inst_8266 = (inst_8265__$1 == null);
var state_8300__$1 = (function (){var statearr_8305 = state_8300;
(statearr_8305[(7)] = inst_8265__$1);

return statearr_8305;
})();
if(cljs.core.truth_(inst_8266)){
var statearr_8306_8369 = state_8300__$1;
(statearr_8306_8369[(1)] = (5));

} else {
var statearr_8307_8370 = state_8300__$1;
(statearr_8307_8370[(1)] = (6));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_8301 === (15))){
var inst_8278 = (state_8300[(8)]);
var state_8300__$1 = state_8300;
return cljs.core.async.impl.ioc_helpers.put_BANG_(state_8300__$1,(18),to,inst_8278);
} else {
if((state_val_8301 === (21))){
var inst_8291 = (state_8300[(2)]);
var state_8300__$1 = state_8300;
var statearr_8308_8371 = state_8300__$1;
(statearr_8308_8371[(2)] = inst_8291);

(statearr_8308_8371[(1)] = (13));


return cljs.core.cst$kw$recur;
} else {
if((state_val_8301 === (13))){
var inst_8293 = (state_8300[(2)]);
var state_8300__$1 = (function (){var statearr_8309 = state_8300;
(statearr_8309[(9)] = inst_8293);

return statearr_8309;
})();
var statearr_8310_8372 = state_8300__$1;
(statearr_8310_8372[(2)] = null);

(statearr_8310_8372[(1)] = (2));


return cljs.core.cst$kw$recur;
} else {
if((state_val_8301 === (6))){
var inst_8265 = (state_8300[(7)]);
var state_8300__$1 = state_8300;
return cljs.core.async.impl.ioc_helpers.take_BANG_(state_8300__$1,(11),inst_8265);
} else {
if((state_val_8301 === (17))){
var inst_8286 = (state_8300[(2)]);
var state_8300__$1 = state_8300;
if(cljs.core.truth_(inst_8286)){
var statearr_8311_8373 = state_8300__$1;
(statearr_8311_8373[(1)] = (19));

} else {
var statearr_8312_8374 = state_8300__$1;
(statearr_8312_8374[(1)] = (20));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_8301 === (3))){
var inst_8298 = (state_8300[(2)]);
var state_8300__$1 = state_8300;
return cljs.core.async.impl.ioc_helpers.return_chan(state_8300__$1,inst_8298);
} else {
if((state_val_8301 === (12))){
var inst_8275 = (state_8300[(10)]);
var state_8300__$1 = state_8300;
return cljs.core.async.impl.ioc_helpers.take_BANG_(state_8300__$1,(14),inst_8275);
} else {
if((state_val_8301 === (2))){
var state_8300__$1 = state_8300;
return cljs.core.async.impl.ioc_helpers.take_BANG_(state_8300__$1,(4),results);
} else {
if((state_val_8301 === (19))){
var state_8300__$1 = state_8300;
var statearr_8313_8375 = state_8300__$1;
(statearr_8313_8375[(2)] = null);

(statearr_8313_8375[(1)] = (12));


return cljs.core.cst$kw$recur;
} else {
if((state_val_8301 === (11))){
var inst_8275 = (state_8300[(2)]);
var state_8300__$1 = (function (){var statearr_8314 = state_8300;
(statearr_8314[(10)] = inst_8275);

return statearr_8314;
})();
var statearr_8315_8376 = state_8300__$1;
(statearr_8315_8376[(2)] = null);

(statearr_8315_8376[(1)] = (12));


return cljs.core.cst$kw$recur;
} else {
if((state_val_8301 === (9))){
var state_8300__$1 = state_8300;
var statearr_8316_8377 = state_8300__$1;
(statearr_8316_8377[(2)] = null);

(statearr_8316_8377[(1)] = (10));


return cljs.core.cst$kw$recur;
} else {
if((state_val_8301 === (5))){
var state_8300__$1 = state_8300;
if(cljs.core.truth_(close_QMARK_)){
var statearr_8317_8378 = state_8300__$1;
(statearr_8317_8378[(1)] = (8));

} else {
var statearr_8318_8379 = state_8300__$1;
(statearr_8318_8379[(1)] = (9));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_8301 === (14))){
var inst_8278 = (state_8300[(8)]);
var inst_8280 = (state_8300[(11)]);
var inst_8278__$1 = (state_8300[(2)]);
var inst_8279 = (inst_8278__$1 == null);
var inst_8280__$1 = cljs.core.not(inst_8279);
var state_8300__$1 = (function (){var statearr_8319 = state_8300;
(statearr_8319[(8)] = inst_8278__$1);

(statearr_8319[(11)] = inst_8280__$1);

return statearr_8319;
})();
if(inst_8280__$1){
var statearr_8320_8380 = state_8300__$1;
(statearr_8320_8380[(1)] = (15));

} else {
var statearr_8321_8381 = state_8300__$1;
(statearr_8321_8381[(1)] = (16));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_8301 === (16))){
var inst_8280 = (state_8300[(11)]);
var state_8300__$1 = state_8300;
var statearr_8322_8382 = state_8300__$1;
(statearr_8322_8382[(2)] = inst_8280);

(statearr_8322_8382[(1)] = (17));


return cljs.core.cst$kw$recur;
} else {
if((state_val_8301 === (10))){
var inst_8272 = (state_8300[(2)]);
var state_8300__$1 = state_8300;
var statearr_8323_8383 = state_8300__$1;
(statearr_8323_8383[(2)] = inst_8272);

(statearr_8323_8383[(1)] = (7));


return cljs.core.cst$kw$recur;
} else {
if((state_val_8301 === (18))){
var inst_8283 = (state_8300[(2)]);
var state_8300__$1 = state_8300;
var statearr_8324_8384 = state_8300__$1;
(statearr_8324_8384[(2)] = inst_8283);

(statearr_8324_8384[(1)] = (17));


return cljs.core.cst$kw$recur;
} else {
if((state_val_8301 === (8))){
var inst_8269 = cljs.core.async.close_BANG_(to);
var state_8300__$1 = state_8300;
var statearr_8325_8385 = state_8300__$1;
(statearr_8325_8385[(2)] = inst_8269);

(statearr_8325_8385[(1)] = (10));


return cljs.core.cst$kw$recur;
} else {
return null;
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
});})(c__7992__auto__,jobs,results,process,async))
;
return ((function (switch__7885__auto__,c__7992__auto__,jobs,results,process,async){
return (function() {
var cljs$core$async$pipeline_STAR__$_state_machine__7886__auto__ = null;
var cljs$core$async$pipeline_STAR__$_state_machine__7886__auto____0 = (function (){
var statearr_8326 = [null,null,null,null,null,null,null,null,null,null,null,null];
(statearr_8326[(0)] = cljs$core$async$pipeline_STAR__$_state_machine__7886__auto__);

(statearr_8326[(1)] = (1));

return statearr_8326;
});
var cljs$core$async$pipeline_STAR__$_state_machine__7886__auto____1 = (function (state_8300){
while(true){
var ret_value__7887__auto__ = (function (){try{while(true){
var result__7888__auto__ = switch__7885__auto__(state_8300);
if(cljs.core.keyword_identical_QMARK_(result__7888__auto__,cljs.core.cst$kw$recur)){
continue;
} else {
return result__7888__auto__;
}
break;
}
}catch (e8327){if((e8327 instanceof Object)){
var ex__7889__auto__ = e8327;
var statearr_8328_8386 = state_8300;
(statearr_8328_8386[(5)] = ex__7889__auto__);


cljs.core.async.impl.ioc_helpers.process_exception(state_8300);

return cljs.core.cst$kw$recur;
} else {
throw e8327;

}
}})();
if(cljs.core.keyword_identical_QMARK_(ret_value__7887__auto__,cljs.core.cst$kw$recur)){
var G__8387 = state_8300;
state_8300 = G__8387;
continue;
} else {
return ret_value__7887__auto__;
}
break;
}
});
cljs$core$async$pipeline_STAR__$_state_machine__7886__auto__ = function(state_8300){
switch(arguments.length){
case 0:
return cljs$core$async$pipeline_STAR__$_state_machine__7886__auto____0.call(this);
case 1:
return cljs$core$async$pipeline_STAR__$_state_machine__7886__auto____1.call(this,state_8300);
}
throw(new Error('Invalid arity: ' + arguments.length));
};
cljs$core$async$pipeline_STAR__$_state_machine__7886__auto__.cljs$core$IFn$_invoke$arity$0 = cljs$core$async$pipeline_STAR__$_state_machine__7886__auto____0;
cljs$core$async$pipeline_STAR__$_state_machine__7886__auto__.cljs$core$IFn$_invoke$arity$1 = cljs$core$async$pipeline_STAR__$_state_machine__7886__auto____1;
return cljs$core$async$pipeline_STAR__$_state_machine__7886__auto__;
})()
;})(switch__7885__auto__,c__7992__auto__,jobs,results,process,async))
})();
var state__7994__auto__ = (function (){var statearr_8329 = (f__7993__auto__.cljs$core$IFn$_invoke$arity$0 ? f__7993__auto__.cljs$core$IFn$_invoke$arity$0() : f__7993__auto__.call(null));
(statearr_8329[(6)] = c__7992__auto__);

return statearr_8329;
})();
return cljs.core.async.impl.ioc_helpers.run_state_machine_wrapped(state__7994__auto__);
});})(c__7992__auto__,jobs,results,process,async))
);

return c__7992__auto__;
});
/**
 * Takes elements from the from channel and supplies them to the to
 *   channel, subject to the async function af, with parallelism n. af
 *   must be a function of two arguments, the first an input value and
 *   the second a channel on which to place the result(s). af must close!
 *   the channel before returning.  The presumption is that af will
 *   return immediately, having launched some asynchronous operation
 *   whose completion/callback will manipulate the result channel. Outputs
 *   will be returned in order relative to  the inputs. By default, the to
 *   channel will be closed when the from channel closes, but can be
 *   determined by the close?  parameter. Will stop consuming the from
 *   channel if the to channel closes.
 */
cljs.core.async.pipeline_async = (function cljs$core$async$pipeline_async(var_args){
var G__8389 = arguments.length;
switch (G__8389) {
case 4:
return cljs.core.async.pipeline_async.cljs$core$IFn$_invoke$arity$4((arguments[(0)]),(arguments[(1)]),(arguments[(2)]),(arguments[(3)]));

break;
case 5:
return cljs.core.async.pipeline_async.cljs$core$IFn$_invoke$arity$5((arguments[(0)]),(arguments[(1)]),(arguments[(2)]),(arguments[(3)]),(arguments[(4)]));

break;
default:
throw (new Error(["Invalid arity: ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(arguments.length)].join('')));

}
});

cljs.core.async.pipeline_async.cljs$core$IFn$_invoke$arity$4 = (function (n,to,af,from){
return cljs.core.async.pipeline_async.cljs$core$IFn$_invoke$arity$5(n,to,af,from,true);
});

cljs.core.async.pipeline_async.cljs$core$IFn$_invoke$arity$5 = (function (n,to,af,from,close_QMARK_){
return cljs.core.async.pipeline_STAR_(n,to,af,from,close_QMARK_,null,cljs.core.cst$kw$async);
});

cljs.core.async.pipeline_async.cljs$lang$maxFixedArity = 5;

/**
 * Takes elements from the from channel and supplies them to the to
 *   channel, subject to the transducer xf, with parallelism n. Because
 *   it is parallel, the transducer will be applied independently to each
 *   element, not across elements, and may produce zero or more outputs
 *   per input.  Outputs will be returned in order relative to the
 *   inputs. By default, the to channel will be closed when the from
 *   channel closes, but can be determined by the close?  parameter. Will
 *   stop consuming the from channel if the to channel closes.
 * 
 *   Note this is supplied for API compatibility with the Clojure version.
 *   Values of N > 1 will not result in actual concurrency in a
 *   single-threaded runtime.
 */
cljs.core.async.pipeline = (function cljs$core$async$pipeline(var_args){
var G__8392 = arguments.length;
switch (G__8392) {
case 4:
return cljs.core.async.pipeline.cljs$core$IFn$_invoke$arity$4((arguments[(0)]),(arguments[(1)]),(arguments[(2)]),(arguments[(3)]));

break;
case 5:
return cljs.core.async.pipeline.cljs$core$IFn$_invoke$arity$5((arguments[(0)]),(arguments[(1)]),(arguments[(2)]),(arguments[(3)]),(arguments[(4)]));

break;
case 6:
return cljs.core.async.pipeline.cljs$core$IFn$_invoke$arity$6((arguments[(0)]),(arguments[(1)]),(arguments[(2)]),(arguments[(3)]),(arguments[(4)]),(arguments[(5)]));

break;
default:
throw (new Error(["Invalid arity: ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(arguments.length)].join('')));

}
});

cljs.core.async.pipeline.cljs$core$IFn$_invoke$arity$4 = (function (n,to,xf,from){
return cljs.core.async.pipeline.cljs$core$IFn$_invoke$arity$5(n,to,xf,from,true);
});

cljs.core.async.pipeline.cljs$core$IFn$_invoke$arity$5 = (function (n,to,xf,from,close_QMARK_){
return cljs.core.async.pipeline.cljs$core$IFn$_invoke$arity$6(n,to,xf,from,close_QMARK_,null);
});

cljs.core.async.pipeline.cljs$core$IFn$_invoke$arity$6 = (function (n,to,xf,from,close_QMARK_,ex_handler){
return cljs.core.async.pipeline_STAR_(n,to,xf,from,close_QMARK_,ex_handler,cljs.core.cst$kw$compute);
});

cljs.core.async.pipeline.cljs$lang$maxFixedArity = 6;

/**
 * Takes a predicate and a source channel and returns a vector of two
 *   channels, the first of which will contain the values for which the
 *   predicate returned true, the second those for which it returned
 *   false.
 * 
 *   The out channels will be unbuffered by default, or two buf-or-ns can
 *   be supplied. The channels will close after the source channel has
 *   closed.
 */
cljs.core.async.split = (function cljs$core$async$split(var_args){
var G__8395 = arguments.length;
switch (G__8395) {
case 2:
return cljs.core.async.split.cljs$core$IFn$_invoke$arity$2((arguments[(0)]),(arguments[(1)]));

break;
case 4:
return cljs.core.async.split.cljs$core$IFn$_invoke$arity$4((arguments[(0)]),(arguments[(1)]),(arguments[(2)]),(arguments[(3)]));

break;
default:
throw (new Error(["Invalid arity: ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(arguments.length)].join('')));

}
});

cljs.core.async.split.cljs$core$IFn$_invoke$arity$2 = (function (p,ch){
return cljs.core.async.split.cljs$core$IFn$_invoke$arity$4(p,ch,null,null);
});

cljs.core.async.split.cljs$core$IFn$_invoke$arity$4 = (function (p,ch,t_buf_or_n,f_buf_or_n){
var tc = cljs.core.async.chan.cljs$core$IFn$_invoke$arity$1(t_buf_or_n);
var fc = cljs.core.async.chan.cljs$core$IFn$_invoke$arity$1(f_buf_or_n);
var c__7992__auto___8444 = cljs.core.async.chan.cljs$core$IFn$_invoke$arity$1((1));
cljs.core.async.impl.dispatch.run(((function (c__7992__auto___8444,tc,fc){
return (function (){
var f__7993__auto__ = (function (){var switch__7885__auto__ = ((function (c__7992__auto___8444,tc,fc){
return (function (state_8421){
var state_val_8422 = (state_8421[(1)]);
if((state_val_8422 === (7))){
var inst_8417 = (state_8421[(2)]);
var state_8421__$1 = state_8421;
var statearr_8423_8445 = state_8421__$1;
(statearr_8423_8445[(2)] = inst_8417);

(statearr_8423_8445[(1)] = (3));


return cljs.core.cst$kw$recur;
} else {
if((state_val_8422 === (1))){
var state_8421__$1 = state_8421;
var statearr_8424_8446 = state_8421__$1;
(statearr_8424_8446[(2)] = null);

(statearr_8424_8446[(1)] = (2));


return cljs.core.cst$kw$recur;
} else {
if((state_val_8422 === (4))){
var inst_8398 = (state_8421[(7)]);
var inst_8398__$1 = (state_8421[(2)]);
var inst_8399 = (inst_8398__$1 == null);
var state_8421__$1 = (function (){var statearr_8425 = state_8421;
(statearr_8425[(7)] = inst_8398__$1);

return statearr_8425;
})();
if(cljs.core.truth_(inst_8399)){
var statearr_8426_8447 = state_8421__$1;
(statearr_8426_8447[(1)] = (5));

} else {
var statearr_8427_8448 = state_8421__$1;
(statearr_8427_8448[(1)] = (6));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_8422 === (13))){
var state_8421__$1 = state_8421;
var statearr_8428_8449 = state_8421__$1;
(statearr_8428_8449[(2)] = null);

(statearr_8428_8449[(1)] = (14));


return cljs.core.cst$kw$recur;
} else {
if((state_val_8422 === (6))){
var inst_8398 = (state_8421[(7)]);
var inst_8404 = (p.cljs$core$IFn$_invoke$arity$1 ? p.cljs$core$IFn$_invoke$arity$1(inst_8398) : p.call(null,inst_8398));
var state_8421__$1 = state_8421;
if(cljs.core.truth_(inst_8404)){
var statearr_8429_8450 = state_8421__$1;
(statearr_8429_8450[(1)] = (9));

} else {
var statearr_8430_8451 = state_8421__$1;
(statearr_8430_8451[(1)] = (10));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_8422 === (3))){
var inst_8419 = (state_8421[(2)]);
var state_8421__$1 = state_8421;
return cljs.core.async.impl.ioc_helpers.return_chan(state_8421__$1,inst_8419);
} else {
if((state_val_8422 === (12))){
var state_8421__$1 = state_8421;
var statearr_8431_8452 = state_8421__$1;
(statearr_8431_8452[(2)] = null);

(statearr_8431_8452[(1)] = (2));


return cljs.core.cst$kw$recur;
} else {
if((state_val_8422 === (2))){
var state_8421__$1 = state_8421;
return cljs.core.async.impl.ioc_helpers.take_BANG_(state_8421__$1,(4),ch);
} else {
if((state_val_8422 === (11))){
var inst_8398 = (state_8421[(7)]);
var inst_8408 = (state_8421[(2)]);
var state_8421__$1 = state_8421;
return cljs.core.async.impl.ioc_helpers.put_BANG_(state_8421__$1,(8),inst_8408,inst_8398);
} else {
if((state_val_8422 === (9))){
var state_8421__$1 = state_8421;
var statearr_8432_8453 = state_8421__$1;
(statearr_8432_8453[(2)] = tc);

(statearr_8432_8453[(1)] = (11));


return cljs.core.cst$kw$recur;
} else {
if((state_val_8422 === (5))){
var inst_8401 = cljs.core.async.close_BANG_(tc);
var inst_8402 = cljs.core.async.close_BANG_(fc);
var state_8421__$1 = (function (){var statearr_8433 = state_8421;
(statearr_8433[(8)] = inst_8401);

return statearr_8433;
})();
var statearr_8434_8454 = state_8421__$1;
(statearr_8434_8454[(2)] = inst_8402);

(statearr_8434_8454[(1)] = (7));


return cljs.core.cst$kw$recur;
} else {
if((state_val_8422 === (14))){
var inst_8415 = (state_8421[(2)]);
var state_8421__$1 = state_8421;
var statearr_8435_8455 = state_8421__$1;
(statearr_8435_8455[(2)] = inst_8415);

(statearr_8435_8455[(1)] = (7));


return cljs.core.cst$kw$recur;
} else {
if((state_val_8422 === (10))){
var state_8421__$1 = state_8421;
var statearr_8436_8456 = state_8421__$1;
(statearr_8436_8456[(2)] = fc);

(statearr_8436_8456[(1)] = (11));


return cljs.core.cst$kw$recur;
} else {
if((state_val_8422 === (8))){
var inst_8410 = (state_8421[(2)]);
var state_8421__$1 = state_8421;
if(cljs.core.truth_(inst_8410)){
var statearr_8437_8457 = state_8421__$1;
(statearr_8437_8457[(1)] = (12));

} else {
var statearr_8438_8458 = state_8421__$1;
(statearr_8438_8458[(1)] = (13));

}

return cljs.core.cst$kw$recur;
} else {
return null;
}
}
}
}
}
}
}
}
}
}
}
}
}
}
});})(c__7992__auto___8444,tc,fc))
;
return ((function (switch__7885__auto__,c__7992__auto___8444,tc,fc){
return (function() {
var cljs$core$async$state_machine__7886__auto__ = null;
var cljs$core$async$state_machine__7886__auto____0 = (function (){
var statearr_8439 = [null,null,null,null,null,null,null,null,null];
(statearr_8439[(0)] = cljs$core$async$state_machine__7886__auto__);

(statearr_8439[(1)] = (1));

return statearr_8439;
});
var cljs$core$async$state_machine__7886__auto____1 = (function (state_8421){
while(true){
var ret_value__7887__auto__ = (function (){try{while(true){
var result__7888__auto__ = switch__7885__auto__(state_8421);
if(cljs.core.keyword_identical_QMARK_(result__7888__auto__,cljs.core.cst$kw$recur)){
continue;
} else {
return result__7888__auto__;
}
break;
}
}catch (e8440){if((e8440 instanceof Object)){
var ex__7889__auto__ = e8440;
var statearr_8441_8459 = state_8421;
(statearr_8441_8459[(5)] = ex__7889__auto__);


cljs.core.async.impl.ioc_helpers.process_exception(state_8421);

return cljs.core.cst$kw$recur;
} else {
throw e8440;

}
}})();
if(cljs.core.keyword_identical_QMARK_(ret_value__7887__auto__,cljs.core.cst$kw$recur)){
var G__8460 = state_8421;
state_8421 = G__8460;
continue;
} else {
return ret_value__7887__auto__;
}
break;
}
});
cljs$core$async$state_machine__7886__auto__ = function(state_8421){
switch(arguments.length){
case 0:
return cljs$core$async$state_machine__7886__auto____0.call(this);
case 1:
return cljs$core$async$state_machine__7886__auto____1.call(this,state_8421);
}
throw(new Error('Invalid arity: ' + arguments.length));
};
cljs$core$async$state_machine__7886__auto__.cljs$core$IFn$_invoke$arity$0 = cljs$core$async$state_machine__7886__auto____0;
cljs$core$async$state_machine__7886__auto__.cljs$core$IFn$_invoke$arity$1 = cljs$core$async$state_machine__7886__auto____1;
return cljs$core$async$state_machine__7886__auto__;
})()
;})(switch__7885__auto__,c__7992__auto___8444,tc,fc))
})();
var state__7994__auto__ = (function (){var statearr_8442 = (f__7993__auto__.cljs$core$IFn$_invoke$arity$0 ? f__7993__auto__.cljs$core$IFn$_invoke$arity$0() : f__7993__auto__.call(null));
(statearr_8442[(6)] = c__7992__auto___8444);

return statearr_8442;
})();
return cljs.core.async.impl.ioc_helpers.run_state_machine_wrapped(state__7994__auto__);
});})(c__7992__auto___8444,tc,fc))
);


return new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [tc,fc], null);
});

cljs.core.async.split.cljs$lang$maxFixedArity = 4;

/**
 * f should be a function of 2 arguments. Returns a channel containing
 *   the single result of applying f to init and the first item from the
 *   channel, then applying f to that result and the 2nd item, etc. If
 *   the channel closes without yielding items, returns init and f is not
 *   called. ch must close before reduce produces a result.
 */
cljs.core.async.reduce = (function cljs$core$async$reduce(f,init,ch){
var c__7992__auto__ = cljs.core.async.chan.cljs$core$IFn$_invoke$arity$1((1));
cljs.core.async.impl.dispatch.run(((function (c__7992__auto__){
return (function (){
var f__7993__auto__ = (function (){var switch__7885__auto__ = ((function (c__7992__auto__){
return (function (state_8481){
var state_val_8482 = (state_8481[(1)]);
if((state_val_8482 === (7))){
var inst_8477 = (state_8481[(2)]);
var state_8481__$1 = state_8481;
var statearr_8483_8501 = state_8481__$1;
(statearr_8483_8501[(2)] = inst_8477);

(statearr_8483_8501[(1)] = (3));


return cljs.core.cst$kw$recur;
} else {
if((state_val_8482 === (1))){
var inst_8461 = init;
var state_8481__$1 = (function (){var statearr_8484 = state_8481;
(statearr_8484[(7)] = inst_8461);

return statearr_8484;
})();
var statearr_8485_8502 = state_8481__$1;
(statearr_8485_8502[(2)] = null);

(statearr_8485_8502[(1)] = (2));


return cljs.core.cst$kw$recur;
} else {
if((state_val_8482 === (4))){
var inst_8464 = (state_8481[(8)]);
var inst_8464__$1 = (state_8481[(2)]);
var inst_8465 = (inst_8464__$1 == null);
var state_8481__$1 = (function (){var statearr_8486 = state_8481;
(statearr_8486[(8)] = inst_8464__$1);

return statearr_8486;
})();
if(cljs.core.truth_(inst_8465)){
var statearr_8487_8503 = state_8481__$1;
(statearr_8487_8503[(1)] = (5));

} else {
var statearr_8488_8504 = state_8481__$1;
(statearr_8488_8504[(1)] = (6));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_8482 === (6))){
var inst_8468 = (state_8481[(9)]);
var inst_8464 = (state_8481[(8)]);
var inst_8461 = (state_8481[(7)]);
var inst_8468__$1 = (f.cljs$core$IFn$_invoke$arity$2 ? f.cljs$core$IFn$_invoke$arity$2(inst_8461,inst_8464) : f.call(null,inst_8461,inst_8464));
var inst_8469 = cljs.core.reduced_QMARK_(inst_8468__$1);
var state_8481__$1 = (function (){var statearr_8489 = state_8481;
(statearr_8489[(9)] = inst_8468__$1);

return statearr_8489;
})();
if(inst_8469){
var statearr_8490_8505 = state_8481__$1;
(statearr_8490_8505[(1)] = (8));

} else {
var statearr_8491_8506 = state_8481__$1;
(statearr_8491_8506[(1)] = (9));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_8482 === (3))){
var inst_8479 = (state_8481[(2)]);
var state_8481__$1 = state_8481;
return cljs.core.async.impl.ioc_helpers.return_chan(state_8481__$1,inst_8479);
} else {
if((state_val_8482 === (2))){
var state_8481__$1 = state_8481;
return cljs.core.async.impl.ioc_helpers.take_BANG_(state_8481__$1,(4),ch);
} else {
if((state_val_8482 === (9))){
var inst_8468 = (state_8481[(9)]);
var inst_8461 = inst_8468;
var state_8481__$1 = (function (){var statearr_8492 = state_8481;
(statearr_8492[(7)] = inst_8461);

return statearr_8492;
})();
var statearr_8493_8507 = state_8481__$1;
(statearr_8493_8507[(2)] = null);

(statearr_8493_8507[(1)] = (2));


return cljs.core.cst$kw$recur;
} else {
if((state_val_8482 === (5))){
var inst_8461 = (state_8481[(7)]);
var state_8481__$1 = state_8481;
var statearr_8494_8508 = state_8481__$1;
(statearr_8494_8508[(2)] = inst_8461);

(statearr_8494_8508[(1)] = (7));


return cljs.core.cst$kw$recur;
} else {
if((state_val_8482 === (10))){
var inst_8475 = (state_8481[(2)]);
var state_8481__$1 = state_8481;
var statearr_8495_8509 = state_8481__$1;
(statearr_8495_8509[(2)] = inst_8475);

(statearr_8495_8509[(1)] = (7));


return cljs.core.cst$kw$recur;
} else {
if((state_val_8482 === (8))){
var inst_8468 = (state_8481[(9)]);
var inst_8471 = cljs.core.deref(inst_8468);
var state_8481__$1 = state_8481;
var statearr_8496_8510 = state_8481__$1;
(statearr_8496_8510[(2)] = inst_8471);

(statearr_8496_8510[(1)] = (10));


return cljs.core.cst$kw$recur;
} else {
return null;
}
}
}
}
}
}
}
}
}
}
});})(c__7992__auto__))
;
return ((function (switch__7885__auto__,c__7992__auto__){
return (function() {
var cljs$core$async$reduce_$_state_machine__7886__auto__ = null;
var cljs$core$async$reduce_$_state_machine__7886__auto____0 = (function (){
var statearr_8497 = [null,null,null,null,null,null,null,null,null,null];
(statearr_8497[(0)] = cljs$core$async$reduce_$_state_machine__7886__auto__);

(statearr_8497[(1)] = (1));

return statearr_8497;
});
var cljs$core$async$reduce_$_state_machine__7886__auto____1 = (function (state_8481){
while(true){
var ret_value__7887__auto__ = (function (){try{while(true){
var result__7888__auto__ = switch__7885__auto__(state_8481);
if(cljs.core.keyword_identical_QMARK_(result__7888__auto__,cljs.core.cst$kw$recur)){
continue;
} else {
return result__7888__auto__;
}
break;
}
}catch (e8498){if((e8498 instanceof Object)){
var ex__7889__auto__ = e8498;
var statearr_8499_8511 = state_8481;
(statearr_8499_8511[(5)] = ex__7889__auto__);


cljs.core.async.impl.ioc_helpers.process_exception(state_8481);

return cljs.core.cst$kw$recur;
} else {
throw e8498;

}
}})();
if(cljs.core.keyword_identical_QMARK_(ret_value__7887__auto__,cljs.core.cst$kw$recur)){
var G__8512 = state_8481;
state_8481 = G__8512;
continue;
} else {
return ret_value__7887__auto__;
}
break;
}
});
cljs$core$async$reduce_$_state_machine__7886__auto__ = function(state_8481){
switch(arguments.length){
case 0:
return cljs$core$async$reduce_$_state_machine__7886__auto____0.call(this);
case 1:
return cljs$core$async$reduce_$_state_machine__7886__auto____1.call(this,state_8481);
}
throw(new Error('Invalid arity: ' + arguments.length));
};
cljs$core$async$reduce_$_state_machine__7886__auto__.cljs$core$IFn$_invoke$arity$0 = cljs$core$async$reduce_$_state_machine__7886__auto____0;
cljs$core$async$reduce_$_state_machine__7886__auto__.cljs$core$IFn$_invoke$arity$1 = cljs$core$async$reduce_$_state_machine__7886__auto____1;
return cljs$core$async$reduce_$_state_machine__7886__auto__;
})()
;})(switch__7885__auto__,c__7992__auto__))
})();
var state__7994__auto__ = (function (){var statearr_8500 = (f__7993__auto__.cljs$core$IFn$_invoke$arity$0 ? f__7993__auto__.cljs$core$IFn$_invoke$arity$0() : f__7993__auto__.call(null));
(statearr_8500[(6)] = c__7992__auto__);

return statearr_8500;
})();
return cljs.core.async.impl.ioc_helpers.run_state_machine_wrapped(state__7994__auto__);
});})(c__7992__auto__))
);

return c__7992__auto__;
});
/**
 * async/reduces a channel with a transformation (xform f).
 *   Returns a channel containing the result.  ch must close before
 *   transduce produces a result.
 */
cljs.core.async.transduce = (function cljs$core$async$transduce(xform,f,init,ch){
var f__$1 = (xform.cljs$core$IFn$_invoke$arity$1 ? xform.cljs$core$IFn$_invoke$arity$1(f) : xform.call(null,f));
var c__7992__auto__ = cljs.core.async.chan.cljs$core$IFn$_invoke$arity$1((1));
cljs.core.async.impl.dispatch.run(((function (c__7992__auto__,f__$1){
return (function (){
var f__7993__auto__ = (function (){var switch__7885__auto__ = ((function (c__7992__auto__,f__$1){
return (function (state_8518){
var state_val_8519 = (state_8518[(1)]);
if((state_val_8519 === (1))){
var inst_8513 = cljs.core.async.reduce(f__$1,init,ch);
var state_8518__$1 = state_8518;
return cljs.core.async.impl.ioc_helpers.take_BANG_(state_8518__$1,(2),inst_8513);
} else {
if((state_val_8519 === (2))){
var inst_8515 = (state_8518[(2)]);
var inst_8516 = (f__$1.cljs$core$IFn$_invoke$arity$1 ? f__$1.cljs$core$IFn$_invoke$arity$1(inst_8515) : f__$1.call(null,inst_8515));
var state_8518__$1 = state_8518;
return cljs.core.async.impl.ioc_helpers.return_chan(state_8518__$1,inst_8516);
} else {
return null;
}
}
});})(c__7992__auto__,f__$1))
;
return ((function (switch__7885__auto__,c__7992__auto__,f__$1){
return (function() {
var cljs$core$async$transduce_$_state_machine__7886__auto__ = null;
var cljs$core$async$transduce_$_state_machine__7886__auto____0 = (function (){
var statearr_8520 = [null,null,null,null,null,null,null];
(statearr_8520[(0)] = cljs$core$async$transduce_$_state_machine__7886__auto__);

(statearr_8520[(1)] = (1));

return statearr_8520;
});
var cljs$core$async$transduce_$_state_machine__7886__auto____1 = (function (state_8518){
while(true){
var ret_value__7887__auto__ = (function (){try{while(true){
var result__7888__auto__ = switch__7885__auto__(state_8518);
if(cljs.core.keyword_identical_QMARK_(result__7888__auto__,cljs.core.cst$kw$recur)){
continue;
} else {
return result__7888__auto__;
}
break;
}
}catch (e8521){if((e8521 instanceof Object)){
var ex__7889__auto__ = e8521;
var statearr_8522_8524 = state_8518;
(statearr_8522_8524[(5)] = ex__7889__auto__);


cljs.core.async.impl.ioc_helpers.process_exception(state_8518);

return cljs.core.cst$kw$recur;
} else {
throw e8521;

}
}})();
if(cljs.core.keyword_identical_QMARK_(ret_value__7887__auto__,cljs.core.cst$kw$recur)){
var G__8525 = state_8518;
state_8518 = G__8525;
continue;
} else {
return ret_value__7887__auto__;
}
break;
}
});
cljs$core$async$transduce_$_state_machine__7886__auto__ = function(state_8518){
switch(arguments.length){
case 0:
return cljs$core$async$transduce_$_state_machine__7886__auto____0.call(this);
case 1:
return cljs$core$async$transduce_$_state_machine__7886__auto____1.call(this,state_8518);
}
throw(new Error('Invalid arity: ' + arguments.length));
};
cljs$core$async$transduce_$_state_machine__7886__auto__.cljs$core$IFn$_invoke$arity$0 = cljs$core$async$transduce_$_state_machine__7886__auto____0;
cljs$core$async$transduce_$_state_machine__7886__auto__.cljs$core$IFn$_invoke$arity$1 = cljs$core$async$transduce_$_state_machine__7886__auto____1;
return cljs$core$async$transduce_$_state_machine__7886__auto__;
})()
;})(switch__7885__auto__,c__7992__auto__,f__$1))
})();
var state__7994__auto__ = (function (){var statearr_8523 = (f__7993__auto__.cljs$core$IFn$_invoke$arity$0 ? f__7993__auto__.cljs$core$IFn$_invoke$arity$0() : f__7993__auto__.call(null));
(statearr_8523[(6)] = c__7992__auto__);

return statearr_8523;
})();
return cljs.core.async.impl.ioc_helpers.run_state_machine_wrapped(state__7994__auto__);
});})(c__7992__auto__,f__$1))
);

return c__7992__auto__;
});
/**
 * Puts the contents of coll into the supplied channel.
 * 
 *   By default the channel will be closed after the items are copied,
 *   but can be determined by the close? parameter.
 * 
 *   Returns a channel which will close after the items are copied.
 */
cljs.core.async.onto_chan = (function cljs$core$async$onto_chan(var_args){
var G__8527 = arguments.length;
switch (G__8527) {
case 2:
return cljs.core.async.onto_chan.cljs$core$IFn$_invoke$arity$2((arguments[(0)]),(arguments[(1)]));

break;
case 3:
return cljs.core.async.onto_chan.cljs$core$IFn$_invoke$arity$3((arguments[(0)]),(arguments[(1)]),(arguments[(2)]));

break;
default:
throw (new Error(["Invalid arity: ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(arguments.length)].join('')));

}
});

cljs.core.async.onto_chan.cljs$core$IFn$_invoke$arity$2 = (function (ch,coll){
return cljs.core.async.onto_chan.cljs$core$IFn$_invoke$arity$3(ch,coll,true);
});

cljs.core.async.onto_chan.cljs$core$IFn$_invoke$arity$3 = (function (ch,coll,close_QMARK_){
var c__7992__auto__ = cljs.core.async.chan.cljs$core$IFn$_invoke$arity$1((1));
cljs.core.async.impl.dispatch.run(((function (c__7992__auto__){
return (function (){
var f__7993__auto__ = (function (){var switch__7885__auto__ = ((function (c__7992__auto__){
return (function (state_8552){
var state_val_8553 = (state_8552[(1)]);
if((state_val_8553 === (7))){
var inst_8534 = (state_8552[(2)]);
var state_8552__$1 = state_8552;
var statearr_8554_8575 = state_8552__$1;
(statearr_8554_8575[(2)] = inst_8534);

(statearr_8554_8575[(1)] = (6));


return cljs.core.cst$kw$recur;
} else {
if((state_val_8553 === (1))){
var inst_8528 = cljs.core.seq(coll);
var inst_8529 = inst_8528;
var state_8552__$1 = (function (){var statearr_8555 = state_8552;
(statearr_8555[(7)] = inst_8529);

return statearr_8555;
})();
var statearr_8556_8576 = state_8552__$1;
(statearr_8556_8576[(2)] = null);

(statearr_8556_8576[(1)] = (2));


return cljs.core.cst$kw$recur;
} else {
if((state_val_8553 === (4))){
var inst_8529 = (state_8552[(7)]);
var inst_8532 = cljs.core.first(inst_8529);
var state_8552__$1 = state_8552;
return cljs.core.async.impl.ioc_helpers.put_BANG_(state_8552__$1,(7),ch,inst_8532);
} else {
if((state_val_8553 === (13))){
var inst_8546 = (state_8552[(2)]);
var state_8552__$1 = state_8552;
var statearr_8557_8577 = state_8552__$1;
(statearr_8557_8577[(2)] = inst_8546);

(statearr_8557_8577[(1)] = (10));


return cljs.core.cst$kw$recur;
} else {
if((state_val_8553 === (6))){
var inst_8537 = (state_8552[(2)]);
var state_8552__$1 = state_8552;
if(cljs.core.truth_(inst_8537)){
var statearr_8558_8578 = state_8552__$1;
(statearr_8558_8578[(1)] = (8));

} else {
var statearr_8559_8579 = state_8552__$1;
(statearr_8559_8579[(1)] = (9));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_8553 === (3))){
var inst_8550 = (state_8552[(2)]);
var state_8552__$1 = state_8552;
return cljs.core.async.impl.ioc_helpers.return_chan(state_8552__$1,inst_8550);
} else {
if((state_val_8553 === (12))){
var state_8552__$1 = state_8552;
var statearr_8560_8580 = state_8552__$1;
(statearr_8560_8580[(2)] = null);

(statearr_8560_8580[(1)] = (13));


return cljs.core.cst$kw$recur;
} else {
if((state_val_8553 === (2))){
var inst_8529 = (state_8552[(7)]);
var state_8552__$1 = state_8552;
if(cljs.core.truth_(inst_8529)){
var statearr_8561_8581 = state_8552__$1;
(statearr_8561_8581[(1)] = (4));

} else {
var statearr_8562_8582 = state_8552__$1;
(statearr_8562_8582[(1)] = (5));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_8553 === (11))){
var inst_8543 = cljs.core.async.close_BANG_(ch);
var state_8552__$1 = state_8552;
var statearr_8563_8583 = state_8552__$1;
(statearr_8563_8583[(2)] = inst_8543);

(statearr_8563_8583[(1)] = (13));


return cljs.core.cst$kw$recur;
} else {
if((state_val_8553 === (9))){
var state_8552__$1 = state_8552;
if(cljs.core.truth_(close_QMARK_)){
var statearr_8564_8584 = state_8552__$1;
(statearr_8564_8584[(1)] = (11));

} else {
var statearr_8565_8585 = state_8552__$1;
(statearr_8565_8585[(1)] = (12));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_8553 === (5))){
var inst_8529 = (state_8552[(7)]);
var state_8552__$1 = state_8552;
var statearr_8566_8586 = state_8552__$1;
(statearr_8566_8586[(2)] = inst_8529);

(statearr_8566_8586[(1)] = (6));


return cljs.core.cst$kw$recur;
} else {
if((state_val_8553 === (10))){
var inst_8548 = (state_8552[(2)]);
var state_8552__$1 = state_8552;
var statearr_8567_8587 = state_8552__$1;
(statearr_8567_8587[(2)] = inst_8548);

(statearr_8567_8587[(1)] = (3));


return cljs.core.cst$kw$recur;
} else {
if((state_val_8553 === (8))){
var inst_8529 = (state_8552[(7)]);
var inst_8539 = cljs.core.next(inst_8529);
var inst_8529__$1 = inst_8539;
var state_8552__$1 = (function (){var statearr_8568 = state_8552;
(statearr_8568[(7)] = inst_8529__$1);

return statearr_8568;
})();
var statearr_8569_8588 = state_8552__$1;
(statearr_8569_8588[(2)] = null);

(statearr_8569_8588[(1)] = (2));


return cljs.core.cst$kw$recur;
} else {
return null;
}
}
}
}
}
}
}
}
}
}
}
}
}
});})(c__7992__auto__))
;
return ((function (switch__7885__auto__,c__7992__auto__){
return (function() {
var cljs$core$async$state_machine__7886__auto__ = null;
var cljs$core$async$state_machine__7886__auto____0 = (function (){
var statearr_8570 = [null,null,null,null,null,null,null,null];
(statearr_8570[(0)] = cljs$core$async$state_machine__7886__auto__);

(statearr_8570[(1)] = (1));

return statearr_8570;
});
var cljs$core$async$state_machine__7886__auto____1 = (function (state_8552){
while(true){
var ret_value__7887__auto__ = (function (){try{while(true){
var result__7888__auto__ = switch__7885__auto__(state_8552);
if(cljs.core.keyword_identical_QMARK_(result__7888__auto__,cljs.core.cst$kw$recur)){
continue;
} else {
return result__7888__auto__;
}
break;
}
}catch (e8571){if((e8571 instanceof Object)){
var ex__7889__auto__ = e8571;
var statearr_8572_8589 = state_8552;
(statearr_8572_8589[(5)] = ex__7889__auto__);


cljs.core.async.impl.ioc_helpers.process_exception(state_8552);

return cljs.core.cst$kw$recur;
} else {
throw e8571;

}
}})();
if(cljs.core.keyword_identical_QMARK_(ret_value__7887__auto__,cljs.core.cst$kw$recur)){
var G__8590 = state_8552;
state_8552 = G__8590;
continue;
} else {
return ret_value__7887__auto__;
}
break;
}
});
cljs$core$async$state_machine__7886__auto__ = function(state_8552){
switch(arguments.length){
case 0:
return cljs$core$async$state_machine__7886__auto____0.call(this);
case 1:
return cljs$core$async$state_machine__7886__auto____1.call(this,state_8552);
}
throw(new Error('Invalid arity: ' + arguments.length));
};
cljs$core$async$state_machine__7886__auto__.cljs$core$IFn$_invoke$arity$0 = cljs$core$async$state_machine__7886__auto____0;
cljs$core$async$state_machine__7886__auto__.cljs$core$IFn$_invoke$arity$1 = cljs$core$async$state_machine__7886__auto____1;
return cljs$core$async$state_machine__7886__auto__;
})()
;})(switch__7885__auto__,c__7992__auto__))
})();
var state__7994__auto__ = (function (){var statearr_8573 = (f__7993__auto__.cljs$core$IFn$_invoke$arity$0 ? f__7993__auto__.cljs$core$IFn$_invoke$arity$0() : f__7993__auto__.call(null));
(statearr_8573[(6)] = c__7992__auto__);

return statearr_8573;
})();
return cljs.core.async.impl.ioc_helpers.run_state_machine_wrapped(state__7994__auto__);
});})(c__7992__auto__))
);

return c__7992__auto__;
});

cljs.core.async.onto_chan.cljs$lang$maxFixedArity = 3;

/**
 * Creates and returns a channel which contains the contents of coll,
 *   closing when exhausted.
 */
cljs.core.async.to_chan = (function cljs$core$async$to_chan(coll){
var ch = cljs.core.async.chan.cljs$core$IFn$_invoke$arity$1(cljs.core.bounded_count((100),coll));
cljs.core.async.onto_chan.cljs$core$IFn$_invoke$arity$2(ch,coll);

return ch;
});

/**
 * @interface
 */
cljs.core.async.Mux = function(){};

cljs.core.async.muxch_STAR_ = (function cljs$core$async$muxch_STAR_(_){
if((((!((_ == null)))) && ((!((_.cljs$core$async$Mux$muxch_STAR_$arity$1 == null)))))){
return _.cljs$core$async$Mux$muxch_STAR_$arity$1(_);
} else {
var x__4347__auto__ = (((_ == null))?null:_);
var m__4348__auto__ = (cljs.core.async.muxch_STAR_[goog.typeOf(x__4347__auto__)]);
if((!((m__4348__auto__ == null)))){
return (m__4348__auto__.cljs$core$IFn$_invoke$arity$1 ? m__4348__auto__.cljs$core$IFn$_invoke$arity$1(_) : m__4348__auto__.call(null,_));
} else {
var m__4348__auto____$1 = (cljs.core.async.muxch_STAR_["_"]);
if((!((m__4348__auto____$1 == null)))){
return (m__4348__auto____$1.cljs$core$IFn$_invoke$arity$1 ? m__4348__auto____$1.cljs$core$IFn$_invoke$arity$1(_) : m__4348__auto____$1.call(null,_));
} else {
throw cljs.core.missing_protocol("Mux.muxch*",_);
}
}
}
});


/**
 * @interface
 */
cljs.core.async.Mult = function(){};

cljs.core.async.tap_STAR_ = (function cljs$core$async$tap_STAR_(m,ch,close_QMARK_){
if((((!((m == null)))) && ((!((m.cljs$core$async$Mult$tap_STAR_$arity$3 == null)))))){
return m.cljs$core$async$Mult$tap_STAR_$arity$3(m,ch,close_QMARK_);
} else {
var x__4347__auto__ = (((m == null))?null:m);
var m__4348__auto__ = (cljs.core.async.tap_STAR_[goog.typeOf(x__4347__auto__)]);
if((!((m__4348__auto__ == null)))){
return (m__4348__auto__.cljs$core$IFn$_invoke$arity$3 ? m__4348__auto__.cljs$core$IFn$_invoke$arity$3(m,ch,close_QMARK_) : m__4348__auto__.call(null,m,ch,close_QMARK_));
} else {
var m__4348__auto____$1 = (cljs.core.async.tap_STAR_["_"]);
if((!((m__4348__auto____$1 == null)))){
return (m__4348__auto____$1.cljs$core$IFn$_invoke$arity$3 ? m__4348__auto____$1.cljs$core$IFn$_invoke$arity$3(m,ch,close_QMARK_) : m__4348__auto____$1.call(null,m,ch,close_QMARK_));
} else {
throw cljs.core.missing_protocol("Mult.tap*",m);
}
}
}
});

cljs.core.async.untap_STAR_ = (function cljs$core$async$untap_STAR_(m,ch){
if((((!((m == null)))) && ((!((m.cljs$core$async$Mult$untap_STAR_$arity$2 == null)))))){
return m.cljs$core$async$Mult$untap_STAR_$arity$2(m,ch);
} else {
var x__4347__auto__ = (((m == null))?null:m);
var m__4348__auto__ = (cljs.core.async.untap_STAR_[goog.typeOf(x__4347__auto__)]);
if((!((m__4348__auto__ == null)))){
return (m__4348__auto__.cljs$core$IFn$_invoke$arity$2 ? m__4348__auto__.cljs$core$IFn$_invoke$arity$2(m,ch) : m__4348__auto__.call(null,m,ch));
} else {
var m__4348__auto____$1 = (cljs.core.async.untap_STAR_["_"]);
if((!((m__4348__auto____$1 == null)))){
return (m__4348__auto____$1.cljs$core$IFn$_invoke$arity$2 ? m__4348__auto____$1.cljs$core$IFn$_invoke$arity$2(m,ch) : m__4348__auto____$1.call(null,m,ch));
} else {
throw cljs.core.missing_protocol("Mult.untap*",m);
}
}
}
});

cljs.core.async.untap_all_STAR_ = (function cljs$core$async$untap_all_STAR_(m){
if((((!((m == null)))) && ((!((m.cljs$core$async$Mult$untap_all_STAR_$arity$1 == null)))))){
return m.cljs$core$async$Mult$untap_all_STAR_$arity$1(m);
} else {
var x__4347__auto__ = (((m == null))?null:m);
var m__4348__auto__ = (cljs.core.async.untap_all_STAR_[goog.typeOf(x__4347__auto__)]);
if((!((m__4348__auto__ == null)))){
return (m__4348__auto__.cljs$core$IFn$_invoke$arity$1 ? m__4348__auto__.cljs$core$IFn$_invoke$arity$1(m) : m__4348__auto__.call(null,m));
} else {
var m__4348__auto____$1 = (cljs.core.async.untap_all_STAR_["_"]);
if((!((m__4348__auto____$1 == null)))){
return (m__4348__auto____$1.cljs$core$IFn$_invoke$arity$1 ? m__4348__auto____$1.cljs$core$IFn$_invoke$arity$1(m) : m__4348__auto____$1.call(null,m));
} else {
throw cljs.core.missing_protocol("Mult.untap-all*",m);
}
}
}
});

/**
 * Creates and returns a mult(iple) of the supplied channel. Channels
 *   containing copies of the channel can be created with 'tap', and
 *   detached with 'untap'.
 * 
 *   Each item is distributed to all taps in parallel and synchronously,
 *   i.e. each tap must accept before the next item is distributed. Use
 *   buffering/windowing to prevent slow taps from holding up the mult.
 * 
 *   Items received when there are no taps get dropped.
 * 
 *   If a tap puts to a closed channel, it will be removed from the mult.
 */
cljs.core.async.mult = (function cljs$core$async$mult(ch){
var cs = cljs.core.atom.cljs$core$IFn$_invoke$arity$1(cljs.core.PersistentArrayMap.EMPTY);
var m = (function (){
if((typeof cljs !== 'undefined') && (typeof cljs.core !== 'undefined') && (typeof cljs.core.async !== 'undefined') && (typeof cljs.core.async.t_cljs$core$async8591 !== 'undefined')){
} else {

/**
* @constructor
 * @implements {cljs.core.async.Mult}
 * @implements {cljs.core.IMeta}
 * @implements {cljs.core.async.Mux}
 * @implements {cljs.core.IWithMeta}
*/
cljs.core.async.t_cljs$core$async8591 = (function (ch,cs,meta8592){
this.ch = ch;
this.cs = cs;
this.meta8592 = meta8592;
this.cljs$lang$protocol_mask$partition0$ = 393216;
this.cljs$lang$protocol_mask$partition1$ = 0;
});
cljs.core.async.t_cljs$core$async8591.prototype.cljs$core$IWithMeta$_with_meta$arity$2 = ((function (cs){
return (function (_8593,meta8592__$1){
var self__ = this;
var _8593__$1 = this;
return (new cljs.core.async.t_cljs$core$async8591(self__.ch,self__.cs,meta8592__$1));
});})(cs))
;

cljs.core.async.t_cljs$core$async8591.prototype.cljs$core$IMeta$_meta$arity$1 = ((function (cs){
return (function (_8593){
var self__ = this;
var _8593__$1 = this;
return self__.meta8592;
});})(cs))
;

cljs.core.async.t_cljs$core$async8591.prototype.cljs$core$async$Mux$ = cljs.core.PROTOCOL_SENTINEL;

cljs.core.async.t_cljs$core$async8591.prototype.cljs$core$async$Mux$muxch_STAR_$arity$1 = ((function (cs){
return (function (_){
var self__ = this;
var ___$1 = this;
return self__.ch;
});})(cs))
;

cljs.core.async.t_cljs$core$async8591.prototype.cljs$core$async$Mult$ = cljs.core.PROTOCOL_SENTINEL;

cljs.core.async.t_cljs$core$async8591.prototype.cljs$core$async$Mult$tap_STAR_$arity$3 = ((function (cs){
return (function (_,ch__$1,close_QMARK_){
var self__ = this;
var ___$1 = this;
cljs.core.swap_BANG_.cljs$core$IFn$_invoke$arity$4(self__.cs,cljs.core.assoc,ch__$1,close_QMARK_);

return null;
});})(cs))
;

cljs.core.async.t_cljs$core$async8591.prototype.cljs$core$async$Mult$untap_STAR_$arity$2 = ((function (cs){
return (function (_,ch__$1){
var self__ = this;
var ___$1 = this;
cljs.core.swap_BANG_.cljs$core$IFn$_invoke$arity$3(self__.cs,cljs.core.dissoc,ch__$1);

return null;
});})(cs))
;

cljs.core.async.t_cljs$core$async8591.prototype.cljs$core$async$Mult$untap_all_STAR_$arity$1 = ((function (cs){
return (function (_){
var self__ = this;
var ___$1 = this;
cljs.core.reset_BANG_(self__.cs,cljs.core.PersistentArrayMap.EMPTY);

return null;
});})(cs))
;

cljs.core.async.t_cljs$core$async8591.getBasis = ((function (cs){
return (function (){
return new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [cljs.core.cst$sym$ch,cljs.core.cst$sym$cs,cljs.core.cst$sym$meta8592], null);
});})(cs))
;

cljs.core.async.t_cljs$core$async8591.cljs$lang$type = true;

cljs.core.async.t_cljs$core$async8591.cljs$lang$ctorStr = "cljs.core.async/t_cljs$core$async8591";

cljs.core.async.t_cljs$core$async8591.cljs$lang$ctorPrWriter = ((function (cs){
return (function (this__4290__auto__,writer__4291__auto__,opt__4292__auto__){
return cljs.core._write(writer__4291__auto__,"cljs.core.async/t_cljs$core$async8591");
});})(cs))
;

/**
 * Positional factory function for cljs.core.async/t_cljs$core$async8591.
 */
cljs.core.async.__GT_t_cljs$core$async8591 = ((function (cs){
return (function cljs$core$async$mult_$___GT_t_cljs$core$async8591(ch__$1,cs__$1,meta8592){
return (new cljs.core.async.t_cljs$core$async8591(ch__$1,cs__$1,meta8592));
});})(cs))
;

}

return (new cljs.core.async.t_cljs$core$async8591(ch,cs,cljs.core.PersistentArrayMap.EMPTY));
})()
;
var dchan = cljs.core.async.chan.cljs$core$IFn$_invoke$arity$1((1));
var dctr = cljs.core.atom.cljs$core$IFn$_invoke$arity$1(null);
var done = ((function (cs,m,dchan,dctr){
return (function (_){
if((cljs.core.swap_BANG_.cljs$core$IFn$_invoke$arity$2(dctr,cljs.core.dec) === (0))){
return cljs.core.async.put_BANG_.cljs$core$IFn$_invoke$arity$2(dchan,true);
} else {
return null;
}
});})(cs,m,dchan,dctr))
;
var c__7992__auto___8813 = cljs.core.async.chan.cljs$core$IFn$_invoke$arity$1((1));
cljs.core.async.impl.dispatch.run(((function (c__7992__auto___8813,cs,m,dchan,dctr,done){
return (function (){
var f__7993__auto__ = (function (){var switch__7885__auto__ = ((function (c__7992__auto___8813,cs,m,dchan,dctr,done){
return (function (state_8728){
var state_val_8729 = (state_8728[(1)]);
if((state_val_8729 === (7))){
var inst_8724 = (state_8728[(2)]);
var state_8728__$1 = state_8728;
var statearr_8730_8814 = state_8728__$1;
(statearr_8730_8814[(2)] = inst_8724);

(statearr_8730_8814[(1)] = (3));


return cljs.core.cst$kw$recur;
} else {
if((state_val_8729 === (20))){
var inst_8627 = (state_8728[(7)]);
var inst_8639 = cljs.core.first(inst_8627);
var inst_8640 = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(inst_8639,(0),null);
var inst_8641 = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(inst_8639,(1),null);
var state_8728__$1 = (function (){var statearr_8731 = state_8728;
(statearr_8731[(8)] = inst_8640);

return statearr_8731;
})();
if(cljs.core.truth_(inst_8641)){
var statearr_8732_8815 = state_8728__$1;
(statearr_8732_8815[(1)] = (22));

} else {
var statearr_8733_8816 = state_8728__$1;
(statearr_8733_8816[(1)] = (23));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_8729 === (27))){
var inst_8669 = (state_8728[(9)]);
var inst_8676 = (state_8728[(10)]);
var inst_8596 = (state_8728[(11)]);
var inst_8671 = (state_8728[(12)]);
var inst_8676__$1 = cljs.core._nth.cljs$core$IFn$_invoke$arity$2(inst_8669,inst_8671);
var inst_8677 = cljs.core.async.put_BANG_.cljs$core$IFn$_invoke$arity$3(inst_8676__$1,inst_8596,done);
var state_8728__$1 = (function (){var statearr_8734 = state_8728;
(statearr_8734[(10)] = inst_8676__$1);

return statearr_8734;
})();
if(cljs.core.truth_(inst_8677)){
var statearr_8735_8817 = state_8728__$1;
(statearr_8735_8817[(1)] = (30));

} else {
var statearr_8736_8818 = state_8728__$1;
(statearr_8736_8818[(1)] = (31));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_8729 === (1))){
var state_8728__$1 = state_8728;
var statearr_8737_8819 = state_8728__$1;
(statearr_8737_8819[(2)] = null);

(statearr_8737_8819[(1)] = (2));


return cljs.core.cst$kw$recur;
} else {
if((state_val_8729 === (24))){
var inst_8627 = (state_8728[(7)]);
var inst_8646 = (state_8728[(2)]);
var inst_8647 = cljs.core.next(inst_8627);
var inst_8605 = inst_8647;
var inst_8606 = null;
var inst_8607 = (0);
var inst_8608 = (0);
var state_8728__$1 = (function (){var statearr_8738 = state_8728;
(statearr_8738[(13)] = inst_8608);

(statearr_8738[(14)] = inst_8607);

(statearr_8738[(15)] = inst_8606);

(statearr_8738[(16)] = inst_8605);

(statearr_8738[(17)] = inst_8646);

return statearr_8738;
})();
var statearr_8739_8820 = state_8728__$1;
(statearr_8739_8820[(2)] = null);

(statearr_8739_8820[(1)] = (8));


return cljs.core.cst$kw$recur;
} else {
if((state_val_8729 === (39))){
var state_8728__$1 = state_8728;
var statearr_8743_8821 = state_8728__$1;
(statearr_8743_8821[(2)] = null);

(statearr_8743_8821[(1)] = (41));


return cljs.core.cst$kw$recur;
} else {
if((state_val_8729 === (4))){
var inst_8596 = (state_8728[(11)]);
var inst_8596__$1 = (state_8728[(2)]);
var inst_8597 = (inst_8596__$1 == null);
var state_8728__$1 = (function (){var statearr_8744 = state_8728;
(statearr_8744[(11)] = inst_8596__$1);

return statearr_8744;
})();
if(cljs.core.truth_(inst_8597)){
var statearr_8745_8822 = state_8728__$1;
(statearr_8745_8822[(1)] = (5));

} else {
var statearr_8746_8823 = state_8728__$1;
(statearr_8746_8823[(1)] = (6));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_8729 === (15))){
var inst_8608 = (state_8728[(13)]);
var inst_8607 = (state_8728[(14)]);
var inst_8606 = (state_8728[(15)]);
var inst_8605 = (state_8728[(16)]);
var inst_8623 = (state_8728[(2)]);
var inst_8624 = (inst_8608 + (1));
var tmp8740 = inst_8607;
var tmp8741 = inst_8606;
var tmp8742 = inst_8605;
var inst_8605__$1 = tmp8742;
var inst_8606__$1 = tmp8741;
var inst_8607__$1 = tmp8740;
var inst_8608__$1 = inst_8624;
var state_8728__$1 = (function (){var statearr_8747 = state_8728;
(statearr_8747[(18)] = inst_8623);

(statearr_8747[(13)] = inst_8608__$1);

(statearr_8747[(14)] = inst_8607__$1);

(statearr_8747[(15)] = inst_8606__$1);

(statearr_8747[(16)] = inst_8605__$1);

return statearr_8747;
})();
var statearr_8748_8824 = state_8728__$1;
(statearr_8748_8824[(2)] = null);

(statearr_8748_8824[(1)] = (8));


return cljs.core.cst$kw$recur;
} else {
if((state_val_8729 === (21))){
var inst_8650 = (state_8728[(2)]);
var state_8728__$1 = state_8728;
var statearr_8752_8825 = state_8728__$1;
(statearr_8752_8825[(2)] = inst_8650);

(statearr_8752_8825[(1)] = (18));


return cljs.core.cst$kw$recur;
} else {
if((state_val_8729 === (31))){
var inst_8676 = (state_8728[(10)]);
var inst_8680 = done(null);
var inst_8681 = m.cljs$core$async$Mult$untap_STAR_$arity$2(null,inst_8676);
var state_8728__$1 = (function (){var statearr_8753 = state_8728;
(statearr_8753[(19)] = inst_8680);

return statearr_8753;
})();
var statearr_8754_8826 = state_8728__$1;
(statearr_8754_8826[(2)] = inst_8681);

(statearr_8754_8826[(1)] = (32));


return cljs.core.cst$kw$recur;
} else {
if((state_val_8729 === (32))){
var inst_8669 = (state_8728[(9)]);
var inst_8670 = (state_8728[(20)]);
var inst_8671 = (state_8728[(12)]);
var inst_8668 = (state_8728[(21)]);
var inst_8683 = (state_8728[(2)]);
var inst_8684 = (inst_8671 + (1));
var tmp8749 = inst_8669;
var tmp8750 = inst_8670;
var tmp8751 = inst_8668;
var inst_8668__$1 = tmp8751;
var inst_8669__$1 = tmp8749;
var inst_8670__$1 = tmp8750;
var inst_8671__$1 = inst_8684;
var state_8728__$1 = (function (){var statearr_8755 = state_8728;
(statearr_8755[(9)] = inst_8669__$1);

(statearr_8755[(20)] = inst_8670__$1);

(statearr_8755[(22)] = inst_8683);

(statearr_8755[(12)] = inst_8671__$1);

(statearr_8755[(21)] = inst_8668__$1);

return statearr_8755;
})();
var statearr_8756_8827 = state_8728__$1;
(statearr_8756_8827[(2)] = null);

(statearr_8756_8827[(1)] = (25));


return cljs.core.cst$kw$recur;
} else {
if((state_val_8729 === (40))){
var inst_8696 = (state_8728[(23)]);
var inst_8700 = done(null);
var inst_8701 = m.cljs$core$async$Mult$untap_STAR_$arity$2(null,inst_8696);
var state_8728__$1 = (function (){var statearr_8757 = state_8728;
(statearr_8757[(24)] = inst_8700);

return statearr_8757;
})();
var statearr_8758_8828 = state_8728__$1;
(statearr_8758_8828[(2)] = inst_8701);

(statearr_8758_8828[(1)] = (41));


return cljs.core.cst$kw$recur;
} else {
if((state_val_8729 === (33))){
var inst_8687 = (state_8728[(25)]);
var inst_8689 = cljs.core.chunked_seq_QMARK_(inst_8687);
var state_8728__$1 = state_8728;
if(inst_8689){
var statearr_8759_8829 = state_8728__$1;
(statearr_8759_8829[(1)] = (36));

} else {
var statearr_8760_8830 = state_8728__$1;
(statearr_8760_8830[(1)] = (37));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_8729 === (13))){
var inst_8617 = (state_8728[(26)]);
var inst_8620 = cljs.core.async.close_BANG_(inst_8617);
var state_8728__$1 = state_8728;
var statearr_8761_8831 = state_8728__$1;
(statearr_8761_8831[(2)] = inst_8620);

(statearr_8761_8831[(1)] = (15));


return cljs.core.cst$kw$recur;
} else {
if((state_val_8729 === (22))){
var inst_8640 = (state_8728[(8)]);
var inst_8643 = cljs.core.async.close_BANG_(inst_8640);
var state_8728__$1 = state_8728;
var statearr_8762_8832 = state_8728__$1;
(statearr_8762_8832[(2)] = inst_8643);

(statearr_8762_8832[(1)] = (24));


return cljs.core.cst$kw$recur;
} else {
if((state_val_8729 === (36))){
var inst_8687 = (state_8728[(25)]);
var inst_8691 = cljs.core.chunk_first(inst_8687);
var inst_8692 = cljs.core.chunk_rest(inst_8687);
var inst_8693 = cljs.core.count(inst_8691);
var inst_8668 = inst_8692;
var inst_8669 = inst_8691;
var inst_8670 = inst_8693;
var inst_8671 = (0);
var state_8728__$1 = (function (){var statearr_8763 = state_8728;
(statearr_8763[(9)] = inst_8669);

(statearr_8763[(20)] = inst_8670);

(statearr_8763[(12)] = inst_8671);

(statearr_8763[(21)] = inst_8668);

return statearr_8763;
})();
var statearr_8764_8833 = state_8728__$1;
(statearr_8764_8833[(2)] = null);

(statearr_8764_8833[(1)] = (25));


return cljs.core.cst$kw$recur;
} else {
if((state_val_8729 === (41))){
var inst_8687 = (state_8728[(25)]);
var inst_8703 = (state_8728[(2)]);
var inst_8704 = cljs.core.next(inst_8687);
var inst_8668 = inst_8704;
var inst_8669 = null;
var inst_8670 = (0);
var inst_8671 = (0);
var state_8728__$1 = (function (){var statearr_8765 = state_8728;
(statearr_8765[(9)] = inst_8669);

(statearr_8765[(27)] = inst_8703);

(statearr_8765[(20)] = inst_8670);

(statearr_8765[(12)] = inst_8671);

(statearr_8765[(21)] = inst_8668);

return statearr_8765;
})();
var statearr_8766_8834 = state_8728__$1;
(statearr_8766_8834[(2)] = null);

(statearr_8766_8834[(1)] = (25));


return cljs.core.cst$kw$recur;
} else {
if((state_val_8729 === (43))){
var state_8728__$1 = state_8728;
var statearr_8767_8835 = state_8728__$1;
(statearr_8767_8835[(2)] = null);

(statearr_8767_8835[(1)] = (44));


return cljs.core.cst$kw$recur;
} else {
if((state_val_8729 === (29))){
var inst_8712 = (state_8728[(2)]);
var state_8728__$1 = state_8728;
var statearr_8768_8836 = state_8728__$1;
(statearr_8768_8836[(2)] = inst_8712);

(statearr_8768_8836[(1)] = (26));


return cljs.core.cst$kw$recur;
} else {
if((state_val_8729 === (44))){
var inst_8721 = (state_8728[(2)]);
var state_8728__$1 = (function (){var statearr_8769 = state_8728;
(statearr_8769[(28)] = inst_8721);

return statearr_8769;
})();
var statearr_8770_8837 = state_8728__$1;
(statearr_8770_8837[(2)] = null);

(statearr_8770_8837[(1)] = (2));


return cljs.core.cst$kw$recur;
} else {
if((state_val_8729 === (6))){
var inst_8660 = (state_8728[(29)]);
var inst_8659 = cljs.core.deref(cs);
var inst_8660__$1 = cljs.core.keys(inst_8659);
var inst_8661 = cljs.core.count(inst_8660__$1);
var inst_8662 = cljs.core.reset_BANG_(dctr,inst_8661);
var inst_8667 = cljs.core.seq(inst_8660__$1);
var inst_8668 = inst_8667;
var inst_8669 = null;
var inst_8670 = (0);
var inst_8671 = (0);
var state_8728__$1 = (function (){var statearr_8771 = state_8728;
(statearr_8771[(9)] = inst_8669);

(statearr_8771[(29)] = inst_8660__$1);

(statearr_8771[(30)] = inst_8662);

(statearr_8771[(20)] = inst_8670);

(statearr_8771[(12)] = inst_8671);

(statearr_8771[(21)] = inst_8668);

return statearr_8771;
})();
var statearr_8772_8838 = state_8728__$1;
(statearr_8772_8838[(2)] = null);

(statearr_8772_8838[(1)] = (25));


return cljs.core.cst$kw$recur;
} else {
if((state_val_8729 === (28))){
var inst_8687 = (state_8728[(25)]);
var inst_8668 = (state_8728[(21)]);
var inst_8687__$1 = cljs.core.seq(inst_8668);
var state_8728__$1 = (function (){var statearr_8773 = state_8728;
(statearr_8773[(25)] = inst_8687__$1);

return statearr_8773;
})();
if(inst_8687__$1){
var statearr_8774_8839 = state_8728__$1;
(statearr_8774_8839[(1)] = (33));

} else {
var statearr_8775_8840 = state_8728__$1;
(statearr_8775_8840[(1)] = (34));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_8729 === (25))){
var inst_8670 = (state_8728[(20)]);
var inst_8671 = (state_8728[(12)]);
var inst_8673 = (inst_8671 < inst_8670);
var inst_8674 = inst_8673;
var state_8728__$1 = state_8728;
if(cljs.core.truth_(inst_8674)){
var statearr_8776_8841 = state_8728__$1;
(statearr_8776_8841[(1)] = (27));

} else {
var statearr_8777_8842 = state_8728__$1;
(statearr_8777_8842[(1)] = (28));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_8729 === (34))){
var state_8728__$1 = state_8728;
var statearr_8778_8843 = state_8728__$1;
(statearr_8778_8843[(2)] = null);

(statearr_8778_8843[(1)] = (35));


return cljs.core.cst$kw$recur;
} else {
if((state_val_8729 === (17))){
var state_8728__$1 = state_8728;
var statearr_8779_8844 = state_8728__$1;
(statearr_8779_8844[(2)] = null);

(statearr_8779_8844[(1)] = (18));


return cljs.core.cst$kw$recur;
} else {
if((state_val_8729 === (3))){
var inst_8726 = (state_8728[(2)]);
var state_8728__$1 = state_8728;
return cljs.core.async.impl.ioc_helpers.return_chan(state_8728__$1,inst_8726);
} else {
if((state_val_8729 === (12))){
var inst_8655 = (state_8728[(2)]);
var state_8728__$1 = state_8728;
var statearr_8780_8845 = state_8728__$1;
(statearr_8780_8845[(2)] = inst_8655);

(statearr_8780_8845[(1)] = (9));


return cljs.core.cst$kw$recur;
} else {
if((state_val_8729 === (2))){
var state_8728__$1 = state_8728;
return cljs.core.async.impl.ioc_helpers.take_BANG_(state_8728__$1,(4),ch);
} else {
if((state_val_8729 === (23))){
var state_8728__$1 = state_8728;
var statearr_8781_8846 = state_8728__$1;
(statearr_8781_8846[(2)] = null);

(statearr_8781_8846[(1)] = (24));


return cljs.core.cst$kw$recur;
} else {
if((state_val_8729 === (35))){
var inst_8710 = (state_8728[(2)]);
var state_8728__$1 = state_8728;
var statearr_8782_8847 = state_8728__$1;
(statearr_8782_8847[(2)] = inst_8710);

(statearr_8782_8847[(1)] = (29));


return cljs.core.cst$kw$recur;
} else {
if((state_val_8729 === (19))){
var inst_8627 = (state_8728[(7)]);
var inst_8631 = cljs.core.chunk_first(inst_8627);
var inst_8632 = cljs.core.chunk_rest(inst_8627);
var inst_8633 = cljs.core.count(inst_8631);
var inst_8605 = inst_8632;
var inst_8606 = inst_8631;
var inst_8607 = inst_8633;
var inst_8608 = (0);
var state_8728__$1 = (function (){var statearr_8783 = state_8728;
(statearr_8783[(13)] = inst_8608);

(statearr_8783[(14)] = inst_8607);

(statearr_8783[(15)] = inst_8606);

(statearr_8783[(16)] = inst_8605);

return statearr_8783;
})();
var statearr_8784_8848 = state_8728__$1;
(statearr_8784_8848[(2)] = null);

(statearr_8784_8848[(1)] = (8));


return cljs.core.cst$kw$recur;
} else {
if((state_val_8729 === (11))){
var inst_8605 = (state_8728[(16)]);
var inst_8627 = (state_8728[(7)]);
var inst_8627__$1 = cljs.core.seq(inst_8605);
var state_8728__$1 = (function (){var statearr_8785 = state_8728;
(statearr_8785[(7)] = inst_8627__$1);

return statearr_8785;
})();
if(inst_8627__$1){
var statearr_8786_8849 = state_8728__$1;
(statearr_8786_8849[(1)] = (16));

} else {
var statearr_8787_8850 = state_8728__$1;
(statearr_8787_8850[(1)] = (17));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_8729 === (9))){
var inst_8657 = (state_8728[(2)]);
var state_8728__$1 = state_8728;
var statearr_8788_8851 = state_8728__$1;
(statearr_8788_8851[(2)] = inst_8657);

(statearr_8788_8851[(1)] = (7));


return cljs.core.cst$kw$recur;
} else {
if((state_val_8729 === (5))){
var inst_8603 = cljs.core.deref(cs);
var inst_8604 = cljs.core.seq(inst_8603);
var inst_8605 = inst_8604;
var inst_8606 = null;
var inst_8607 = (0);
var inst_8608 = (0);
var state_8728__$1 = (function (){var statearr_8789 = state_8728;
(statearr_8789[(13)] = inst_8608);

(statearr_8789[(14)] = inst_8607);

(statearr_8789[(15)] = inst_8606);

(statearr_8789[(16)] = inst_8605);

return statearr_8789;
})();
var statearr_8790_8852 = state_8728__$1;
(statearr_8790_8852[(2)] = null);

(statearr_8790_8852[(1)] = (8));


return cljs.core.cst$kw$recur;
} else {
if((state_val_8729 === (14))){
var state_8728__$1 = state_8728;
var statearr_8791_8853 = state_8728__$1;
(statearr_8791_8853[(2)] = null);

(statearr_8791_8853[(1)] = (15));


return cljs.core.cst$kw$recur;
} else {
if((state_val_8729 === (45))){
var inst_8718 = (state_8728[(2)]);
var state_8728__$1 = state_8728;
var statearr_8792_8854 = state_8728__$1;
(statearr_8792_8854[(2)] = inst_8718);

(statearr_8792_8854[(1)] = (44));


return cljs.core.cst$kw$recur;
} else {
if((state_val_8729 === (26))){
var inst_8660 = (state_8728[(29)]);
var inst_8714 = (state_8728[(2)]);
var inst_8715 = cljs.core.seq(inst_8660);
var state_8728__$1 = (function (){var statearr_8793 = state_8728;
(statearr_8793[(31)] = inst_8714);

return statearr_8793;
})();
if(inst_8715){
var statearr_8794_8855 = state_8728__$1;
(statearr_8794_8855[(1)] = (42));

} else {
var statearr_8795_8856 = state_8728__$1;
(statearr_8795_8856[(1)] = (43));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_8729 === (16))){
var inst_8627 = (state_8728[(7)]);
var inst_8629 = cljs.core.chunked_seq_QMARK_(inst_8627);
var state_8728__$1 = state_8728;
if(inst_8629){
var statearr_8796_8857 = state_8728__$1;
(statearr_8796_8857[(1)] = (19));

} else {
var statearr_8797_8858 = state_8728__$1;
(statearr_8797_8858[(1)] = (20));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_8729 === (38))){
var inst_8707 = (state_8728[(2)]);
var state_8728__$1 = state_8728;
var statearr_8798_8859 = state_8728__$1;
(statearr_8798_8859[(2)] = inst_8707);

(statearr_8798_8859[(1)] = (35));


return cljs.core.cst$kw$recur;
} else {
if((state_val_8729 === (30))){
var state_8728__$1 = state_8728;
var statearr_8799_8860 = state_8728__$1;
(statearr_8799_8860[(2)] = null);

(statearr_8799_8860[(1)] = (32));


return cljs.core.cst$kw$recur;
} else {
if((state_val_8729 === (10))){
var inst_8608 = (state_8728[(13)]);
var inst_8606 = (state_8728[(15)]);
var inst_8616 = cljs.core._nth.cljs$core$IFn$_invoke$arity$2(inst_8606,inst_8608);
var inst_8617 = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(inst_8616,(0),null);
var inst_8618 = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(inst_8616,(1),null);
var state_8728__$1 = (function (){var statearr_8800 = state_8728;
(statearr_8800[(26)] = inst_8617);

return statearr_8800;
})();
if(cljs.core.truth_(inst_8618)){
var statearr_8801_8861 = state_8728__$1;
(statearr_8801_8861[(1)] = (13));

} else {
var statearr_8802_8862 = state_8728__$1;
(statearr_8802_8862[(1)] = (14));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_8729 === (18))){
var inst_8653 = (state_8728[(2)]);
var state_8728__$1 = state_8728;
var statearr_8803_8863 = state_8728__$1;
(statearr_8803_8863[(2)] = inst_8653);

(statearr_8803_8863[(1)] = (12));


return cljs.core.cst$kw$recur;
} else {
if((state_val_8729 === (42))){
var state_8728__$1 = state_8728;
return cljs.core.async.impl.ioc_helpers.take_BANG_(state_8728__$1,(45),dchan);
} else {
if((state_val_8729 === (37))){
var inst_8696 = (state_8728[(23)]);
var inst_8596 = (state_8728[(11)]);
var inst_8687 = (state_8728[(25)]);
var inst_8696__$1 = cljs.core.first(inst_8687);
var inst_8697 = cljs.core.async.put_BANG_.cljs$core$IFn$_invoke$arity$3(inst_8696__$1,inst_8596,done);
var state_8728__$1 = (function (){var statearr_8804 = state_8728;
(statearr_8804[(23)] = inst_8696__$1);

return statearr_8804;
})();
if(cljs.core.truth_(inst_8697)){
var statearr_8805_8864 = state_8728__$1;
(statearr_8805_8864[(1)] = (39));

} else {
var statearr_8806_8865 = state_8728__$1;
(statearr_8806_8865[(1)] = (40));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_8729 === (8))){
var inst_8608 = (state_8728[(13)]);
var inst_8607 = (state_8728[(14)]);
var inst_8610 = (inst_8608 < inst_8607);
var inst_8611 = inst_8610;
var state_8728__$1 = state_8728;
if(cljs.core.truth_(inst_8611)){
var statearr_8807_8866 = state_8728__$1;
(statearr_8807_8866[(1)] = (10));

} else {
var statearr_8808_8867 = state_8728__$1;
(statearr_8808_8867[(1)] = (11));

}

return cljs.core.cst$kw$recur;
} else {
return null;
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
});})(c__7992__auto___8813,cs,m,dchan,dctr,done))
;
return ((function (switch__7885__auto__,c__7992__auto___8813,cs,m,dchan,dctr,done){
return (function() {
var cljs$core$async$mult_$_state_machine__7886__auto__ = null;
var cljs$core$async$mult_$_state_machine__7886__auto____0 = (function (){
var statearr_8809 = [null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null];
(statearr_8809[(0)] = cljs$core$async$mult_$_state_machine__7886__auto__);

(statearr_8809[(1)] = (1));

return statearr_8809;
});
var cljs$core$async$mult_$_state_machine__7886__auto____1 = (function (state_8728){
while(true){
var ret_value__7887__auto__ = (function (){try{while(true){
var result__7888__auto__ = switch__7885__auto__(state_8728);
if(cljs.core.keyword_identical_QMARK_(result__7888__auto__,cljs.core.cst$kw$recur)){
continue;
} else {
return result__7888__auto__;
}
break;
}
}catch (e8810){if((e8810 instanceof Object)){
var ex__7889__auto__ = e8810;
var statearr_8811_8868 = state_8728;
(statearr_8811_8868[(5)] = ex__7889__auto__);


cljs.core.async.impl.ioc_helpers.process_exception(state_8728);

return cljs.core.cst$kw$recur;
} else {
throw e8810;

}
}})();
if(cljs.core.keyword_identical_QMARK_(ret_value__7887__auto__,cljs.core.cst$kw$recur)){
var G__8869 = state_8728;
state_8728 = G__8869;
continue;
} else {
return ret_value__7887__auto__;
}
break;
}
});
cljs$core$async$mult_$_state_machine__7886__auto__ = function(state_8728){
switch(arguments.length){
case 0:
return cljs$core$async$mult_$_state_machine__7886__auto____0.call(this);
case 1:
return cljs$core$async$mult_$_state_machine__7886__auto____1.call(this,state_8728);
}
throw(new Error('Invalid arity: ' + arguments.length));
};
cljs$core$async$mult_$_state_machine__7886__auto__.cljs$core$IFn$_invoke$arity$0 = cljs$core$async$mult_$_state_machine__7886__auto____0;
cljs$core$async$mult_$_state_machine__7886__auto__.cljs$core$IFn$_invoke$arity$1 = cljs$core$async$mult_$_state_machine__7886__auto____1;
return cljs$core$async$mult_$_state_machine__7886__auto__;
})()
;})(switch__7885__auto__,c__7992__auto___8813,cs,m,dchan,dctr,done))
})();
var state__7994__auto__ = (function (){var statearr_8812 = (f__7993__auto__.cljs$core$IFn$_invoke$arity$0 ? f__7993__auto__.cljs$core$IFn$_invoke$arity$0() : f__7993__auto__.call(null));
(statearr_8812[(6)] = c__7992__auto___8813);

return statearr_8812;
})();
return cljs.core.async.impl.ioc_helpers.run_state_machine_wrapped(state__7994__auto__);
});})(c__7992__auto___8813,cs,m,dchan,dctr,done))
);


return m;
});
/**
 * Copies the mult source onto the supplied channel.
 * 
 *   By default the channel will be closed when the source closes,
 *   but can be determined by the close? parameter.
 */
cljs.core.async.tap = (function cljs$core$async$tap(var_args){
var G__8871 = arguments.length;
switch (G__8871) {
case 2:
return cljs.core.async.tap.cljs$core$IFn$_invoke$arity$2((arguments[(0)]),(arguments[(1)]));

break;
case 3:
return cljs.core.async.tap.cljs$core$IFn$_invoke$arity$3((arguments[(0)]),(arguments[(1)]),(arguments[(2)]));

break;
default:
throw (new Error(["Invalid arity: ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(arguments.length)].join('')));

}
});

cljs.core.async.tap.cljs$core$IFn$_invoke$arity$2 = (function (mult,ch){
return cljs.core.async.tap.cljs$core$IFn$_invoke$arity$3(mult,ch,true);
});

cljs.core.async.tap.cljs$core$IFn$_invoke$arity$3 = (function (mult,ch,close_QMARK_){
cljs.core.async.tap_STAR_(mult,ch,close_QMARK_);

return ch;
});

cljs.core.async.tap.cljs$lang$maxFixedArity = 3;

/**
 * Disconnects a target channel from a mult
 */
cljs.core.async.untap = (function cljs$core$async$untap(mult,ch){
return cljs.core.async.untap_STAR_(mult,ch);
});
/**
 * Disconnects all target channels from a mult
 */
cljs.core.async.untap_all = (function cljs$core$async$untap_all(mult){
return cljs.core.async.untap_all_STAR_(mult);
});

/**
 * @interface
 */
cljs.core.async.Mix = function(){};

cljs.core.async.admix_STAR_ = (function cljs$core$async$admix_STAR_(m,ch){
if((((!((m == null)))) && ((!((m.cljs$core$async$Mix$admix_STAR_$arity$2 == null)))))){
return m.cljs$core$async$Mix$admix_STAR_$arity$2(m,ch);
} else {
var x__4347__auto__ = (((m == null))?null:m);
var m__4348__auto__ = (cljs.core.async.admix_STAR_[goog.typeOf(x__4347__auto__)]);
if((!((m__4348__auto__ == null)))){
return (m__4348__auto__.cljs$core$IFn$_invoke$arity$2 ? m__4348__auto__.cljs$core$IFn$_invoke$arity$2(m,ch) : m__4348__auto__.call(null,m,ch));
} else {
var m__4348__auto____$1 = (cljs.core.async.admix_STAR_["_"]);
if((!((m__4348__auto____$1 == null)))){
return (m__4348__auto____$1.cljs$core$IFn$_invoke$arity$2 ? m__4348__auto____$1.cljs$core$IFn$_invoke$arity$2(m,ch) : m__4348__auto____$1.call(null,m,ch));
} else {
throw cljs.core.missing_protocol("Mix.admix*",m);
}
}
}
});

cljs.core.async.unmix_STAR_ = (function cljs$core$async$unmix_STAR_(m,ch){
if((((!((m == null)))) && ((!((m.cljs$core$async$Mix$unmix_STAR_$arity$2 == null)))))){
return m.cljs$core$async$Mix$unmix_STAR_$arity$2(m,ch);
} else {
var x__4347__auto__ = (((m == null))?null:m);
var m__4348__auto__ = (cljs.core.async.unmix_STAR_[goog.typeOf(x__4347__auto__)]);
if((!((m__4348__auto__ == null)))){
return (m__4348__auto__.cljs$core$IFn$_invoke$arity$2 ? m__4348__auto__.cljs$core$IFn$_invoke$arity$2(m,ch) : m__4348__auto__.call(null,m,ch));
} else {
var m__4348__auto____$1 = (cljs.core.async.unmix_STAR_["_"]);
if((!((m__4348__auto____$1 == null)))){
return (m__4348__auto____$1.cljs$core$IFn$_invoke$arity$2 ? m__4348__auto____$1.cljs$core$IFn$_invoke$arity$2(m,ch) : m__4348__auto____$1.call(null,m,ch));
} else {
throw cljs.core.missing_protocol("Mix.unmix*",m);
}
}
}
});

cljs.core.async.unmix_all_STAR_ = (function cljs$core$async$unmix_all_STAR_(m){
if((((!((m == null)))) && ((!((m.cljs$core$async$Mix$unmix_all_STAR_$arity$1 == null)))))){
return m.cljs$core$async$Mix$unmix_all_STAR_$arity$1(m);
} else {
var x__4347__auto__ = (((m == null))?null:m);
var m__4348__auto__ = (cljs.core.async.unmix_all_STAR_[goog.typeOf(x__4347__auto__)]);
if((!((m__4348__auto__ == null)))){
return (m__4348__auto__.cljs$core$IFn$_invoke$arity$1 ? m__4348__auto__.cljs$core$IFn$_invoke$arity$1(m) : m__4348__auto__.call(null,m));
} else {
var m__4348__auto____$1 = (cljs.core.async.unmix_all_STAR_["_"]);
if((!((m__4348__auto____$1 == null)))){
return (m__4348__auto____$1.cljs$core$IFn$_invoke$arity$1 ? m__4348__auto____$1.cljs$core$IFn$_invoke$arity$1(m) : m__4348__auto____$1.call(null,m));
} else {
throw cljs.core.missing_protocol("Mix.unmix-all*",m);
}
}
}
});

cljs.core.async.toggle_STAR_ = (function cljs$core$async$toggle_STAR_(m,state_map){
if((((!((m == null)))) && ((!((m.cljs$core$async$Mix$toggle_STAR_$arity$2 == null)))))){
return m.cljs$core$async$Mix$toggle_STAR_$arity$2(m,state_map);
} else {
var x__4347__auto__ = (((m == null))?null:m);
var m__4348__auto__ = (cljs.core.async.toggle_STAR_[goog.typeOf(x__4347__auto__)]);
if((!((m__4348__auto__ == null)))){
return (m__4348__auto__.cljs$core$IFn$_invoke$arity$2 ? m__4348__auto__.cljs$core$IFn$_invoke$arity$2(m,state_map) : m__4348__auto__.call(null,m,state_map));
} else {
var m__4348__auto____$1 = (cljs.core.async.toggle_STAR_["_"]);
if((!((m__4348__auto____$1 == null)))){
return (m__4348__auto____$1.cljs$core$IFn$_invoke$arity$2 ? m__4348__auto____$1.cljs$core$IFn$_invoke$arity$2(m,state_map) : m__4348__auto____$1.call(null,m,state_map));
} else {
throw cljs.core.missing_protocol("Mix.toggle*",m);
}
}
}
});

cljs.core.async.solo_mode_STAR_ = (function cljs$core$async$solo_mode_STAR_(m,mode){
if((((!((m == null)))) && ((!((m.cljs$core$async$Mix$solo_mode_STAR_$arity$2 == null)))))){
return m.cljs$core$async$Mix$solo_mode_STAR_$arity$2(m,mode);
} else {
var x__4347__auto__ = (((m == null))?null:m);
var m__4348__auto__ = (cljs.core.async.solo_mode_STAR_[goog.typeOf(x__4347__auto__)]);
if((!((m__4348__auto__ == null)))){
return (m__4348__auto__.cljs$core$IFn$_invoke$arity$2 ? m__4348__auto__.cljs$core$IFn$_invoke$arity$2(m,mode) : m__4348__auto__.call(null,m,mode));
} else {
var m__4348__auto____$1 = (cljs.core.async.solo_mode_STAR_["_"]);
if((!((m__4348__auto____$1 == null)))){
return (m__4348__auto____$1.cljs$core$IFn$_invoke$arity$2 ? m__4348__auto____$1.cljs$core$IFn$_invoke$arity$2(m,mode) : m__4348__auto____$1.call(null,m,mode));
} else {
throw cljs.core.missing_protocol("Mix.solo-mode*",m);
}
}
}
});

cljs.core.async.ioc_alts_BANG_ = (function cljs$core$async$ioc_alts_BANG_(var_args){
var args__4647__auto__ = [];
var len__4641__auto___8883 = arguments.length;
var i__4642__auto___8884 = (0);
while(true){
if((i__4642__auto___8884 < len__4641__auto___8883)){
args__4647__auto__.push((arguments[i__4642__auto___8884]));

var G__8885 = (i__4642__auto___8884 + (1));
i__4642__auto___8884 = G__8885;
continue;
} else {
}
break;
}

var argseq__4648__auto__ = ((((3) < args__4647__auto__.length))?(new cljs.core.IndexedSeq(args__4647__auto__.slice((3)),(0),null)):null);
return cljs.core.async.ioc_alts_BANG_.cljs$core$IFn$_invoke$arity$variadic((arguments[(0)]),(arguments[(1)]),(arguments[(2)]),argseq__4648__auto__);
});

cljs.core.async.ioc_alts_BANG_.cljs$core$IFn$_invoke$arity$variadic = (function (state,cont_block,ports,p__8877){
var map__8878 = p__8877;
var map__8878__$1 = (((((!((map__8878 == null))))?(((((map__8878.cljs$lang$protocol_mask$partition0$ & (64))) || ((cljs.core.PROTOCOL_SENTINEL === map__8878.cljs$core$ISeq$))))?true:false):false))?cljs.core.apply.cljs$core$IFn$_invoke$arity$2(cljs.core.hash_map,map__8878):map__8878);
var opts = map__8878__$1;
var statearr_8880_8886 = state;
(statearr_8880_8886[(1)] = cont_block);


var temp__5457__auto__ = cljs.core.async.do_alts(((function (map__8878,map__8878__$1,opts){
return (function (val){
var statearr_8881_8887 = state;
(statearr_8881_8887[(2)] = val);


return cljs.core.async.impl.ioc_helpers.run_state_machine_wrapped(state);
});})(map__8878,map__8878__$1,opts))
,ports,opts);
if(cljs.core.truth_(temp__5457__auto__)){
var cb = temp__5457__auto__;
var statearr_8882_8888 = state;
(statearr_8882_8888[(2)] = cljs.core.deref(cb));


return cljs.core.cst$kw$recur;
} else {
return null;
}
});

cljs.core.async.ioc_alts_BANG_.cljs$lang$maxFixedArity = (3);

/** @this {Function} */
cljs.core.async.ioc_alts_BANG_.cljs$lang$applyTo = (function (seq8873){
var G__8874 = cljs.core.first(seq8873);
var seq8873__$1 = cljs.core.next(seq8873);
var G__8875 = cljs.core.first(seq8873__$1);
var seq8873__$2 = cljs.core.next(seq8873__$1);
var G__8876 = cljs.core.first(seq8873__$2);
var seq8873__$3 = cljs.core.next(seq8873__$2);
var self__4628__auto__ = this;
return self__4628__auto__.cljs$core$IFn$_invoke$arity$variadic(G__8874,G__8875,G__8876,seq8873__$3);
});

/**
 * Creates and returns a mix of one or more input channels which will
 *   be put on the supplied out channel. Input sources can be added to
 *   the mix with 'admix', and removed with 'unmix'. A mix supports
 *   soloing, muting and pausing multiple inputs atomically using
 *   'toggle', and can solo using either muting or pausing as determined
 *   by 'solo-mode'.
 * 
 *   Each channel can have zero or more boolean modes set via 'toggle':
 * 
 *   :solo - when true, only this (ond other soloed) channel(s) will appear
 *        in the mix output channel. :mute and :pause states of soloed
 *        channels are ignored. If solo-mode is :mute, non-soloed
 *        channels are muted, if :pause, non-soloed channels are
 *        paused.
 * 
 *   :mute - muted channels will have their contents consumed but not included in the mix
 *   :pause - paused channels will not have their contents consumed (and thus also not included in the mix)
 */
cljs.core.async.mix = (function cljs$core$async$mix(out){
var cs = cljs.core.atom.cljs$core$IFn$_invoke$arity$1(cljs.core.PersistentArrayMap.EMPTY);
var solo_modes = new cljs.core.PersistentHashSet(null, new cljs.core.PersistentArrayMap(null, 2, [cljs.core.cst$kw$pause,null,cljs.core.cst$kw$mute,null], null), null);
var attrs = cljs.core.conj.cljs$core$IFn$_invoke$arity$2(solo_modes,cljs.core.cst$kw$solo);
var solo_mode = cljs.core.atom.cljs$core$IFn$_invoke$arity$1(cljs.core.cst$kw$mute);
var change = cljs.core.async.chan.cljs$core$IFn$_invoke$arity$0();
var changed = ((function (cs,solo_modes,attrs,solo_mode,change){
return (function (){
return cljs.core.async.put_BANG_.cljs$core$IFn$_invoke$arity$2(change,true);
});})(cs,solo_modes,attrs,solo_mode,change))
;
var pick = ((function (cs,solo_modes,attrs,solo_mode,change,changed){
return (function (attr,chs){
return cljs.core.reduce_kv(((function (cs,solo_modes,attrs,solo_mode,change,changed){
return (function (ret,c,v){
if(cljs.core.truth_((attr.cljs$core$IFn$_invoke$arity$1 ? attr.cljs$core$IFn$_invoke$arity$1(v) : attr.call(null,v)))){
return cljs.core.conj.cljs$core$IFn$_invoke$arity$2(ret,c);
} else {
return ret;
}
});})(cs,solo_modes,attrs,solo_mode,change,changed))
,cljs.core.PersistentHashSet.EMPTY,chs);
});})(cs,solo_modes,attrs,solo_mode,change,changed))
;
var calc_state = ((function (cs,solo_modes,attrs,solo_mode,change,changed,pick){
return (function (){
var chs = cljs.core.deref(cs);
var mode = cljs.core.deref(solo_mode);
var solos = pick(cljs.core.cst$kw$solo,chs);
var pauses = pick(cljs.core.cst$kw$pause,chs);
return new cljs.core.PersistentArrayMap(null, 3, [cljs.core.cst$kw$solos,solos,cljs.core.cst$kw$mutes,pick(cljs.core.cst$kw$mute,chs),cljs.core.cst$kw$reads,cljs.core.conj.cljs$core$IFn$_invoke$arity$2(((((cljs.core._EQ_.cljs$core$IFn$_invoke$arity$2(mode,cljs.core.cst$kw$pause)) && ((!(cljs.core.empty_QMARK_(solos))))))?cljs.core.vec(solos):cljs.core.vec(cljs.core.remove.cljs$core$IFn$_invoke$arity$2(pauses,cljs.core.keys(chs)))),change)], null);
});})(cs,solo_modes,attrs,solo_mode,change,changed,pick))
;
var m = (function (){
if((typeof cljs !== 'undefined') && (typeof cljs.core !== 'undefined') && (typeof cljs.core.async !== 'undefined') && (typeof cljs.core.async.t_cljs$core$async8889 !== 'undefined')){
} else {

/**
* @constructor
 * @implements {cljs.core.IMeta}
 * @implements {cljs.core.async.Mix}
 * @implements {cljs.core.async.Mux}
 * @implements {cljs.core.IWithMeta}
*/
cljs.core.async.t_cljs$core$async8889 = (function (out,cs,solo_modes,attrs,solo_mode,change,changed,pick,calc_state,meta8890){
this.out = out;
this.cs = cs;
this.solo_modes = solo_modes;
this.attrs = attrs;
this.solo_mode = solo_mode;
this.change = change;
this.changed = changed;
this.pick = pick;
this.calc_state = calc_state;
this.meta8890 = meta8890;
this.cljs$lang$protocol_mask$partition0$ = 393216;
this.cljs$lang$protocol_mask$partition1$ = 0;
});
cljs.core.async.t_cljs$core$async8889.prototype.cljs$core$IWithMeta$_with_meta$arity$2 = ((function (cs,solo_modes,attrs,solo_mode,change,changed,pick,calc_state){
return (function (_8891,meta8890__$1){
var self__ = this;
var _8891__$1 = this;
return (new cljs.core.async.t_cljs$core$async8889(self__.out,self__.cs,self__.solo_modes,self__.attrs,self__.solo_mode,self__.change,self__.changed,self__.pick,self__.calc_state,meta8890__$1));
});})(cs,solo_modes,attrs,solo_mode,change,changed,pick,calc_state))
;

cljs.core.async.t_cljs$core$async8889.prototype.cljs$core$IMeta$_meta$arity$1 = ((function (cs,solo_modes,attrs,solo_mode,change,changed,pick,calc_state){
return (function (_8891){
var self__ = this;
var _8891__$1 = this;
return self__.meta8890;
});})(cs,solo_modes,attrs,solo_mode,change,changed,pick,calc_state))
;

cljs.core.async.t_cljs$core$async8889.prototype.cljs$core$async$Mux$ = cljs.core.PROTOCOL_SENTINEL;

cljs.core.async.t_cljs$core$async8889.prototype.cljs$core$async$Mux$muxch_STAR_$arity$1 = ((function (cs,solo_modes,attrs,solo_mode,change,changed,pick,calc_state){
return (function (_){
var self__ = this;
var ___$1 = this;
return self__.out;
});})(cs,solo_modes,attrs,solo_mode,change,changed,pick,calc_state))
;

cljs.core.async.t_cljs$core$async8889.prototype.cljs$core$async$Mix$ = cljs.core.PROTOCOL_SENTINEL;

cljs.core.async.t_cljs$core$async8889.prototype.cljs$core$async$Mix$admix_STAR_$arity$2 = ((function (cs,solo_modes,attrs,solo_mode,change,changed,pick,calc_state){
return (function (_,ch){
var self__ = this;
var ___$1 = this;
cljs.core.swap_BANG_.cljs$core$IFn$_invoke$arity$4(self__.cs,cljs.core.assoc,ch,cljs.core.PersistentArrayMap.EMPTY);

return (self__.changed.cljs$core$IFn$_invoke$arity$0 ? self__.changed.cljs$core$IFn$_invoke$arity$0() : self__.changed.call(null));
});})(cs,solo_modes,attrs,solo_mode,change,changed,pick,calc_state))
;

cljs.core.async.t_cljs$core$async8889.prototype.cljs$core$async$Mix$unmix_STAR_$arity$2 = ((function (cs,solo_modes,attrs,solo_mode,change,changed,pick,calc_state){
return (function (_,ch){
var self__ = this;
var ___$1 = this;
cljs.core.swap_BANG_.cljs$core$IFn$_invoke$arity$3(self__.cs,cljs.core.dissoc,ch);

return (self__.changed.cljs$core$IFn$_invoke$arity$0 ? self__.changed.cljs$core$IFn$_invoke$arity$0() : self__.changed.call(null));
});})(cs,solo_modes,attrs,solo_mode,change,changed,pick,calc_state))
;

cljs.core.async.t_cljs$core$async8889.prototype.cljs$core$async$Mix$unmix_all_STAR_$arity$1 = ((function (cs,solo_modes,attrs,solo_mode,change,changed,pick,calc_state){
return (function (_){
var self__ = this;
var ___$1 = this;
cljs.core.reset_BANG_(self__.cs,cljs.core.PersistentArrayMap.EMPTY);

return (self__.changed.cljs$core$IFn$_invoke$arity$0 ? self__.changed.cljs$core$IFn$_invoke$arity$0() : self__.changed.call(null));
});})(cs,solo_modes,attrs,solo_mode,change,changed,pick,calc_state))
;

cljs.core.async.t_cljs$core$async8889.prototype.cljs$core$async$Mix$toggle_STAR_$arity$2 = ((function (cs,solo_modes,attrs,solo_mode,change,changed,pick,calc_state){
return (function (_,state_map){
var self__ = this;
var ___$1 = this;
cljs.core.swap_BANG_.cljs$core$IFn$_invoke$arity$3(self__.cs,cljs.core.partial.cljs$core$IFn$_invoke$arity$2(cljs.core.merge_with,cljs.core.merge),state_map);

return (self__.changed.cljs$core$IFn$_invoke$arity$0 ? self__.changed.cljs$core$IFn$_invoke$arity$0() : self__.changed.call(null));
});})(cs,solo_modes,attrs,solo_mode,change,changed,pick,calc_state))
;

cljs.core.async.t_cljs$core$async8889.prototype.cljs$core$async$Mix$solo_mode_STAR_$arity$2 = ((function (cs,solo_modes,attrs,solo_mode,change,changed,pick,calc_state){
return (function (_,mode){
var self__ = this;
var ___$1 = this;

cljs.core.reset_BANG_(self__.solo_mode,mode);

return (self__.changed.cljs$core$IFn$_invoke$arity$0 ? self__.changed.cljs$core$IFn$_invoke$arity$0() : self__.changed.call(null));
});})(cs,solo_modes,attrs,solo_mode,change,changed,pick,calc_state))
;

cljs.core.async.t_cljs$core$async8889.getBasis = ((function (cs,solo_modes,attrs,solo_mode,change,changed,pick,calc_state){
return (function (){
return new cljs.core.PersistentVector(null, 10, 5, cljs.core.PersistentVector.EMPTY_NODE, [cljs.core.cst$sym$out,cljs.core.cst$sym$cs,cljs.core.cst$sym$solo_DASH_modes,cljs.core.cst$sym$attrs,cljs.core.cst$sym$solo_DASH_mode,cljs.core.cst$sym$change,cljs.core.cst$sym$changed,cljs.core.cst$sym$pick,cljs.core.cst$sym$calc_DASH_state,cljs.core.cst$sym$meta8890], null);
});})(cs,solo_modes,attrs,solo_mode,change,changed,pick,calc_state))
;

cljs.core.async.t_cljs$core$async8889.cljs$lang$type = true;

cljs.core.async.t_cljs$core$async8889.cljs$lang$ctorStr = "cljs.core.async/t_cljs$core$async8889";

cljs.core.async.t_cljs$core$async8889.cljs$lang$ctorPrWriter = ((function (cs,solo_modes,attrs,solo_mode,change,changed,pick,calc_state){
return (function (this__4290__auto__,writer__4291__auto__,opt__4292__auto__){
return cljs.core._write(writer__4291__auto__,"cljs.core.async/t_cljs$core$async8889");
});})(cs,solo_modes,attrs,solo_mode,change,changed,pick,calc_state))
;

/**
 * Positional factory function for cljs.core.async/t_cljs$core$async8889.
 */
cljs.core.async.__GT_t_cljs$core$async8889 = ((function (cs,solo_modes,attrs,solo_mode,change,changed,pick,calc_state){
return (function cljs$core$async$mix_$___GT_t_cljs$core$async8889(out__$1,cs__$1,solo_modes__$1,attrs__$1,solo_mode__$1,change__$1,changed__$1,pick__$1,calc_state__$1,meta8890){
return (new cljs.core.async.t_cljs$core$async8889(out__$1,cs__$1,solo_modes__$1,attrs__$1,solo_mode__$1,change__$1,changed__$1,pick__$1,calc_state__$1,meta8890));
});})(cs,solo_modes,attrs,solo_mode,change,changed,pick,calc_state))
;

}

return (new cljs.core.async.t_cljs$core$async8889(out,cs,solo_modes,attrs,solo_mode,change,changed,pick,calc_state,cljs.core.PersistentArrayMap.EMPTY));
})()
;
var c__7992__auto___9053 = cljs.core.async.chan.cljs$core$IFn$_invoke$arity$1((1));
cljs.core.async.impl.dispatch.run(((function (c__7992__auto___9053,cs,solo_modes,attrs,solo_mode,change,changed,pick,calc_state,m){
return (function (){
var f__7993__auto__ = (function (){var switch__7885__auto__ = ((function (c__7992__auto___9053,cs,solo_modes,attrs,solo_mode,change,changed,pick,calc_state,m){
return (function (state_8993){
var state_val_8994 = (state_8993[(1)]);
if((state_val_8994 === (7))){
var inst_8908 = (state_8993[(2)]);
var state_8993__$1 = state_8993;
var statearr_8995_9054 = state_8993__$1;
(statearr_8995_9054[(2)] = inst_8908);

(statearr_8995_9054[(1)] = (4));


return cljs.core.cst$kw$recur;
} else {
if((state_val_8994 === (20))){
var inst_8920 = (state_8993[(7)]);
var state_8993__$1 = state_8993;
var statearr_8996_9055 = state_8993__$1;
(statearr_8996_9055[(2)] = inst_8920);

(statearr_8996_9055[(1)] = (21));


return cljs.core.cst$kw$recur;
} else {
if((state_val_8994 === (27))){
var state_8993__$1 = state_8993;
var statearr_8997_9056 = state_8993__$1;
(statearr_8997_9056[(2)] = null);

(statearr_8997_9056[(1)] = (28));


return cljs.core.cst$kw$recur;
} else {
if((state_val_8994 === (1))){
var inst_8895 = (state_8993[(8)]);
var inst_8895__$1 = calc_state();
var inst_8897 = (inst_8895__$1 == null);
var inst_8898 = cljs.core.not(inst_8897);
var state_8993__$1 = (function (){var statearr_8998 = state_8993;
(statearr_8998[(8)] = inst_8895__$1);

return statearr_8998;
})();
if(inst_8898){
var statearr_8999_9057 = state_8993__$1;
(statearr_8999_9057[(1)] = (2));

} else {
var statearr_9000_9058 = state_8993__$1;
(statearr_9000_9058[(1)] = (3));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_8994 === (24))){
var inst_8944 = (state_8993[(9)]);
var inst_8967 = (state_8993[(10)]);
var inst_8953 = (state_8993[(11)]);
var inst_8967__$1 = (inst_8944.cljs$core$IFn$_invoke$arity$1 ? inst_8944.cljs$core$IFn$_invoke$arity$1(inst_8953) : inst_8944.call(null,inst_8953));
var state_8993__$1 = (function (){var statearr_9001 = state_8993;
(statearr_9001[(10)] = inst_8967__$1);

return statearr_9001;
})();
if(cljs.core.truth_(inst_8967__$1)){
var statearr_9002_9059 = state_8993__$1;
(statearr_9002_9059[(1)] = (29));

} else {
var statearr_9003_9060 = state_8993__$1;
(statearr_9003_9060[(1)] = (30));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_8994 === (4))){
var inst_8911 = (state_8993[(2)]);
var state_8993__$1 = state_8993;
if(cljs.core.truth_(inst_8911)){
var statearr_9004_9061 = state_8993__$1;
(statearr_9004_9061[(1)] = (8));

} else {
var statearr_9005_9062 = state_8993__$1;
(statearr_9005_9062[(1)] = (9));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_8994 === (15))){
var inst_8938 = (state_8993[(2)]);
var state_8993__$1 = state_8993;
if(cljs.core.truth_(inst_8938)){
var statearr_9006_9063 = state_8993__$1;
(statearr_9006_9063[(1)] = (19));

} else {
var statearr_9007_9064 = state_8993__$1;
(statearr_9007_9064[(1)] = (20));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_8994 === (21))){
var inst_8943 = (state_8993[(12)]);
var inst_8943__$1 = (state_8993[(2)]);
var inst_8944 = cljs.core.get.cljs$core$IFn$_invoke$arity$2(inst_8943__$1,cljs.core.cst$kw$solos);
var inst_8945 = cljs.core.get.cljs$core$IFn$_invoke$arity$2(inst_8943__$1,cljs.core.cst$kw$mutes);
var inst_8946 = cljs.core.get.cljs$core$IFn$_invoke$arity$2(inst_8943__$1,cljs.core.cst$kw$reads);
var state_8993__$1 = (function (){var statearr_9008 = state_8993;
(statearr_9008[(9)] = inst_8944);

(statearr_9008[(13)] = inst_8945);

(statearr_9008[(12)] = inst_8943__$1);

return statearr_9008;
})();
return cljs.core.async.ioc_alts_BANG_(state_8993__$1,(22),inst_8946);
} else {
if((state_val_8994 === (31))){
var inst_8975 = (state_8993[(2)]);
var state_8993__$1 = state_8993;
if(cljs.core.truth_(inst_8975)){
var statearr_9009_9065 = state_8993__$1;
(statearr_9009_9065[(1)] = (32));

} else {
var statearr_9010_9066 = state_8993__$1;
(statearr_9010_9066[(1)] = (33));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_8994 === (32))){
var inst_8952 = (state_8993[(14)]);
var state_8993__$1 = state_8993;
return cljs.core.async.impl.ioc_helpers.put_BANG_(state_8993__$1,(35),out,inst_8952);
} else {
if((state_val_8994 === (33))){
var inst_8943 = (state_8993[(12)]);
var inst_8920 = inst_8943;
var state_8993__$1 = (function (){var statearr_9011 = state_8993;
(statearr_9011[(7)] = inst_8920);

return statearr_9011;
})();
var statearr_9012_9067 = state_8993__$1;
(statearr_9012_9067[(2)] = null);

(statearr_9012_9067[(1)] = (11));


return cljs.core.cst$kw$recur;
} else {
if((state_val_8994 === (13))){
var inst_8920 = (state_8993[(7)]);
var inst_8927 = inst_8920.cljs$lang$protocol_mask$partition0$;
var inst_8928 = (inst_8927 & (64));
var inst_8929 = inst_8920.cljs$core$ISeq$;
var inst_8930 = (cljs.core.PROTOCOL_SENTINEL === inst_8929);
var inst_8931 = ((inst_8928) || (inst_8930));
var state_8993__$1 = state_8993;
if(cljs.core.truth_(inst_8931)){
var statearr_9013_9068 = state_8993__$1;
(statearr_9013_9068[(1)] = (16));

} else {
var statearr_9014_9069 = state_8993__$1;
(statearr_9014_9069[(1)] = (17));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_8994 === (22))){
var inst_8952 = (state_8993[(14)]);
var inst_8953 = (state_8993[(11)]);
var inst_8951 = (state_8993[(2)]);
var inst_8952__$1 = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(inst_8951,(0),null);
var inst_8953__$1 = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(inst_8951,(1),null);
var inst_8954 = (inst_8952__$1 == null);
var inst_8955 = cljs.core._EQ_.cljs$core$IFn$_invoke$arity$2(inst_8953__$1,change);
var inst_8956 = ((inst_8954) || (inst_8955));
var state_8993__$1 = (function (){var statearr_9015 = state_8993;
(statearr_9015[(14)] = inst_8952__$1);

(statearr_9015[(11)] = inst_8953__$1);

return statearr_9015;
})();
if(cljs.core.truth_(inst_8956)){
var statearr_9016_9070 = state_8993__$1;
(statearr_9016_9070[(1)] = (23));

} else {
var statearr_9017_9071 = state_8993__$1;
(statearr_9017_9071[(1)] = (24));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_8994 === (36))){
var inst_8943 = (state_8993[(12)]);
var inst_8920 = inst_8943;
var state_8993__$1 = (function (){var statearr_9018 = state_8993;
(statearr_9018[(7)] = inst_8920);

return statearr_9018;
})();
var statearr_9019_9072 = state_8993__$1;
(statearr_9019_9072[(2)] = null);

(statearr_9019_9072[(1)] = (11));


return cljs.core.cst$kw$recur;
} else {
if((state_val_8994 === (29))){
var inst_8967 = (state_8993[(10)]);
var state_8993__$1 = state_8993;
var statearr_9020_9073 = state_8993__$1;
(statearr_9020_9073[(2)] = inst_8967);

(statearr_9020_9073[(1)] = (31));


return cljs.core.cst$kw$recur;
} else {
if((state_val_8994 === (6))){
var state_8993__$1 = state_8993;
var statearr_9021_9074 = state_8993__$1;
(statearr_9021_9074[(2)] = false);

(statearr_9021_9074[(1)] = (7));


return cljs.core.cst$kw$recur;
} else {
if((state_val_8994 === (28))){
var inst_8963 = (state_8993[(2)]);
var inst_8964 = calc_state();
var inst_8920 = inst_8964;
var state_8993__$1 = (function (){var statearr_9022 = state_8993;
(statearr_9022[(15)] = inst_8963);

(statearr_9022[(7)] = inst_8920);

return statearr_9022;
})();
var statearr_9023_9075 = state_8993__$1;
(statearr_9023_9075[(2)] = null);

(statearr_9023_9075[(1)] = (11));


return cljs.core.cst$kw$recur;
} else {
if((state_val_8994 === (25))){
var inst_8989 = (state_8993[(2)]);
var state_8993__$1 = state_8993;
var statearr_9024_9076 = state_8993__$1;
(statearr_9024_9076[(2)] = inst_8989);

(statearr_9024_9076[(1)] = (12));


return cljs.core.cst$kw$recur;
} else {
if((state_val_8994 === (34))){
var inst_8987 = (state_8993[(2)]);
var state_8993__$1 = state_8993;
var statearr_9025_9077 = state_8993__$1;
(statearr_9025_9077[(2)] = inst_8987);

(statearr_9025_9077[(1)] = (25));


return cljs.core.cst$kw$recur;
} else {
if((state_val_8994 === (17))){
var state_8993__$1 = state_8993;
var statearr_9026_9078 = state_8993__$1;
(statearr_9026_9078[(2)] = false);

(statearr_9026_9078[(1)] = (18));


return cljs.core.cst$kw$recur;
} else {
if((state_val_8994 === (3))){
var state_8993__$1 = state_8993;
var statearr_9027_9079 = state_8993__$1;
(statearr_9027_9079[(2)] = false);

(statearr_9027_9079[(1)] = (4));


return cljs.core.cst$kw$recur;
} else {
if((state_val_8994 === (12))){
var inst_8991 = (state_8993[(2)]);
var state_8993__$1 = state_8993;
return cljs.core.async.impl.ioc_helpers.return_chan(state_8993__$1,inst_8991);
} else {
if((state_val_8994 === (2))){
var inst_8895 = (state_8993[(8)]);
var inst_8900 = inst_8895.cljs$lang$protocol_mask$partition0$;
var inst_8901 = (inst_8900 & (64));
var inst_8902 = inst_8895.cljs$core$ISeq$;
var inst_8903 = (cljs.core.PROTOCOL_SENTINEL === inst_8902);
var inst_8904 = ((inst_8901) || (inst_8903));
var state_8993__$1 = state_8993;
if(cljs.core.truth_(inst_8904)){
var statearr_9028_9080 = state_8993__$1;
(statearr_9028_9080[(1)] = (5));

} else {
var statearr_9029_9081 = state_8993__$1;
(statearr_9029_9081[(1)] = (6));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_8994 === (23))){
var inst_8952 = (state_8993[(14)]);
var inst_8958 = (inst_8952 == null);
var state_8993__$1 = state_8993;
if(cljs.core.truth_(inst_8958)){
var statearr_9030_9082 = state_8993__$1;
(statearr_9030_9082[(1)] = (26));

} else {
var statearr_9031_9083 = state_8993__$1;
(statearr_9031_9083[(1)] = (27));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_8994 === (35))){
var inst_8978 = (state_8993[(2)]);
var state_8993__$1 = state_8993;
if(cljs.core.truth_(inst_8978)){
var statearr_9032_9084 = state_8993__$1;
(statearr_9032_9084[(1)] = (36));

} else {
var statearr_9033_9085 = state_8993__$1;
(statearr_9033_9085[(1)] = (37));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_8994 === (19))){
var inst_8920 = (state_8993[(7)]);
var inst_8940 = cljs.core.apply.cljs$core$IFn$_invoke$arity$2(cljs.core.hash_map,inst_8920);
var state_8993__$1 = state_8993;
var statearr_9034_9086 = state_8993__$1;
(statearr_9034_9086[(2)] = inst_8940);

(statearr_9034_9086[(1)] = (21));


return cljs.core.cst$kw$recur;
} else {
if((state_val_8994 === (11))){
var inst_8920 = (state_8993[(7)]);
var inst_8924 = (inst_8920 == null);
var inst_8925 = cljs.core.not(inst_8924);
var state_8993__$1 = state_8993;
if(inst_8925){
var statearr_9035_9087 = state_8993__$1;
(statearr_9035_9087[(1)] = (13));

} else {
var statearr_9036_9088 = state_8993__$1;
(statearr_9036_9088[(1)] = (14));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_8994 === (9))){
var inst_8895 = (state_8993[(8)]);
var state_8993__$1 = state_8993;
var statearr_9037_9089 = state_8993__$1;
(statearr_9037_9089[(2)] = inst_8895);

(statearr_9037_9089[(1)] = (10));


return cljs.core.cst$kw$recur;
} else {
if((state_val_8994 === (5))){
var state_8993__$1 = state_8993;
var statearr_9038_9090 = state_8993__$1;
(statearr_9038_9090[(2)] = true);

(statearr_9038_9090[(1)] = (7));


return cljs.core.cst$kw$recur;
} else {
if((state_val_8994 === (14))){
var state_8993__$1 = state_8993;
var statearr_9039_9091 = state_8993__$1;
(statearr_9039_9091[(2)] = false);

(statearr_9039_9091[(1)] = (15));


return cljs.core.cst$kw$recur;
} else {
if((state_val_8994 === (26))){
var inst_8953 = (state_8993[(11)]);
var inst_8960 = cljs.core.swap_BANG_.cljs$core$IFn$_invoke$arity$3(cs,cljs.core.dissoc,inst_8953);
var state_8993__$1 = state_8993;
var statearr_9040_9092 = state_8993__$1;
(statearr_9040_9092[(2)] = inst_8960);

(statearr_9040_9092[(1)] = (28));


return cljs.core.cst$kw$recur;
} else {
if((state_val_8994 === (16))){
var state_8993__$1 = state_8993;
var statearr_9041_9093 = state_8993__$1;
(statearr_9041_9093[(2)] = true);

(statearr_9041_9093[(1)] = (18));


return cljs.core.cst$kw$recur;
} else {
if((state_val_8994 === (38))){
var inst_8983 = (state_8993[(2)]);
var state_8993__$1 = state_8993;
var statearr_9042_9094 = state_8993__$1;
(statearr_9042_9094[(2)] = inst_8983);

(statearr_9042_9094[(1)] = (34));


return cljs.core.cst$kw$recur;
} else {
if((state_val_8994 === (30))){
var inst_8944 = (state_8993[(9)]);
var inst_8945 = (state_8993[(13)]);
var inst_8953 = (state_8993[(11)]);
var inst_8970 = cljs.core.empty_QMARK_(inst_8944);
var inst_8971 = (inst_8945.cljs$core$IFn$_invoke$arity$1 ? inst_8945.cljs$core$IFn$_invoke$arity$1(inst_8953) : inst_8945.call(null,inst_8953));
var inst_8972 = cljs.core.not(inst_8971);
var inst_8973 = ((inst_8970) && (inst_8972));
var state_8993__$1 = state_8993;
var statearr_9043_9095 = state_8993__$1;
(statearr_9043_9095[(2)] = inst_8973);

(statearr_9043_9095[(1)] = (31));


return cljs.core.cst$kw$recur;
} else {
if((state_val_8994 === (10))){
var inst_8895 = (state_8993[(8)]);
var inst_8916 = (state_8993[(2)]);
var inst_8917 = cljs.core.get.cljs$core$IFn$_invoke$arity$2(inst_8916,cljs.core.cst$kw$solos);
var inst_8918 = cljs.core.get.cljs$core$IFn$_invoke$arity$2(inst_8916,cljs.core.cst$kw$mutes);
var inst_8919 = cljs.core.get.cljs$core$IFn$_invoke$arity$2(inst_8916,cljs.core.cst$kw$reads);
var inst_8920 = inst_8895;
var state_8993__$1 = (function (){var statearr_9044 = state_8993;
(statearr_9044[(16)] = inst_8917);

(statearr_9044[(17)] = inst_8919);

(statearr_9044[(7)] = inst_8920);

(statearr_9044[(18)] = inst_8918);

return statearr_9044;
})();
var statearr_9045_9096 = state_8993__$1;
(statearr_9045_9096[(2)] = null);

(statearr_9045_9096[(1)] = (11));


return cljs.core.cst$kw$recur;
} else {
if((state_val_8994 === (18))){
var inst_8935 = (state_8993[(2)]);
var state_8993__$1 = state_8993;
var statearr_9046_9097 = state_8993__$1;
(statearr_9046_9097[(2)] = inst_8935);

(statearr_9046_9097[(1)] = (15));


return cljs.core.cst$kw$recur;
} else {
if((state_val_8994 === (37))){
var state_8993__$1 = state_8993;
var statearr_9047_9098 = state_8993__$1;
(statearr_9047_9098[(2)] = null);

(statearr_9047_9098[(1)] = (38));


return cljs.core.cst$kw$recur;
} else {
if((state_val_8994 === (8))){
var inst_8895 = (state_8993[(8)]);
var inst_8913 = cljs.core.apply.cljs$core$IFn$_invoke$arity$2(cljs.core.hash_map,inst_8895);
var state_8993__$1 = state_8993;
var statearr_9048_9099 = state_8993__$1;
(statearr_9048_9099[(2)] = inst_8913);

(statearr_9048_9099[(1)] = (10));


return cljs.core.cst$kw$recur;
} else {
return null;
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
});})(c__7992__auto___9053,cs,solo_modes,attrs,solo_mode,change,changed,pick,calc_state,m))
;
return ((function (switch__7885__auto__,c__7992__auto___9053,cs,solo_modes,attrs,solo_mode,change,changed,pick,calc_state,m){
return (function() {
var cljs$core$async$mix_$_state_machine__7886__auto__ = null;
var cljs$core$async$mix_$_state_machine__7886__auto____0 = (function (){
var statearr_9049 = [null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null];
(statearr_9049[(0)] = cljs$core$async$mix_$_state_machine__7886__auto__);

(statearr_9049[(1)] = (1));

return statearr_9049;
});
var cljs$core$async$mix_$_state_machine__7886__auto____1 = (function (state_8993){
while(true){
var ret_value__7887__auto__ = (function (){try{while(true){
var result__7888__auto__ = switch__7885__auto__(state_8993);
if(cljs.core.keyword_identical_QMARK_(result__7888__auto__,cljs.core.cst$kw$recur)){
continue;
} else {
return result__7888__auto__;
}
break;
}
}catch (e9050){if((e9050 instanceof Object)){
var ex__7889__auto__ = e9050;
var statearr_9051_9100 = state_8993;
(statearr_9051_9100[(5)] = ex__7889__auto__);


cljs.core.async.impl.ioc_helpers.process_exception(state_8993);

return cljs.core.cst$kw$recur;
} else {
throw e9050;

}
}})();
if(cljs.core.keyword_identical_QMARK_(ret_value__7887__auto__,cljs.core.cst$kw$recur)){
var G__9101 = state_8993;
state_8993 = G__9101;
continue;
} else {
return ret_value__7887__auto__;
}
break;
}
});
cljs$core$async$mix_$_state_machine__7886__auto__ = function(state_8993){
switch(arguments.length){
case 0:
return cljs$core$async$mix_$_state_machine__7886__auto____0.call(this);
case 1:
return cljs$core$async$mix_$_state_machine__7886__auto____1.call(this,state_8993);
}
throw(new Error('Invalid arity: ' + arguments.length));
};
cljs$core$async$mix_$_state_machine__7886__auto__.cljs$core$IFn$_invoke$arity$0 = cljs$core$async$mix_$_state_machine__7886__auto____0;
cljs$core$async$mix_$_state_machine__7886__auto__.cljs$core$IFn$_invoke$arity$1 = cljs$core$async$mix_$_state_machine__7886__auto____1;
return cljs$core$async$mix_$_state_machine__7886__auto__;
})()
;})(switch__7885__auto__,c__7992__auto___9053,cs,solo_modes,attrs,solo_mode,change,changed,pick,calc_state,m))
})();
var state__7994__auto__ = (function (){var statearr_9052 = (f__7993__auto__.cljs$core$IFn$_invoke$arity$0 ? f__7993__auto__.cljs$core$IFn$_invoke$arity$0() : f__7993__auto__.call(null));
(statearr_9052[(6)] = c__7992__auto___9053);

return statearr_9052;
})();
return cljs.core.async.impl.ioc_helpers.run_state_machine_wrapped(state__7994__auto__);
});})(c__7992__auto___9053,cs,solo_modes,attrs,solo_mode,change,changed,pick,calc_state,m))
);


return m;
});
/**
 * Adds ch as an input to the mix
 */
cljs.core.async.admix = (function cljs$core$async$admix(mix,ch){
return cljs.core.async.admix_STAR_(mix,ch);
});
/**
 * Removes ch as an input to the mix
 */
cljs.core.async.unmix = (function cljs$core$async$unmix(mix,ch){
return cljs.core.async.unmix_STAR_(mix,ch);
});
/**
 * removes all inputs from the mix
 */
cljs.core.async.unmix_all = (function cljs$core$async$unmix_all(mix){
return cljs.core.async.unmix_all_STAR_(mix);
});
/**
 * Atomically sets the state(s) of one or more channels in a mix. The
 *   state map is a map of channels -> channel-state-map. A
 *   channel-state-map is a map of attrs -> boolean, where attr is one or
 *   more of :mute, :pause or :solo. Any states supplied are merged with
 *   the current state.
 * 
 *   Note that channels can be added to a mix via toggle, which can be
 *   used to add channels in a particular (e.g. paused) state.
 */
cljs.core.async.toggle = (function cljs$core$async$toggle(mix,state_map){
return cljs.core.async.toggle_STAR_(mix,state_map);
});
/**
 * Sets the solo mode of the mix. mode must be one of :mute or :pause
 */
cljs.core.async.solo_mode = (function cljs$core$async$solo_mode(mix,mode){
return cljs.core.async.solo_mode_STAR_(mix,mode);
});

/**
 * @interface
 */
cljs.core.async.Pub = function(){};

cljs.core.async.sub_STAR_ = (function cljs$core$async$sub_STAR_(p,v,ch,close_QMARK_){
if((((!((p == null)))) && ((!((p.cljs$core$async$Pub$sub_STAR_$arity$4 == null)))))){
return p.cljs$core$async$Pub$sub_STAR_$arity$4(p,v,ch,close_QMARK_);
} else {
var x__4347__auto__ = (((p == null))?null:p);
var m__4348__auto__ = (cljs.core.async.sub_STAR_[goog.typeOf(x__4347__auto__)]);
if((!((m__4348__auto__ == null)))){
return (m__4348__auto__.cljs$core$IFn$_invoke$arity$4 ? m__4348__auto__.cljs$core$IFn$_invoke$arity$4(p,v,ch,close_QMARK_) : m__4348__auto__.call(null,p,v,ch,close_QMARK_));
} else {
var m__4348__auto____$1 = (cljs.core.async.sub_STAR_["_"]);
if((!((m__4348__auto____$1 == null)))){
return (m__4348__auto____$1.cljs$core$IFn$_invoke$arity$4 ? m__4348__auto____$1.cljs$core$IFn$_invoke$arity$4(p,v,ch,close_QMARK_) : m__4348__auto____$1.call(null,p,v,ch,close_QMARK_));
} else {
throw cljs.core.missing_protocol("Pub.sub*",p);
}
}
}
});

cljs.core.async.unsub_STAR_ = (function cljs$core$async$unsub_STAR_(p,v,ch){
if((((!((p == null)))) && ((!((p.cljs$core$async$Pub$unsub_STAR_$arity$3 == null)))))){
return p.cljs$core$async$Pub$unsub_STAR_$arity$3(p,v,ch);
} else {
var x__4347__auto__ = (((p == null))?null:p);
var m__4348__auto__ = (cljs.core.async.unsub_STAR_[goog.typeOf(x__4347__auto__)]);
if((!((m__4348__auto__ == null)))){
return (m__4348__auto__.cljs$core$IFn$_invoke$arity$3 ? m__4348__auto__.cljs$core$IFn$_invoke$arity$3(p,v,ch) : m__4348__auto__.call(null,p,v,ch));
} else {
var m__4348__auto____$1 = (cljs.core.async.unsub_STAR_["_"]);
if((!((m__4348__auto____$1 == null)))){
return (m__4348__auto____$1.cljs$core$IFn$_invoke$arity$3 ? m__4348__auto____$1.cljs$core$IFn$_invoke$arity$3(p,v,ch) : m__4348__auto____$1.call(null,p,v,ch));
} else {
throw cljs.core.missing_protocol("Pub.unsub*",p);
}
}
}
});

cljs.core.async.unsub_all_STAR_ = (function cljs$core$async$unsub_all_STAR_(var_args){
var G__9103 = arguments.length;
switch (G__9103) {
case 1:
return cljs.core.async.unsub_all_STAR_.cljs$core$IFn$_invoke$arity$1((arguments[(0)]));

break;
case 2:
return cljs.core.async.unsub_all_STAR_.cljs$core$IFn$_invoke$arity$2((arguments[(0)]),(arguments[(1)]));

break;
default:
throw (new Error(["Invalid arity: ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(arguments.length)].join('')));

}
});

cljs.core.async.unsub_all_STAR_.cljs$core$IFn$_invoke$arity$1 = (function (p){
if((((!((p == null)))) && ((!((p.cljs$core$async$Pub$unsub_all_STAR_$arity$1 == null)))))){
return p.cljs$core$async$Pub$unsub_all_STAR_$arity$1(p);
} else {
var x__4347__auto__ = (((p == null))?null:p);
var m__4348__auto__ = (cljs.core.async.unsub_all_STAR_[goog.typeOf(x__4347__auto__)]);
if((!((m__4348__auto__ == null)))){
return (m__4348__auto__.cljs$core$IFn$_invoke$arity$1 ? m__4348__auto__.cljs$core$IFn$_invoke$arity$1(p) : m__4348__auto__.call(null,p));
} else {
var m__4348__auto____$1 = (cljs.core.async.unsub_all_STAR_["_"]);
if((!((m__4348__auto____$1 == null)))){
return (m__4348__auto____$1.cljs$core$IFn$_invoke$arity$1 ? m__4348__auto____$1.cljs$core$IFn$_invoke$arity$1(p) : m__4348__auto____$1.call(null,p));
} else {
throw cljs.core.missing_protocol("Pub.unsub-all*",p);
}
}
}
});

cljs.core.async.unsub_all_STAR_.cljs$core$IFn$_invoke$arity$2 = (function (p,v){
if((((!((p == null)))) && ((!((p.cljs$core$async$Pub$unsub_all_STAR_$arity$2 == null)))))){
return p.cljs$core$async$Pub$unsub_all_STAR_$arity$2(p,v);
} else {
var x__4347__auto__ = (((p == null))?null:p);
var m__4348__auto__ = (cljs.core.async.unsub_all_STAR_[goog.typeOf(x__4347__auto__)]);
if((!((m__4348__auto__ == null)))){
return (m__4348__auto__.cljs$core$IFn$_invoke$arity$2 ? m__4348__auto__.cljs$core$IFn$_invoke$arity$2(p,v) : m__4348__auto__.call(null,p,v));
} else {
var m__4348__auto____$1 = (cljs.core.async.unsub_all_STAR_["_"]);
if((!((m__4348__auto____$1 == null)))){
return (m__4348__auto____$1.cljs$core$IFn$_invoke$arity$2 ? m__4348__auto____$1.cljs$core$IFn$_invoke$arity$2(p,v) : m__4348__auto____$1.call(null,p,v));
} else {
throw cljs.core.missing_protocol("Pub.unsub-all*",p);
}
}
}
});

cljs.core.async.unsub_all_STAR_.cljs$lang$maxFixedArity = 2;


/**
 * Creates and returns a pub(lication) of the supplied channel,
 *   partitioned into topics by the topic-fn. topic-fn will be applied to
 *   each value on the channel and the result will determine the 'topic'
 *   on which that value will be put. Channels can be subscribed to
 *   receive copies of topics using 'sub', and unsubscribed using
 *   'unsub'. Each topic will be handled by an internal mult on a
 *   dedicated channel. By default these internal channels are
 *   unbuffered, but a buf-fn can be supplied which, given a topic,
 *   creates a buffer with desired properties.
 * 
 *   Each item is distributed to all subs in parallel and synchronously,
 *   i.e. each sub must accept before the next item is distributed. Use
 *   buffering/windowing to prevent slow subs from holding up the pub.
 * 
 *   Items received when there are no matching subs get dropped.
 * 
 *   Note that if buf-fns are used then each topic is handled
 *   asynchronously, i.e. if a channel is subscribed to more than one
 *   topic it should not expect them to be interleaved identically with
 *   the source.
 */
cljs.core.async.pub = (function cljs$core$async$pub(var_args){
var G__9107 = arguments.length;
switch (G__9107) {
case 2:
return cljs.core.async.pub.cljs$core$IFn$_invoke$arity$2((arguments[(0)]),(arguments[(1)]));

break;
case 3:
return cljs.core.async.pub.cljs$core$IFn$_invoke$arity$3((arguments[(0)]),(arguments[(1)]),(arguments[(2)]));

break;
default:
throw (new Error(["Invalid arity: ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(arguments.length)].join('')));

}
});

cljs.core.async.pub.cljs$core$IFn$_invoke$arity$2 = (function (ch,topic_fn){
return cljs.core.async.pub.cljs$core$IFn$_invoke$arity$3(ch,topic_fn,cljs.core.constantly(null));
});

cljs.core.async.pub.cljs$core$IFn$_invoke$arity$3 = (function (ch,topic_fn,buf_fn){
var mults = cljs.core.atom.cljs$core$IFn$_invoke$arity$1(cljs.core.PersistentArrayMap.EMPTY);
var ensure_mult = ((function (mults){
return (function (topic){
var or__4047__auto__ = cljs.core.get.cljs$core$IFn$_invoke$arity$2(cljs.core.deref(mults),topic);
if(cljs.core.truth_(or__4047__auto__)){
return or__4047__auto__;
} else {
return cljs.core.get.cljs$core$IFn$_invoke$arity$2(cljs.core.swap_BANG_.cljs$core$IFn$_invoke$arity$2(mults,((function (or__4047__auto__,mults){
return (function (p1__9105_SHARP_){
if(cljs.core.truth_((p1__9105_SHARP_.cljs$core$IFn$_invoke$arity$1 ? p1__9105_SHARP_.cljs$core$IFn$_invoke$arity$1(topic) : p1__9105_SHARP_.call(null,topic)))){
return p1__9105_SHARP_;
} else {
return cljs.core.assoc.cljs$core$IFn$_invoke$arity$3(p1__9105_SHARP_,topic,cljs.core.async.mult(cljs.core.async.chan.cljs$core$IFn$_invoke$arity$1((buf_fn.cljs$core$IFn$_invoke$arity$1 ? buf_fn.cljs$core$IFn$_invoke$arity$1(topic) : buf_fn.call(null,topic)))));
}
});})(or__4047__auto__,mults))
),topic);
}
});})(mults))
;
var p = (function (){
if((typeof cljs !== 'undefined') && (typeof cljs.core !== 'undefined') && (typeof cljs.core.async !== 'undefined') && (typeof cljs.core.async.t_cljs$core$async9108 !== 'undefined')){
} else {

/**
* @constructor
 * @implements {cljs.core.async.Pub}
 * @implements {cljs.core.IMeta}
 * @implements {cljs.core.async.Mux}
 * @implements {cljs.core.IWithMeta}
*/
cljs.core.async.t_cljs$core$async9108 = (function (ch,topic_fn,buf_fn,mults,ensure_mult,meta9109){
this.ch = ch;
this.topic_fn = topic_fn;
this.buf_fn = buf_fn;
this.mults = mults;
this.ensure_mult = ensure_mult;
this.meta9109 = meta9109;
this.cljs$lang$protocol_mask$partition0$ = 393216;
this.cljs$lang$protocol_mask$partition1$ = 0;
});
cljs.core.async.t_cljs$core$async9108.prototype.cljs$core$IWithMeta$_with_meta$arity$2 = ((function (mults,ensure_mult){
return (function (_9110,meta9109__$1){
var self__ = this;
var _9110__$1 = this;
return (new cljs.core.async.t_cljs$core$async9108(self__.ch,self__.topic_fn,self__.buf_fn,self__.mults,self__.ensure_mult,meta9109__$1));
});})(mults,ensure_mult))
;

cljs.core.async.t_cljs$core$async9108.prototype.cljs$core$IMeta$_meta$arity$1 = ((function (mults,ensure_mult){
return (function (_9110){
var self__ = this;
var _9110__$1 = this;
return self__.meta9109;
});})(mults,ensure_mult))
;

cljs.core.async.t_cljs$core$async9108.prototype.cljs$core$async$Mux$ = cljs.core.PROTOCOL_SENTINEL;

cljs.core.async.t_cljs$core$async9108.prototype.cljs$core$async$Mux$muxch_STAR_$arity$1 = ((function (mults,ensure_mult){
return (function (_){
var self__ = this;
var ___$1 = this;
return self__.ch;
});})(mults,ensure_mult))
;

cljs.core.async.t_cljs$core$async9108.prototype.cljs$core$async$Pub$ = cljs.core.PROTOCOL_SENTINEL;

cljs.core.async.t_cljs$core$async9108.prototype.cljs$core$async$Pub$sub_STAR_$arity$4 = ((function (mults,ensure_mult){
return (function (p,topic,ch__$1,close_QMARK_){
var self__ = this;
var p__$1 = this;
var m = (self__.ensure_mult.cljs$core$IFn$_invoke$arity$1 ? self__.ensure_mult.cljs$core$IFn$_invoke$arity$1(topic) : self__.ensure_mult.call(null,topic));
return cljs.core.async.tap.cljs$core$IFn$_invoke$arity$3(m,ch__$1,close_QMARK_);
});})(mults,ensure_mult))
;

cljs.core.async.t_cljs$core$async9108.prototype.cljs$core$async$Pub$unsub_STAR_$arity$3 = ((function (mults,ensure_mult){
return (function (p,topic,ch__$1){
var self__ = this;
var p__$1 = this;
var temp__5457__auto__ = cljs.core.get.cljs$core$IFn$_invoke$arity$2(cljs.core.deref(self__.mults),topic);
if(cljs.core.truth_(temp__5457__auto__)){
var m = temp__5457__auto__;
return cljs.core.async.untap(m,ch__$1);
} else {
return null;
}
});})(mults,ensure_mult))
;

cljs.core.async.t_cljs$core$async9108.prototype.cljs$core$async$Pub$unsub_all_STAR_$arity$1 = ((function (mults,ensure_mult){
return (function (_){
var self__ = this;
var ___$1 = this;
return cljs.core.reset_BANG_(self__.mults,cljs.core.PersistentArrayMap.EMPTY);
});})(mults,ensure_mult))
;

cljs.core.async.t_cljs$core$async9108.prototype.cljs$core$async$Pub$unsub_all_STAR_$arity$2 = ((function (mults,ensure_mult){
return (function (_,topic){
var self__ = this;
var ___$1 = this;
return cljs.core.swap_BANG_.cljs$core$IFn$_invoke$arity$3(self__.mults,cljs.core.dissoc,topic);
});})(mults,ensure_mult))
;

cljs.core.async.t_cljs$core$async9108.getBasis = ((function (mults,ensure_mult){
return (function (){
return new cljs.core.PersistentVector(null, 6, 5, cljs.core.PersistentVector.EMPTY_NODE, [cljs.core.cst$sym$ch,cljs.core.cst$sym$topic_DASH_fn,cljs.core.cst$sym$buf_DASH_fn,cljs.core.cst$sym$mults,cljs.core.cst$sym$ensure_DASH_mult,cljs.core.cst$sym$meta9109], null);
});})(mults,ensure_mult))
;

cljs.core.async.t_cljs$core$async9108.cljs$lang$type = true;

cljs.core.async.t_cljs$core$async9108.cljs$lang$ctorStr = "cljs.core.async/t_cljs$core$async9108";

cljs.core.async.t_cljs$core$async9108.cljs$lang$ctorPrWriter = ((function (mults,ensure_mult){
return (function (this__4290__auto__,writer__4291__auto__,opt__4292__auto__){
return cljs.core._write(writer__4291__auto__,"cljs.core.async/t_cljs$core$async9108");
});})(mults,ensure_mult))
;

/**
 * Positional factory function for cljs.core.async/t_cljs$core$async9108.
 */
cljs.core.async.__GT_t_cljs$core$async9108 = ((function (mults,ensure_mult){
return (function cljs$core$async$__GT_t_cljs$core$async9108(ch__$1,topic_fn__$1,buf_fn__$1,mults__$1,ensure_mult__$1,meta9109){
return (new cljs.core.async.t_cljs$core$async9108(ch__$1,topic_fn__$1,buf_fn__$1,mults__$1,ensure_mult__$1,meta9109));
});})(mults,ensure_mult))
;

}

return (new cljs.core.async.t_cljs$core$async9108(ch,topic_fn,buf_fn,mults,ensure_mult,cljs.core.PersistentArrayMap.EMPTY));
})()
;
var c__7992__auto___9228 = cljs.core.async.chan.cljs$core$IFn$_invoke$arity$1((1));
cljs.core.async.impl.dispatch.run(((function (c__7992__auto___9228,mults,ensure_mult,p){
return (function (){
var f__7993__auto__ = (function (){var switch__7885__auto__ = ((function (c__7992__auto___9228,mults,ensure_mult,p){
return (function (state_9182){
var state_val_9183 = (state_9182[(1)]);
if((state_val_9183 === (7))){
var inst_9178 = (state_9182[(2)]);
var state_9182__$1 = state_9182;
var statearr_9184_9229 = state_9182__$1;
(statearr_9184_9229[(2)] = inst_9178);

(statearr_9184_9229[(1)] = (3));


return cljs.core.cst$kw$recur;
} else {
if((state_val_9183 === (20))){
var state_9182__$1 = state_9182;
var statearr_9185_9230 = state_9182__$1;
(statearr_9185_9230[(2)] = null);

(statearr_9185_9230[(1)] = (21));


return cljs.core.cst$kw$recur;
} else {
if((state_val_9183 === (1))){
var state_9182__$1 = state_9182;
var statearr_9186_9231 = state_9182__$1;
(statearr_9186_9231[(2)] = null);

(statearr_9186_9231[(1)] = (2));


return cljs.core.cst$kw$recur;
} else {
if((state_val_9183 === (24))){
var inst_9161 = (state_9182[(7)]);
var inst_9170 = cljs.core.swap_BANG_.cljs$core$IFn$_invoke$arity$3(mults,cljs.core.dissoc,inst_9161);
var state_9182__$1 = state_9182;
var statearr_9187_9232 = state_9182__$1;
(statearr_9187_9232[(2)] = inst_9170);

(statearr_9187_9232[(1)] = (25));


return cljs.core.cst$kw$recur;
} else {
if((state_val_9183 === (4))){
var inst_9113 = (state_9182[(8)]);
var inst_9113__$1 = (state_9182[(2)]);
var inst_9114 = (inst_9113__$1 == null);
var state_9182__$1 = (function (){var statearr_9188 = state_9182;
(statearr_9188[(8)] = inst_9113__$1);

return statearr_9188;
})();
if(cljs.core.truth_(inst_9114)){
var statearr_9189_9233 = state_9182__$1;
(statearr_9189_9233[(1)] = (5));

} else {
var statearr_9190_9234 = state_9182__$1;
(statearr_9190_9234[(1)] = (6));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_9183 === (15))){
var inst_9155 = (state_9182[(2)]);
var state_9182__$1 = state_9182;
var statearr_9191_9235 = state_9182__$1;
(statearr_9191_9235[(2)] = inst_9155);

(statearr_9191_9235[(1)] = (12));


return cljs.core.cst$kw$recur;
} else {
if((state_val_9183 === (21))){
var inst_9175 = (state_9182[(2)]);
var state_9182__$1 = (function (){var statearr_9192 = state_9182;
(statearr_9192[(9)] = inst_9175);

return statearr_9192;
})();
var statearr_9193_9236 = state_9182__$1;
(statearr_9193_9236[(2)] = null);

(statearr_9193_9236[(1)] = (2));


return cljs.core.cst$kw$recur;
} else {
if((state_val_9183 === (13))){
var inst_9137 = (state_9182[(10)]);
var inst_9139 = cljs.core.chunked_seq_QMARK_(inst_9137);
var state_9182__$1 = state_9182;
if(inst_9139){
var statearr_9194_9237 = state_9182__$1;
(statearr_9194_9237[(1)] = (16));

} else {
var statearr_9195_9238 = state_9182__$1;
(statearr_9195_9238[(1)] = (17));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_9183 === (22))){
var inst_9167 = (state_9182[(2)]);
var state_9182__$1 = state_9182;
if(cljs.core.truth_(inst_9167)){
var statearr_9196_9239 = state_9182__$1;
(statearr_9196_9239[(1)] = (23));

} else {
var statearr_9197_9240 = state_9182__$1;
(statearr_9197_9240[(1)] = (24));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_9183 === (6))){
var inst_9113 = (state_9182[(8)]);
var inst_9163 = (state_9182[(11)]);
var inst_9161 = (state_9182[(7)]);
var inst_9161__$1 = (topic_fn.cljs$core$IFn$_invoke$arity$1 ? topic_fn.cljs$core$IFn$_invoke$arity$1(inst_9113) : topic_fn.call(null,inst_9113));
var inst_9162 = cljs.core.deref(mults);
var inst_9163__$1 = cljs.core.get.cljs$core$IFn$_invoke$arity$2(inst_9162,inst_9161__$1);
var state_9182__$1 = (function (){var statearr_9198 = state_9182;
(statearr_9198[(11)] = inst_9163__$1);

(statearr_9198[(7)] = inst_9161__$1);

return statearr_9198;
})();
if(cljs.core.truth_(inst_9163__$1)){
var statearr_9199_9241 = state_9182__$1;
(statearr_9199_9241[(1)] = (19));

} else {
var statearr_9200_9242 = state_9182__$1;
(statearr_9200_9242[(1)] = (20));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_9183 === (25))){
var inst_9172 = (state_9182[(2)]);
var state_9182__$1 = state_9182;
var statearr_9201_9243 = state_9182__$1;
(statearr_9201_9243[(2)] = inst_9172);

(statearr_9201_9243[(1)] = (21));


return cljs.core.cst$kw$recur;
} else {
if((state_val_9183 === (17))){
var inst_9137 = (state_9182[(10)]);
var inst_9146 = cljs.core.first(inst_9137);
var inst_9147 = cljs.core.async.muxch_STAR_(inst_9146);
var inst_9148 = cljs.core.async.close_BANG_(inst_9147);
var inst_9149 = cljs.core.next(inst_9137);
var inst_9123 = inst_9149;
var inst_9124 = null;
var inst_9125 = (0);
var inst_9126 = (0);
var state_9182__$1 = (function (){var statearr_9202 = state_9182;
(statearr_9202[(12)] = inst_9125);

(statearr_9202[(13)] = inst_9123);

(statearr_9202[(14)] = inst_9148);

(statearr_9202[(15)] = inst_9124);

(statearr_9202[(16)] = inst_9126);

return statearr_9202;
})();
var statearr_9203_9244 = state_9182__$1;
(statearr_9203_9244[(2)] = null);

(statearr_9203_9244[(1)] = (8));


return cljs.core.cst$kw$recur;
} else {
if((state_val_9183 === (3))){
var inst_9180 = (state_9182[(2)]);
var state_9182__$1 = state_9182;
return cljs.core.async.impl.ioc_helpers.return_chan(state_9182__$1,inst_9180);
} else {
if((state_val_9183 === (12))){
var inst_9157 = (state_9182[(2)]);
var state_9182__$1 = state_9182;
var statearr_9204_9245 = state_9182__$1;
(statearr_9204_9245[(2)] = inst_9157);

(statearr_9204_9245[(1)] = (9));


return cljs.core.cst$kw$recur;
} else {
if((state_val_9183 === (2))){
var state_9182__$1 = state_9182;
return cljs.core.async.impl.ioc_helpers.take_BANG_(state_9182__$1,(4),ch);
} else {
if((state_val_9183 === (23))){
var state_9182__$1 = state_9182;
var statearr_9205_9246 = state_9182__$1;
(statearr_9205_9246[(2)] = null);

(statearr_9205_9246[(1)] = (25));


return cljs.core.cst$kw$recur;
} else {
if((state_val_9183 === (19))){
var inst_9113 = (state_9182[(8)]);
var inst_9163 = (state_9182[(11)]);
var inst_9165 = cljs.core.async.muxch_STAR_(inst_9163);
var state_9182__$1 = state_9182;
return cljs.core.async.impl.ioc_helpers.put_BANG_(state_9182__$1,(22),inst_9165,inst_9113);
} else {
if((state_val_9183 === (11))){
var inst_9123 = (state_9182[(13)]);
var inst_9137 = (state_9182[(10)]);
var inst_9137__$1 = cljs.core.seq(inst_9123);
var state_9182__$1 = (function (){var statearr_9206 = state_9182;
(statearr_9206[(10)] = inst_9137__$1);

return statearr_9206;
})();
if(inst_9137__$1){
var statearr_9207_9247 = state_9182__$1;
(statearr_9207_9247[(1)] = (13));

} else {
var statearr_9208_9248 = state_9182__$1;
(statearr_9208_9248[(1)] = (14));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_9183 === (9))){
var inst_9159 = (state_9182[(2)]);
var state_9182__$1 = state_9182;
var statearr_9209_9249 = state_9182__$1;
(statearr_9209_9249[(2)] = inst_9159);

(statearr_9209_9249[(1)] = (7));


return cljs.core.cst$kw$recur;
} else {
if((state_val_9183 === (5))){
var inst_9120 = cljs.core.deref(mults);
var inst_9121 = cljs.core.vals(inst_9120);
var inst_9122 = cljs.core.seq(inst_9121);
var inst_9123 = inst_9122;
var inst_9124 = null;
var inst_9125 = (0);
var inst_9126 = (0);
var state_9182__$1 = (function (){var statearr_9210 = state_9182;
(statearr_9210[(12)] = inst_9125);

(statearr_9210[(13)] = inst_9123);

(statearr_9210[(15)] = inst_9124);

(statearr_9210[(16)] = inst_9126);

return statearr_9210;
})();
var statearr_9211_9250 = state_9182__$1;
(statearr_9211_9250[(2)] = null);

(statearr_9211_9250[(1)] = (8));


return cljs.core.cst$kw$recur;
} else {
if((state_val_9183 === (14))){
var state_9182__$1 = state_9182;
var statearr_9215_9251 = state_9182__$1;
(statearr_9215_9251[(2)] = null);

(statearr_9215_9251[(1)] = (15));


return cljs.core.cst$kw$recur;
} else {
if((state_val_9183 === (16))){
var inst_9137 = (state_9182[(10)]);
var inst_9141 = cljs.core.chunk_first(inst_9137);
var inst_9142 = cljs.core.chunk_rest(inst_9137);
var inst_9143 = cljs.core.count(inst_9141);
var inst_9123 = inst_9142;
var inst_9124 = inst_9141;
var inst_9125 = inst_9143;
var inst_9126 = (0);
var state_9182__$1 = (function (){var statearr_9216 = state_9182;
(statearr_9216[(12)] = inst_9125);

(statearr_9216[(13)] = inst_9123);

(statearr_9216[(15)] = inst_9124);

(statearr_9216[(16)] = inst_9126);

return statearr_9216;
})();
var statearr_9217_9252 = state_9182__$1;
(statearr_9217_9252[(2)] = null);

(statearr_9217_9252[(1)] = (8));


return cljs.core.cst$kw$recur;
} else {
if((state_val_9183 === (10))){
var inst_9125 = (state_9182[(12)]);
var inst_9123 = (state_9182[(13)]);
var inst_9124 = (state_9182[(15)]);
var inst_9126 = (state_9182[(16)]);
var inst_9131 = cljs.core._nth.cljs$core$IFn$_invoke$arity$2(inst_9124,inst_9126);
var inst_9132 = cljs.core.async.muxch_STAR_(inst_9131);
var inst_9133 = cljs.core.async.close_BANG_(inst_9132);
var inst_9134 = (inst_9126 + (1));
var tmp9212 = inst_9125;
var tmp9213 = inst_9123;
var tmp9214 = inst_9124;
var inst_9123__$1 = tmp9213;
var inst_9124__$1 = tmp9214;
var inst_9125__$1 = tmp9212;
var inst_9126__$1 = inst_9134;
var state_9182__$1 = (function (){var statearr_9218 = state_9182;
(statearr_9218[(12)] = inst_9125__$1);

(statearr_9218[(13)] = inst_9123__$1);

(statearr_9218[(15)] = inst_9124__$1);

(statearr_9218[(16)] = inst_9126__$1);

(statearr_9218[(17)] = inst_9133);

return statearr_9218;
})();
var statearr_9219_9253 = state_9182__$1;
(statearr_9219_9253[(2)] = null);

(statearr_9219_9253[(1)] = (8));


return cljs.core.cst$kw$recur;
} else {
if((state_val_9183 === (18))){
var inst_9152 = (state_9182[(2)]);
var state_9182__$1 = state_9182;
var statearr_9220_9254 = state_9182__$1;
(statearr_9220_9254[(2)] = inst_9152);

(statearr_9220_9254[(1)] = (15));


return cljs.core.cst$kw$recur;
} else {
if((state_val_9183 === (8))){
var inst_9125 = (state_9182[(12)]);
var inst_9126 = (state_9182[(16)]);
var inst_9128 = (inst_9126 < inst_9125);
var inst_9129 = inst_9128;
var state_9182__$1 = state_9182;
if(cljs.core.truth_(inst_9129)){
var statearr_9221_9255 = state_9182__$1;
(statearr_9221_9255[(1)] = (10));

} else {
var statearr_9222_9256 = state_9182__$1;
(statearr_9222_9256[(1)] = (11));

}

return cljs.core.cst$kw$recur;
} else {
return null;
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
});})(c__7992__auto___9228,mults,ensure_mult,p))
;
return ((function (switch__7885__auto__,c__7992__auto___9228,mults,ensure_mult,p){
return (function() {
var cljs$core$async$state_machine__7886__auto__ = null;
var cljs$core$async$state_machine__7886__auto____0 = (function (){
var statearr_9223 = [null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null];
(statearr_9223[(0)] = cljs$core$async$state_machine__7886__auto__);

(statearr_9223[(1)] = (1));

return statearr_9223;
});
var cljs$core$async$state_machine__7886__auto____1 = (function (state_9182){
while(true){
var ret_value__7887__auto__ = (function (){try{while(true){
var result__7888__auto__ = switch__7885__auto__(state_9182);
if(cljs.core.keyword_identical_QMARK_(result__7888__auto__,cljs.core.cst$kw$recur)){
continue;
} else {
return result__7888__auto__;
}
break;
}
}catch (e9224){if((e9224 instanceof Object)){
var ex__7889__auto__ = e9224;
var statearr_9225_9257 = state_9182;
(statearr_9225_9257[(5)] = ex__7889__auto__);


cljs.core.async.impl.ioc_helpers.process_exception(state_9182);

return cljs.core.cst$kw$recur;
} else {
throw e9224;

}
}})();
if(cljs.core.keyword_identical_QMARK_(ret_value__7887__auto__,cljs.core.cst$kw$recur)){
var G__9258 = state_9182;
state_9182 = G__9258;
continue;
} else {
return ret_value__7887__auto__;
}
break;
}
});
cljs$core$async$state_machine__7886__auto__ = function(state_9182){
switch(arguments.length){
case 0:
return cljs$core$async$state_machine__7886__auto____0.call(this);
case 1:
return cljs$core$async$state_machine__7886__auto____1.call(this,state_9182);
}
throw(new Error('Invalid arity: ' + arguments.length));
};
cljs$core$async$state_machine__7886__auto__.cljs$core$IFn$_invoke$arity$0 = cljs$core$async$state_machine__7886__auto____0;
cljs$core$async$state_machine__7886__auto__.cljs$core$IFn$_invoke$arity$1 = cljs$core$async$state_machine__7886__auto____1;
return cljs$core$async$state_machine__7886__auto__;
})()
;})(switch__7885__auto__,c__7992__auto___9228,mults,ensure_mult,p))
})();
var state__7994__auto__ = (function (){var statearr_9226 = (f__7993__auto__.cljs$core$IFn$_invoke$arity$0 ? f__7993__auto__.cljs$core$IFn$_invoke$arity$0() : f__7993__auto__.call(null));
(statearr_9226[(6)] = c__7992__auto___9228);

return statearr_9226;
})();
return cljs.core.async.impl.ioc_helpers.run_state_machine_wrapped(state__7994__auto__);
});})(c__7992__auto___9228,mults,ensure_mult,p))
);


return p;
});

cljs.core.async.pub.cljs$lang$maxFixedArity = 3;

/**
 * Subscribes a channel to a topic of a pub.
 * 
 *   By default the channel will be closed when the source closes,
 *   but can be determined by the close? parameter.
 */
cljs.core.async.sub = (function cljs$core$async$sub(var_args){
var G__9260 = arguments.length;
switch (G__9260) {
case 3:
return cljs.core.async.sub.cljs$core$IFn$_invoke$arity$3((arguments[(0)]),(arguments[(1)]),(arguments[(2)]));

break;
case 4:
return cljs.core.async.sub.cljs$core$IFn$_invoke$arity$4((arguments[(0)]),(arguments[(1)]),(arguments[(2)]),(arguments[(3)]));

break;
default:
throw (new Error(["Invalid arity: ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(arguments.length)].join('')));

}
});

cljs.core.async.sub.cljs$core$IFn$_invoke$arity$3 = (function (p,topic,ch){
return cljs.core.async.sub.cljs$core$IFn$_invoke$arity$4(p,topic,ch,true);
});

cljs.core.async.sub.cljs$core$IFn$_invoke$arity$4 = (function (p,topic,ch,close_QMARK_){
return cljs.core.async.sub_STAR_(p,topic,ch,close_QMARK_);
});

cljs.core.async.sub.cljs$lang$maxFixedArity = 4;

/**
 * Unsubscribes a channel from a topic of a pub
 */
cljs.core.async.unsub = (function cljs$core$async$unsub(p,topic,ch){
return cljs.core.async.unsub_STAR_(p,topic,ch);
});
/**
 * Unsubscribes all channels from a pub, or a topic of a pub
 */
cljs.core.async.unsub_all = (function cljs$core$async$unsub_all(var_args){
var G__9263 = arguments.length;
switch (G__9263) {
case 1:
return cljs.core.async.unsub_all.cljs$core$IFn$_invoke$arity$1((arguments[(0)]));

break;
case 2:
return cljs.core.async.unsub_all.cljs$core$IFn$_invoke$arity$2((arguments[(0)]),(arguments[(1)]));

break;
default:
throw (new Error(["Invalid arity: ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(arguments.length)].join('')));

}
});

cljs.core.async.unsub_all.cljs$core$IFn$_invoke$arity$1 = (function (p){
return cljs.core.async.unsub_all_STAR_.cljs$core$IFn$_invoke$arity$1(p);
});

cljs.core.async.unsub_all.cljs$core$IFn$_invoke$arity$2 = (function (p,topic){
return cljs.core.async.unsub_all_STAR_.cljs$core$IFn$_invoke$arity$2(p,topic);
});

cljs.core.async.unsub_all.cljs$lang$maxFixedArity = 2;

/**
 * Takes a function and a collection of source channels, and returns a
 *   channel which contains the values produced by applying f to the set
 *   of first items taken from each source channel, followed by applying
 *   f to the set of second items from each channel, until any one of the
 *   channels is closed, at which point the output channel will be
 *   closed. The returned channel will be unbuffered by default, or a
 *   buf-or-n can be supplied
 */
cljs.core.async.map = (function cljs$core$async$map(var_args){
var G__9266 = arguments.length;
switch (G__9266) {
case 2:
return cljs.core.async.map.cljs$core$IFn$_invoke$arity$2((arguments[(0)]),(arguments[(1)]));

break;
case 3:
return cljs.core.async.map.cljs$core$IFn$_invoke$arity$3((arguments[(0)]),(arguments[(1)]),(arguments[(2)]));

break;
default:
throw (new Error(["Invalid arity: ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(arguments.length)].join('')));

}
});

cljs.core.async.map.cljs$core$IFn$_invoke$arity$2 = (function (f,chs){
return cljs.core.async.map.cljs$core$IFn$_invoke$arity$3(f,chs,null);
});

cljs.core.async.map.cljs$core$IFn$_invoke$arity$3 = (function (f,chs,buf_or_n){
var chs__$1 = cljs.core.vec(chs);
var out = cljs.core.async.chan.cljs$core$IFn$_invoke$arity$1(buf_or_n);
var cnt = cljs.core.count(chs__$1);
var rets = cljs.core.object_array.cljs$core$IFn$_invoke$arity$1(cnt);
var dchan = cljs.core.async.chan.cljs$core$IFn$_invoke$arity$1((1));
var dctr = cljs.core.atom.cljs$core$IFn$_invoke$arity$1(null);
var done = cljs.core.mapv.cljs$core$IFn$_invoke$arity$2(((function (chs__$1,out,cnt,rets,dchan,dctr){
return (function (i){
return ((function (chs__$1,out,cnt,rets,dchan,dctr){
return (function (ret){
(rets[i] = ret);

if((cljs.core.swap_BANG_.cljs$core$IFn$_invoke$arity$2(dctr,cljs.core.dec) === (0))){
return cljs.core.async.put_BANG_.cljs$core$IFn$_invoke$arity$2(dchan,rets.slice((0)));
} else {
return null;
}
});
;})(chs__$1,out,cnt,rets,dchan,dctr))
});})(chs__$1,out,cnt,rets,dchan,dctr))
,cljs.core.range.cljs$core$IFn$_invoke$arity$1(cnt));
var c__7992__auto___9333 = cljs.core.async.chan.cljs$core$IFn$_invoke$arity$1((1));
cljs.core.async.impl.dispatch.run(((function (c__7992__auto___9333,chs__$1,out,cnt,rets,dchan,dctr,done){
return (function (){
var f__7993__auto__ = (function (){var switch__7885__auto__ = ((function (c__7992__auto___9333,chs__$1,out,cnt,rets,dchan,dctr,done){
return (function (state_9305){
var state_val_9306 = (state_9305[(1)]);
if((state_val_9306 === (7))){
var state_9305__$1 = state_9305;
var statearr_9307_9334 = state_9305__$1;
(statearr_9307_9334[(2)] = null);

(statearr_9307_9334[(1)] = (8));


return cljs.core.cst$kw$recur;
} else {
if((state_val_9306 === (1))){
var state_9305__$1 = state_9305;
var statearr_9308_9335 = state_9305__$1;
(statearr_9308_9335[(2)] = null);

(statearr_9308_9335[(1)] = (2));


return cljs.core.cst$kw$recur;
} else {
if((state_val_9306 === (4))){
var inst_9269 = (state_9305[(7)]);
var inst_9271 = (inst_9269 < cnt);
var state_9305__$1 = state_9305;
if(cljs.core.truth_(inst_9271)){
var statearr_9309_9336 = state_9305__$1;
(statearr_9309_9336[(1)] = (6));

} else {
var statearr_9310_9337 = state_9305__$1;
(statearr_9310_9337[(1)] = (7));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_9306 === (15))){
var inst_9301 = (state_9305[(2)]);
var state_9305__$1 = state_9305;
var statearr_9311_9338 = state_9305__$1;
(statearr_9311_9338[(2)] = inst_9301);

(statearr_9311_9338[(1)] = (3));


return cljs.core.cst$kw$recur;
} else {
if((state_val_9306 === (13))){
var inst_9294 = cljs.core.async.close_BANG_(out);
var state_9305__$1 = state_9305;
var statearr_9312_9339 = state_9305__$1;
(statearr_9312_9339[(2)] = inst_9294);

(statearr_9312_9339[(1)] = (15));


return cljs.core.cst$kw$recur;
} else {
if((state_val_9306 === (6))){
var state_9305__$1 = state_9305;
var statearr_9313_9340 = state_9305__$1;
(statearr_9313_9340[(2)] = null);

(statearr_9313_9340[(1)] = (11));


return cljs.core.cst$kw$recur;
} else {
if((state_val_9306 === (3))){
var inst_9303 = (state_9305[(2)]);
var state_9305__$1 = state_9305;
return cljs.core.async.impl.ioc_helpers.return_chan(state_9305__$1,inst_9303);
} else {
if((state_val_9306 === (12))){
var inst_9291 = (state_9305[(8)]);
var inst_9291__$1 = (state_9305[(2)]);
var inst_9292 = cljs.core.some(cljs.core.nil_QMARK_,inst_9291__$1);
var state_9305__$1 = (function (){var statearr_9314 = state_9305;
(statearr_9314[(8)] = inst_9291__$1);

return statearr_9314;
})();
if(cljs.core.truth_(inst_9292)){
var statearr_9315_9341 = state_9305__$1;
(statearr_9315_9341[(1)] = (13));

} else {
var statearr_9316_9342 = state_9305__$1;
(statearr_9316_9342[(1)] = (14));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_9306 === (2))){
var inst_9268 = cljs.core.reset_BANG_(dctr,cnt);
var inst_9269 = (0);
var state_9305__$1 = (function (){var statearr_9317 = state_9305;
(statearr_9317[(7)] = inst_9269);

(statearr_9317[(9)] = inst_9268);

return statearr_9317;
})();
var statearr_9318_9343 = state_9305__$1;
(statearr_9318_9343[(2)] = null);

(statearr_9318_9343[(1)] = (4));


return cljs.core.cst$kw$recur;
} else {
if((state_val_9306 === (11))){
var inst_9269 = (state_9305[(7)]);
var _ = cljs.core.async.impl.ioc_helpers.add_exception_frame(state_9305,(10),Object,null,(9));
var inst_9278 = (chs__$1.cljs$core$IFn$_invoke$arity$1 ? chs__$1.cljs$core$IFn$_invoke$arity$1(inst_9269) : chs__$1.call(null,inst_9269));
var inst_9279 = (done.cljs$core$IFn$_invoke$arity$1 ? done.cljs$core$IFn$_invoke$arity$1(inst_9269) : done.call(null,inst_9269));
var inst_9280 = cljs.core.async.take_BANG_.cljs$core$IFn$_invoke$arity$2(inst_9278,inst_9279);
var state_9305__$1 = state_9305;
var statearr_9319_9344 = state_9305__$1;
(statearr_9319_9344[(2)] = inst_9280);


cljs.core.async.impl.ioc_helpers.process_exception(state_9305__$1);

return cljs.core.cst$kw$recur;
} else {
if((state_val_9306 === (9))){
var inst_9269 = (state_9305[(7)]);
var inst_9282 = (state_9305[(2)]);
var inst_9283 = (inst_9269 + (1));
var inst_9269__$1 = inst_9283;
var state_9305__$1 = (function (){var statearr_9320 = state_9305;
(statearr_9320[(7)] = inst_9269__$1);

(statearr_9320[(10)] = inst_9282);

return statearr_9320;
})();
var statearr_9321_9345 = state_9305__$1;
(statearr_9321_9345[(2)] = null);

(statearr_9321_9345[(1)] = (4));


return cljs.core.cst$kw$recur;
} else {
if((state_val_9306 === (5))){
var inst_9289 = (state_9305[(2)]);
var state_9305__$1 = (function (){var statearr_9322 = state_9305;
(statearr_9322[(11)] = inst_9289);

return statearr_9322;
})();
return cljs.core.async.impl.ioc_helpers.take_BANG_(state_9305__$1,(12),dchan);
} else {
if((state_val_9306 === (14))){
var inst_9291 = (state_9305[(8)]);
var inst_9296 = cljs.core.apply.cljs$core$IFn$_invoke$arity$2(f,inst_9291);
var state_9305__$1 = state_9305;
return cljs.core.async.impl.ioc_helpers.put_BANG_(state_9305__$1,(16),out,inst_9296);
} else {
if((state_val_9306 === (16))){
var inst_9298 = (state_9305[(2)]);
var state_9305__$1 = (function (){var statearr_9323 = state_9305;
(statearr_9323[(12)] = inst_9298);

return statearr_9323;
})();
var statearr_9324_9346 = state_9305__$1;
(statearr_9324_9346[(2)] = null);

(statearr_9324_9346[(1)] = (2));


return cljs.core.cst$kw$recur;
} else {
if((state_val_9306 === (10))){
var inst_9273 = (state_9305[(2)]);
var inst_9274 = cljs.core.swap_BANG_.cljs$core$IFn$_invoke$arity$2(dctr,cljs.core.dec);
var state_9305__$1 = (function (){var statearr_9325 = state_9305;
(statearr_9325[(13)] = inst_9273);

return statearr_9325;
})();
var statearr_9326_9347 = state_9305__$1;
(statearr_9326_9347[(2)] = inst_9274);


cljs.core.async.impl.ioc_helpers.process_exception(state_9305__$1);

return cljs.core.cst$kw$recur;
} else {
if((state_val_9306 === (8))){
var inst_9287 = (state_9305[(2)]);
var state_9305__$1 = state_9305;
var statearr_9327_9348 = state_9305__$1;
(statearr_9327_9348[(2)] = inst_9287);

(statearr_9327_9348[(1)] = (5));


return cljs.core.cst$kw$recur;
} else {
return null;
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
});})(c__7992__auto___9333,chs__$1,out,cnt,rets,dchan,dctr,done))
;
return ((function (switch__7885__auto__,c__7992__auto___9333,chs__$1,out,cnt,rets,dchan,dctr,done){
return (function() {
var cljs$core$async$state_machine__7886__auto__ = null;
var cljs$core$async$state_machine__7886__auto____0 = (function (){
var statearr_9328 = [null,null,null,null,null,null,null,null,null,null,null,null,null,null];
(statearr_9328[(0)] = cljs$core$async$state_machine__7886__auto__);

(statearr_9328[(1)] = (1));

return statearr_9328;
});
var cljs$core$async$state_machine__7886__auto____1 = (function (state_9305){
while(true){
var ret_value__7887__auto__ = (function (){try{while(true){
var result__7888__auto__ = switch__7885__auto__(state_9305);
if(cljs.core.keyword_identical_QMARK_(result__7888__auto__,cljs.core.cst$kw$recur)){
continue;
} else {
return result__7888__auto__;
}
break;
}
}catch (e9329){if((e9329 instanceof Object)){
var ex__7889__auto__ = e9329;
var statearr_9330_9349 = state_9305;
(statearr_9330_9349[(5)] = ex__7889__auto__);


cljs.core.async.impl.ioc_helpers.process_exception(state_9305);

return cljs.core.cst$kw$recur;
} else {
throw e9329;

}
}})();
if(cljs.core.keyword_identical_QMARK_(ret_value__7887__auto__,cljs.core.cst$kw$recur)){
var G__9350 = state_9305;
state_9305 = G__9350;
continue;
} else {
return ret_value__7887__auto__;
}
break;
}
});
cljs$core$async$state_machine__7886__auto__ = function(state_9305){
switch(arguments.length){
case 0:
return cljs$core$async$state_machine__7886__auto____0.call(this);
case 1:
return cljs$core$async$state_machine__7886__auto____1.call(this,state_9305);
}
throw(new Error('Invalid arity: ' + arguments.length));
};
cljs$core$async$state_machine__7886__auto__.cljs$core$IFn$_invoke$arity$0 = cljs$core$async$state_machine__7886__auto____0;
cljs$core$async$state_machine__7886__auto__.cljs$core$IFn$_invoke$arity$1 = cljs$core$async$state_machine__7886__auto____1;
return cljs$core$async$state_machine__7886__auto__;
})()
;})(switch__7885__auto__,c__7992__auto___9333,chs__$1,out,cnt,rets,dchan,dctr,done))
})();
var state__7994__auto__ = (function (){var statearr_9331 = (f__7993__auto__.cljs$core$IFn$_invoke$arity$0 ? f__7993__auto__.cljs$core$IFn$_invoke$arity$0() : f__7993__auto__.call(null));
(statearr_9331[(6)] = c__7992__auto___9333);

return statearr_9331;
})();
return cljs.core.async.impl.ioc_helpers.run_state_machine_wrapped(state__7994__auto__);
});})(c__7992__auto___9333,chs__$1,out,cnt,rets,dchan,dctr,done))
);


return out;
});

cljs.core.async.map.cljs$lang$maxFixedArity = 3;

/**
 * Takes a collection of source channels and returns a channel which
 *   contains all values taken from them. The returned channel will be
 *   unbuffered by default, or a buf-or-n can be supplied. The channel
 *   will close after all the source channels have closed.
 */
cljs.core.async.merge = (function cljs$core$async$merge(var_args){
var G__9353 = arguments.length;
switch (G__9353) {
case 1:
return cljs.core.async.merge.cljs$core$IFn$_invoke$arity$1((arguments[(0)]));

break;
case 2:
return cljs.core.async.merge.cljs$core$IFn$_invoke$arity$2((arguments[(0)]),(arguments[(1)]));

break;
default:
throw (new Error(["Invalid arity: ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(arguments.length)].join('')));

}
});

cljs.core.async.merge.cljs$core$IFn$_invoke$arity$1 = (function (chs){
return cljs.core.async.merge.cljs$core$IFn$_invoke$arity$2(chs,null);
});

cljs.core.async.merge.cljs$core$IFn$_invoke$arity$2 = (function (chs,buf_or_n){
var out = cljs.core.async.chan.cljs$core$IFn$_invoke$arity$1(buf_or_n);
var c__7992__auto___9407 = cljs.core.async.chan.cljs$core$IFn$_invoke$arity$1((1));
cljs.core.async.impl.dispatch.run(((function (c__7992__auto___9407,out){
return (function (){
var f__7993__auto__ = (function (){var switch__7885__auto__ = ((function (c__7992__auto___9407,out){
return (function (state_9385){
var state_val_9386 = (state_9385[(1)]);
if((state_val_9386 === (7))){
var inst_9365 = (state_9385[(7)]);
var inst_9364 = (state_9385[(8)]);
var inst_9364__$1 = (state_9385[(2)]);
var inst_9365__$1 = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(inst_9364__$1,(0),null);
var inst_9366 = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(inst_9364__$1,(1),null);
var inst_9367 = (inst_9365__$1 == null);
var state_9385__$1 = (function (){var statearr_9387 = state_9385;
(statearr_9387[(9)] = inst_9366);

(statearr_9387[(7)] = inst_9365__$1);

(statearr_9387[(8)] = inst_9364__$1);

return statearr_9387;
})();
if(cljs.core.truth_(inst_9367)){
var statearr_9388_9408 = state_9385__$1;
(statearr_9388_9408[(1)] = (8));

} else {
var statearr_9389_9409 = state_9385__$1;
(statearr_9389_9409[(1)] = (9));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_9386 === (1))){
var inst_9354 = cljs.core.vec(chs);
var inst_9355 = inst_9354;
var state_9385__$1 = (function (){var statearr_9390 = state_9385;
(statearr_9390[(10)] = inst_9355);

return statearr_9390;
})();
var statearr_9391_9410 = state_9385__$1;
(statearr_9391_9410[(2)] = null);

(statearr_9391_9410[(1)] = (2));


return cljs.core.cst$kw$recur;
} else {
if((state_val_9386 === (4))){
var inst_9355 = (state_9385[(10)]);
var state_9385__$1 = state_9385;
return cljs.core.async.ioc_alts_BANG_(state_9385__$1,(7),inst_9355);
} else {
if((state_val_9386 === (6))){
var inst_9381 = (state_9385[(2)]);
var state_9385__$1 = state_9385;
var statearr_9392_9411 = state_9385__$1;
(statearr_9392_9411[(2)] = inst_9381);

(statearr_9392_9411[(1)] = (3));


return cljs.core.cst$kw$recur;
} else {
if((state_val_9386 === (3))){
var inst_9383 = (state_9385[(2)]);
var state_9385__$1 = state_9385;
return cljs.core.async.impl.ioc_helpers.return_chan(state_9385__$1,inst_9383);
} else {
if((state_val_9386 === (2))){
var inst_9355 = (state_9385[(10)]);
var inst_9357 = cljs.core.count(inst_9355);
var inst_9358 = (inst_9357 > (0));
var state_9385__$1 = state_9385;
if(cljs.core.truth_(inst_9358)){
var statearr_9394_9412 = state_9385__$1;
(statearr_9394_9412[(1)] = (4));

} else {
var statearr_9395_9413 = state_9385__$1;
(statearr_9395_9413[(1)] = (5));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_9386 === (11))){
var inst_9355 = (state_9385[(10)]);
var inst_9374 = (state_9385[(2)]);
var tmp9393 = inst_9355;
var inst_9355__$1 = tmp9393;
var state_9385__$1 = (function (){var statearr_9396 = state_9385;
(statearr_9396[(10)] = inst_9355__$1);

(statearr_9396[(11)] = inst_9374);

return statearr_9396;
})();
var statearr_9397_9414 = state_9385__$1;
(statearr_9397_9414[(2)] = null);

(statearr_9397_9414[(1)] = (2));


return cljs.core.cst$kw$recur;
} else {
if((state_val_9386 === (9))){
var inst_9365 = (state_9385[(7)]);
var state_9385__$1 = state_9385;
return cljs.core.async.impl.ioc_helpers.put_BANG_(state_9385__$1,(11),out,inst_9365);
} else {
if((state_val_9386 === (5))){
var inst_9379 = cljs.core.async.close_BANG_(out);
var state_9385__$1 = state_9385;
var statearr_9398_9415 = state_9385__$1;
(statearr_9398_9415[(2)] = inst_9379);

(statearr_9398_9415[(1)] = (6));


return cljs.core.cst$kw$recur;
} else {
if((state_val_9386 === (10))){
var inst_9377 = (state_9385[(2)]);
var state_9385__$1 = state_9385;
var statearr_9399_9416 = state_9385__$1;
(statearr_9399_9416[(2)] = inst_9377);

(statearr_9399_9416[(1)] = (6));


return cljs.core.cst$kw$recur;
} else {
if((state_val_9386 === (8))){
var inst_9366 = (state_9385[(9)]);
var inst_9355 = (state_9385[(10)]);
var inst_9365 = (state_9385[(7)]);
var inst_9364 = (state_9385[(8)]);
var inst_9369 = (function (){var cs = inst_9355;
var vec__9360 = inst_9364;
var v = inst_9365;
var c = inst_9366;
return ((function (cs,vec__9360,v,c,inst_9366,inst_9355,inst_9365,inst_9364,state_val_9386,c__7992__auto___9407,out){
return (function (p1__9351_SHARP_){
return cljs.core.not_EQ_.cljs$core$IFn$_invoke$arity$2(c,p1__9351_SHARP_);
});
;})(cs,vec__9360,v,c,inst_9366,inst_9355,inst_9365,inst_9364,state_val_9386,c__7992__auto___9407,out))
})();
var inst_9370 = cljs.core.filterv(inst_9369,inst_9355);
var inst_9355__$1 = inst_9370;
var state_9385__$1 = (function (){var statearr_9400 = state_9385;
(statearr_9400[(10)] = inst_9355__$1);

return statearr_9400;
})();
var statearr_9401_9417 = state_9385__$1;
(statearr_9401_9417[(2)] = null);

(statearr_9401_9417[(1)] = (2));


return cljs.core.cst$kw$recur;
} else {
return null;
}
}
}
}
}
}
}
}
}
}
}
});})(c__7992__auto___9407,out))
;
return ((function (switch__7885__auto__,c__7992__auto___9407,out){
return (function() {
var cljs$core$async$state_machine__7886__auto__ = null;
var cljs$core$async$state_machine__7886__auto____0 = (function (){
var statearr_9402 = [null,null,null,null,null,null,null,null,null,null,null,null];
(statearr_9402[(0)] = cljs$core$async$state_machine__7886__auto__);

(statearr_9402[(1)] = (1));

return statearr_9402;
});
var cljs$core$async$state_machine__7886__auto____1 = (function (state_9385){
while(true){
var ret_value__7887__auto__ = (function (){try{while(true){
var result__7888__auto__ = switch__7885__auto__(state_9385);
if(cljs.core.keyword_identical_QMARK_(result__7888__auto__,cljs.core.cst$kw$recur)){
continue;
} else {
return result__7888__auto__;
}
break;
}
}catch (e9403){if((e9403 instanceof Object)){
var ex__7889__auto__ = e9403;
var statearr_9404_9418 = state_9385;
(statearr_9404_9418[(5)] = ex__7889__auto__);


cljs.core.async.impl.ioc_helpers.process_exception(state_9385);

return cljs.core.cst$kw$recur;
} else {
throw e9403;

}
}})();
if(cljs.core.keyword_identical_QMARK_(ret_value__7887__auto__,cljs.core.cst$kw$recur)){
var G__9419 = state_9385;
state_9385 = G__9419;
continue;
} else {
return ret_value__7887__auto__;
}
break;
}
});
cljs$core$async$state_machine__7886__auto__ = function(state_9385){
switch(arguments.length){
case 0:
return cljs$core$async$state_machine__7886__auto____0.call(this);
case 1:
return cljs$core$async$state_machine__7886__auto____1.call(this,state_9385);
}
throw(new Error('Invalid arity: ' + arguments.length));
};
cljs$core$async$state_machine__7886__auto__.cljs$core$IFn$_invoke$arity$0 = cljs$core$async$state_machine__7886__auto____0;
cljs$core$async$state_machine__7886__auto__.cljs$core$IFn$_invoke$arity$1 = cljs$core$async$state_machine__7886__auto____1;
return cljs$core$async$state_machine__7886__auto__;
})()
;})(switch__7885__auto__,c__7992__auto___9407,out))
})();
var state__7994__auto__ = (function (){var statearr_9405 = (f__7993__auto__.cljs$core$IFn$_invoke$arity$0 ? f__7993__auto__.cljs$core$IFn$_invoke$arity$0() : f__7993__auto__.call(null));
(statearr_9405[(6)] = c__7992__auto___9407);

return statearr_9405;
})();
return cljs.core.async.impl.ioc_helpers.run_state_machine_wrapped(state__7994__auto__);
});})(c__7992__auto___9407,out))
);


return out;
});

cljs.core.async.merge.cljs$lang$maxFixedArity = 2;

/**
 * Returns a channel containing the single (collection) result of the
 *   items taken from the channel conjoined to the supplied
 *   collection. ch must close before into produces a result.
 */
cljs.core.async.into = (function cljs$core$async$into(coll,ch){
return cljs.core.async.reduce(cljs.core.conj,coll,ch);
});
/**
 * Returns a channel that will return, at most, n items from ch. After n items
 * have been returned, or ch has been closed, the return chanel will close.
 * 
 *   The output channel is unbuffered by default, unless buf-or-n is given.
 */
cljs.core.async.take = (function cljs$core$async$take(var_args){
var G__9421 = arguments.length;
switch (G__9421) {
case 2:
return cljs.core.async.take.cljs$core$IFn$_invoke$arity$2((arguments[(0)]),(arguments[(1)]));

break;
case 3:
return cljs.core.async.take.cljs$core$IFn$_invoke$arity$3((arguments[(0)]),(arguments[(1)]),(arguments[(2)]));

break;
default:
throw (new Error(["Invalid arity: ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(arguments.length)].join('')));

}
});

cljs.core.async.take.cljs$core$IFn$_invoke$arity$2 = (function (n,ch){
return cljs.core.async.take.cljs$core$IFn$_invoke$arity$3(n,ch,null);
});

cljs.core.async.take.cljs$core$IFn$_invoke$arity$3 = (function (n,ch,buf_or_n){
var out = cljs.core.async.chan.cljs$core$IFn$_invoke$arity$1(buf_or_n);
var c__7992__auto___9466 = cljs.core.async.chan.cljs$core$IFn$_invoke$arity$1((1));
cljs.core.async.impl.dispatch.run(((function (c__7992__auto___9466,out){
return (function (){
var f__7993__auto__ = (function (){var switch__7885__auto__ = ((function (c__7992__auto___9466,out){
return (function (state_9445){
var state_val_9446 = (state_9445[(1)]);
if((state_val_9446 === (7))){
var inst_9427 = (state_9445[(7)]);
var inst_9427__$1 = (state_9445[(2)]);
var inst_9428 = (inst_9427__$1 == null);
var inst_9429 = cljs.core.not(inst_9428);
var state_9445__$1 = (function (){var statearr_9447 = state_9445;
(statearr_9447[(7)] = inst_9427__$1);

return statearr_9447;
})();
if(inst_9429){
var statearr_9448_9467 = state_9445__$1;
(statearr_9448_9467[(1)] = (8));

} else {
var statearr_9449_9468 = state_9445__$1;
(statearr_9449_9468[(1)] = (9));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_9446 === (1))){
var inst_9422 = (0);
var state_9445__$1 = (function (){var statearr_9450 = state_9445;
(statearr_9450[(8)] = inst_9422);

return statearr_9450;
})();
var statearr_9451_9469 = state_9445__$1;
(statearr_9451_9469[(2)] = null);

(statearr_9451_9469[(1)] = (2));


return cljs.core.cst$kw$recur;
} else {
if((state_val_9446 === (4))){
var state_9445__$1 = state_9445;
return cljs.core.async.impl.ioc_helpers.take_BANG_(state_9445__$1,(7),ch);
} else {
if((state_val_9446 === (6))){
var inst_9440 = (state_9445[(2)]);
var state_9445__$1 = state_9445;
var statearr_9452_9470 = state_9445__$1;
(statearr_9452_9470[(2)] = inst_9440);

(statearr_9452_9470[(1)] = (3));


return cljs.core.cst$kw$recur;
} else {
if((state_val_9446 === (3))){
var inst_9442 = (state_9445[(2)]);
var inst_9443 = cljs.core.async.close_BANG_(out);
var state_9445__$1 = (function (){var statearr_9453 = state_9445;
(statearr_9453[(9)] = inst_9442);

return statearr_9453;
})();
return cljs.core.async.impl.ioc_helpers.return_chan(state_9445__$1,inst_9443);
} else {
if((state_val_9446 === (2))){
var inst_9422 = (state_9445[(8)]);
var inst_9424 = (inst_9422 < n);
var state_9445__$1 = state_9445;
if(cljs.core.truth_(inst_9424)){
var statearr_9454_9471 = state_9445__$1;
(statearr_9454_9471[(1)] = (4));

} else {
var statearr_9455_9472 = state_9445__$1;
(statearr_9455_9472[(1)] = (5));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_9446 === (11))){
var inst_9422 = (state_9445[(8)]);
var inst_9432 = (state_9445[(2)]);
var inst_9433 = (inst_9422 + (1));
var inst_9422__$1 = inst_9433;
var state_9445__$1 = (function (){var statearr_9456 = state_9445;
(statearr_9456[(10)] = inst_9432);

(statearr_9456[(8)] = inst_9422__$1);

return statearr_9456;
})();
var statearr_9457_9473 = state_9445__$1;
(statearr_9457_9473[(2)] = null);

(statearr_9457_9473[(1)] = (2));


return cljs.core.cst$kw$recur;
} else {
if((state_val_9446 === (9))){
var state_9445__$1 = state_9445;
var statearr_9458_9474 = state_9445__$1;
(statearr_9458_9474[(2)] = null);

(statearr_9458_9474[(1)] = (10));


return cljs.core.cst$kw$recur;
} else {
if((state_val_9446 === (5))){
var state_9445__$1 = state_9445;
var statearr_9459_9475 = state_9445__$1;
(statearr_9459_9475[(2)] = null);

(statearr_9459_9475[(1)] = (6));


return cljs.core.cst$kw$recur;
} else {
if((state_val_9446 === (10))){
var inst_9437 = (state_9445[(2)]);
var state_9445__$1 = state_9445;
var statearr_9460_9476 = state_9445__$1;
(statearr_9460_9476[(2)] = inst_9437);

(statearr_9460_9476[(1)] = (6));


return cljs.core.cst$kw$recur;
} else {
if((state_val_9446 === (8))){
var inst_9427 = (state_9445[(7)]);
var state_9445__$1 = state_9445;
return cljs.core.async.impl.ioc_helpers.put_BANG_(state_9445__$1,(11),out,inst_9427);
} else {
return null;
}
}
}
}
}
}
}
}
}
}
}
});})(c__7992__auto___9466,out))
;
return ((function (switch__7885__auto__,c__7992__auto___9466,out){
return (function() {
var cljs$core$async$state_machine__7886__auto__ = null;
var cljs$core$async$state_machine__7886__auto____0 = (function (){
var statearr_9461 = [null,null,null,null,null,null,null,null,null,null,null];
(statearr_9461[(0)] = cljs$core$async$state_machine__7886__auto__);

(statearr_9461[(1)] = (1));

return statearr_9461;
});
var cljs$core$async$state_machine__7886__auto____1 = (function (state_9445){
while(true){
var ret_value__7887__auto__ = (function (){try{while(true){
var result__7888__auto__ = switch__7885__auto__(state_9445);
if(cljs.core.keyword_identical_QMARK_(result__7888__auto__,cljs.core.cst$kw$recur)){
continue;
} else {
return result__7888__auto__;
}
break;
}
}catch (e9462){if((e9462 instanceof Object)){
var ex__7889__auto__ = e9462;
var statearr_9463_9477 = state_9445;
(statearr_9463_9477[(5)] = ex__7889__auto__);


cljs.core.async.impl.ioc_helpers.process_exception(state_9445);

return cljs.core.cst$kw$recur;
} else {
throw e9462;

}
}})();
if(cljs.core.keyword_identical_QMARK_(ret_value__7887__auto__,cljs.core.cst$kw$recur)){
var G__9478 = state_9445;
state_9445 = G__9478;
continue;
} else {
return ret_value__7887__auto__;
}
break;
}
});
cljs$core$async$state_machine__7886__auto__ = function(state_9445){
switch(arguments.length){
case 0:
return cljs$core$async$state_machine__7886__auto____0.call(this);
case 1:
return cljs$core$async$state_machine__7886__auto____1.call(this,state_9445);
}
throw(new Error('Invalid arity: ' + arguments.length));
};
cljs$core$async$state_machine__7886__auto__.cljs$core$IFn$_invoke$arity$0 = cljs$core$async$state_machine__7886__auto____0;
cljs$core$async$state_machine__7886__auto__.cljs$core$IFn$_invoke$arity$1 = cljs$core$async$state_machine__7886__auto____1;
return cljs$core$async$state_machine__7886__auto__;
})()
;})(switch__7885__auto__,c__7992__auto___9466,out))
})();
var state__7994__auto__ = (function (){var statearr_9464 = (f__7993__auto__.cljs$core$IFn$_invoke$arity$0 ? f__7993__auto__.cljs$core$IFn$_invoke$arity$0() : f__7993__auto__.call(null));
(statearr_9464[(6)] = c__7992__auto___9466);

return statearr_9464;
})();
return cljs.core.async.impl.ioc_helpers.run_state_machine_wrapped(state__7994__auto__);
});})(c__7992__auto___9466,out))
);


return out;
});

cljs.core.async.take.cljs$lang$maxFixedArity = 3;

/**
 * Deprecated - this function will be removed. Use transducer instead
 */
cljs.core.async.map_LT_ = (function cljs$core$async$map_LT_(f,ch){
if((typeof cljs !== 'undefined') && (typeof cljs.core !== 'undefined') && (typeof cljs.core.async !== 'undefined') && (typeof cljs.core.async.t_cljs$core$async9480 !== 'undefined')){
} else {

/**
* @constructor
 * @implements {cljs.core.async.impl.protocols.Channel}
 * @implements {cljs.core.async.impl.protocols.WritePort}
 * @implements {cljs.core.async.impl.protocols.ReadPort}
 * @implements {cljs.core.IMeta}
 * @implements {cljs.core.IWithMeta}
*/
cljs.core.async.t_cljs$core$async9480 = (function (f,ch,meta9481){
this.f = f;
this.ch = ch;
this.meta9481 = meta9481;
this.cljs$lang$protocol_mask$partition0$ = 393216;
this.cljs$lang$protocol_mask$partition1$ = 0;
});
cljs.core.async.t_cljs$core$async9480.prototype.cljs$core$IWithMeta$_with_meta$arity$2 = (function (_9482,meta9481__$1){
var self__ = this;
var _9482__$1 = this;
return (new cljs.core.async.t_cljs$core$async9480(self__.f,self__.ch,meta9481__$1));
});

cljs.core.async.t_cljs$core$async9480.prototype.cljs$core$IMeta$_meta$arity$1 = (function (_9482){
var self__ = this;
var _9482__$1 = this;
return self__.meta9481;
});

cljs.core.async.t_cljs$core$async9480.prototype.cljs$core$async$impl$protocols$Channel$ = cljs.core.PROTOCOL_SENTINEL;

cljs.core.async.t_cljs$core$async9480.prototype.cljs$core$async$impl$protocols$Channel$close_BANG_$arity$1 = (function (_){
var self__ = this;
var ___$1 = this;
return cljs.core.async.impl.protocols.close_BANG_(self__.ch);
});

cljs.core.async.t_cljs$core$async9480.prototype.cljs$core$async$impl$protocols$Channel$closed_QMARK_$arity$1 = (function (_){
var self__ = this;
var ___$1 = this;
return cljs.core.async.impl.protocols.closed_QMARK_(self__.ch);
});

cljs.core.async.t_cljs$core$async9480.prototype.cljs$core$async$impl$protocols$ReadPort$ = cljs.core.PROTOCOL_SENTINEL;

cljs.core.async.t_cljs$core$async9480.prototype.cljs$core$async$impl$protocols$ReadPort$take_BANG_$arity$2 = (function (_,fn1){
var self__ = this;
var ___$1 = this;
var ret = cljs.core.async.impl.protocols.take_BANG_(self__.ch,(function (){
if((typeof cljs !== 'undefined') && (typeof cljs.core !== 'undefined') && (typeof cljs.core.async !== 'undefined') && (typeof cljs.core.async.t_cljs$core$async9483 !== 'undefined')){
} else {

/**
* @constructor
 * @implements {cljs.core.async.impl.protocols.Handler}
 * @implements {cljs.core.IMeta}
 * @implements {cljs.core.IWithMeta}
*/
cljs.core.async.t_cljs$core$async9483 = (function (f,ch,meta9481,_,fn1,meta9484){
this.f = f;
this.ch = ch;
this.meta9481 = meta9481;
this._ = _;
this.fn1 = fn1;
this.meta9484 = meta9484;
this.cljs$lang$protocol_mask$partition0$ = 393216;
this.cljs$lang$protocol_mask$partition1$ = 0;
});
cljs.core.async.t_cljs$core$async9483.prototype.cljs$core$IWithMeta$_with_meta$arity$2 = ((function (___$1){
return (function (_9485,meta9484__$1){
var self__ = this;
var _9485__$1 = this;
return (new cljs.core.async.t_cljs$core$async9483(self__.f,self__.ch,self__.meta9481,self__._,self__.fn1,meta9484__$1));
});})(___$1))
;

cljs.core.async.t_cljs$core$async9483.prototype.cljs$core$IMeta$_meta$arity$1 = ((function (___$1){
return (function (_9485){
var self__ = this;
var _9485__$1 = this;
return self__.meta9484;
});})(___$1))
;

cljs.core.async.t_cljs$core$async9483.prototype.cljs$core$async$impl$protocols$Handler$ = cljs.core.PROTOCOL_SENTINEL;

cljs.core.async.t_cljs$core$async9483.prototype.cljs$core$async$impl$protocols$Handler$active_QMARK_$arity$1 = ((function (___$1){
return (function (___$1){
var self__ = this;
var ___$2 = this;
return cljs.core.async.impl.protocols.active_QMARK_(self__.fn1);
});})(___$1))
;

cljs.core.async.t_cljs$core$async9483.prototype.cljs$core$async$impl$protocols$Handler$blockable_QMARK_$arity$1 = ((function (___$1){
return (function (___$1){
var self__ = this;
var ___$2 = this;
return true;
});})(___$1))
;

cljs.core.async.t_cljs$core$async9483.prototype.cljs$core$async$impl$protocols$Handler$commit$arity$1 = ((function (___$1){
return (function (___$1){
var self__ = this;
var ___$2 = this;
var f1 = cljs.core.async.impl.protocols.commit(self__.fn1);
return ((function (f1,___$2,___$1){
return (function (p1__9479_SHARP_){
var G__9486 = (((p1__9479_SHARP_ == null))?null:(self__.f.cljs$core$IFn$_invoke$arity$1 ? self__.f.cljs$core$IFn$_invoke$arity$1(p1__9479_SHARP_) : self__.f.call(null,p1__9479_SHARP_)));
return (f1.cljs$core$IFn$_invoke$arity$1 ? f1.cljs$core$IFn$_invoke$arity$1(G__9486) : f1.call(null,G__9486));
});
;})(f1,___$2,___$1))
});})(___$1))
;

cljs.core.async.t_cljs$core$async9483.getBasis = ((function (___$1){
return (function (){
return new cljs.core.PersistentVector(null, 6, 5, cljs.core.PersistentVector.EMPTY_NODE, [cljs.core.cst$sym$f,cljs.core.cst$sym$ch,cljs.core.cst$sym$meta9481,cljs.core.with_meta(cljs.core.cst$sym$_,new cljs.core.PersistentArrayMap(null, 1, [cljs.core.cst$kw$tag,cljs.core.cst$sym$cljs$core$async_SLASH_t_cljs$core$async9480], null)),cljs.core.cst$sym$fn1,cljs.core.cst$sym$meta9484], null);
});})(___$1))
;

cljs.core.async.t_cljs$core$async9483.cljs$lang$type = true;

cljs.core.async.t_cljs$core$async9483.cljs$lang$ctorStr = "cljs.core.async/t_cljs$core$async9483";

cljs.core.async.t_cljs$core$async9483.cljs$lang$ctorPrWriter = ((function (___$1){
return (function (this__4290__auto__,writer__4291__auto__,opt__4292__auto__){
return cljs.core._write(writer__4291__auto__,"cljs.core.async/t_cljs$core$async9483");
});})(___$1))
;

/**
 * Positional factory function for cljs.core.async/t_cljs$core$async9483.
 */
cljs.core.async.__GT_t_cljs$core$async9483 = ((function (___$1){
return (function cljs$core$async$map_LT__$___GT_t_cljs$core$async9483(f__$1,ch__$1,meta9481__$1,___$2,fn1__$1,meta9484){
return (new cljs.core.async.t_cljs$core$async9483(f__$1,ch__$1,meta9481__$1,___$2,fn1__$1,meta9484));
});})(___$1))
;

}

return (new cljs.core.async.t_cljs$core$async9483(self__.f,self__.ch,self__.meta9481,___$1,fn1,cljs.core.PersistentArrayMap.EMPTY));
})()
);
if(cljs.core.truth_((function (){var and__4036__auto__ = ret;
if(cljs.core.truth_(and__4036__auto__)){
return (!((cljs.core.deref(ret) == null)));
} else {
return and__4036__auto__;
}
})())){
return cljs.core.async.impl.channels.box((function (){var G__9487 = cljs.core.deref(ret);
return (self__.f.cljs$core$IFn$_invoke$arity$1 ? self__.f.cljs$core$IFn$_invoke$arity$1(G__9487) : self__.f.call(null,G__9487));
})());
} else {
return ret;
}
});

cljs.core.async.t_cljs$core$async9480.prototype.cljs$core$async$impl$protocols$WritePort$ = cljs.core.PROTOCOL_SENTINEL;

cljs.core.async.t_cljs$core$async9480.prototype.cljs$core$async$impl$protocols$WritePort$put_BANG_$arity$3 = (function (_,val,fn1){
var self__ = this;
var ___$1 = this;
return cljs.core.async.impl.protocols.put_BANG_(self__.ch,val,fn1);
});

cljs.core.async.t_cljs$core$async9480.getBasis = (function (){
return new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [cljs.core.cst$sym$f,cljs.core.cst$sym$ch,cljs.core.cst$sym$meta9481], null);
});

cljs.core.async.t_cljs$core$async9480.cljs$lang$type = true;

cljs.core.async.t_cljs$core$async9480.cljs$lang$ctorStr = "cljs.core.async/t_cljs$core$async9480";

cljs.core.async.t_cljs$core$async9480.cljs$lang$ctorPrWriter = (function (this__4290__auto__,writer__4291__auto__,opt__4292__auto__){
return cljs.core._write(writer__4291__auto__,"cljs.core.async/t_cljs$core$async9480");
});

/**
 * Positional factory function for cljs.core.async/t_cljs$core$async9480.
 */
cljs.core.async.__GT_t_cljs$core$async9480 = (function cljs$core$async$map_LT__$___GT_t_cljs$core$async9480(f__$1,ch__$1,meta9481){
return (new cljs.core.async.t_cljs$core$async9480(f__$1,ch__$1,meta9481));
});

}

return (new cljs.core.async.t_cljs$core$async9480(f,ch,cljs.core.PersistentArrayMap.EMPTY));
});
/**
 * Deprecated - this function will be removed. Use transducer instead
 */
cljs.core.async.map_GT_ = (function cljs$core$async$map_GT_(f,ch){
if((typeof cljs !== 'undefined') && (typeof cljs.core !== 'undefined') && (typeof cljs.core.async !== 'undefined') && (typeof cljs.core.async.t_cljs$core$async9488 !== 'undefined')){
} else {

/**
* @constructor
 * @implements {cljs.core.async.impl.protocols.Channel}
 * @implements {cljs.core.async.impl.protocols.WritePort}
 * @implements {cljs.core.async.impl.protocols.ReadPort}
 * @implements {cljs.core.IMeta}
 * @implements {cljs.core.IWithMeta}
*/
cljs.core.async.t_cljs$core$async9488 = (function (f,ch,meta9489){
this.f = f;
this.ch = ch;
this.meta9489 = meta9489;
this.cljs$lang$protocol_mask$partition0$ = 393216;
this.cljs$lang$protocol_mask$partition1$ = 0;
});
cljs.core.async.t_cljs$core$async9488.prototype.cljs$core$IWithMeta$_with_meta$arity$2 = (function (_9490,meta9489__$1){
var self__ = this;
var _9490__$1 = this;
return (new cljs.core.async.t_cljs$core$async9488(self__.f,self__.ch,meta9489__$1));
});

cljs.core.async.t_cljs$core$async9488.prototype.cljs$core$IMeta$_meta$arity$1 = (function (_9490){
var self__ = this;
var _9490__$1 = this;
return self__.meta9489;
});

cljs.core.async.t_cljs$core$async9488.prototype.cljs$core$async$impl$protocols$Channel$ = cljs.core.PROTOCOL_SENTINEL;

cljs.core.async.t_cljs$core$async9488.prototype.cljs$core$async$impl$protocols$Channel$close_BANG_$arity$1 = (function (_){
var self__ = this;
var ___$1 = this;
return cljs.core.async.impl.protocols.close_BANG_(self__.ch);
});

cljs.core.async.t_cljs$core$async9488.prototype.cljs$core$async$impl$protocols$ReadPort$ = cljs.core.PROTOCOL_SENTINEL;

cljs.core.async.t_cljs$core$async9488.prototype.cljs$core$async$impl$protocols$ReadPort$take_BANG_$arity$2 = (function (_,fn1){
var self__ = this;
var ___$1 = this;
return cljs.core.async.impl.protocols.take_BANG_(self__.ch,fn1);
});

cljs.core.async.t_cljs$core$async9488.prototype.cljs$core$async$impl$protocols$WritePort$ = cljs.core.PROTOCOL_SENTINEL;

cljs.core.async.t_cljs$core$async9488.prototype.cljs$core$async$impl$protocols$WritePort$put_BANG_$arity$3 = (function (_,val,fn1){
var self__ = this;
var ___$1 = this;
return cljs.core.async.impl.protocols.put_BANG_(self__.ch,(self__.f.cljs$core$IFn$_invoke$arity$1 ? self__.f.cljs$core$IFn$_invoke$arity$1(val) : self__.f.call(null,val)),fn1);
});

cljs.core.async.t_cljs$core$async9488.getBasis = (function (){
return new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [cljs.core.cst$sym$f,cljs.core.cst$sym$ch,cljs.core.cst$sym$meta9489], null);
});

cljs.core.async.t_cljs$core$async9488.cljs$lang$type = true;

cljs.core.async.t_cljs$core$async9488.cljs$lang$ctorStr = "cljs.core.async/t_cljs$core$async9488";

cljs.core.async.t_cljs$core$async9488.cljs$lang$ctorPrWriter = (function (this__4290__auto__,writer__4291__auto__,opt__4292__auto__){
return cljs.core._write(writer__4291__auto__,"cljs.core.async/t_cljs$core$async9488");
});

/**
 * Positional factory function for cljs.core.async/t_cljs$core$async9488.
 */
cljs.core.async.__GT_t_cljs$core$async9488 = (function cljs$core$async$map_GT__$___GT_t_cljs$core$async9488(f__$1,ch__$1,meta9489){
return (new cljs.core.async.t_cljs$core$async9488(f__$1,ch__$1,meta9489));
});

}

return (new cljs.core.async.t_cljs$core$async9488(f,ch,cljs.core.PersistentArrayMap.EMPTY));
});
/**
 * Deprecated - this function will be removed. Use transducer instead
 */
cljs.core.async.filter_GT_ = (function cljs$core$async$filter_GT_(p,ch){
if((typeof cljs !== 'undefined') && (typeof cljs.core !== 'undefined') && (typeof cljs.core.async !== 'undefined') && (typeof cljs.core.async.t_cljs$core$async9491 !== 'undefined')){
} else {

/**
* @constructor
 * @implements {cljs.core.async.impl.protocols.Channel}
 * @implements {cljs.core.async.impl.protocols.WritePort}
 * @implements {cljs.core.async.impl.protocols.ReadPort}
 * @implements {cljs.core.IMeta}
 * @implements {cljs.core.IWithMeta}
*/
cljs.core.async.t_cljs$core$async9491 = (function (p,ch,meta9492){
this.p = p;
this.ch = ch;
this.meta9492 = meta9492;
this.cljs$lang$protocol_mask$partition0$ = 393216;
this.cljs$lang$protocol_mask$partition1$ = 0;
});
cljs.core.async.t_cljs$core$async9491.prototype.cljs$core$IWithMeta$_with_meta$arity$2 = (function (_9493,meta9492__$1){
var self__ = this;
var _9493__$1 = this;
return (new cljs.core.async.t_cljs$core$async9491(self__.p,self__.ch,meta9492__$1));
});

cljs.core.async.t_cljs$core$async9491.prototype.cljs$core$IMeta$_meta$arity$1 = (function (_9493){
var self__ = this;
var _9493__$1 = this;
return self__.meta9492;
});

cljs.core.async.t_cljs$core$async9491.prototype.cljs$core$async$impl$protocols$Channel$ = cljs.core.PROTOCOL_SENTINEL;

cljs.core.async.t_cljs$core$async9491.prototype.cljs$core$async$impl$protocols$Channel$close_BANG_$arity$1 = (function (_){
var self__ = this;
var ___$1 = this;
return cljs.core.async.impl.protocols.close_BANG_(self__.ch);
});

cljs.core.async.t_cljs$core$async9491.prototype.cljs$core$async$impl$protocols$Channel$closed_QMARK_$arity$1 = (function (_){
var self__ = this;
var ___$1 = this;
return cljs.core.async.impl.protocols.closed_QMARK_(self__.ch);
});

cljs.core.async.t_cljs$core$async9491.prototype.cljs$core$async$impl$protocols$ReadPort$ = cljs.core.PROTOCOL_SENTINEL;

cljs.core.async.t_cljs$core$async9491.prototype.cljs$core$async$impl$protocols$ReadPort$take_BANG_$arity$2 = (function (_,fn1){
var self__ = this;
var ___$1 = this;
return cljs.core.async.impl.protocols.take_BANG_(self__.ch,fn1);
});

cljs.core.async.t_cljs$core$async9491.prototype.cljs$core$async$impl$protocols$WritePort$ = cljs.core.PROTOCOL_SENTINEL;

cljs.core.async.t_cljs$core$async9491.prototype.cljs$core$async$impl$protocols$WritePort$put_BANG_$arity$3 = (function (_,val,fn1){
var self__ = this;
var ___$1 = this;
if(cljs.core.truth_((self__.p.cljs$core$IFn$_invoke$arity$1 ? self__.p.cljs$core$IFn$_invoke$arity$1(val) : self__.p.call(null,val)))){
return cljs.core.async.impl.protocols.put_BANG_(self__.ch,val,fn1);
} else {
return cljs.core.async.impl.channels.box(cljs.core.not(cljs.core.async.impl.protocols.closed_QMARK_(self__.ch)));
}
});

cljs.core.async.t_cljs$core$async9491.getBasis = (function (){
return new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [cljs.core.cst$sym$p,cljs.core.cst$sym$ch,cljs.core.cst$sym$meta9492], null);
});

cljs.core.async.t_cljs$core$async9491.cljs$lang$type = true;

cljs.core.async.t_cljs$core$async9491.cljs$lang$ctorStr = "cljs.core.async/t_cljs$core$async9491";

cljs.core.async.t_cljs$core$async9491.cljs$lang$ctorPrWriter = (function (this__4290__auto__,writer__4291__auto__,opt__4292__auto__){
return cljs.core._write(writer__4291__auto__,"cljs.core.async/t_cljs$core$async9491");
});

/**
 * Positional factory function for cljs.core.async/t_cljs$core$async9491.
 */
cljs.core.async.__GT_t_cljs$core$async9491 = (function cljs$core$async$filter_GT__$___GT_t_cljs$core$async9491(p__$1,ch__$1,meta9492){
return (new cljs.core.async.t_cljs$core$async9491(p__$1,ch__$1,meta9492));
});

}

return (new cljs.core.async.t_cljs$core$async9491(p,ch,cljs.core.PersistentArrayMap.EMPTY));
});
/**
 * Deprecated - this function will be removed. Use transducer instead
 */
cljs.core.async.remove_GT_ = (function cljs$core$async$remove_GT_(p,ch){
return cljs.core.async.filter_GT_(cljs.core.complement(p),ch);
});
/**
 * Deprecated - this function will be removed. Use transducer instead
 */
cljs.core.async.filter_LT_ = (function cljs$core$async$filter_LT_(var_args){
var G__9495 = arguments.length;
switch (G__9495) {
case 2:
return cljs.core.async.filter_LT_.cljs$core$IFn$_invoke$arity$2((arguments[(0)]),(arguments[(1)]));

break;
case 3:
return cljs.core.async.filter_LT_.cljs$core$IFn$_invoke$arity$3((arguments[(0)]),(arguments[(1)]),(arguments[(2)]));

break;
default:
throw (new Error(["Invalid arity: ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(arguments.length)].join('')));

}
});

cljs.core.async.filter_LT_.cljs$core$IFn$_invoke$arity$2 = (function (p,ch){
return cljs.core.async.filter_LT_.cljs$core$IFn$_invoke$arity$3(p,ch,null);
});

cljs.core.async.filter_LT_.cljs$core$IFn$_invoke$arity$3 = (function (p,ch,buf_or_n){
var out = cljs.core.async.chan.cljs$core$IFn$_invoke$arity$1(buf_or_n);
var c__7992__auto___9535 = cljs.core.async.chan.cljs$core$IFn$_invoke$arity$1((1));
cljs.core.async.impl.dispatch.run(((function (c__7992__auto___9535,out){
return (function (){
var f__7993__auto__ = (function (){var switch__7885__auto__ = ((function (c__7992__auto___9535,out){
return (function (state_9516){
var state_val_9517 = (state_9516[(1)]);
if((state_val_9517 === (7))){
var inst_9512 = (state_9516[(2)]);
var state_9516__$1 = state_9516;
var statearr_9518_9536 = state_9516__$1;
(statearr_9518_9536[(2)] = inst_9512);

(statearr_9518_9536[(1)] = (3));


return cljs.core.cst$kw$recur;
} else {
if((state_val_9517 === (1))){
var state_9516__$1 = state_9516;
var statearr_9519_9537 = state_9516__$1;
(statearr_9519_9537[(2)] = null);

(statearr_9519_9537[(1)] = (2));


return cljs.core.cst$kw$recur;
} else {
if((state_val_9517 === (4))){
var inst_9498 = (state_9516[(7)]);
var inst_9498__$1 = (state_9516[(2)]);
var inst_9499 = (inst_9498__$1 == null);
var state_9516__$1 = (function (){var statearr_9520 = state_9516;
(statearr_9520[(7)] = inst_9498__$1);

return statearr_9520;
})();
if(cljs.core.truth_(inst_9499)){
var statearr_9521_9538 = state_9516__$1;
(statearr_9521_9538[(1)] = (5));

} else {
var statearr_9522_9539 = state_9516__$1;
(statearr_9522_9539[(1)] = (6));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_9517 === (6))){
var inst_9498 = (state_9516[(7)]);
var inst_9503 = (p.cljs$core$IFn$_invoke$arity$1 ? p.cljs$core$IFn$_invoke$arity$1(inst_9498) : p.call(null,inst_9498));
var state_9516__$1 = state_9516;
if(cljs.core.truth_(inst_9503)){
var statearr_9523_9540 = state_9516__$1;
(statearr_9523_9540[(1)] = (8));

} else {
var statearr_9524_9541 = state_9516__$1;
(statearr_9524_9541[(1)] = (9));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_9517 === (3))){
var inst_9514 = (state_9516[(2)]);
var state_9516__$1 = state_9516;
return cljs.core.async.impl.ioc_helpers.return_chan(state_9516__$1,inst_9514);
} else {
if((state_val_9517 === (2))){
var state_9516__$1 = state_9516;
return cljs.core.async.impl.ioc_helpers.take_BANG_(state_9516__$1,(4),ch);
} else {
if((state_val_9517 === (11))){
var inst_9506 = (state_9516[(2)]);
var state_9516__$1 = state_9516;
var statearr_9525_9542 = state_9516__$1;
(statearr_9525_9542[(2)] = inst_9506);

(statearr_9525_9542[(1)] = (10));


return cljs.core.cst$kw$recur;
} else {
if((state_val_9517 === (9))){
var state_9516__$1 = state_9516;
var statearr_9526_9543 = state_9516__$1;
(statearr_9526_9543[(2)] = null);

(statearr_9526_9543[(1)] = (10));


return cljs.core.cst$kw$recur;
} else {
if((state_val_9517 === (5))){
var inst_9501 = cljs.core.async.close_BANG_(out);
var state_9516__$1 = state_9516;
var statearr_9527_9544 = state_9516__$1;
(statearr_9527_9544[(2)] = inst_9501);

(statearr_9527_9544[(1)] = (7));


return cljs.core.cst$kw$recur;
} else {
if((state_val_9517 === (10))){
var inst_9509 = (state_9516[(2)]);
var state_9516__$1 = (function (){var statearr_9528 = state_9516;
(statearr_9528[(8)] = inst_9509);

return statearr_9528;
})();
var statearr_9529_9545 = state_9516__$1;
(statearr_9529_9545[(2)] = null);

(statearr_9529_9545[(1)] = (2));


return cljs.core.cst$kw$recur;
} else {
if((state_val_9517 === (8))){
var inst_9498 = (state_9516[(7)]);
var state_9516__$1 = state_9516;
return cljs.core.async.impl.ioc_helpers.put_BANG_(state_9516__$1,(11),out,inst_9498);
} else {
return null;
}
}
}
}
}
}
}
}
}
}
}
});})(c__7992__auto___9535,out))
;
return ((function (switch__7885__auto__,c__7992__auto___9535,out){
return (function() {
var cljs$core$async$state_machine__7886__auto__ = null;
var cljs$core$async$state_machine__7886__auto____0 = (function (){
var statearr_9530 = [null,null,null,null,null,null,null,null,null];
(statearr_9530[(0)] = cljs$core$async$state_machine__7886__auto__);

(statearr_9530[(1)] = (1));

return statearr_9530;
});
var cljs$core$async$state_machine__7886__auto____1 = (function (state_9516){
while(true){
var ret_value__7887__auto__ = (function (){try{while(true){
var result__7888__auto__ = switch__7885__auto__(state_9516);
if(cljs.core.keyword_identical_QMARK_(result__7888__auto__,cljs.core.cst$kw$recur)){
continue;
} else {
return result__7888__auto__;
}
break;
}
}catch (e9531){if((e9531 instanceof Object)){
var ex__7889__auto__ = e9531;
var statearr_9532_9546 = state_9516;
(statearr_9532_9546[(5)] = ex__7889__auto__);


cljs.core.async.impl.ioc_helpers.process_exception(state_9516);

return cljs.core.cst$kw$recur;
} else {
throw e9531;

}
}})();
if(cljs.core.keyword_identical_QMARK_(ret_value__7887__auto__,cljs.core.cst$kw$recur)){
var G__9547 = state_9516;
state_9516 = G__9547;
continue;
} else {
return ret_value__7887__auto__;
}
break;
}
});
cljs$core$async$state_machine__7886__auto__ = function(state_9516){
switch(arguments.length){
case 0:
return cljs$core$async$state_machine__7886__auto____0.call(this);
case 1:
return cljs$core$async$state_machine__7886__auto____1.call(this,state_9516);
}
throw(new Error('Invalid arity: ' + arguments.length));
};
cljs$core$async$state_machine__7886__auto__.cljs$core$IFn$_invoke$arity$0 = cljs$core$async$state_machine__7886__auto____0;
cljs$core$async$state_machine__7886__auto__.cljs$core$IFn$_invoke$arity$1 = cljs$core$async$state_machine__7886__auto____1;
return cljs$core$async$state_machine__7886__auto__;
})()
;})(switch__7885__auto__,c__7992__auto___9535,out))
})();
var state__7994__auto__ = (function (){var statearr_9533 = (f__7993__auto__.cljs$core$IFn$_invoke$arity$0 ? f__7993__auto__.cljs$core$IFn$_invoke$arity$0() : f__7993__auto__.call(null));
(statearr_9533[(6)] = c__7992__auto___9535);

return statearr_9533;
})();
return cljs.core.async.impl.ioc_helpers.run_state_machine_wrapped(state__7994__auto__);
});})(c__7992__auto___9535,out))
);


return out;
});

cljs.core.async.filter_LT_.cljs$lang$maxFixedArity = 3;

/**
 * Deprecated - this function will be removed. Use transducer instead
 */
cljs.core.async.remove_LT_ = (function cljs$core$async$remove_LT_(var_args){
var G__9549 = arguments.length;
switch (G__9549) {
case 2:
return cljs.core.async.remove_LT_.cljs$core$IFn$_invoke$arity$2((arguments[(0)]),(arguments[(1)]));

break;
case 3:
return cljs.core.async.remove_LT_.cljs$core$IFn$_invoke$arity$3((arguments[(0)]),(arguments[(1)]),(arguments[(2)]));

break;
default:
throw (new Error(["Invalid arity: ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(arguments.length)].join('')));

}
});

cljs.core.async.remove_LT_.cljs$core$IFn$_invoke$arity$2 = (function (p,ch){
return cljs.core.async.remove_LT_.cljs$core$IFn$_invoke$arity$3(p,ch,null);
});

cljs.core.async.remove_LT_.cljs$core$IFn$_invoke$arity$3 = (function (p,ch,buf_or_n){
return cljs.core.async.filter_LT_.cljs$core$IFn$_invoke$arity$3(cljs.core.complement(p),ch,buf_or_n);
});

cljs.core.async.remove_LT_.cljs$lang$maxFixedArity = 3;

cljs.core.async.mapcat_STAR_ = (function cljs$core$async$mapcat_STAR_(f,in$,out){
var c__7992__auto__ = cljs.core.async.chan.cljs$core$IFn$_invoke$arity$1((1));
cljs.core.async.impl.dispatch.run(((function (c__7992__auto__){
return (function (){
var f__7993__auto__ = (function (){var switch__7885__auto__ = ((function (c__7992__auto__){
return (function (state_9612){
var state_val_9613 = (state_9612[(1)]);
if((state_val_9613 === (7))){
var inst_9608 = (state_9612[(2)]);
var state_9612__$1 = state_9612;
var statearr_9614_9652 = state_9612__$1;
(statearr_9614_9652[(2)] = inst_9608);

(statearr_9614_9652[(1)] = (3));


return cljs.core.cst$kw$recur;
} else {
if((state_val_9613 === (20))){
var inst_9578 = (state_9612[(7)]);
var inst_9589 = (state_9612[(2)]);
var inst_9590 = cljs.core.next(inst_9578);
var inst_9564 = inst_9590;
var inst_9565 = null;
var inst_9566 = (0);
var inst_9567 = (0);
var state_9612__$1 = (function (){var statearr_9615 = state_9612;
(statearr_9615[(8)] = inst_9567);

(statearr_9615[(9)] = inst_9564);

(statearr_9615[(10)] = inst_9565);

(statearr_9615[(11)] = inst_9566);

(statearr_9615[(12)] = inst_9589);

return statearr_9615;
})();
var statearr_9616_9653 = state_9612__$1;
(statearr_9616_9653[(2)] = null);

(statearr_9616_9653[(1)] = (8));


return cljs.core.cst$kw$recur;
} else {
if((state_val_9613 === (1))){
var state_9612__$1 = state_9612;
var statearr_9617_9654 = state_9612__$1;
(statearr_9617_9654[(2)] = null);

(statearr_9617_9654[(1)] = (2));


return cljs.core.cst$kw$recur;
} else {
if((state_val_9613 === (4))){
var inst_9553 = (state_9612[(13)]);
var inst_9553__$1 = (state_9612[(2)]);
var inst_9554 = (inst_9553__$1 == null);
var state_9612__$1 = (function (){var statearr_9618 = state_9612;
(statearr_9618[(13)] = inst_9553__$1);

return statearr_9618;
})();
if(cljs.core.truth_(inst_9554)){
var statearr_9619_9655 = state_9612__$1;
(statearr_9619_9655[(1)] = (5));

} else {
var statearr_9620_9656 = state_9612__$1;
(statearr_9620_9656[(1)] = (6));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_9613 === (15))){
var state_9612__$1 = state_9612;
var statearr_9624_9657 = state_9612__$1;
(statearr_9624_9657[(2)] = null);

(statearr_9624_9657[(1)] = (16));


return cljs.core.cst$kw$recur;
} else {
if((state_val_9613 === (21))){
var state_9612__$1 = state_9612;
var statearr_9625_9658 = state_9612__$1;
(statearr_9625_9658[(2)] = null);

(statearr_9625_9658[(1)] = (23));


return cljs.core.cst$kw$recur;
} else {
if((state_val_9613 === (13))){
var inst_9567 = (state_9612[(8)]);
var inst_9564 = (state_9612[(9)]);
var inst_9565 = (state_9612[(10)]);
var inst_9566 = (state_9612[(11)]);
var inst_9574 = (state_9612[(2)]);
var inst_9575 = (inst_9567 + (1));
var tmp9621 = inst_9564;
var tmp9622 = inst_9565;
var tmp9623 = inst_9566;
var inst_9564__$1 = tmp9621;
var inst_9565__$1 = tmp9622;
var inst_9566__$1 = tmp9623;
var inst_9567__$1 = inst_9575;
var state_9612__$1 = (function (){var statearr_9626 = state_9612;
(statearr_9626[(8)] = inst_9567__$1);

(statearr_9626[(14)] = inst_9574);

(statearr_9626[(9)] = inst_9564__$1);

(statearr_9626[(10)] = inst_9565__$1);

(statearr_9626[(11)] = inst_9566__$1);

return statearr_9626;
})();
var statearr_9627_9659 = state_9612__$1;
(statearr_9627_9659[(2)] = null);

(statearr_9627_9659[(1)] = (8));


return cljs.core.cst$kw$recur;
} else {
if((state_val_9613 === (22))){
var state_9612__$1 = state_9612;
var statearr_9628_9660 = state_9612__$1;
(statearr_9628_9660[(2)] = null);

(statearr_9628_9660[(1)] = (2));


return cljs.core.cst$kw$recur;
} else {
if((state_val_9613 === (6))){
var inst_9553 = (state_9612[(13)]);
var inst_9562 = (f.cljs$core$IFn$_invoke$arity$1 ? f.cljs$core$IFn$_invoke$arity$1(inst_9553) : f.call(null,inst_9553));
var inst_9563 = cljs.core.seq(inst_9562);
var inst_9564 = inst_9563;
var inst_9565 = null;
var inst_9566 = (0);
var inst_9567 = (0);
var state_9612__$1 = (function (){var statearr_9629 = state_9612;
(statearr_9629[(8)] = inst_9567);

(statearr_9629[(9)] = inst_9564);

(statearr_9629[(10)] = inst_9565);

(statearr_9629[(11)] = inst_9566);

return statearr_9629;
})();
var statearr_9630_9661 = state_9612__$1;
(statearr_9630_9661[(2)] = null);

(statearr_9630_9661[(1)] = (8));


return cljs.core.cst$kw$recur;
} else {
if((state_val_9613 === (17))){
var inst_9578 = (state_9612[(7)]);
var inst_9582 = cljs.core.chunk_first(inst_9578);
var inst_9583 = cljs.core.chunk_rest(inst_9578);
var inst_9584 = cljs.core.count(inst_9582);
var inst_9564 = inst_9583;
var inst_9565 = inst_9582;
var inst_9566 = inst_9584;
var inst_9567 = (0);
var state_9612__$1 = (function (){var statearr_9631 = state_9612;
(statearr_9631[(8)] = inst_9567);

(statearr_9631[(9)] = inst_9564);

(statearr_9631[(10)] = inst_9565);

(statearr_9631[(11)] = inst_9566);

return statearr_9631;
})();
var statearr_9632_9662 = state_9612__$1;
(statearr_9632_9662[(2)] = null);

(statearr_9632_9662[(1)] = (8));


return cljs.core.cst$kw$recur;
} else {
if((state_val_9613 === (3))){
var inst_9610 = (state_9612[(2)]);
var state_9612__$1 = state_9612;
return cljs.core.async.impl.ioc_helpers.return_chan(state_9612__$1,inst_9610);
} else {
if((state_val_9613 === (12))){
var inst_9598 = (state_9612[(2)]);
var state_9612__$1 = state_9612;
var statearr_9633_9663 = state_9612__$1;
(statearr_9633_9663[(2)] = inst_9598);

(statearr_9633_9663[(1)] = (9));


return cljs.core.cst$kw$recur;
} else {
if((state_val_9613 === (2))){
var state_9612__$1 = state_9612;
return cljs.core.async.impl.ioc_helpers.take_BANG_(state_9612__$1,(4),in$);
} else {
if((state_val_9613 === (23))){
var inst_9606 = (state_9612[(2)]);
var state_9612__$1 = state_9612;
var statearr_9634_9664 = state_9612__$1;
(statearr_9634_9664[(2)] = inst_9606);

(statearr_9634_9664[(1)] = (7));


return cljs.core.cst$kw$recur;
} else {
if((state_val_9613 === (19))){
var inst_9593 = (state_9612[(2)]);
var state_9612__$1 = state_9612;
var statearr_9635_9665 = state_9612__$1;
(statearr_9635_9665[(2)] = inst_9593);

(statearr_9635_9665[(1)] = (16));


return cljs.core.cst$kw$recur;
} else {
if((state_val_9613 === (11))){
var inst_9578 = (state_9612[(7)]);
var inst_9564 = (state_9612[(9)]);
var inst_9578__$1 = cljs.core.seq(inst_9564);
var state_9612__$1 = (function (){var statearr_9636 = state_9612;
(statearr_9636[(7)] = inst_9578__$1);

return statearr_9636;
})();
if(inst_9578__$1){
var statearr_9637_9666 = state_9612__$1;
(statearr_9637_9666[(1)] = (14));

} else {
var statearr_9638_9667 = state_9612__$1;
(statearr_9638_9667[(1)] = (15));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_9613 === (9))){
var inst_9600 = (state_9612[(2)]);
var inst_9601 = cljs.core.async.impl.protocols.closed_QMARK_(out);
var state_9612__$1 = (function (){var statearr_9639 = state_9612;
(statearr_9639[(15)] = inst_9600);

return statearr_9639;
})();
if(cljs.core.truth_(inst_9601)){
var statearr_9640_9668 = state_9612__$1;
(statearr_9640_9668[(1)] = (21));

} else {
var statearr_9641_9669 = state_9612__$1;
(statearr_9641_9669[(1)] = (22));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_9613 === (5))){
var inst_9556 = cljs.core.async.close_BANG_(out);
var state_9612__$1 = state_9612;
var statearr_9642_9670 = state_9612__$1;
(statearr_9642_9670[(2)] = inst_9556);

(statearr_9642_9670[(1)] = (7));


return cljs.core.cst$kw$recur;
} else {
if((state_val_9613 === (14))){
var inst_9578 = (state_9612[(7)]);
var inst_9580 = cljs.core.chunked_seq_QMARK_(inst_9578);
var state_9612__$1 = state_9612;
if(inst_9580){
var statearr_9643_9671 = state_9612__$1;
(statearr_9643_9671[(1)] = (17));

} else {
var statearr_9644_9672 = state_9612__$1;
(statearr_9644_9672[(1)] = (18));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_9613 === (16))){
var inst_9596 = (state_9612[(2)]);
var state_9612__$1 = state_9612;
var statearr_9645_9673 = state_9612__$1;
(statearr_9645_9673[(2)] = inst_9596);

(statearr_9645_9673[(1)] = (12));


return cljs.core.cst$kw$recur;
} else {
if((state_val_9613 === (10))){
var inst_9567 = (state_9612[(8)]);
var inst_9565 = (state_9612[(10)]);
var inst_9572 = cljs.core._nth.cljs$core$IFn$_invoke$arity$2(inst_9565,inst_9567);
var state_9612__$1 = state_9612;
return cljs.core.async.impl.ioc_helpers.put_BANG_(state_9612__$1,(13),out,inst_9572);
} else {
if((state_val_9613 === (18))){
var inst_9578 = (state_9612[(7)]);
var inst_9587 = cljs.core.first(inst_9578);
var state_9612__$1 = state_9612;
return cljs.core.async.impl.ioc_helpers.put_BANG_(state_9612__$1,(20),out,inst_9587);
} else {
if((state_val_9613 === (8))){
var inst_9567 = (state_9612[(8)]);
var inst_9566 = (state_9612[(11)]);
var inst_9569 = (inst_9567 < inst_9566);
var inst_9570 = inst_9569;
var state_9612__$1 = state_9612;
if(cljs.core.truth_(inst_9570)){
var statearr_9646_9674 = state_9612__$1;
(statearr_9646_9674[(1)] = (10));

} else {
var statearr_9647_9675 = state_9612__$1;
(statearr_9647_9675[(1)] = (11));

}

return cljs.core.cst$kw$recur;
} else {
return null;
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
});})(c__7992__auto__))
;
return ((function (switch__7885__auto__,c__7992__auto__){
return (function() {
var cljs$core$async$mapcat_STAR__$_state_machine__7886__auto__ = null;
var cljs$core$async$mapcat_STAR__$_state_machine__7886__auto____0 = (function (){
var statearr_9648 = [null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null];
(statearr_9648[(0)] = cljs$core$async$mapcat_STAR__$_state_machine__7886__auto__);

(statearr_9648[(1)] = (1));

return statearr_9648;
});
var cljs$core$async$mapcat_STAR__$_state_machine__7886__auto____1 = (function (state_9612){
while(true){
var ret_value__7887__auto__ = (function (){try{while(true){
var result__7888__auto__ = switch__7885__auto__(state_9612);
if(cljs.core.keyword_identical_QMARK_(result__7888__auto__,cljs.core.cst$kw$recur)){
continue;
} else {
return result__7888__auto__;
}
break;
}
}catch (e9649){if((e9649 instanceof Object)){
var ex__7889__auto__ = e9649;
var statearr_9650_9676 = state_9612;
(statearr_9650_9676[(5)] = ex__7889__auto__);


cljs.core.async.impl.ioc_helpers.process_exception(state_9612);

return cljs.core.cst$kw$recur;
} else {
throw e9649;

}
}})();
if(cljs.core.keyword_identical_QMARK_(ret_value__7887__auto__,cljs.core.cst$kw$recur)){
var G__9677 = state_9612;
state_9612 = G__9677;
continue;
} else {
return ret_value__7887__auto__;
}
break;
}
});
cljs$core$async$mapcat_STAR__$_state_machine__7886__auto__ = function(state_9612){
switch(arguments.length){
case 0:
return cljs$core$async$mapcat_STAR__$_state_machine__7886__auto____0.call(this);
case 1:
return cljs$core$async$mapcat_STAR__$_state_machine__7886__auto____1.call(this,state_9612);
}
throw(new Error('Invalid arity: ' + arguments.length));
};
cljs$core$async$mapcat_STAR__$_state_machine__7886__auto__.cljs$core$IFn$_invoke$arity$0 = cljs$core$async$mapcat_STAR__$_state_machine__7886__auto____0;
cljs$core$async$mapcat_STAR__$_state_machine__7886__auto__.cljs$core$IFn$_invoke$arity$1 = cljs$core$async$mapcat_STAR__$_state_machine__7886__auto____1;
return cljs$core$async$mapcat_STAR__$_state_machine__7886__auto__;
})()
;})(switch__7885__auto__,c__7992__auto__))
})();
var state__7994__auto__ = (function (){var statearr_9651 = (f__7993__auto__.cljs$core$IFn$_invoke$arity$0 ? f__7993__auto__.cljs$core$IFn$_invoke$arity$0() : f__7993__auto__.call(null));
(statearr_9651[(6)] = c__7992__auto__);

return statearr_9651;
})();
return cljs.core.async.impl.ioc_helpers.run_state_machine_wrapped(state__7994__auto__);
});})(c__7992__auto__))
);

return c__7992__auto__;
});
/**
 * Deprecated - this function will be removed. Use transducer instead
 */
cljs.core.async.mapcat_LT_ = (function cljs$core$async$mapcat_LT_(var_args){
var G__9679 = arguments.length;
switch (G__9679) {
case 2:
return cljs.core.async.mapcat_LT_.cljs$core$IFn$_invoke$arity$2((arguments[(0)]),(arguments[(1)]));

break;
case 3:
return cljs.core.async.mapcat_LT_.cljs$core$IFn$_invoke$arity$3((arguments[(0)]),(arguments[(1)]),(arguments[(2)]));

break;
default:
throw (new Error(["Invalid arity: ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(arguments.length)].join('')));

}
});

cljs.core.async.mapcat_LT_.cljs$core$IFn$_invoke$arity$2 = (function (f,in$){
return cljs.core.async.mapcat_LT_.cljs$core$IFn$_invoke$arity$3(f,in$,null);
});

cljs.core.async.mapcat_LT_.cljs$core$IFn$_invoke$arity$3 = (function (f,in$,buf_or_n){
var out = cljs.core.async.chan.cljs$core$IFn$_invoke$arity$1(buf_or_n);
cljs.core.async.mapcat_STAR_(f,in$,out);

return out;
});

cljs.core.async.mapcat_LT_.cljs$lang$maxFixedArity = 3;

/**
 * Deprecated - this function will be removed. Use transducer instead
 */
cljs.core.async.mapcat_GT_ = (function cljs$core$async$mapcat_GT_(var_args){
var G__9682 = arguments.length;
switch (G__9682) {
case 2:
return cljs.core.async.mapcat_GT_.cljs$core$IFn$_invoke$arity$2((arguments[(0)]),(arguments[(1)]));

break;
case 3:
return cljs.core.async.mapcat_GT_.cljs$core$IFn$_invoke$arity$3((arguments[(0)]),(arguments[(1)]),(arguments[(2)]));

break;
default:
throw (new Error(["Invalid arity: ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(arguments.length)].join('')));

}
});

cljs.core.async.mapcat_GT_.cljs$core$IFn$_invoke$arity$2 = (function (f,out){
return cljs.core.async.mapcat_GT_.cljs$core$IFn$_invoke$arity$3(f,out,null);
});

cljs.core.async.mapcat_GT_.cljs$core$IFn$_invoke$arity$3 = (function (f,out,buf_or_n){
var in$ = cljs.core.async.chan.cljs$core$IFn$_invoke$arity$1(buf_or_n);
cljs.core.async.mapcat_STAR_(f,in$,out);

return in$;
});

cljs.core.async.mapcat_GT_.cljs$lang$maxFixedArity = 3;

/**
 * Deprecated - this function will be removed. Use transducer instead
 */
cljs.core.async.unique = (function cljs$core$async$unique(var_args){
var G__9685 = arguments.length;
switch (G__9685) {
case 1:
return cljs.core.async.unique.cljs$core$IFn$_invoke$arity$1((arguments[(0)]));

break;
case 2:
return cljs.core.async.unique.cljs$core$IFn$_invoke$arity$2((arguments[(0)]),(arguments[(1)]));

break;
default:
throw (new Error(["Invalid arity: ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(arguments.length)].join('')));

}
});

cljs.core.async.unique.cljs$core$IFn$_invoke$arity$1 = (function (ch){
return cljs.core.async.unique.cljs$core$IFn$_invoke$arity$2(ch,null);
});

cljs.core.async.unique.cljs$core$IFn$_invoke$arity$2 = (function (ch,buf_or_n){
var out = cljs.core.async.chan.cljs$core$IFn$_invoke$arity$1(buf_or_n);
var c__7992__auto___9732 = cljs.core.async.chan.cljs$core$IFn$_invoke$arity$1((1));
cljs.core.async.impl.dispatch.run(((function (c__7992__auto___9732,out){
return (function (){
var f__7993__auto__ = (function (){var switch__7885__auto__ = ((function (c__7992__auto___9732,out){
return (function (state_9709){
var state_val_9710 = (state_9709[(1)]);
if((state_val_9710 === (7))){
var inst_9704 = (state_9709[(2)]);
var state_9709__$1 = state_9709;
var statearr_9711_9733 = state_9709__$1;
(statearr_9711_9733[(2)] = inst_9704);

(statearr_9711_9733[(1)] = (3));


return cljs.core.cst$kw$recur;
} else {
if((state_val_9710 === (1))){
var inst_9686 = null;
var state_9709__$1 = (function (){var statearr_9712 = state_9709;
(statearr_9712[(7)] = inst_9686);

return statearr_9712;
})();
var statearr_9713_9734 = state_9709__$1;
(statearr_9713_9734[(2)] = null);

(statearr_9713_9734[(1)] = (2));


return cljs.core.cst$kw$recur;
} else {
if((state_val_9710 === (4))){
var inst_9689 = (state_9709[(8)]);
var inst_9689__$1 = (state_9709[(2)]);
var inst_9690 = (inst_9689__$1 == null);
var inst_9691 = cljs.core.not(inst_9690);
var state_9709__$1 = (function (){var statearr_9714 = state_9709;
(statearr_9714[(8)] = inst_9689__$1);

return statearr_9714;
})();
if(inst_9691){
var statearr_9715_9735 = state_9709__$1;
(statearr_9715_9735[(1)] = (5));

} else {
var statearr_9716_9736 = state_9709__$1;
(statearr_9716_9736[(1)] = (6));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_9710 === (6))){
var state_9709__$1 = state_9709;
var statearr_9717_9737 = state_9709__$1;
(statearr_9717_9737[(2)] = null);

(statearr_9717_9737[(1)] = (7));


return cljs.core.cst$kw$recur;
} else {
if((state_val_9710 === (3))){
var inst_9706 = (state_9709[(2)]);
var inst_9707 = cljs.core.async.close_BANG_(out);
var state_9709__$1 = (function (){var statearr_9718 = state_9709;
(statearr_9718[(9)] = inst_9706);

return statearr_9718;
})();
return cljs.core.async.impl.ioc_helpers.return_chan(state_9709__$1,inst_9707);
} else {
if((state_val_9710 === (2))){
var state_9709__$1 = state_9709;
return cljs.core.async.impl.ioc_helpers.take_BANG_(state_9709__$1,(4),ch);
} else {
if((state_val_9710 === (11))){
var inst_9689 = (state_9709[(8)]);
var inst_9698 = (state_9709[(2)]);
var inst_9686 = inst_9689;
var state_9709__$1 = (function (){var statearr_9719 = state_9709;
(statearr_9719[(7)] = inst_9686);

(statearr_9719[(10)] = inst_9698);

return statearr_9719;
})();
var statearr_9720_9738 = state_9709__$1;
(statearr_9720_9738[(2)] = null);

(statearr_9720_9738[(1)] = (2));


return cljs.core.cst$kw$recur;
} else {
if((state_val_9710 === (9))){
var inst_9689 = (state_9709[(8)]);
var state_9709__$1 = state_9709;
return cljs.core.async.impl.ioc_helpers.put_BANG_(state_9709__$1,(11),out,inst_9689);
} else {
if((state_val_9710 === (5))){
var inst_9686 = (state_9709[(7)]);
var inst_9689 = (state_9709[(8)]);
var inst_9693 = cljs.core._EQ_.cljs$core$IFn$_invoke$arity$2(inst_9689,inst_9686);
var state_9709__$1 = state_9709;
if(inst_9693){
var statearr_9722_9739 = state_9709__$1;
(statearr_9722_9739[(1)] = (8));

} else {
var statearr_9723_9740 = state_9709__$1;
(statearr_9723_9740[(1)] = (9));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_9710 === (10))){
var inst_9701 = (state_9709[(2)]);
var state_9709__$1 = state_9709;
var statearr_9724_9741 = state_9709__$1;
(statearr_9724_9741[(2)] = inst_9701);

(statearr_9724_9741[(1)] = (7));


return cljs.core.cst$kw$recur;
} else {
if((state_val_9710 === (8))){
var inst_9686 = (state_9709[(7)]);
var tmp9721 = inst_9686;
var inst_9686__$1 = tmp9721;
var state_9709__$1 = (function (){var statearr_9725 = state_9709;
(statearr_9725[(7)] = inst_9686__$1);

return statearr_9725;
})();
var statearr_9726_9742 = state_9709__$1;
(statearr_9726_9742[(2)] = null);

(statearr_9726_9742[(1)] = (2));


return cljs.core.cst$kw$recur;
} else {
return null;
}
}
}
}
}
}
}
}
}
}
}
});})(c__7992__auto___9732,out))
;
return ((function (switch__7885__auto__,c__7992__auto___9732,out){
return (function() {
var cljs$core$async$state_machine__7886__auto__ = null;
var cljs$core$async$state_machine__7886__auto____0 = (function (){
var statearr_9727 = [null,null,null,null,null,null,null,null,null,null,null];
(statearr_9727[(0)] = cljs$core$async$state_machine__7886__auto__);

(statearr_9727[(1)] = (1));

return statearr_9727;
});
var cljs$core$async$state_machine__7886__auto____1 = (function (state_9709){
while(true){
var ret_value__7887__auto__ = (function (){try{while(true){
var result__7888__auto__ = switch__7885__auto__(state_9709);
if(cljs.core.keyword_identical_QMARK_(result__7888__auto__,cljs.core.cst$kw$recur)){
continue;
} else {
return result__7888__auto__;
}
break;
}
}catch (e9728){if((e9728 instanceof Object)){
var ex__7889__auto__ = e9728;
var statearr_9729_9743 = state_9709;
(statearr_9729_9743[(5)] = ex__7889__auto__);


cljs.core.async.impl.ioc_helpers.process_exception(state_9709);

return cljs.core.cst$kw$recur;
} else {
throw e9728;

}
}})();
if(cljs.core.keyword_identical_QMARK_(ret_value__7887__auto__,cljs.core.cst$kw$recur)){
var G__9744 = state_9709;
state_9709 = G__9744;
continue;
} else {
return ret_value__7887__auto__;
}
break;
}
});
cljs$core$async$state_machine__7886__auto__ = function(state_9709){
switch(arguments.length){
case 0:
return cljs$core$async$state_machine__7886__auto____0.call(this);
case 1:
return cljs$core$async$state_machine__7886__auto____1.call(this,state_9709);
}
throw(new Error('Invalid arity: ' + arguments.length));
};
cljs$core$async$state_machine__7886__auto__.cljs$core$IFn$_invoke$arity$0 = cljs$core$async$state_machine__7886__auto____0;
cljs$core$async$state_machine__7886__auto__.cljs$core$IFn$_invoke$arity$1 = cljs$core$async$state_machine__7886__auto____1;
return cljs$core$async$state_machine__7886__auto__;
})()
;})(switch__7885__auto__,c__7992__auto___9732,out))
})();
var state__7994__auto__ = (function (){var statearr_9730 = (f__7993__auto__.cljs$core$IFn$_invoke$arity$0 ? f__7993__auto__.cljs$core$IFn$_invoke$arity$0() : f__7993__auto__.call(null));
(statearr_9730[(6)] = c__7992__auto___9732);

return statearr_9730;
})();
return cljs.core.async.impl.ioc_helpers.run_state_machine_wrapped(state__7994__auto__);
});})(c__7992__auto___9732,out))
);


return out;
});

cljs.core.async.unique.cljs$lang$maxFixedArity = 2;

/**
 * Deprecated - this function will be removed. Use transducer instead
 */
cljs.core.async.partition = (function cljs$core$async$partition(var_args){
var G__9746 = arguments.length;
switch (G__9746) {
case 2:
return cljs.core.async.partition.cljs$core$IFn$_invoke$arity$2((arguments[(0)]),(arguments[(1)]));

break;
case 3:
return cljs.core.async.partition.cljs$core$IFn$_invoke$arity$3((arguments[(0)]),(arguments[(1)]),(arguments[(2)]));

break;
default:
throw (new Error(["Invalid arity: ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(arguments.length)].join('')));

}
});

cljs.core.async.partition.cljs$core$IFn$_invoke$arity$2 = (function (n,ch){
return cljs.core.async.partition.cljs$core$IFn$_invoke$arity$3(n,ch,null);
});

cljs.core.async.partition.cljs$core$IFn$_invoke$arity$3 = (function (n,ch,buf_or_n){
var out = cljs.core.async.chan.cljs$core$IFn$_invoke$arity$1(buf_or_n);
var c__7992__auto___9812 = cljs.core.async.chan.cljs$core$IFn$_invoke$arity$1((1));
cljs.core.async.impl.dispatch.run(((function (c__7992__auto___9812,out){
return (function (){
var f__7993__auto__ = (function (){var switch__7885__auto__ = ((function (c__7992__auto___9812,out){
return (function (state_9784){
var state_val_9785 = (state_9784[(1)]);
if((state_val_9785 === (7))){
var inst_9780 = (state_9784[(2)]);
var state_9784__$1 = state_9784;
var statearr_9786_9813 = state_9784__$1;
(statearr_9786_9813[(2)] = inst_9780);

(statearr_9786_9813[(1)] = (3));


return cljs.core.cst$kw$recur;
} else {
if((state_val_9785 === (1))){
var inst_9747 = (new Array(n));
var inst_9748 = inst_9747;
var inst_9749 = (0);
var state_9784__$1 = (function (){var statearr_9787 = state_9784;
(statearr_9787[(7)] = inst_9749);

(statearr_9787[(8)] = inst_9748);

return statearr_9787;
})();
var statearr_9788_9814 = state_9784__$1;
(statearr_9788_9814[(2)] = null);

(statearr_9788_9814[(1)] = (2));


return cljs.core.cst$kw$recur;
} else {
if((state_val_9785 === (4))){
var inst_9752 = (state_9784[(9)]);
var inst_9752__$1 = (state_9784[(2)]);
var inst_9753 = (inst_9752__$1 == null);
var inst_9754 = cljs.core.not(inst_9753);
var state_9784__$1 = (function (){var statearr_9789 = state_9784;
(statearr_9789[(9)] = inst_9752__$1);

return statearr_9789;
})();
if(inst_9754){
var statearr_9790_9815 = state_9784__$1;
(statearr_9790_9815[(1)] = (5));

} else {
var statearr_9791_9816 = state_9784__$1;
(statearr_9791_9816[(1)] = (6));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_9785 === (15))){
var inst_9774 = (state_9784[(2)]);
var state_9784__$1 = state_9784;
var statearr_9792_9817 = state_9784__$1;
(statearr_9792_9817[(2)] = inst_9774);

(statearr_9792_9817[(1)] = (14));


return cljs.core.cst$kw$recur;
} else {
if((state_val_9785 === (13))){
var state_9784__$1 = state_9784;
var statearr_9793_9818 = state_9784__$1;
(statearr_9793_9818[(2)] = null);

(statearr_9793_9818[(1)] = (14));


return cljs.core.cst$kw$recur;
} else {
if((state_val_9785 === (6))){
var inst_9749 = (state_9784[(7)]);
var inst_9770 = (inst_9749 > (0));
var state_9784__$1 = state_9784;
if(cljs.core.truth_(inst_9770)){
var statearr_9794_9819 = state_9784__$1;
(statearr_9794_9819[(1)] = (12));

} else {
var statearr_9795_9820 = state_9784__$1;
(statearr_9795_9820[(1)] = (13));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_9785 === (3))){
var inst_9782 = (state_9784[(2)]);
var state_9784__$1 = state_9784;
return cljs.core.async.impl.ioc_helpers.return_chan(state_9784__$1,inst_9782);
} else {
if((state_val_9785 === (12))){
var inst_9748 = (state_9784[(8)]);
var inst_9772 = cljs.core.vec(inst_9748);
var state_9784__$1 = state_9784;
return cljs.core.async.impl.ioc_helpers.put_BANG_(state_9784__$1,(15),out,inst_9772);
} else {
if((state_val_9785 === (2))){
var state_9784__$1 = state_9784;
return cljs.core.async.impl.ioc_helpers.take_BANG_(state_9784__$1,(4),ch);
} else {
if((state_val_9785 === (11))){
var inst_9764 = (state_9784[(2)]);
var inst_9765 = (new Array(n));
var inst_9748 = inst_9765;
var inst_9749 = (0);
var state_9784__$1 = (function (){var statearr_9796 = state_9784;
(statearr_9796[(10)] = inst_9764);

(statearr_9796[(7)] = inst_9749);

(statearr_9796[(8)] = inst_9748);

return statearr_9796;
})();
var statearr_9797_9821 = state_9784__$1;
(statearr_9797_9821[(2)] = null);

(statearr_9797_9821[(1)] = (2));


return cljs.core.cst$kw$recur;
} else {
if((state_val_9785 === (9))){
var inst_9748 = (state_9784[(8)]);
var inst_9762 = cljs.core.vec(inst_9748);
var state_9784__$1 = state_9784;
return cljs.core.async.impl.ioc_helpers.put_BANG_(state_9784__$1,(11),out,inst_9762);
} else {
if((state_val_9785 === (5))){
var inst_9757 = (state_9784[(11)]);
var inst_9752 = (state_9784[(9)]);
var inst_9749 = (state_9784[(7)]);
var inst_9748 = (state_9784[(8)]);
var inst_9756 = (inst_9748[inst_9749] = inst_9752);
var inst_9757__$1 = (inst_9749 + (1));
var inst_9758 = (inst_9757__$1 < n);
var state_9784__$1 = (function (){var statearr_9798 = state_9784;
(statearr_9798[(11)] = inst_9757__$1);

(statearr_9798[(12)] = inst_9756);

return statearr_9798;
})();
if(cljs.core.truth_(inst_9758)){
var statearr_9799_9822 = state_9784__$1;
(statearr_9799_9822[(1)] = (8));

} else {
var statearr_9800_9823 = state_9784__$1;
(statearr_9800_9823[(1)] = (9));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_9785 === (14))){
var inst_9777 = (state_9784[(2)]);
var inst_9778 = cljs.core.async.close_BANG_(out);
var state_9784__$1 = (function (){var statearr_9802 = state_9784;
(statearr_9802[(13)] = inst_9777);

return statearr_9802;
})();
var statearr_9803_9824 = state_9784__$1;
(statearr_9803_9824[(2)] = inst_9778);

(statearr_9803_9824[(1)] = (7));


return cljs.core.cst$kw$recur;
} else {
if((state_val_9785 === (10))){
var inst_9768 = (state_9784[(2)]);
var state_9784__$1 = state_9784;
var statearr_9804_9825 = state_9784__$1;
(statearr_9804_9825[(2)] = inst_9768);

(statearr_9804_9825[(1)] = (7));


return cljs.core.cst$kw$recur;
} else {
if((state_val_9785 === (8))){
var inst_9757 = (state_9784[(11)]);
var inst_9748 = (state_9784[(8)]);
var tmp9801 = inst_9748;
var inst_9748__$1 = tmp9801;
var inst_9749 = inst_9757;
var state_9784__$1 = (function (){var statearr_9805 = state_9784;
(statearr_9805[(7)] = inst_9749);

(statearr_9805[(8)] = inst_9748__$1);

return statearr_9805;
})();
var statearr_9806_9826 = state_9784__$1;
(statearr_9806_9826[(2)] = null);

(statearr_9806_9826[(1)] = (2));


return cljs.core.cst$kw$recur;
} else {
return null;
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
});})(c__7992__auto___9812,out))
;
return ((function (switch__7885__auto__,c__7992__auto___9812,out){
return (function() {
var cljs$core$async$state_machine__7886__auto__ = null;
var cljs$core$async$state_machine__7886__auto____0 = (function (){
var statearr_9807 = [null,null,null,null,null,null,null,null,null,null,null,null,null,null];
(statearr_9807[(0)] = cljs$core$async$state_machine__7886__auto__);

(statearr_9807[(1)] = (1));

return statearr_9807;
});
var cljs$core$async$state_machine__7886__auto____1 = (function (state_9784){
while(true){
var ret_value__7887__auto__ = (function (){try{while(true){
var result__7888__auto__ = switch__7885__auto__(state_9784);
if(cljs.core.keyword_identical_QMARK_(result__7888__auto__,cljs.core.cst$kw$recur)){
continue;
} else {
return result__7888__auto__;
}
break;
}
}catch (e9808){if((e9808 instanceof Object)){
var ex__7889__auto__ = e9808;
var statearr_9809_9827 = state_9784;
(statearr_9809_9827[(5)] = ex__7889__auto__);


cljs.core.async.impl.ioc_helpers.process_exception(state_9784);

return cljs.core.cst$kw$recur;
} else {
throw e9808;

}
}})();
if(cljs.core.keyword_identical_QMARK_(ret_value__7887__auto__,cljs.core.cst$kw$recur)){
var G__9828 = state_9784;
state_9784 = G__9828;
continue;
} else {
return ret_value__7887__auto__;
}
break;
}
});
cljs$core$async$state_machine__7886__auto__ = function(state_9784){
switch(arguments.length){
case 0:
return cljs$core$async$state_machine__7886__auto____0.call(this);
case 1:
return cljs$core$async$state_machine__7886__auto____1.call(this,state_9784);
}
throw(new Error('Invalid arity: ' + arguments.length));
};
cljs$core$async$state_machine__7886__auto__.cljs$core$IFn$_invoke$arity$0 = cljs$core$async$state_machine__7886__auto____0;
cljs$core$async$state_machine__7886__auto__.cljs$core$IFn$_invoke$arity$1 = cljs$core$async$state_machine__7886__auto____1;
return cljs$core$async$state_machine__7886__auto__;
})()
;})(switch__7885__auto__,c__7992__auto___9812,out))
})();
var state__7994__auto__ = (function (){var statearr_9810 = (f__7993__auto__.cljs$core$IFn$_invoke$arity$0 ? f__7993__auto__.cljs$core$IFn$_invoke$arity$0() : f__7993__auto__.call(null));
(statearr_9810[(6)] = c__7992__auto___9812);

return statearr_9810;
})();
return cljs.core.async.impl.ioc_helpers.run_state_machine_wrapped(state__7994__auto__);
});})(c__7992__auto___9812,out))
);


return out;
});

cljs.core.async.partition.cljs$lang$maxFixedArity = 3;

/**
 * Deprecated - this function will be removed. Use transducer instead
 */
cljs.core.async.partition_by = (function cljs$core$async$partition_by(var_args){
var G__9830 = arguments.length;
switch (G__9830) {
case 2:
return cljs.core.async.partition_by.cljs$core$IFn$_invoke$arity$2((arguments[(0)]),(arguments[(1)]));

break;
case 3:
return cljs.core.async.partition_by.cljs$core$IFn$_invoke$arity$3((arguments[(0)]),(arguments[(1)]),(arguments[(2)]));

break;
default:
throw (new Error(["Invalid arity: ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(arguments.length)].join('')));

}
});

cljs.core.async.partition_by.cljs$core$IFn$_invoke$arity$2 = (function (f,ch){
return cljs.core.async.partition_by.cljs$core$IFn$_invoke$arity$3(f,ch,null);
});

cljs.core.async.partition_by.cljs$core$IFn$_invoke$arity$3 = (function (f,ch,buf_or_n){
var out = cljs.core.async.chan.cljs$core$IFn$_invoke$arity$1(buf_or_n);
var c__7992__auto___9900 = cljs.core.async.chan.cljs$core$IFn$_invoke$arity$1((1));
cljs.core.async.impl.dispatch.run(((function (c__7992__auto___9900,out){
return (function (){
var f__7993__auto__ = (function (){var switch__7885__auto__ = ((function (c__7992__auto___9900,out){
return (function (state_9872){
var state_val_9873 = (state_9872[(1)]);
if((state_val_9873 === (7))){
var inst_9868 = (state_9872[(2)]);
var state_9872__$1 = state_9872;
var statearr_9874_9901 = state_9872__$1;
(statearr_9874_9901[(2)] = inst_9868);

(statearr_9874_9901[(1)] = (3));


return cljs.core.cst$kw$recur;
} else {
if((state_val_9873 === (1))){
var inst_9831 = [];
var inst_9832 = inst_9831;
var inst_9833 = cljs.core.cst$kw$cljs$core$async_SLASH_nothing;
var state_9872__$1 = (function (){var statearr_9875 = state_9872;
(statearr_9875[(7)] = inst_9832);

(statearr_9875[(8)] = inst_9833);

return statearr_9875;
})();
var statearr_9876_9902 = state_9872__$1;
(statearr_9876_9902[(2)] = null);

(statearr_9876_9902[(1)] = (2));


return cljs.core.cst$kw$recur;
} else {
if((state_val_9873 === (4))){
var inst_9836 = (state_9872[(9)]);
var inst_9836__$1 = (state_9872[(2)]);
var inst_9837 = (inst_9836__$1 == null);
var inst_9838 = cljs.core.not(inst_9837);
var state_9872__$1 = (function (){var statearr_9877 = state_9872;
(statearr_9877[(9)] = inst_9836__$1);

return statearr_9877;
})();
if(inst_9838){
var statearr_9878_9903 = state_9872__$1;
(statearr_9878_9903[(1)] = (5));

} else {
var statearr_9879_9904 = state_9872__$1;
(statearr_9879_9904[(1)] = (6));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_9873 === (15))){
var inst_9862 = (state_9872[(2)]);
var state_9872__$1 = state_9872;
var statearr_9880_9905 = state_9872__$1;
(statearr_9880_9905[(2)] = inst_9862);

(statearr_9880_9905[(1)] = (14));


return cljs.core.cst$kw$recur;
} else {
if((state_val_9873 === (13))){
var state_9872__$1 = state_9872;
var statearr_9881_9906 = state_9872__$1;
(statearr_9881_9906[(2)] = null);

(statearr_9881_9906[(1)] = (14));


return cljs.core.cst$kw$recur;
} else {
if((state_val_9873 === (6))){
var inst_9832 = (state_9872[(7)]);
var inst_9857 = inst_9832.length;
var inst_9858 = (inst_9857 > (0));
var state_9872__$1 = state_9872;
if(cljs.core.truth_(inst_9858)){
var statearr_9882_9907 = state_9872__$1;
(statearr_9882_9907[(1)] = (12));

} else {
var statearr_9883_9908 = state_9872__$1;
(statearr_9883_9908[(1)] = (13));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_9873 === (3))){
var inst_9870 = (state_9872[(2)]);
var state_9872__$1 = state_9872;
return cljs.core.async.impl.ioc_helpers.return_chan(state_9872__$1,inst_9870);
} else {
if((state_val_9873 === (12))){
var inst_9832 = (state_9872[(7)]);
var inst_9860 = cljs.core.vec(inst_9832);
var state_9872__$1 = state_9872;
return cljs.core.async.impl.ioc_helpers.put_BANG_(state_9872__$1,(15),out,inst_9860);
} else {
if((state_val_9873 === (2))){
var state_9872__$1 = state_9872;
return cljs.core.async.impl.ioc_helpers.take_BANG_(state_9872__$1,(4),ch);
} else {
if((state_val_9873 === (11))){
var inst_9840 = (state_9872[(10)]);
var inst_9836 = (state_9872[(9)]);
var inst_9850 = (state_9872[(2)]);
var inst_9851 = [];
var inst_9852 = inst_9851.push(inst_9836);
var inst_9832 = inst_9851;
var inst_9833 = inst_9840;
var state_9872__$1 = (function (){var statearr_9884 = state_9872;
(statearr_9884[(11)] = inst_9850);

(statearr_9884[(12)] = inst_9852);

(statearr_9884[(7)] = inst_9832);

(statearr_9884[(8)] = inst_9833);

return statearr_9884;
})();
var statearr_9885_9909 = state_9872__$1;
(statearr_9885_9909[(2)] = null);

(statearr_9885_9909[(1)] = (2));


return cljs.core.cst$kw$recur;
} else {
if((state_val_9873 === (9))){
var inst_9832 = (state_9872[(7)]);
var inst_9848 = cljs.core.vec(inst_9832);
var state_9872__$1 = state_9872;
return cljs.core.async.impl.ioc_helpers.put_BANG_(state_9872__$1,(11),out,inst_9848);
} else {
if((state_val_9873 === (5))){
var inst_9840 = (state_9872[(10)]);
var inst_9836 = (state_9872[(9)]);
var inst_9833 = (state_9872[(8)]);
var inst_9840__$1 = (f.cljs$core$IFn$_invoke$arity$1 ? f.cljs$core$IFn$_invoke$arity$1(inst_9836) : f.call(null,inst_9836));
var inst_9841 = cljs.core._EQ_.cljs$core$IFn$_invoke$arity$2(inst_9840__$1,inst_9833);
var inst_9842 = cljs.core.keyword_identical_QMARK_(inst_9833,cljs.core.cst$kw$cljs$core$async_SLASH_nothing);
var inst_9843 = ((inst_9841) || (inst_9842));
var state_9872__$1 = (function (){var statearr_9886 = state_9872;
(statearr_9886[(10)] = inst_9840__$1);

return statearr_9886;
})();
if(cljs.core.truth_(inst_9843)){
var statearr_9887_9910 = state_9872__$1;
(statearr_9887_9910[(1)] = (8));

} else {
var statearr_9888_9911 = state_9872__$1;
(statearr_9888_9911[(1)] = (9));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_9873 === (14))){
var inst_9865 = (state_9872[(2)]);
var inst_9866 = cljs.core.async.close_BANG_(out);
var state_9872__$1 = (function (){var statearr_9890 = state_9872;
(statearr_9890[(13)] = inst_9865);

return statearr_9890;
})();
var statearr_9891_9912 = state_9872__$1;
(statearr_9891_9912[(2)] = inst_9866);

(statearr_9891_9912[(1)] = (7));


return cljs.core.cst$kw$recur;
} else {
if((state_val_9873 === (10))){
var inst_9855 = (state_9872[(2)]);
var state_9872__$1 = state_9872;
var statearr_9892_9913 = state_9872__$1;
(statearr_9892_9913[(2)] = inst_9855);

(statearr_9892_9913[(1)] = (7));


return cljs.core.cst$kw$recur;
} else {
if((state_val_9873 === (8))){
var inst_9840 = (state_9872[(10)]);
var inst_9836 = (state_9872[(9)]);
var inst_9832 = (state_9872[(7)]);
var inst_9845 = inst_9832.push(inst_9836);
var tmp9889 = inst_9832;
var inst_9832__$1 = tmp9889;
var inst_9833 = inst_9840;
var state_9872__$1 = (function (){var statearr_9893 = state_9872;
(statearr_9893[(14)] = inst_9845);

(statearr_9893[(7)] = inst_9832__$1);

(statearr_9893[(8)] = inst_9833);

return statearr_9893;
})();
var statearr_9894_9914 = state_9872__$1;
(statearr_9894_9914[(2)] = null);

(statearr_9894_9914[(1)] = (2));


return cljs.core.cst$kw$recur;
} else {
return null;
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
});})(c__7992__auto___9900,out))
;
return ((function (switch__7885__auto__,c__7992__auto___9900,out){
return (function() {
var cljs$core$async$state_machine__7886__auto__ = null;
var cljs$core$async$state_machine__7886__auto____0 = (function (){
var statearr_9895 = [null,null,null,null,null,null,null,null,null,null,null,null,null,null,null];
(statearr_9895[(0)] = cljs$core$async$state_machine__7886__auto__);

(statearr_9895[(1)] = (1));

return statearr_9895;
});
var cljs$core$async$state_machine__7886__auto____1 = (function (state_9872){
while(true){
var ret_value__7887__auto__ = (function (){try{while(true){
var result__7888__auto__ = switch__7885__auto__(state_9872);
if(cljs.core.keyword_identical_QMARK_(result__7888__auto__,cljs.core.cst$kw$recur)){
continue;
} else {
return result__7888__auto__;
}
break;
}
}catch (e9896){if((e9896 instanceof Object)){
var ex__7889__auto__ = e9896;
var statearr_9897_9915 = state_9872;
(statearr_9897_9915[(5)] = ex__7889__auto__);


cljs.core.async.impl.ioc_helpers.process_exception(state_9872);

return cljs.core.cst$kw$recur;
} else {
throw e9896;

}
}})();
if(cljs.core.keyword_identical_QMARK_(ret_value__7887__auto__,cljs.core.cst$kw$recur)){
var G__9916 = state_9872;
state_9872 = G__9916;
continue;
} else {
return ret_value__7887__auto__;
}
break;
}
});
cljs$core$async$state_machine__7886__auto__ = function(state_9872){
switch(arguments.length){
case 0:
return cljs$core$async$state_machine__7886__auto____0.call(this);
case 1:
return cljs$core$async$state_machine__7886__auto____1.call(this,state_9872);
}
throw(new Error('Invalid arity: ' + arguments.length));
};
cljs$core$async$state_machine__7886__auto__.cljs$core$IFn$_invoke$arity$0 = cljs$core$async$state_machine__7886__auto____0;
cljs$core$async$state_machine__7886__auto__.cljs$core$IFn$_invoke$arity$1 = cljs$core$async$state_machine__7886__auto____1;
return cljs$core$async$state_machine__7886__auto__;
})()
;})(switch__7885__auto__,c__7992__auto___9900,out))
})();
var state__7994__auto__ = (function (){var statearr_9898 = (f__7993__auto__.cljs$core$IFn$_invoke$arity$0 ? f__7993__auto__.cljs$core$IFn$_invoke$arity$0() : f__7993__auto__.call(null));
(statearr_9898[(6)] = c__7992__auto___9900);

return statearr_9898;
})();
return cljs.core.async.impl.ioc_helpers.run_state_machine_wrapped(state__7994__auto__);
});})(c__7992__auto___9900,out))
);


return out;
});

cljs.core.async.partition_by.cljs$lang$maxFixedArity = 3;

