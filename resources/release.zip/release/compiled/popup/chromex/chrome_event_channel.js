// Compiled by ClojureScript 1.10.439 {:static-fns true, :optimize-constants true, :elide-asserts true}
goog.provide('chromex.chrome_event_channel');
goog.require('cljs.core');
goog.require('cljs.core.constants');
goog.require('cljs.core.async.impl.protocols');
goog.require('chromex.protocols.chrome_event_subscription');
goog.require('chromex.protocols.chrome_event_channel');

/**
* @constructor
 * @implements {cljs.core.async.impl.protocols.Channel}
 * @implements {cljs.core.async.impl.protocols.WritePort}
 * @implements {cljs.core.async.impl.protocols.ReadPort}
 * @implements {chromex.protocols.chrome_event_channel.IChromeEventChannel}
*/
chromex.chrome_event_channel.ChromeEventChannel = (function (chan,subscriptions){
this.chan = chan;
this.subscriptions = subscriptions;
});
chromex.chrome_event_channel.ChromeEventChannel.prototype.chromex$protocols$chrome_event_channel$IChromeEventChannel$ = cljs.core.PROTOCOL_SENTINEL;

chromex.chrome_event_channel.ChromeEventChannel.prototype.chromex$protocols$chrome_event_channel$IChromeEventChannel$register_BANG_$arity$2 = (function (_this,subscription){
var self__ = this;
var _this__$1 = this;
return self__.subscriptions = cljs.core.conj.cljs$core$IFn$_invoke$arity$2(self__.subscriptions,subscription);
});

chromex.chrome_event_channel.ChromeEventChannel.prototype.chromex$protocols$chrome_event_channel$IChromeEventChannel$unregister_BANG_$arity$2 = (function (_this,subscription){
var self__ = this;
var _this__$1 = this;
return self__.subscriptions = cljs.core.disj.cljs$core$IFn$_invoke$arity$2(self__.subscriptions,subscription);
});

chromex.chrome_event_channel.ChromeEventChannel.prototype.chromex$protocols$chrome_event_channel$IChromeEventChannel$unsubscribe_all_BANG_$arity$1 = (function (_this){
var self__ = this;
var _this__$1 = this;
var seq__22788_22792 = cljs.core.seq(self__.subscriptions);
var chunk__22789_22793 = null;
var count__22790_22794 = (0);
var i__22791_22795 = (0);
while(true){
if((i__22791_22795 < count__22790_22794)){
var subscription_22796 = chunk__22789_22793.cljs$core$IIndexed$_nth$arity$2(null,i__22791_22795);
chromex.protocols.chrome_event_subscription.unsubscribe_BANG_(subscription_22796);


var G__22797 = seq__22788_22792;
var G__22798 = chunk__22789_22793;
var G__22799 = count__22790_22794;
var G__22800 = (i__22791_22795 + (1));
seq__22788_22792 = G__22797;
chunk__22789_22793 = G__22798;
count__22790_22794 = G__22799;
i__22791_22795 = G__22800;
continue;
} else {
var temp__5457__auto___22801 = cljs.core.seq(seq__22788_22792);
if(temp__5457__auto___22801){
var seq__22788_22802__$1 = temp__5457__auto___22801;
if(cljs.core.chunked_seq_QMARK_(seq__22788_22802__$1)){
var c__4461__auto___22803 = cljs.core.chunk_first(seq__22788_22802__$1);
var G__22804 = cljs.core.chunk_rest(seq__22788_22802__$1);
var G__22805 = c__4461__auto___22803;
var G__22806 = cljs.core.count(c__4461__auto___22803);
var G__22807 = (0);
seq__22788_22792 = G__22804;
chunk__22789_22793 = G__22805;
count__22790_22794 = G__22806;
i__22791_22795 = G__22807;
continue;
} else {
var subscription_22808 = cljs.core.first(seq__22788_22802__$1);
chromex.protocols.chrome_event_subscription.unsubscribe_BANG_(subscription_22808);


var G__22809 = cljs.core.next(seq__22788_22802__$1);
var G__22810 = null;
var G__22811 = (0);
var G__22812 = (0);
seq__22788_22792 = G__22809;
chunk__22789_22793 = G__22810;
count__22790_22794 = G__22811;
i__22791_22795 = G__22812;
continue;
}
} else {
}
}
break;
}

return self__.subscriptions = cljs.core.PersistentHashSet.EMPTY;
});

chromex.chrome_event_channel.ChromeEventChannel.prototype.cljs$core$async$impl$protocols$WritePort$ = cljs.core.PROTOCOL_SENTINEL;

chromex.chrome_event_channel.ChromeEventChannel.prototype.cljs$core$async$impl$protocols$WritePort$put_BANG_$arity$3 = (function (_this,val,handler){
var self__ = this;
var _this__$1 = this;
return cljs.core.async.impl.protocols.put_BANG_(self__.chan,val,handler);
});

chromex.chrome_event_channel.ChromeEventChannel.prototype.cljs$core$async$impl$protocols$ReadPort$ = cljs.core.PROTOCOL_SENTINEL;

chromex.chrome_event_channel.ChromeEventChannel.prototype.cljs$core$async$impl$protocols$ReadPort$take_BANG_$arity$2 = (function (_this,handler){
var self__ = this;
var _this__$1 = this;
return cljs.core.async.impl.protocols.take_BANG_(self__.chan,handler);
});

chromex.chrome_event_channel.ChromeEventChannel.prototype.cljs$core$async$impl$protocols$Channel$ = cljs.core.PROTOCOL_SENTINEL;

chromex.chrome_event_channel.ChromeEventChannel.prototype.cljs$core$async$impl$protocols$Channel$closed_QMARK_$arity$1 = (function (_this){
var self__ = this;
var _this__$1 = this;
return cljs.core.async.impl.protocols.closed_QMARK_(self__.chan);
});

chromex.chrome_event_channel.ChromeEventChannel.prototype.cljs$core$async$impl$protocols$Channel$close_BANG_$arity$1 = (function (this$){
var self__ = this;
var this$__$1 = this;
this$__$1.chromex$protocols$chrome_event_channel$IChromeEventChannel$unsubscribe_all_BANG_$arity$1(null);

return cljs.core.async.impl.protocols.close_BANG_(self__.chan);
});

chromex.chrome_event_channel.ChromeEventChannel.getBasis = (function (){
return new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [cljs.core.cst$sym$chan,cljs.core.with_meta(cljs.core.cst$sym$subscriptions,new cljs.core.PersistentArrayMap(null, 1, [cljs.core.cst$kw$mutable,true], null))], null);
});

chromex.chrome_event_channel.ChromeEventChannel.cljs$lang$type = true;

chromex.chrome_event_channel.ChromeEventChannel.cljs$lang$ctorStr = "chromex.chrome-event-channel/ChromeEventChannel";

chromex.chrome_event_channel.ChromeEventChannel.cljs$lang$ctorPrWriter = (function (this__4290__auto__,writer__4291__auto__,opt__4292__auto__){
return cljs.core._write(writer__4291__auto__,"chromex.chrome-event-channel/ChromeEventChannel");
});

/**
 * Positional factory function for chromex.chrome-event-channel/ChromeEventChannel.
 */
chromex.chrome_event_channel.__GT_ChromeEventChannel = (function chromex$chrome_event_channel$__GT_ChromeEventChannel(chan,subscriptions){
return (new chromex.chrome_event_channel.ChromeEventChannel(chan,subscriptions));
});

chromex.chrome_event_channel.make_chrome_event_channel = (function chromex$chrome_event_channel$make_chrome_event_channel(chan){
return (new chromex.chrome_event_channel.ChromeEventChannel(chan,cljs.core.PersistentHashSet.EMPTY));
});
