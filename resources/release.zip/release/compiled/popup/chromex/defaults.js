// Compiled by ClojureScript 1.10.439 {:static-fns true, :optimize-constants true, :elide-asserts true}
goog.provide('chromex.defaults');
goog.require('cljs.core');
goog.require('cljs.core.constants');
goog.require('cljs.core.async');
goog.require('chromex.support');
goog.require('oops.core');
goog.require('goog.object');
goog.require('chromex.error');
goog.require('chromex.protocols.chrome_port');
goog.require('chromex.protocols.chrome_port_state');
chromex.defaults.log_prefix = "[chromex]";
chromex.defaults.console_log = (function chromex$defaults$console_log(var_args){
var args__4647__auto__ = [];
var len__4641__auto___22833 = arguments.length;
var i__4642__auto___22834 = (0);
while(true){
if((i__4642__auto___22834 < len__4641__auto___22833)){
args__4647__auto__.push((arguments[i__4642__auto___22834]));

var G__22835 = (i__4642__auto___22834 + (1));
i__4642__auto___22834 = G__22835;
continue;
} else {
}
break;
}

var argseq__4648__auto__ = ((((0) < args__4647__auto__.length))?(new cljs.core.IndexedSeq(args__4647__auto__.slice((0)),(0),null)):null);
return chromex.defaults.console_log.cljs$core$IFn$_invoke$arity$variadic(argseq__4648__auto__);
});

chromex.defaults.console_log.cljs$core$IFn$_invoke$arity$variadic = (function (args){
return console.log.apply(console,cljs.core.into_array.cljs$core$IFn$_invoke$arity$1(args));
});

chromex.defaults.console_log.cljs$lang$maxFixedArity = (0);

/** @this {Function} */
chromex.defaults.console_log.cljs$lang$applyTo = (function (seq22832){
var self__4629__auto__ = this;
return self__4629__auto__.cljs$core$IFn$_invoke$arity$variadic(cljs.core.seq(seq22832));
});

chromex.defaults.console_error = (function chromex$defaults$console_error(var_args){
var args__4647__auto__ = [];
var len__4641__auto___22837 = arguments.length;
var i__4642__auto___22838 = (0);
while(true){
if((i__4642__auto___22838 < len__4641__auto___22837)){
args__4647__auto__.push((arguments[i__4642__auto___22838]));

var G__22839 = (i__4642__auto___22838 + (1));
i__4642__auto___22838 = G__22839;
continue;
} else {
}
break;
}

var argseq__4648__auto__ = ((((0) < args__4647__auto__.length))?(new cljs.core.IndexedSeq(args__4647__auto__.slice((0)),(0),null)):null);
return chromex.defaults.console_error.cljs$core$IFn$_invoke$arity$variadic(argseq__4648__auto__);
});

chromex.defaults.console_error.cljs$core$IFn$_invoke$arity$variadic = (function (args){
return console.error.apply(console,cljs.core.into_array.cljs$core$IFn$_invoke$arity$1(args));
});

chromex.defaults.console_error.cljs$lang$maxFixedArity = (0);

/** @this {Function} */
chromex.defaults.console_error.cljs$lang$applyTo = (function (seq22836){
var self__4629__auto__ = this;
return self__4629__auto__.cljs$core$IFn$_invoke$arity$variadic(cljs.core.seq(seq22836));
});

chromex.defaults.default_logger = (function chromex$defaults$default_logger(var_args){
var args__4647__auto__ = [];
var len__4641__auto___22841 = arguments.length;
var i__4642__auto___22842 = (0);
while(true){
if((i__4642__auto___22842 < len__4641__auto___22841)){
args__4647__auto__.push((arguments[i__4642__auto___22842]));

var G__22843 = (i__4642__auto___22842 + (1));
i__4642__auto___22842 = G__22843;
continue;
} else {
}
break;
}

var argseq__4648__auto__ = ((((0) < args__4647__auto__.length))?(new cljs.core.IndexedSeq(args__4647__auto__.slice((0)),(0),null)):null);
return chromex.defaults.default_logger.cljs$core$IFn$_invoke$arity$variadic(argseq__4648__auto__);
});

chromex.defaults.default_logger.cljs$core$IFn$_invoke$arity$variadic = (function (args){
return cljs.core.apply.cljs$core$IFn$_invoke$arity$3(chromex.defaults.console_log,chromex.defaults.log_prefix,args);
});

chromex.defaults.default_logger.cljs$lang$maxFixedArity = (0);

/** @this {Function} */
chromex.defaults.default_logger.cljs$lang$applyTo = (function (seq22840){
var self__4629__auto__ = this;
return self__4629__auto__.cljs$core$IFn$_invoke$arity$variadic(cljs.core.seq(seq22840));
});

chromex.defaults.default_callback_error_reporter = (function chromex$defaults$default_callback_error_reporter(descriptor,error){
var function$ = (function (){var or__4047__auto__ = [cljs.core.str.cljs$core$IFn$_invoke$arity$1(cljs.core.namespace(cljs.core.cst$kw$id.cljs$core$IFn$_invoke$arity$1(descriptor))),"/",cljs.core.str.cljs$core$IFn$_invoke$arity$1(cljs.core.name(cljs.core.cst$kw$id.cljs$core$IFn$_invoke$arity$1(descriptor)))].join('');
if(cljs.core.truth_(or__4047__auto__)){
return or__4047__auto__;
} else {
return "an unknown function";
}
})();
var explanation = (function (){var target_obj_22844 = error;
var next_obj_22845 = (target_obj_22844["message"]);
return next_obj_22845;
})();
var message = ["an error occurred during the call to ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(function$),cljs.core.str.cljs$core$IFn$_invoke$arity$1((cljs.core.truth_(explanation)?[": ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(explanation)].join(''):null))].join('');
return chromex.defaults.console_error.cljs$core$IFn$_invoke$arity$variadic(cljs.core.prim_seq.cljs$core$IFn$_invoke$arity$2([chromex.defaults.log_prefix,message,"Details:",error], 0));
});
chromex.defaults.report_error_if_needed_BANG_ = (function chromex$defaults$report_error_if_needed_BANG_(config,descriptor,error){
var temp__5457__auto__ = cljs.core.cst$kw$callback_DASH_error_DASH_reporter.cljs$core$IFn$_invoke$arity$1(config);
if(cljs.core.truth_(temp__5457__auto__)){
var error_reporter = temp__5457__auto__;

return (error_reporter.cljs$core$IFn$_invoke$arity$2 ? error_reporter.cljs$core$IFn$_invoke$arity$2(descriptor,error) : error_reporter.call(null,descriptor,error));
} else {
return null;
}
});
chromex.defaults.normalize_args = (function chromex$defaults$normalize_args(args){
return cljs.core.vec(args);
});
chromex.defaults.default_callback_fn_factory = (function chromex$defaults$default_callback_fn_factory(config,descriptor,chan){
return (function() { 
var G__22850__delegate = function (args){
var normalized_args = chromex.defaults.normalize_args(args);
var temp__5459__auto__ = (function (){var target_obj_22846 = cljs.core.cst$kw$root.cljs$core$IFn$_invoke$arity$1(config);
var next_obj_22847 = (target_obj_22846["chrome"]);
var next_obj_22848 = (next_obj_22847["runtime"]);
var next_obj_22849 = (next_obj_22848["lastError"]);
if((!((next_obj_22849 == null)))){
return next_obj_22849;
} else {
return null;
}
})();
if((temp__5459__auto__ == null)){
chromex.error.set_last_error_BANG_(null);

chromex.error.set_last_error_args_BANG_(null);

return cljs.core.async.put_BANG_.cljs$core$IFn$_invoke$arity$2(chan,normalized_args);
} else {
var error = temp__5459__auto__;
chromex.error.set_last_error_BANG_(error);

chromex.error.set_last_error_args_BANG_(normalized_args);

chromex.defaults.report_error_if_needed_BANG_(config,descriptor,error);

return cljs.core.async.close_BANG_(chan);
}
};
var G__22850 = function (var_args){
var args = null;
if (arguments.length > 0) {
var G__22851__i = 0, G__22851__a = new Array(arguments.length -  0);
while (G__22851__i < G__22851__a.length) {G__22851__a[G__22851__i] = arguments[G__22851__i + 0]; ++G__22851__i;}
  args = new cljs.core.IndexedSeq(G__22851__a,0,null);
} 
return G__22850__delegate.call(this,args);};
G__22850.cljs$lang$maxFixedArity = 0;
G__22850.cljs$lang$applyTo = (function (arglist__22852){
var args = cljs.core.seq(arglist__22852);
return G__22850__delegate(args);
});
G__22850.cljs$core$IFn$_invoke$arity$variadic = G__22850__delegate;
return G__22850;
})()
;
});
chromex.defaults.default_callback_channel_factory = (function chromex$defaults$default_callback_channel_factory(_config){
return cljs.core.async.promise_chan.cljs$core$IFn$_invoke$arity$0();
});
chromex.defaults.default_event_listener_factory = (function chromex$defaults$default_event_listener_factory(_config,event_id,chan){
return (function() { 
var G__22853__delegate = function (args){
return cljs.core.async.put_BANG_.cljs$core$IFn$_invoke$arity$2(chan,new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [event_id,cljs.core.vec(args)], null));
};
var G__22853 = function (var_args){
var args = null;
if (arguments.length > 0) {
var G__22854__i = 0, G__22854__a = new Array(arguments.length -  0);
while (G__22854__i < G__22854__a.length) {G__22854__a[G__22854__i] = arguments[G__22854__i + 0]; ++G__22854__i;}
  args = new cljs.core.IndexedSeq(G__22854__a,0,null);
} 
return G__22853__delegate.call(this,args);};
G__22853.cljs$lang$maxFixedArity = 0;
G__22853.cljs$lang$applyTo = (function (arglist__22855){
var args = cljs.core.seq(arglist__22855);
return G__22853__delegate(args);
});
G__22853.cljs$core$IFn$_invoke$arity$variadic = G__22853__delegate;
return G__22853;
})()
;
});
chromex.defaults.default_missing_api_check = (function chromex$defaults$default_missing_api_check(api,obj,key){
if(cljs.core.truth_(goog.object.containsKey(obj,key))){
return null;
} else {
throw (new Error(["Chromex library tried to access a missing Chrome API object '",cljs.core.str.cljs$core$IFn$_invoke$arity$1(api),"'.\n","Your Chrome version might be too old or too recent for running this extension.\n","This is a failure which probably requires a software update."].join('')));
}
});
chromex.defaults.default_chrome_content_setting_callback_fn_factory = (function chromex$defaults$default_chrome_content_setting_callback_fn_factory(config,chan){
return (function() { 
var G__22860__delegate = function (args){
var last_error = (function (){var target_obj_22856 = cljs.core.cst$kw$root.cljs$core$IFn$_invoke$arity$1(config);
var next_obj_22857 = (target_obj_22856["chrome"]);
var next_obj_22858 = (next_obj_22857["runtime"]);
var next_obj_22859 = (next_obj_22858["lastError"]);
if((!((next_obj_22859 == null)))){
return next_obj_22859;
} else {
return null;
}
})();
return cljs.core.async.put_BANG_.cljs$core$IFn$_invoke$arity$2(chan,new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [cljs.core.vec(args),last_error], null));
};
var G__22860 = function (var_args){
var args = null;
if (arguments.length > 0) {
var G__22861__i = 0, G__22861__a = new Array(arguments.length -  0);
while (G__22861__i < G__22861__a.length) {G__22861__a[G__22861__i] = arguments[G__22861__i + 0]; ++G__22861__i;}
  args = new cljs.core.IndexedSeq(G__22861__a,0,null);
} 
return G__22860__delegate.call(this,args);};
G__22860.cljs$lang$maxFixedArity = 0;
G__22860.cljs$lang$applyTo = (function (arglist__22862){
var args = cljs.core.seq(arglist__22862);
return G__22860__delegate(args);
});
G__22860.cljs$core$IFn$_invoke$arity$variadic = G__22860__delegate;
return G__22860;
})()
;
});
chromex.defaults.default_chrome_content_setting_callback_channel_factory = (function chromex$defaults$default_chrome_content_setting_callback_channel_factory(_config){
return cljs.core.async.chan.cljs$core$IFn$_invoke$arity$0();
});
chromex.defaults.default_chrome_storage_area_callback_fn_factory = (function chromex$defaults$default_chrome_storage_area_callback_fn_factory(config,chan){
return (function() { 
var G__22867__delegate = function (args){
var last_error = (function (){var target_obj_22863 = cljs.core.cst$kw$root.cljs$core$IFn$_invoke$arity$1(config);
var next_obj_22864 = (target_obj_22863["chrome"]);
var next_obj_22865 = (next_obj_22864["runtime"]);
var next_obj_22866 = (next_obj_22865["lastError"]);
if((!((next_obj_22866 == null)))){
return next_obj_22866;
} else {
return null;
}
})();
return cljs.core.async.put_BANG_.cljs$core$IFn$_invoke$arity$2(chan,new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [cljs.core.vec(args),last_error], null));
};
var G__22867 = function (var_args){
var args = null;
if (arguments.length > 0) {
var G__22868__i = 0, G__22868__a = new Array(arguments.length -  0);
while (G__22868__i < G__22868__a.length) {G__22868__a[G__22868__i] = arguments[G__22868__i + 0]; ++G__22868__i;}
  args = new cljs.core.IndexedSeq(G__22868__a,0,null);
} 
return G__22867__delegate.call(this,args);};
G__22867.cljs$lang$maxFixedArity = 0;
G__22867.cljs$lang$applyTo = (function (arglist__22869){
var args = cljs.core.seq(arglist__22869);
return G__22867__delegate(args);
});
G__22867.cljs$core$IFn$_invoke$arity$variadic = G__22867__delegate;
return G__22867;
})()
;
});
chromex.defaults.default_chrome_storage_area_callback_channel_factory = (function chromex$defaults$default_chrome_storage_area_callback_channel_factory(_config){
return cljs.core.async.chan.cljs$core$IFn$_invoke$arity$0();
});
chromex.defaults.default_chrome_port_channel_factory = (function chromex$defaults$default_chrome_port_channel_factory(_config){
return cljs.core.async.chan.cljs$core$IFn$_invoke$arity$0();
});
chromex.defaults.default_chrome_port_on_message_fn_factory = (function chromex$defaults$default_chrome_port_on_message_fn_factory(config,chrome_port){
return (function (message){
if((message == null)){
var config__6143__auto__ = config;
var handler_key__6144__auto__ = cljs.core.cst$kw$chrome_DASH_port_DASH_received_DASH_nil_DASH_message;
var handler__6145__auto__ = handler_key__6144__auto__.cljs$core$IFn$_invoke$arity$1(config__6143__auto__);

return (handler__6145__auto__.cljs$core$IFn$_invoke$arity$2 ? handler__6145__auto__.cljs$core$IFn$_invoke$arity$2(config__6143__auto__,chrome_port) : handler__6145__auto__.call(null,config__6143__auto__,chrome_port));
} else {
chromex.protocols.chrome_port_state.put_message_BANG_(chrome_port,message);

return null;
}
});
});
chromex.defaults.default_chrome_port_on_disconnect_fn_factory = (function chromex$defaults$default_chrome_port_on_disconnect_fn_factory(_config,chrome_port){
return (function (){
chromex.protocols.chrome_port_state.close_resources_BANG_(chrome_port);

chromex.protocols.chrome_port_state.set_connected_BANG_(chrome_port,false);

return null;
});
});
chromex.defaults.default_chrome_port_disconnect_called_on_disconnected_port = (function chromex$defaults$default_chrome_port_disconnect_called_on_disconnected_port(_config,_chrome_port){
return null;
});
chromex.defaults.default_chrome_port_post_message_called_on_disconnected_port = (function chromex$defaults$default_chrome_port_post_message_called_on_disconnected_port(_config,_chrome_port){
return null;
});
chromex.defaults.default_chrome_port_on_disconnect_called_on_disconnected_port = (function chromex$defaults$default_chrome_port_on_disconnect_called_on_disconnected_port(_config,_chrome_port){
return null;
});
chromex.defaults.default_chrome_port_on_message_called_on_disconnected_port = (function chromex$defaults$default_chrome_port_on_message_called_on_disconnected_port(_config,_chrome_port){
return null;
});
chromex.defaults.default_chrome_port_post_message_called_with_nil = (function chromex$defaults$default_chrome_port_post_message_called_with_nil(_config,_chrome_port){
return null;
});
chromex.defaults.default_chrome_port_received_nil_message = (function chromex$defaults$default_chrome_port_received_nil_message(_config,_chrome_port){
return null;
});
chromex.defaults.default_chrome_port_put_message_called_on_disconnected_port = (function chromex$defaults$default_chrome_port_put_message_called_on_disconnected_port(_config,_chrome_port,message){
return null;
});
chromex.defaults.default_config = cljs.core.PersistentHashMap.fromArrays([cljs.core.cst$kw$chrome_DASH_port_DASH_post_DASH_message_DASH_called_DASH_on_DASH_disconnected_DASH_port,cljs.core.cst$kw$chrome_DASH_port_DASH_put_DASH_message_DASH_called_DASH_on_DASH_disconnected_DASH_port,cljs.core.cst$kw$chrome_DASH_port_DASH_on_DASH_disconnect_DASH_called_DASH_on_DASH_disconnected_DASH_port,cljs.core.cst$kw$chrome_DASH_storage_DASH_area_DASH_callback_DASH_channel_DASH_factory,cljs.core.cst$kw$chrome_DASH_port_DASH_post_DASH_message_DASH_called_DASH_with_DASH_nil,cljs.core.cst$kw$chrome_DASH_port_DASH_channel_DASH_factory,cljs.core.cst$kw$missing_DASH_api_DASH_check_DASH_fn,cljs.core.cst$kw$chrome_DASH_port_DASH_received_DASH_nil_DASH_message,cljs.core.cst$kw$chrome_DASH_port_DASH_on_DASH_message_DASH_called_DASH_on_DASH_disconnected_DASH_port,cljs.core.cst$kw$chrome_DASH_port_DASH_on_DASH_message_DASH_fn_DASH_factory,cljs.core.cst$kw$chrome_DASH_port_DASH_disconnect_DASH_called_DASH_on_DASH_disconnected_DASH_port,cljs.core.cst$kw$chrome_DASH_content_DASH_setting_DASH_callback_DASH_channel_DASH_factory,cljs.core.cst$kw$root,cljs.core.cst$kw$event_DASH_listener_DASH_factory,cljs.core.cst$kw$callback_DASH_fn_DASH_factory,cljs.core.cst$kw$chrome_DASH_content_DASH_setting_DASH_callback_DASH_fn_DASH_factory,cljs.core.cst$kw$chrome_DASH_storage_DASH_area_DASH_callback_DASH_fn_DASH_factory,cljs.core.cst$kw$callback_DASH_error_DASH_reporter,cljs.core.cst$kw$callback_DASH_channel_DASH_factory,cljs.core.cst$kw$chrome_DASH_port_DASH_on_DASH_disconnect_DASH_fn_DASH_factory],[chromex.defaults.default_chrome_port_post_message_called_on_disconnected_port,chromex.defaults.default_chrome_port_put_message_called_on_disconnected_port,chromex.defaults.default_chrome_port_on_disconnect_called_on_disconnected_port,chromex.defaults.default_chrome_storage_area_callback_channel_factory,chromex.defaults.default_chrome_port_post_message_called_with_nil,chromex.defaults.default_chrome_port_channel_factory,chromex.defaults.default_missing_api_check,chromex.defaults.default_chrome_port_received_nil_message,chromex.defaults.default_chrome_port_on_message_called_on_disconnected_port,chromex.defaults.default_chrome_port_on_message_fn_factory,chromex.defaults.default_chrome_port_disconnect_called_on_disconnected_port,chromex.defaults.default_chrome_content_setting_callback_channel_factory,goog.global,chromex.defaults.default_event_listener_factory,chromex.defaults.default_callback_fn_factory,chromex.defaults.default_chrome_content_setting_callback_fn_factory,chromex.defaults.default_chrome_storage_area_callback_fn_factory,chromex.defaults.default_callback_error_reporter,chromex.defaults.default_callback_channel_factory,chromex.defaults.default_chrome_port_on_disconnect_fn_factory]);
