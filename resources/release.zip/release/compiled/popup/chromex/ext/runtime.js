// Compiled by ClojureScript 1.10.439 {:static-fns true, :optimize-constants true, :elide-asserts true}
goog.provide('chromex.ext.runtime');
goog.require('cljs.core');
goog.require('cljs.core.constants');
goog.require('chromex.core');
chromex.ext.runtime.last_error_STAR_ = (function chromex$ext$runtime$last_error_STAR_(config){
var result_22959 = (function (){var final_args_array_22960 = chromex.support.prepare_final_args_array(cljs.core.PersistentVector.EMPTY,"chrome.runtime.lastError");
var ns_22961 = (function (){var target_obj_22963 = cljs.core.cst$kw$root.cljs$core$IFn$_invoke$arity$1(config);
var next_obj_22964 = (target_obj_22963["chrome"]);
var next_obj_22965 = (next_obj_22964["runtime"]);
return next_obj_22965;
})();


var target_22962 = (function (){var target_obj_22966 = ns_22961;
var next_obj_22967 = (target_obj_22966["lastError"]);
if((!((next_obj_22967 == null)))){
return next_obj_22967;
} else {
return null;
}
})();
return target_22962;
})();
return result_22959;
});
chromex.ext.runtime.id_STAR_ = (function chromex$ext$runtime$id_STAR_(config){
var result_22968 = (function (){var final_args_array_22969 = chromex.support.prepare_final_args_array(cljs.core.PersistentVector.EMPTY,"chrome.runtime.id");
var ns_22970 = (function (){var target_obj_22972 = cljs.core.cst$kw$root.cljs$core$IFn$_invoke$arity$1(config);
var next_obj_22973 = (target_obj_22972["chrome"]);
var next_obj_22974 = (next_obj_22973["runtime"]);
return next_obj_22974;
})();


var target_22971 = (function (){var target_obj_22975 = ns_22970;
var next_obj_22976 = (target_obj_22975["id"]);
if((!((next_obj_22976 == null)))){
return next_obj_22976;
} else {
return null;
}
})();
return target_22971;
})();
return result_22968;
});
chromex.ext.runtime.get_background_page_STAR_ = (function chromex$ext$runtime$get_background_page_STAR_(config){
var callback_chan_22977 = (function (){var config__6143__auto__ = config;
var handler_key__6144__auto__ = cljs.core.cst$kw$callback_DASH_channel_DASH_factory;
var handler__6145__auto__ = handler_key__6144__auto__.cljs$core$IFn$_invoke$arity$1(config__6143__auto__);

return (handler__6145__auto__.cljs$core$IFn$_invoke$arity$1 ? handler__6145__auto__.cljs$core$IFn$_invoke$arity$1(config__6143__auto__) : handler__6145__auto__.call(null,config__6143__auto__));
})();
var marshalled_callback_22979_22996 = ((function (callback_chan_22977){
return (function (cb_background_page_22983){
var fexpr__22987 = (function (){var config__6143__auto__ = config;
var handler_key__6144__auto__ = cljs.core.cst$kw$callback_DASH_fn_DASH_factory;
var handler__6145__auto__ = handler_key__6144__auto__.cljs$core$IFn$_invoke$arity$1(config__6143__auto__);

var G__22988 = config__6143__auto__;
var G__22989 = new cljs.core.PersistentArrayMap(null, 5, [cljs.core.cst$kw$id,cljs.core.cst$kw$chromex$ext$runtime_SLASH_get_DASH_background_DASH_page,cljs.core.cst$kw$name,"getBackgroundPage",cljs.core.cst$kw$callback_QMARK_,true,cljs.core.cst$kw$params,new cljs.core.PersistentVector(null, 1, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentArrayMap(null, 3, [cljs.core.cst$kw$name,"callback",cljs.core.cst$kw$type,cljs.core.cst$kw$callback,cljs.core.cst$kw$callback,new cljs.core.PersistentArrayMap(null, 1, [cljs.core.cst$kw$params,new cljs.core.PersistentVector(null, 1, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentArrayMap(null, 3, [cljs.core.cst$kw$name,"background-page",cljs.core.cst$kw$optional_QMARK_,true,cljs.core.cst$kw$type,"Window"], null)], null)], null)], null)], null),cljs.core.cst$kw$function_QMARK_,true], null);
var G__22990 = callback_chan_22977;
return (handler__6145__auto__.cljs$core$IFn$_invoke$arity$3 ? handler__6145__auto__.cljs$core$IFn$_invoke$arity$3(G__22988,G__22989,G__22990) : handler__6145__auto__.call(null,G__22988,G__22989,G__22990));
})();
return (fexpr__22987.cljs$core$IFn$_invoke$arity$1 ? fexpr__22987.cljs$core$IFn$_invoke$arity$1(cb_background_page_22983) : fexpr__22987.call(null,cb_background_page_22983));
});})(callback_chan_22977))
;
var result_22978_22997 = (function (){var final_args_array_22980 = chromex.support.prepare_final_args_array(new cljs.core.PersistentVector(null, 1, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_callback_22979_22996,"callback",null], null)], null),"chrome.runtime.getBackgroundPage");
var ns_22981 = (function (){var target_obj_22991 = cljs.core.cst$kw$root.cljs$core$IFn$_invoke$arity$1(config);
var next_obj_22992 = (target_obj_22991["chrome"]);
var next_obj_22993 = (next_obj_22992["runtime"]);
return next_obj_22993;
})();
var config__6181__auto___22998 = config;
var api_check_fn__6182__auto___22999 = cljs.core.cst$kw$missing_DASH_api_DASH_check_DASH_fn.cljs$core$IFn$_invoke$arity$1(config__6181__auto___22998);

(api_check_fn__6182__auto___22999.cljs$core$IFn$_invoke$arity$3 ? api_check_fn__6182__auto___22999.cljs$core$IFn$_invoke$arity$3("chrome.runtime.getBackgroundPage",ns_22981,"getBackgroundPage") : api_check_fn__6182__auto___22999.call(null,"chrome.runtime.getBackgroundPage",ns_22981,"getBackgroundPage"));


var target_22982 = (function (){var target_obj_22994 = ns_22981;
var next_obj_22995 = (target_obj_22994["getBackgroundPage"]);
if((!((next_obj_22995 == null)))){
return next_obj_22995;
} else {
return null;
}
})();
return target_22982.apply(ns_22981,final_args_array_22980);
})();

return callback_chan_22977;
});
chromex.ext.runtime.open_options_page_STAR_ = (function chromex$ext$runtime$open_options_page_STAR_(config){
var callback_chan_23000 = (function (){var config__6143__auto__ = config;
var handler_key__6144__auto__ = cljs.core.cst$kw$callback_DASH_channel_DASH_factory;
var handler__6145__auto__ = handler_key__6144__auto__.cljs$core$IFn$_invoke$arity$1(config__6143__auto__);

return (handler__6145__auto__.cljs$core$IFn$_invoke$arity$1 ? handler__6145__auto__.cljs$core$IFn$_invoke$arity$1(config__6143__auto__) : handler__6145__auto__.call(null,config__6143__auto__));
})();
var marshalled_callback_23002_23014 = (function (){var config__6143__auto__ = config;
var handler_key__6144__auto__ = cljs.core.cst$kw$callback_DASH_fn_DASH_factory;
var handler__6145__auto__ = handler_key__6144__auto__.cljs$core$IFn$_invoke$arity$1(config__6143__auto__);

var G__23006 = config__6143__auto__;
var G__23007 = new cljs.core.PersistentArrayMap(null, 6, [cljs.core.cst$kw$id,cljs.core.cst$kw$chromex$ext$runtime_SLASH_open_DASH_options_DASH_page,cljs.core.cst$kw$name,"openOptionsPage",cljs.core.cst$kw$since,"42",cljs.core.cst$kw$callback_QMARK_,true,cljs.core.cst$kw$params,new cljs.core.PersistentVector(null, 1, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentArrayMap(null, 3, [cljs.core.cst$kw$name,"callback",cljs.core.cst$kw$optional_QMARK_,true,cljs.core.cst$kw$type,cljs.core.cst$kw$callback], null)], null),cljs.core.cst$kw$function_QMARK_,true], null);
var G__23008 = callback_chan_23000;
return (handler__6145__auto__.cljs$core$IFn$_invoke$arity$3 ? handler__6145__auto__.cljs$core$IFn$_invoke$arity$3(G__23006,G__23007,G__23008) : handler__6145__auto__.call(null,G__23006,G__23007,G__23008));
})();
var result_23001_23015 = (function (){var final_args_array_23003 = chromex.support.prepare_final_args_array(new cljs.core.PersistentVector(null, 1, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_callback_23002_23014,"callback",true], null)], null),"chrome.runtime.openOptionsPage");
var ns_23004 = (function (){var target_obj_23009 = cljs.core.cst$kw$root.cljs$core$IFn$_invoke$arity$1(config);
var next_obj_23010 = (target_obj_23009["chrome"]);
var next_obj_23011 = (next_obj_23010["runtime"]);
return next_obj_23011;
})();
var config__6181__auto___23016 = config;
var api_check_fn__6182__auto___23017 = cljs.core.cst$kw$missing_DASH_api_DASH_check_DASH_fn.cljs$core$IFn$_invoke$arity$1(config__6181__auto___23016);

(api_check_fn__6182__auto___23017.cljs$core$IFn$_invoke$arity$3 ? api_check_fn__6182__auto___23017.cljs$core$IFn$_invoke$arity$3("chrome.runtime.openOptionsPage",ns_23004,"openOptionsPage") : api_check_fn__6182__auto___23017.call(null,"chrome.runtime.openOptionsPage",ns_23004,"openOptionsPage"));


var target_23005 = (function (){var target_obj_23012 = ns_23004;
var next_obj_23013 = (target_obj_23012["openOptionsPage"]);
if((!((next_obj_23013 == null)))){
return next_obj_23013;
} else {
return null;
}
})();
return target_23005.apply(ns_23004,final_args_array_23003);
})();

return callback_chan_23000;
});
chromex.ext.runtime.get_manifest_STAR_ = (function chromex$ext$runtime$get_manifest_STAR_(config){
var result_23018 = (function (){var final_args_array_23019 = chromex.support.prepare_final_args_array(cljs.core.PersistentVector.EMPTY,"chrome.runtime.getManifest");
var ns_23020 = (function (){var target_obj_23022 = cljs.core.cst$kw$root.cljs$core$IFn$_invoke$arity$1(config);
var next_obj_23023 = (target_obj_23022["chrome"]);
var next_obj_23024 = (next_obj_23023["runtime"]);
return next_obj_23024;
})();
var config__6181__auto___23027 = config;
var api_check_fn__6182__auto___23028 = cljs.core.cst$kw$missing_DASH_api_DASH_check_DASH_fn.cljs$core$IFn$_invoke$arity$1(config__6181__auto___23027);

(api_check_fn__6182__auto___23028.cljs$core$IFn$_invoke$arity$3 ? api_check_fn__6182__auto___23028.cljs$core$IFn$_invoke$arity$3("chrome.runtime.getManifest",ns_23020,"getManifest") : api_check_fn__6182__auto___23028.call(null,"chrome.runtime.getManifest",ns_23020,"getManifest"));


var target_23021 = (function (){var target_obj_23025 = ns_23020;
var next_obj_23026 = (target_obj_23025["getManifest"]);
if((!((next_obj_23026 == null)))){
return next_obj_23026;
} else {
return null;
}
})();
return target_23021.apply(ns_23020,final_args_array_23019);
})();
return result_23018;
});
chromex.ext.runtime.get_url_STAR_ = (function chromex$ext$runtime$get_url_STAR_(config,path){
var marshalled_path_23030 = (function (){var omit_test_23034 = path;
if(cljs.core.keyword_identical_QMARK_(omit_test_23034,cljs.core.cst$kw$omit)){
return cljs.core.cst$kw$omit;
} else {
return omit_test_23034;
}
})();
var result_23029 = (function (){var final_args_array_23031 = chromex.support.prepare_final_args_array(new cljs.core.PersistentVector(null, 1, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_path_23030,"path",null], null)], null),"chrome.runtime.getURL");
var ns_23032 = (function (){var target_obj_23035 = cljs.core.cst$kw$root.cljs$core$IFn$_invoke$arity$1(config);
var next_obj_23036 = (target_obj_23035["chrome"]);
var next_obj_23037 = (next_obj_23036["runtime"]);
return next_obj_23037;
})();
var config__6181__auto___23040 = config;
var api_check_fn__6182__auto___23041 = cljs.core.cst$kw$missing_DASH_api_DASH_check_DASH_fn.cljs$core$IFn$_invoke$arity$1(config__6181__auto___23040);

(api_check_fn__6182__auto___23041.cljs$core$IFn$_invoke$arity$3 ? api_check_fn__6182__auto___23041.cljs$core$IFn$_invoke$arity$3("chrome.runtime.getURL",ns_23032,"getURL") : api_check_fn__6182__auto___23041.call(null,"chrome.runtime.getURL",ns_23032,"getURL"));


var target_23033 = (function (){var target_obj_23038 = ns_23032;
var next_obj_23039 = (target_obj_23038["getURL"]);
if((!((next_obj_23039 == null)))){
return next_obj_23039;
} else {
return null;
}
})();
return target_23033.apply(ns_23032,final_args_array_23031);
})();
return result_23029;
});
chromex.ext.runtime.set_uninstall_url_STAR_ = (function chromex$ext$runtime$set_uninstall_url_STAR_(config,url){
var callback_chan_23042 = (function (){var config__6143__auto__ = config;
var handler_key__6144__auto__ = cljs.core.cst$kw$callback_DASH_channel_DASH_factory;
var handler__6145__auto__ = handler_key__6144__auto__.cljs$core$IFn$_invoke$arity$1(config__6143__auto__);

return (handler__6145__auto__.cljs$core$IFn$_invoke$arity$1 ? handler__6145__auto__.cljs$core$IFn$_invoke$arity$1(config__6143__auto__) : handler__6145__auto__.call(null,config__6143__auto__));
})();
var marshalled_url_23044_23058 = (function (){var omit_test_23049 = url;
if(cljs.core.keyword_identical_QMARK_(omit_test_23049,cljs.core.cst$kw$omit)){
return cljs.core.cst$kw$omit;
} else {
return omit_test_23049;
}
})();
var marshalled_callback_23045_23059 = (function (){var config__6143__auto__ = config;
var handler_key__6144__auto__ = cljs.core.cst$kw$callback_DASH_fn_DASH_factory;
var handler__6145__auto__ = handler_key__6144__auto__.cljs$core$IFn$_invoke$arity$1(config__6143__auto__);

var G__23050 = config__6143__auto__;
var G__23051 = new cljs.core.PersistentArrayMap(null, 6, [cljs.core.cst$kw$id,cljs.core.cst$kw$chromex$ext$runtime_SLASH_set_DASH_uninstall_DASH_url,cljs.core.cst$kw$name,"setUninstallURL",cljs.core.cst$kw$since,"41",cljs.core.cst$kw$callback_QMARK_,true,cljs.core.cst$kw$params,new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentArrayMap(null, 2, [cljs.core.cst$kw$name,"url",cljs.core.cst$kw$type,"string"], null),new cljs.core.PersistentArrayMap(null, 3, [cljs.core.cst$kw$name,"callback",cljs.core.cst$kw$optional_QMARK_,true,cljs.core.cst$kw$type,cljs.core.cst$kw$callback], null)], null),cljs.core.cst$kw$function_QMARK_,true], null);
var G__23052 = callback_chan_23042;
return (handler__6145__auto__.cljs$core$IFn$_invoke$arity$3 ? handler__6145__auto__.cljs$core$IFn$_invoke$arity$3(G__23050,G__23051,G__23052) : handler__6145__auto__.call(null,G__23050,G__23051,G__23052));
})();
var result_23043_23060 = (function (){var final_args_array_23046 = chromex.support.prepare_final_args_array(new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_url_23044_23058,"url",null], null),new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_callback_23045_23059,"callback",true], null)], null),"chrome.runtime.setUninstallURL");
var ns_23047 = (function (){var target_obj_23053 = cljs.core.cst$kw$root.cljs$core$IFn$_invoke$arity$1(config);
var next_obj_23054 = (target_obj_23053["chrome"]);
var next_obj_23055 = (next_obj_23054["runtime"]);
return next_obj_23055;
})();
var config__6181__auto___23061 = config;
var api_check_fn__6182__auto___23062 = cljs.core.cst$kw$missing_DASH_api_DASH_check_DASH_fn.cljs$core$IFn$_invoke$arity$1(config__6181__auto___23061);

(api_check_fn__6182__auto___23062.cljs$core$IFn$_invoke$arity$3 ? api_check_fn__6182__auto___23062.cljs$core$IFn$_invoke$arity$3("chrome.runtime.setUninstallURL",ns_23047,"setUninstallURL") : api_check_fn__6182__auto___23062.call(null,"chrome.runtime.setUninstallURL",ns_23047,"setUninstallURL"));


var target_23048 = (function (){var target_obj_23056 = ns_23047;
var next_obj_23057 = (target_obj_23056["setUninstallURL"]);
if((!((next_obj_23057 == null)))){
return next_obj_23057;
} else {
return null;
}
})();
return target_23048.apply(ns_23047,final_args_array_23046);
})();

return callback_chan_23042;
});
chromex.ext.runtime.reload_STAR_ = (function chromex$ext$runtime$reload_STAR_(config){
var result_23063 = (function (){var final_args_array_23064 = chromex.support.prepare_final_args_array(cljs.core.PersistentVector.EMPTY,"chrome.runtime.reload");
var ns_23065 = (function (){var target_obj_23067 = cljs.core.cst$kw$root.cljs$core$IFn$_invoke$arity$1(config);
var next_obj_23068 = (target_obj_23067["chrome"]);
var next_obj_23069 = (next_obj_23068["runtime"]);
return next_obj_23069;
})();
var config__6181__auto___23072 = config;
var api_check_fn__6182__auto___23073 = cljs.core.cst$kw$missing_DASH_api_DASH_check_DASH_fn.cljs$core$IFn$_invoke$arity$1(config__6181__auto___23072);

(api_check_fn__6182__auto___23073.cljs$core$IFn$_invoke$arity$3 ? api_check_fn__6182__auto___23073.cljs$core$IFn$_invoke$arity$3("chrome.runtime.reload",ns_23065,"reload") : api_check_fn__6182__auto___23073.call(null,"chrome.runtime.reload",ns_23065,"reload"));


var target_23066 = (function (){var target_obj_23070 = ns_23065;
var next_obj_23071 = (target_obj_23070["reload"]);
if((!((next_obj_23071 == null)))){
return next_obj_23071;
} else {
return null;
}
})();
return target_23066.apply(ns_23065,final_args_array_23064);
})();
return result_23063;
});
chromex.ext.runtime.request_update_check_STAR_ = (function chromex$ext$runtime$request_update_check_STAR_(config){
var callback_chan_23074 = (function (){var config__6143__auto__ = config;
var handler_key__6144__auto__ = cljs.core.cst$kw$callback_DASH_channel_DASH_factory;
var handler__6145__auto__ = handler_key__6144__auto__.cljs$core$IFn$_invoke$arity$1(config__6143__auto__);

return (handler__6145__auto__.cljs$core$IFn$_invoke$arity$1 ? handler__6145__auto__.cljs$core$IFn$_invoke$arity$1(config__6143__auto__) : handler__6145__auto__.call(null,config__6143__auto__));
})();
var marshalled_callback_23076_23094 = ((function (callback_chan_23074){
return (function (cb_status_23080,cb_details_23081){
var fexpr__23085 = (function (){var config__6143__auto__ = config;
var handler_key__6144__auto__ = cljs.core.cst$kw$callback_DASH_fn_DASH_factory;
var handler__6145__auto__ = handler_key__6144__auto__.cljs$core$IFn$_invoke$arity$1(config__6143__auto__);

var G__23086 = config__6143__auto__;
var G__23087 = new cljs.core.PersistentArrayMap(null, 5, [cljs.core.cst$kw$id,cljs.core.cst$kw$chromex$ext$runtime_SLASH_request_DASH_update_DASH_check,cljs.core.cst$kw$name,"requestUpdateCheck",cljs.core.cst$kw$callback_QMARK_,true,cljs.core.cst$kw$params,new cljs.core.PersistentVector(null, 1, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentArrayMap(null, 3, [cljs.core.cst$kw$name,"callback",cljs.core.cst$kw$type,cljs.core.cst$kw$callback,cljs.core.cst$kw$callback,new cljs.core.PersistentArrayMap(null, 1, [cljs.core.cst$kw$params,new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentArrayMap(null, 2, [cljs.core.cst$kw$name,"status",cljs.core.cst$kw$type,"runtime.RequestUpdateCheckStatus"], null),new cljs.core.PersistentArrayMap(null, 3, [cljs.core.cst$kw$name,"details",cljs.core.cst$kw$optional_QMARK_,true,cljs.core.cst$kw$type,"object"], null)], null)], null)], null)], null),cljs.core.cst$kw$function_QMARK_,true], null);
var G__23088 = callback_chan_23074;
return (handler__6145__auto__.cljs$core$IFn$_invoke$arity$3 ? handler__6145__auto__.cljs$core$IFn$_invoke$arity$3(G__23086,G__23087,G__23088) : handler__6145__auto__.call(null,G__23086,G__23087,G__23088));
})();
return (fexpr__23085.cljs$core$IFn$_invoke$arity$2 ? fexpr__23085.cljs$core$IFn$_invoke$arity$2(cb_status_23080,cb_details_23081) : fexpr__23085.call(null,cb_status_23080,cb_details_23081));
});})(callback_chan_23074))
;
var result_23075_23095 = (function (){var final_args_array_23077 = chromex.support.prepare_final_args_array(new cljs.core.PersistentVector(null, 1, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_callback_23076_23094,"callback",null], null)], null),"chrome.runtime.requestUpdateCheck");
var ns_23078 = (function (){var target_obj_23089 = cljs.core.cst$kw$root.cljs$core$IFn$_invoke$arity$1(config);
var next_obj_23090 = (target_obj_23089["chrome"]);
var next_obj_23091 = (next_obj_23090["runtime"]);
return next_obj_23091;
})();
var config__6181__auto___23096 = config;
var api_check_fn__6182__auto___23097 = cljs.core.cst$kw$missing_DASH_api_DASH_check_DASH_fn.cljs$core$IFn$_invoke$arity$1(config__6181__auto___23096);

(api_check_fn__6182__auto___23097.cljs$core$IFn$_invoke$arity$3 ? api_check_fn__6182__auto___23097.cljs$core$IFn$_invoke$arity$3("chrome.runtime.requestUpdateCheck",ns_23078,"requestUpdateCheck") : api_check_fn__6182__auto___23097.call(null,"chrome.runtime.requestUpdateCheck",ns_23078,"requestUpdateCheck"));


var target_23079 = (function (){var target_obj_23092 = ns_23078;
var next_obj_23093 = (target_obj_23092["requestUpdateCheck"]);
if((!((next_obj_23093 == null)))){
return next_obj_23093;
} else {
return null;
}
})();
return target_23079.apply(ns_23078,final_args_array_23077);
})();

return callback_chan_23074;
});
chromex.ext.runtime.restart_STAR_ = (function chromex$ext$runtime$restart_STAR_(config){
var result_23098 = (function (){var final_args_array_23099 = chromex.support.prepare_final_args_array(cljs.core.PersistentVector.EMPTY,"chrome.runtime.restart");
var ns_23100 = (function (){var target_obj_23102 = cljs.core.cst$kw$root.cljs$core$IFn$_invoke$arity$1(config);
var next_obj_23103 = (target_obj_23102["chrome"]);
var next_obj_23104 = (next_obj_23103["runtime"]);
return next_obj_23104;
})();
var config__6181__auto___23107 = config;
var api_check_fn__6182__auto___23108 = cljs.core.cst$kw$missing_DASH_api_DASH_check_DASH_fn.cljs$core$IFn$_invoke$arity$1(config__6181__auto___23107);

(api_check_fn__6182__auto___23108.cljs$core$IFn$_invoke$arity$3 ? api_check_fn__6182__auto___23108.cljs$core$IFn$_invoke$arity$3("chrome.runtime.restart",ns_23100,"restart") : api_check_fn__6182__auto___23108.call(null,"chrome.runtime.restart",ns_23100,"restart"));


var target_23101 = (function (){var target_obj_23105 = ns_23100;
var next_obj_23106 = (target_obj_23105["restart"]);
if((!((next_obj_23106 == null)))){
return next_obj_23106;
} else {
return null;
}
})();
return target_23101.apply(ns_23100,final_args_array_23099);
})();
return result_23098;
});
chromex.ext.runtime.restart_after_delay_STAR_ = (function chromex$ext$runtime$restart_after_delay_STAR_(config,seconds){
var callback_chan_23109 = (function (){var config__6143__auto__ = config;
var handler_key__6144__auto__ = cljs.core.cst$kw$callback_DASH_channel_DASH_factory;
var handler__6145__auto__ = handler_key__6144__auto__.cljs$core$IFn$_invoke$arity$1(config__6143__auto__);

return (handler__6145__auto__.cljs$core$IFn$_invoke$arity$1 ? handler__6145__auto__.cljs$core$IFn$_invoke$arity$1(config__6143__auto__) : handler__6145__auto__.call(null,config__6143__auto__));
})();
var marshalled_seconds_23111_23125 = (function (){var omit_test_23116 = seconds;
if(cljs.core.keyword_identical_QMARK_(omit_test_23116,cljs.core.cst$kw$omit)){
return cljs.core.cst$kw$omit;
} else {
return omit_test_23116;
}
})();
var marshalled_callback_23112_23126 = (function (){var config__6143__auto__ = config;
var handler_key__6144__auto__ = cljs.core.cst$kw$callback_DASH_fn_DASH_factory;
var handler__6145__auto__ = handler_key__6144__auto__.cljs$core$IFn$_invoke$arity$1(config__6143__auto__);

var G__23117 = config__6143__auto__;
var G__23118 = new cljs.core.PersistentArrayMap(null, 6, [cljs.core.cst$kw$id,cljs.core.cst$kw$chromex$ext$runtime_SLASH_restart_DASH_after_DASH_delay,cljs.core.cst$kw$name,"restartAfterDelay",cljs.core.cst$kw$since,"53",cljs.core.cst$kw$callback_QMARK_,true,cljs.core.cst$kw$params,new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentArrayMap(null, 2, [cljs.core.cst$kw$name,"seconds",cljs.core.cst$kw$type,"integer"], null),new cljs.core.PersistentArrayMap(null, 3, [cljs.core.cst$kw$name,"callback",cljs.core.cst$kw$optional_QMARK_,true,cljs.core.cst$kw$type,cljs.core.cst$kw$callback], null)], null),cljs.core.cst$kw$function_QMARK_,true], null);
var G__23119 = callback_chan_23109;
return (handler__6145__auto__.cljs$core$IFn$_invoke$arity$3 ? handler__6145__auto__.cljs$core$IFn$_invoke$arity$3(G__23117,G__23118,G__23119) : handler__6145__auto__.call(null,G__23117,G__23118,G__23119));
})();
var result_23110_23127 = (function (){var final_args_array_23113 = chromex.support.prepare_final_args_array(new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_seconds_23111_23125,"seconds",null], null),new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_callback_23112_23126,"callback",true], null)], null),"chrome.runtime.restartAfterDelay");
var ns_23114 = (function (){var target_obj_23120 = cljs.core.cst$kw$root.cljs$core$IFn$_invoke$arity$1(config);
var next_obj_23121 = (target_obj_23120["chrome"]);
var next_obj_23122 = (next_obj_23121["runtime"]);
return next_obj_23122;
})();
var config__6181__auto___23128 = config;
var api_check_fn__6182__auto___23129 = cljs.core.cst$kw$missing_DASH_api_DASH_check_DASH_fn.cljs$core$IFn$_invoke$arity$1(config__6181__auto___23128);

(api_check_fn__6182__auto___23129.cljs$core$IFn$_invoke$arity$3 ? api_check_fn__6182__auto___23129.cljs$core$IFn$_invoke$arity$3("chrome.runtime.restartAfterDelay",ns_23114,"restartAfterDelay") : api_check_fn__6182__auto___23129.call(null,"chrome.runtime.restartAfterDelay",ns_23114,"restartAfterDelay"));


var target_23115 = (function (){var target_obj_23123 = ns_23114;
var next_obj_23124 = (target_obj_23123["restartAfterDelay"]);
if((!((next_obj_23124 == null)))){
return next_obj_23124;
} else {
return null;
}
})();
return target_23115.apply(ns_23114,final_args_array_23113);
})();

return callback_chan_23109;
});
chromex.ext.runtime.connect_STAR_ = (function chromex$ext$runtime$connect_STAR_(config,extension_id,connect_info){
var marshalled_extension_id_23131 = (function (){var omit_test_23136 = extension_id;
if(cljs.core.keyword_identical_QMARK_(omit_test_23136,cljs.core.cst$kw$omit)){
return cljs.core.cst$kw$omit;
} else {
return omit_test_23136;
}
})();
var marshalled_connect_info_23132 = (function (){var omit_test_23137 = connect_info;
if(cljs.core.keyword_identical_QMARK_(omit_test_23137,cljs.core.cst$kw$omit)){
return cljs.core.cst$kw$omit;
} else {
return omit_test_23137;
}
})();
var result_23130 = (function (){var final_args_array_23133 = chromex.support.prepare_final_args_array(new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_extension_id_23131,"extension-id",true], null),new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_connect_info_23132,"connect-info",true], null)], null),"chrome.runtime.connect");
var ns_23134 = (function (){var target_obj_23138 = cljs.core.cst$kw$root.cljs$core$IFn$_invoke$arity$1(config);
var next_obj_23139 = (target_obj_23138["chrome"]);
var next_obj_23140 = (next_obj_23139["runtime"]);
return next_obj_23140;
})();
var config__6181__auto___23143 = config;
var api_check_fn__6182__auto___23144 = cljs.core.cst$kw$missing_DASH_api_DASH_check_DASH_fn.cljs$core$IFn$_invoke$arity$1(config__6181__auto___23143);

(api_check_fn__6182__auto___23144.cljs$core$IFn$_invoke$arity$3 ? api_check_fn__6182__auto___23144.cljs$core$IFn$_invoke$arity$3("chrome.runtime.connect",ns_23134,"connect") : api_check_fn__6182__auto___23144.call(null,"chrome.runtime.connect",ns_23134,"connect"));


var target_23135 = (function (){var target_obj_23141 = ns_23134;
var next_obj_23142 = (target_obj_23141["connect"]);
if((!((next_obj_23142 == null)))){
return next_obj_23142;
} else {
return null;
}
})();
return target_23135.apply(ns_23134,final_args_array_23133);
})();
return chromex.marshalling.from_native_chrome_port(config,result_23130);
});
chromex.ext.runtime.connect_native_STAR_ = (function chromex$ext$runtime$connect_native_STAR_(config,application){
var marshalled_application_23146 = (function (){var omit_test_23150 = application;
if(cljs.core.keyword_identical_QMARK_(omit_test_23150,cljs.core.cst$kw$omit)){
return cljs.core.cst$kw$omit;
} else {
return omit_test_23150;
}
})();
var result_23145 = (function (){var final_args_array_23147 = chromex.support.prepare_final_args_array(new cljs.core.PersistentVector(null, 1, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_application_23146,"application",null], null)], null),"chrome.runtime.connectNative");
var ns_23148 = (function (){var target_obj_23151 = cljs.core.cst$kw$root.cljs$core$IFn$_invoke$arity$1(config);
var next_obj_23152 = (target_obj_23151["chrome"]);
var next_obj_23153 = (next_obj_23152["runtime"]);
return next_obj_23153;
})();
var config__6181__auto___23156 = config;
var api_check_fn__6182__auto___23157 = cljs.core.cst$kw$missing_DASH_api_DASH_check_DASH_fn.cljs$core$IFn$_invoke$arity$1(config__6181__auto___23156);

(api_check_fn__6182__auto___23157.cljs$core$IFn$_invoke$arity$3 ? api_check_fn__6182__auto___23157.cljs$core$IFn$_invoke$arity$3("chrome.runtime.connectNative",ns_23148,"connectNative") : api_check_fn__6182__auto___23157.call(null,"chrome.runtime.connectNative",ns_23148,"connectNative"));


var target_23149 = (function (){var target_obj_23154 = ns_23148;
var next_obj_23155 = (target_obj_23154["connectNative"]);
if((!((next_obj_23155 == null)))){
return next_obj_23155;
} else {
return null;
}
})();
return target_23149.apply(ns_23148,final_args_array_23147);
})();
return chromex.marshalling.from_native_chrome_port(config,result_23145);
});
chromex.ext.runtime.send_message_STAR_ = (function chromex$ext$runtime$send_message_STAR_(config,extension_id,message,options){
var callback_chan_23158 = (function (){var config__6143__auto__ = config;
var handler_key__6144__auto__ = cljs.core.cst$kw$callback_DASH_channel_DASH_factory;
var handler__6145__auto__ = handler_key__6144__auto__.cljs$core$IFn$_invoke$arity$1(config__6143__auto__);

return (handler__6145__auto__.cljs$core$IFn$_invoke$arity$1 ? handler__6145__auto__.cljs$core$IFn$_invoke$arity$1(config__6143__auto__) : handler__6145__auto__.call(null,config__6143__auto__));
})();
var marshalled_extension_id_23160_23183 = (function (){var omit_test_23167 = extension_id;
if(cljs.core.keyword_identical_QMARK_(omit_test_23167,cljs.core.cst$kw$omit)){
return cljs.core.cst$kw$omit;
} else {
return omit_test_23167;
}
})();
var marshalled_message_23161_23184 = (function (){var omit_test_23168 = message;
if(cljs.core.keyword_identical_QMARK_(omit_test_23168,cljs.core.cst$kw$omit)){
return cljs.core.cst$kw$omit;
} else {
return omit_test_23168;
}
})();
var marshalled_options_23162_23185 = (function (){var omit_test_23169 = options;
if(cljs.core.keyword_identical_QMARK_(omit_test_23169,cljs.core.cst$kw$omit)){
return cljs.core.cst$kw$omit;
} else {
return omit_test_23169;
}
})();
var marshalled_response_callback_23163_23186 = ((function (marshalled_extension_id_23160_23183,marshalled_message_23161_23184,marshalled_options_23162_23185,callback_chan_23158){
return (function (cb_response_23170){
var fexpr__23174 = (function (){var config__6143__auto__ = config;
var handler_key__6144__auto__ = cljs.core.cst$kw$callback_DASH_fn_DASH_factory;
var handler__6145__auto__ = handler_key__6144__auto__.cljs$core$IFn$_invoke$arity$1(config__6143__auto__);

var G__23175 = config__6143__auto__;
var G__23176 = new cljs.core.PersistentArrayMap(null, 5, [cljs.core.cst$kw$id,cljs.core.cst$kw$chromex$ext$runtime_SLASH_send_DASH_message,cljs.core.cst$kw$name,"sendMessage",cljs.core.cst$kw$callback_QMARK_,true,cljs.core.cst$kw$params,new cljs.core.PersistentVector(null, 4, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentArrayMap(null, 3, [cljs.core.cst$kw$name,"extension-id",cljs.core.cst$kw$optional_QMARK_,true,cljs.core.cst$kw$type,"string"], null),new cljs.core.PersistentArrayMap(null, 2, [cljs.core.cst$kw$name,"message",cljs.core.cst$kw$type,"any"], null),new cljs.core.PersistentArrayMap(null, 3, [cljs.core.cst$kw$name,"options",cljs.core.cst$kw$optional_QMARK_,true,cljs.core.cst$kw$type,"object"], null),new cljs.core.PersistentArrayMap(null, 4, [cljs.core.cst$kw$name,"response-callback",cljs.core.cst$kw$optional_QMARK_,true,cljs.core.cst$kw$type,cljs.core.cst$kw$callback,cljs.core.cst$kw$callback,new cljs.core.PersistentArrayMap(null, 1, [cljs.core.cst$kw$params,new cljs.core.PersistentVector(null, 1, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentArrayMap(null, 2, [cljs.core.cst$kw$name,"response",cljs.core.cst$kw$type,"any"], null)], null)], null)], null)], null),cljs.core.cst$kw$function_QMARK_,true], null);
var G__23177 = callback_chan_23158;
return (handler__6145__auto__.cljs$core$IFn$_invoke$arity$3 ? handler__6145__auto__.cljs$core$IFn$_invoke$arity$3(G__23175,G__23176,G__23177) : handler__6145__auto__.call(null,G__23175,G__23176,G__23177));
})();
return (fexpr__23174.cljs$core$IFn$_invoke$arity$1 ? fexpr__23174.cljs$core$IFn$_invoke$arity$1(cb_response_23170) : fexpr__23174.call(null,cb_response_23170));
});})(marshalled_extension_id_23160_23183,marshalled_message_23161_23184,marshalled_options_23162_23185,callback_chan_23158))
;
var result_23159_23187 = (function (){var final_args_array_23164 = chromex.support.prepare_final_args_array(new cljs.core.PersistentVector(null, 4, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_extension_id_23160_23183,"extension-id",true], null),new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_message_23161_23184,"message",null], null),new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_options_23162_23185,"options",true], null),new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_response_callback_23163_23186,"response-callback",true], null)], null),"chrome.runtime.sendMessage");
var ns_23165 = (function (){var target_obj_23178 = cljs.core.cst$kw$root.cljs$core$IFn$_invoke$arity$1(config);
var next_obj_23179 = (target_obj_23178["chrome"]);
var next_obj_23180 = (next_obj_23179["runtime"]);
return next_obj_23180;
})();
var config__6181__auto___23188 = config;
var api_check_fn__6182__auto___23189 = cljs.core.cst$kw$missing_DASH_api_DASH_check_DASH_fn.cljs$core$IFn$_invoke$arity$1(config__6181__auto___23188);

(api_check_fn__6182__auto___23189.cljs$core$IFn$_invoke$arity$3 ? api_check_fn__6182__auto___23189.cljs$core$IFn$_invoke$arity$3("chrome.runtime.sendMessage",ns_23165,"sendMessage") : api_check_fn__6182__auto___23189.call(null,"chrome.runtime.sendMessage",ns_23165,"sendMessage"));


var target_23166 = (function (){var target_obj_23181 = ns_23165;
var next_obj_23182 = (target_obj_23181["sendMessage"]);
if((!((next_obj_23182 == null)))){
return next_obj_23182;
} else {
return null;
}
})();
return target_23166.apply(ns_23165,final_args_array_23164);
})();

return callback_chan_23158;
});
chromex.ext.runtime.send_native_message_STAR_ = (function chromex$ext$runtime$send_native_message_STAR_(config,application,message){
var callback_chan_23190 = (function (){var config__6143__auto__ = config;
var handler_key__6144__auto__ = cljs.core.cst$kw$callback_DASH_channel_DASH_factory;
var handler__6145__auto__ = handler_key__6144__auto__.cljs$core$IFn$_invoke$arity$1(config__6143__auto__);

return (handler__6145__auto__.cljs$core$IFn$_invoke$arity$1 ? handler__6145__auto__.cljs$core$IFn$_invoke$arity$1(config__6143__auto__) : handler__6145__auto__.call(null,config__6143__auto__));
})();
var marshalled_application_23192_23213 = (function (){var omit_test_23198 = application;
if(cljs.core.keyword_identical_QMARK_(omit_test_23198,cljs.core.cst$kw$omit)){
return cljs.core.cst$kw$omit;
} else {
return omit_test_23198;
}
})();
var marshalled_message_23193_23214 = (function (){var omit_test_23199 = message;
if(cljs.core.keyword_identical_QMARK_(omit_test_23199,cljs.core.cst$kw$omit)){
return cljs.core.cst$kw$omit;
} else {
return omit_test_23199;
}
})();
var marshalled_response_callback_23194_23215 = ((function (marshalled_application_23192_23213,marshalled_message_23193_23214,callback_chan_23190){
return (function (cb_response_23200){
var fexpr__23204 = (function (){var config__6143__auto__ = config;
var handler_key__6144__auto__ = cljs.core.cst$kw$callback_DASH_fn_DASH_factory;
var handler__6145__auto__ = handler_key__6144__auto__.cljs$core$IFn$_invoke$arity$1(config__6143__auto__);

var G__23205 = config__6143__auto__;
var G__23206 = new cljs.core.PersistentArrayMap(null, 6, [cljs.core.cst$kw$id,cljs.core.cst$kw$chromex$ext$runtime_SLASH_send_DASH_native_DASH_message,cljs.core.cst$kw$name,"sendNativeMessage",cljs.core.cst$kw$since,"28",cljs.core.cst$kw$callback_QMARK_,true,cljs.core.cst$kw$params,new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentArrayMap(null, 2, [cljs.core.cst$kw$name,"application",cljs.core.cst$kw$type,"string"], null),new cljs.core.PersistentArrayMap(null, 2, [cljs.core.cst$kw$name,"message",cljs.core.cst$kw$type,"object"], null),new cljs.core.PersistentArrayMap(null, 4, [cljs.core.cst$kw$name,"response-callback",cljs.core.cst$kw$optional_QMARK_,true,cljs.core.cst$kw$type,cljs.core.cst$kw$callback,cljs.core.cst$kw$callback,new cljs.core.PersistentArrayMap(null, 1, [cljs.core.cst$kw$params,new cljs.core.PersistentVector(null, 1, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentArrayMap(null, 2, [cljs.core.cst$kw$name,"response",cljs.core.cst$kw$type,"any"], null)], null)], null)], null)], null),cljs.core.cst$kw$function_QMARK_,true], null);
var G__23207 = callback_chan_23190;
return (handler__6145__auto__.cljs$core$IFn$_invoke$arity$3 ? handler__6145__auto__.cljs$core$IFn$_invoke$arity$3(G__23205,G__23206,G__23207) : handler__6145__auto__.call(null,G__23205,G__23206,G__23207));
})();
return (fexpr__23204.cljs$core$IFn$_invoke$arity$1 ? fexpr__23204.cljs$core$IFn$_invoke$arity$1(cb_response_23200) : fexpr__23204.call(null,cb_response_23200));
});})(marshalled_application_23192_23213,marshalled_message_23193_23214,callback_chan_23190))
;
var result_23191_23216 = (function (){var final_args_array_23195 = chromex.support.prepare_final_args_array(new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_application_23192_23213,"application",null], null),new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_message_23193_23214,"message",null], null),new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_response_callback_23194_23215,"response-callback",true], null)], null),"chrome.runtime.sendNativeMessage");
var ns_23196 = (function (){var target_obj_23208 = cljs.core.cst$kw$root.cljs$core$IFn$_invoke$arity$1(config);
var next_obj_23209 = (target_obj_23208["chrome"]);
var next_obj_23210 = (next_obj_23209["runtime"]);
return next_obj_23210;
})();
var config__6181__auto___23217 = config;
var api_check_fn__6182__auto___23218 = cljs.core.cst$kw$missing_DASH_api_DASH_check_DASH_fn.cljs$core$IFn$_invoke$arity$1(config__6181__auto___23217);

(api_check_fn__6182__auto___23218.cljs$core$IFn$_invoke$arity$3 ? api_check_fn__6182__auto___23218.cljs$core$IFn$_invoke$arity$3("chrome.runtime.sendNativeMessage",ns_23196,"sendNativeMessage") : api_check_fn__6182__auto___23218.call(null,"chrome.runtime.sendNativeMessage",ns_23196,"sendNativeMessage"));


var target_23197 = (function (){var target_obj_23211 = ns_23196;
var next_obj_23212 = (target_obj_23211["sendNativeMessage"]);
if((!((next_obj_23212 == null)))){
return next_obj_23212;
} else {
return null;
}
})();
return target_23197.apply(ns_23196,final_args_array_23195);
})();

return callback_chan_23190;
});
chromex.ext.runtime.get_platform_info_STAR_ = (function chromex$ext$runtime$get_platform_info_STAR_(config){
var callback_chan_23219 = (function (){var config__6143__auto__ = config;
var handler_key__6144__auto__ = cljs.core.cst$kw$callback_DASH_channel_DASH_factory;
var handler__6145__auto__ = handler_key__6144__auto__.cljs$core$IFn$_invoke$arity$1(config__6143__auto__);

return (handler__6145__auto__.cljs$core$IFn$_invoke$arity$1 ? handler__6145__auto__.cljs$core$IFn$_invoke$arity$1(config__6143__auto__) : handler__6145__auto__.call(null,config__6143__auto__));
})();
var marshalled_callback_23221_23238 = ((function (callback_chan_23219){
return (function (cb_platform_info_23225){
var fexpr__23229 = (function (){var config__6143__auto__ = config;
var handler_key__6144__auto__ = cljs.core.cst$kw$callback_DASH_fn_DASH_factory;
var handler__6145__auto__ = handler_key__6144__auto__.cljs$core$IFn$_invoke$arity$1(config__6143__auto__);

var G__23230 = config__6143__auto__;
var G__23231 = new cljs.core.PersistentArrayMap(null, 6, [cljs.core.cst$kw$id,cljs.core.cst$kw$chromex$ext$runtime_SLASH_get_DASH_platform_DASH_info,cljs.core.cst$kw$name,"getPlatformInfo",cljs.core.cst$kw$since,"29",cljs.core.cst$kw$callback_QMARK_,true,cljs.core.cst$kw$params,new cljs.core.PersistentVector(null, 1, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentArrayMap(null, 3, [cljs.core.cst$kw$name,"callback",cljs.core.cst$kw$type,cljs.core.cst$kw$callback,cljs.core.cst$kw$callback,new cljs.core.PersistentArrayMap(null, 1, [cljs.core.cst$kw$params,new cljs.core.PersistentVector(null, 1, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentArrayMap(null, 2, [cljs.core.cst$kw$name,"platform-info",cljs.core.cst$kw$type,"runtime.PlatformInfo"], null)], null)], null)], null)], null),cljs.core.cst$kw$function_QMARK_,true], null);
var G__23232 = callback_chan_23219;
return (handler__6145__auto__.cljs$core$IFn$_invoke$arity$3 ? handler__6145__auto__.cljs$core$IFn$_invoke$arity$3(G__23230,G__23231,G__23232) : handler__6145__auto__.call(null,G__23230,G__23231,G__23232));
})();
return (fexpr__23229.cljs$core$IFn$_invoke$arity$1 ? fexpr__23229.cljs$core$IFn$_invoke$arity$1(cb_platform_info_23225) : fexpr__23229.call(null,cb_platform_info_23225));
});})(callback_chan_23219))
;
var result_23220_23239 = (function (){var final_args_array_23222 = chromex.support.prepare_final_args_array(new cljs.core.PersistentVector(null, 1, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_callback_23221_23238,"callback",null], null)], null),"chrome.runtime.getPlatformInfo");
var ns_23223 = (function (){var target_obj_23233 = cljs.core.cst$kw$root.cljs$core$IFn$_invoke$arity$1(config);
var next_obj_23234 = (target_obj_23233["chrome"]);
var next_obj_23235 = (next_obj_23234["runtime"]);
return next_obj_23235;
})();
var config__6181__auto___23240 = config;
var api_check_fn__6182__auto___23241 = cljs.core.cst$kw$missing_DASH_api_DASH_check_DASH_fn.cljs$core$IFn$_invoke$arity$1(config__6181__auto___23240);

(api_check_fn__6182__auto___23241.cljs$core$IFn$_invoke$arity$3 ? api_check_fn__6182__auto___23241.cljs$core$IFn$_invoke$arity$3("chrome.runtime.getPlatformInfo",ns_23223,"getPlatformInfo") : api_check_fn__6182__auto___23241.call(null,"chrome.runtime.getPlatformInfo",ns_23223,"getPlatformInfo"));


var target_23224 = (function (){var target_obj_23236 = ns_23223;
var next_obj_23237 = (target_obj_23236["getPlatformInfo"]);
if((!((next_obj_23237 == null)))){
return next_obj_23237;
} else {
return null;
}
})();
return target_23224.apply(ns_23223,final_args_array_23222);
})();

return callback_chan_23219;
});
chromex.ext.runtime.get_package_directory_entry_STAR_ = (function chromex$ext$runtime$get_package_directory_entry_STAR_(config){
var callback_chan_23242 = (function (){var config__6143__auto__ = config;
var handler_key__6144__auto__ = cljs.core.cst$kw$callback_DASH_channel_DASH_factory;
var handler__6145__auto__ = handler_key__6144__auto__.cljs$core$IFn$_invoke$arity$1(config__6143__auto__);

return (handler__6145__auto__.cljs$core$IFn$_invoke$arity$1 ? handler__6145__auto__.cljs$core$IFn$_invoke$arity$1(config__6143__auto__) : handler__6145__auto__.call(null,config__6143__auto__));
})();
var marshalled_callback_23244_23261 = ((function (callback_chan_23242){
return (function (cb_directory_entry_23248){
var fexpr__23252 = (function (){var config__6143__auto__ = config;
var handler_key__6144__auto__ = cljs.core.cst$kw$callback_DASH_fn_DASH_factory;
var handler__6145__auto__ = handler_key__6144__auto__.cljs$core$IFn$_invoke$arity$1(config__6143__auto__);

var G__23253 = config__6143__auto__;
var G__23254 = new cljs.core.PersistentArrayMap(null, 6, [cljs.core.cst$kw$id,cljs.core.cst$kw$chromex$ext$runtime_SLASH_get_DASH_package_DASH_directory_DASH_entry,cljs.core.cst$kw$name,"getPackageDirectoryEntry",cljs.core.cst$kw$since,"29",cljs.core.cst$kw$callback_QMARK_,true,cljs.core.cst$kw$params,new cljs.core.PersistentVector(null, 1, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentArrayMap(null, 3, [cljs.core.cst$kw$name,"callback",cljs.core.cst$kw$type,cljs.core.cst$kw$callback,cljs.core.cst$kw$callback,new cljs.core.PersistentArrayMap(null, 1, [cljs.core.cst$kw$params,new cljs.core.PersistentVector(null, 1, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentArrayMap(null, 2, [cljs.core.cst$kw$name,"directory-entry",cljs.core.cst$kw$type,"DirectoryEntry"], null)], null)], null)], null)], null),cljs.core.cst$kw$function_QMARK_,true], null);
var G__23255 = callback_chan_23242;
return (handler__6145__auto__.cljs$core$IFn$_invoke$arity$3 ? handler__6145__auto__.cljs$core$IFn$_invoke$arity$3(G__23253,G__23254,G__23255) : handler__6145__auto__.call(null,G__23253,G__23254,G__23255));
})();
return (fexpr__23252.cljs$core$IFn$_invoke$arity$1 ? fexpr__23252.cljs$core$IFn$_invoke$arity$1(cb_directory_entry_23248) : fexpr__23252.call(null,cb_directory_entry_23248));
});})(callback_chan_23242))
;
var result_23243_23262 = (function (){var final_args_array_23245 = chromex.support.prepare_final_args_array(new cljs.core.PersistentVector(null, 1, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_callback_23244_23261,"callback",null], null)], null),"chrome.runtime.getPackageDirectoryEntry");
var ns_23246 = (function (){var target_obj_23256 = cljs.core.cst$kw$root.cljs$core$IFn$_invoke$arity$1(config);
var next_obj_23257 = (target_obj_23256["chrome"]);
var next_obj_23258 = (next_obj_23257["runtime"]);
return next_obj_23258;
})();
var config__6181__auto___23263 = config;
var api_check_fn__6182__auto___23264 = cljs.core.cst$kw$missing_DASH_api_DASH_check_DASH_fn.cljs$core$IFn$_invoke$arity$1(config__6181__auto___23263);

(api_check_fn__6182__auto___23264.cljs$core$IFn$_invoke$arity$3 ? api_check_fn__6182__auto___23264.cljs$core$IFn$_invoke$arity$3("chrome.runtime.getPackageDirectoryEntry",ns_23246,"getPackageDirectoryEntry") : api_check_fn__6182__auto___23264.call(null,"chrome.runtime.getPackageDirectoryEntry",ns_23246,"getPackageDirectoryEntry"));


var target_23247 = (function (){var target_obj_23259 = ns_23246;
var next_obj_23260 = (target_obj_23259["getPackageDirectoryEntry"]);
if((!((next_obj_23260 == null)))){
return next_obj_23260;
} else {
return null;
}
})();
return target_23247.apply(ns_23246,final_args_array_23245);
})();

return callback_chan_23242;
});
chromex.ext.runtime.on_startup_STAR_ = (function chromex$ext$runtime$on_startup_STAR_(var_args){
var args__4647__auto__ = [];
var len__4641__auto___23282 = arguments.length;
var i__4642__auto___23283 = (0);
while(true){
if((i__4642__auto___23283 < len__4641__auto___23282)){
args__4647__auto__.push((arguments[i__4642__auto___23283]));

var G__23284 = (i__4642__auto___23283 + (1));
i__4642__auto___23283 = G__23284;
continue;
} else {
}
break;
}

var argseq__4648__auto__ = ((((2) < args__4647__auto__.length))?(new cljs.core.IndexedSeq(args__4647__auto__.slice((2)),(0),null)):null);
return chromex.ext.runtime.on_startup_STAR_.cljs$core$IFn$_invoke$arity$variadic((arguments[(0)]),(arguments[(1)]),argseq__4648__auto__);
});

chromex.ext.runtime.on_startup_STAR_.cljs$core$IFn$_invoke$arity$variadic = (function (config,channel,args){
var event_fn_23268 = (function (){var config__6143__auto__ = config;
var handler_key__6144__auto__ = cljs.core.cst$kw$event_DASH_listener_DASH_factory;
var handler__6145__auto__ = handler_key__6144__auto__.cljs$core$IFn$_invoke$arity$1(config__6143__auto__);

var G__23274 = config__6143__auto__;
var G__23275 = cljs.core.cst$kw$chromex$ext$runtime_SLASH_on_DASH_startup;
var G__23276 = channel;
return (handler__6145__auto__.cljs$core$IFn$_invoke$arity$3 ? handler__6145__auto__.cljs$core$IFn$_invoke$arity$3(G__23274,G__23275,G__23276) : handler__6145__auto__.call(null,G__23274,G__23275,G__23276));
})();
var handler_fn_23269 = event_fn_23268;
var logging_fn_23270 = ((function (event_fn_23268,handler_fn_23269){
return (function (){

return (handler_fn_23269.cljs$core$IFn$_invoke$arity$0 ? handler_fn_23269.cljs$core$IFn$_invoke$arity$0() : handler_fn_23269.call(null));
});})(event_fn_23268,handler_fn_23269))
;
var ns_obj_23273 = (function (){var target_obj_23277 = cljs.core.cst$kw$root.cljs$core$IFn$_invoke$arity$1(config);
var next_obj_23278 = (target_obj_23277["chrome"]);
var next_obj_23279 = (next_obj_23278["runtime"]);
return next_obj_23279;
})();
var config__6181__auto___23285 = config;
var api_check_fn__6182__auto___23286 = cljs.core.cst$kw$missing_DASH_api_DASH_check_DASH_fn.cljs$core$IFn$_invoke$arity$1(config__6181__auto___23285);

(api_check_fn__6182__auto___23286.cljs$core$IFn$_invoke$arity$3 ? api_check_fn__6182__auto___23286.cljs$core$IFn$_invoke$arity$3("chrome.runtime.onStartup",ns_obj_23273,"onStartup") : api_check_fn__6182__auto___23286.call(null,"chrome.runtime.onStartup",ns_obj_23273,"onStartup"));

var event_obj_23271 = (function (){var target_obj_23280 = ns_obj_23273;
var next_obj_23281 = (target_obj_23280["onStartup"]);
return next_obj_23281;
})();
var result_23272 = chromex.chrome_event_subscription.make_chrome_event_subscription(event_obj_23271,logging_fn_23270,channel);
result_23272.chromex$protocols$chrome_event_subscription$IChromeEventSubscription$subscribe_BANG_$arity$2(null,args);

return result_23272;
});

chromex.ext.runtime.on_startup_STAR_.cljs$lang$maxFixedArity = (2);

/** @this {Function} */
chromex.ext.runtime.on_startup_STAR_.cljs$lang$applyTo = (function (seq23265){
var G__23266 = cljs.core.first(seq23265);
var seq23265__$1 = cljs.core.next(seq23265);
var G__23267 = cljs.core.first(seq23265__$1);
var seq23265__$2 = cljs.core.next(seq23265__$1);
var self__4628__auto__ = this;
return self__4628__auto__.cljs$core$IFn$_invoke$arity$variadic(G__23266,G__23267,seq23265__$2);
});

chromex.ext.runtime.on_installed_STAR_ = (function chromex$ext$runtime$on_installed_STAR_(var_args){
var args__4647__auto__ = [];
var len__4641__auto___23306 = arguments.length;
var i__4642__auto___23307 = (0);
while(true){
if((i__4642__auto___23307 < len__4641__auto___23306)){
args__4647__auto__.push((arguments[i__4642__auto___23307]));

var G__23308 = (i__4642__auto___23307 + (1));
i__4642__auto___23307 = G__23308;
continue;
} else {
}
break;
}

var argseq__4648__auto__ = ((((2) < args__4647__auto__.length))?(new cljs.core.IndexedSeq(args__4647__auto__.slice((2)),(0),null)):null);
return chromex.ext.runtime.on_installed_STAR_.cljs$core$IFn$_invoke$arity$variadic((arguments[(0)]),(arguments[(1)]),argseq__4648__auto__);
});

chromex.ext.runtime.on_installed_STAR_.cljs$core$IFn$_invoke$arity$variadic = (function (config,channel,args){
var event_fn_23290 = (function (){var config__6143__auto__ = config;
var handler_key__6144__auto__ = cljs.core.cst$kw$event_DASH_listener_DASH_factory;
var handler__6145__auto__ = handler_key__6144__auto__.cljs$core$IFn$_invoke$arity$1(config__6143__auto__);

var G__23298 = config__6143__auto__;
var G__23299 = cljs.core.cst$kw$chromex$ext$runtime_SLASH_on_DASH_installed;
var G__23300 = channel;
return (handler__6145__auto__.cljs$core$IFn$_invoke$arity$3 ? handler__6145__auto__.cljs$core$IFn$_invoke$arity$3(G__23298,G__23299,G__23300) : handler__6145__auto__.call(null,G__23298,G__23299,G__23300));
})();
var handler_fn_23291 = ((function (event_fn_23290){
return (function (cb_details_23296){
return (event_fn_23290.cljs$core$IFn$_invoke$arity$1 ? event_fn_23290.cljs$core$IFn$_invoke$arity$1(cb_details_23296) : event_fn_23290.call(null,cb_details_23296));
});})(event_fn_23290))
;
var logging_fn_23292 = ((function (event_fn_23290,handler_fn_23291){
return (function (cb_param_details_23297){

return handler_fn_23291(cb_param_details_23297);
});})(event_fn_23290,handler_fn_23291))
;
var ns_obj_23295 = (function (){var target_obj_23301 = cljs.core.cst$kw$root.cljs$core$IFn$_invoke$arity$1(config);
var next_obj_23302 = (target_obj_23301["chrome"]);
var next_obj_23303 = (next_obj_23302["runtime"]);
return next_obj_23303;
})();
var config__6181__auto___23309 = config;
var api_check_fn__6182__auto___23310 = cljs.core.cst$kw$missing_DASH_api_DASH_check_DASH_fn.cljs$core$IFn$_invoke$arity$1(config__6181__auto___23309);

(api_check_fn__6182__auto___23310.cljs$core$IFn$_invoke$arity$3 ? api_check_fn__6182__auto___23310.cljs$core$IFn$_invoke$arity$3("chrome.runtime.onInstalled",ns_obj_23295,"onInstalled") : api_check_fn__6182__auto___23310.call(null,"chrome.runtime.onInstalled",ns_obj_23295,"onInstalled"));

var event_obj_23293 = (function (){var target_obj_23304 = ns_obj_23295;
var next_obj_23305 = (target_obj_23304["onInstalled"]);
return next_obj_23305;
})();
var result_23294 = chromex.chrome_event_subscription.make_chrome_event_subscription(event_obj_23293,logging_fn_23292,channel);
result_23294.chromex$protocols$chrome_event_subscription$IChromeEventSubscription$subscribe_BANG_$arity$2(null,args);

return result_23294;
});

chromex.ext.runtime.on_installed_STAR_.cljs$lang$maxFixedArity = (2);

/** @this {Function} */
chromex.ext.runtime.on_installed_STAR_.cljs$lang$applyTo = (function (seq23287){
var G__23288 = cljs.core.first(seq23287);
var seq23287__$1 = cljs.core.next(seq23287);
var G__23289 = cljs.core.first(seq23287__$1);
var seq23287__$2 = cljs.core.next(seq23287__$1);
var self__4628__auto__ = this;
return self__4628__auto__.cljs$core$IFn$_invoke$arity$variadic(G__23288,G__23289,seq23287__$2);
});

chromex.ext.runtime.on_suspend_STAR_ = (function chromex$ext$runtime$on_suspend_STAR_(var_args){
var args__4647__auto__ = [];
var len__4641__auto___23328 = arguments.length;
var i__4642__auto___23329 = (0);
while(true){
if((i__4642__auto___23329 < len__4641__auto___23328)){
args__4647__auto__.push((arguments[i__4642__auto___23329]));

var G__23330 = (i__4642__auto___23329 + (1));
i__4642__auto___23329 = G__23330;
continue;
} else {
}
break;
}

var argseq__4648__auto__ = ((((2) < args__4647__auto__.length))?(new cljs.core.IndexedSeq(args__4647__auto__.slice((2)),(0),null)):null);
return chromex.ext.runtime.on_suspend_STAR_.cljs$core$IFn$_invoke$arity$variadic((arguments[(0)]),(arguments[(1)]),argseq__4648__auto__);
});

chromex.ext.runtime.on_suspend_STAR_.cljs$core$IFn$_invoke$arity$variadic = (function (config,channel,args){
var event_fn_23314 = (function (){var config__6143__auto__ = config;
var handler_key__6144__auto__ = cljs.core.cst$kw$event_DASH_listener_DASH_factory;
var handler__6145__auto__ = handler_key__6144__auto__.cljs$core$IFn$_invoke$arity$1(config__6143__auto__);

var G__23320 = config__6143__auto__;
var G__23321 = cljs.core.cst$kw$chromex$ext$runtime_SLASH_on_DASH_suspend;
var G__23322 = channel;
return (handler__6145__auto__.cljs$core$IFn$_invoke$arity$3 ? handler__6145__auto__.cljs$core$IFn$_invoke$arity$3(G__23320,G__23321,G__23322) : handler__6145__auto__.call(null,G__23320,G__23321,G__23322));
})();
var handler_fn_23315 = event_fn_23314;
var logging_fn_23316 = ((function (event_fn_23314,handler_fn_23315){
return (function (){

return (handler_fn_23315.cljs$core$IFn$_invoke$arity$0 ? handler_fn_23315.cljs$core$IFn$_invoke$arity$0() : handler_fn_23315.call(null));
});})(event_fn_23314,handler_fn_23315))
;
var ns_obj_23319 = (function (){var target_obj_23323 = cljs.core.cst$kw$root.cljs$core$IFn$_invoke$arity$1(config);
var next_obj_23324 = (target_obj_23323["chrome"]);
var next_obj_23325 = (next_obj_23324["runtime"]);
return next_obj_23325;
})();
var config__6181__auto___23331 = config;
var api_check_fn__6182__auto___23332 = cljs.core.cst$kw$missing_DASH_api_DASH_check_DASH_fn.cljs$core$IFn$_invoke$arity$1(config__6181__auto___23331);

(api_check_fn__6182__auto___23332.cljs$core$IFn$_invoke$arity$3 ? api_check_fn__6182__auto___23332.cljs$core$IFn$_invoke$arity$3("chrome.runtime.onSuspend",ns_obj_23319,"onSuspend") : api_check_fn__6182__auto___23332.call(null,"chrome.runtime.onSuspend",ns_obj_23319,"onSuspend"));

var event_obj_23317 = (function (){var target_obj_23326 = ns_obj_23319;
var next_obj_23327 = (target_obj_23326["onSuspend"]);
return next_obj_23327;
})();
var result_23318 = chromex.chrome_event_subscription.make_chrome_event_subscription(event_obj_23317,logging_fn_23316,channel);
result_23318.chromex$protocols$chrome_event_subscription$IChromeEventSubscription$subscribe_BANG_$arity$2(null,args);

return result_23318;
});

chromex.ext.runtime.on_suspend_STAR_.cljs$lang$maxFixedArity = (2);

/** @this {Function} */
chromex.ext.runtime.on_suspend_STAR_.cljs$lang$applyTo = (function (seq23311){
var G__23312 = cljs.core.first(seq23311);
var seq23311__$1 = cljs.core.next(seq23311);
var G__23313 = cljs.core.first(seq23311__$1);
var seq23311__$2 = cljs.core.next(seq23311__$1);
var self__4628__auto__ = this;
return self__4628__auto__.cljs$core$IFn$_invoke$arity$variadic(G__23312,G__23313,seq23311__$2);
});

chromex.ext.runtime.on_suspend_canceled_STAR_ = (function chromex$ext$runtime$on_suspend_canceled_STAR_(var_args){
var args__4647__auto__ = [];
var len__4641__auto___23350 = arguments.length;
var i__4642__auto___23351 = (0);
while(true){
if((i__4642__auto___23351 < len__4641__auto___23350)){
args__4647__auto__.push((arguments[i__4642__auto___23351]));

var G__23352 = (i__4642__auto___23351 + (1));
i__4642__auto___23351 = G__23352;
continue;
} else {
}
break;
}

var argseq__4648__auto__ = ((((2) < args__4647__auto__.length))?(new cljs.core.IndexedSeq(args__4647__auto__.slice((2)),(0),null)):null);
return chromex.ext.runtime.on_suspend_canceled_STAR_.cljs$core$IFn$_invoke$arity$variadic((arguments[(0)]),(arguments[(1)]),argseq__4648__auto__);
});

chromex.ext.runtime.on_suspend_canceled_STAR_.cljs$core$IFn$_invoke$arity$variadic = (function (config,channel,args){
var event_fn_23336 = (function (){var config__6143__auto__ = config;
var handler_key__6144__auto__ = cljs.core.cst$kw$event_DASH_listener_DASH_factory;
var handler__6145__auto__ = handler_key__6144__auto__.cljs$core$IFn$_invoke$arity$1(config__6143__auto__);

var G__23342 = config__6143__auto__;
var G__23343 = cljs.core.cst$kw$chromex$ext$runtime_SLASH_on_DASH_suspend_DASH_canceled;
var G__23344 = channel;
return (handler__6145__auto__.cljs$core$IFn$_invoke$arity$3 ? handler__6145__auto__.cljs$core$IFn$_invoke$arity$3(G__23342,G__23343,G__23344) : handler__6145__auto__.call(null,G__23342,G__23343,G__23344));
})();
var handler_fn_23337 = event_fn_23336;
var logging_fn_23338 = ((function (event_fn_23336,handler_fn_23337){
return (function (){

return (handler_fn_23337.cljs$core$IFn$_invoke$arity$0 ? handler_fn_23337.cljs$core$IFn$_invoke$arity$0() : handler_fn_23337.call(null));
});})(event_fn_23336,handler_fn_23337))
;
var ns_obj_23341 = (function (){var target_obj_23345 = cljs.core.cst$kw$root.cljs$core$IFn$_invoke$arity$1(config);
var next_obj_23346 = (target_obj_23345["chrome"]);
var next_obj_23347 = (next_obj_23346["runtime"]);
return next_obj_23347;
})();
var config__6181__auto___23353 = config;
var api_check_fn__6182__auto___23354 = cljs.core.cst$kw$missing_DASH_api_DASH_check_DASH_fn.cljs$core$IFn$_invoke$arity$1(config__6181__auto___23353);

(api_check_fn__6182__auto___23354.cljs$core$IFn$_invoke$arity$3 ? api_check_fn__6182__auto___23354.cljs$core$IFn$_invoke$arity$3("chrome.runtime.onSuspendCanceled",ns_obj_23341,"onSuspendCanceled") : api_check_fn__6182__auto___23354.call(null,"chrome.runtime.onSuspendCanceled",ns_obj_23341,"onSuspendCanceled"));

var event_obj_23339 = (function (){var target_obj_23348 = ns_obj_23341;
var next_obj_23349 = (target_obj_23348["onSuspendCanceled"]);
return next_obj_23349;
})();
var result_23340 = chromex.chrome_event_subscription.make_chrome_event_subscription(event_obj_23339,logging_fn_23338,channel);
result_23340.chromex$protocols$chrome_event_subscription$IChromeEventSubscription$subscribe_BANG_$arity$2(null,args);

return result_23340;
});

chromex.ext.runtime.on_suspend_canceled_STAR_.cljs$lang$maxFixedArity = (2);

/** @this {Function} */
chromex.ext.runtime.on_suspend_canceled_STAR_.cljs$lang$applyTo = (function (seq23333){
var G__23334 = cljs.core.first(seq23333);
var seq23333__$1 = cljs.core.next(seq23333);
var G__23335 = cljs.core.first(seq23333__$1);
var seq23333__$2 = cljs.core.next(seq23333__$1);
var self__4628__auto__ = this;
return self__4628__auto__.cljs$core$IFn$_invoke$arity$variadic(G__23334,G__23335,seq23333__$2);
});

chromex.ext.runtime.on_update_available_STAR_ = (function chromex$ext$runtime$on_update_available_STAR_(var_args){
var args__4647__auto__ = [];
var len__4641__auto___23374 = arguments.length;
var i__4642__auto___23375 = (0);
while(true){
if((i__4642__auto___23375 < len__4641__auto___23374)){
args__4647__auto__.push((arguments[i__4642__auto___23375]));

var G__23376 = (i__4642__auto___23375 + (1));
i__4642__auto___23375 = G__23376;
continue;
} else {
}
break;
}

var argseq__4648__auto__ = ((((2) < args__4647__auto__.length))?(new cljs.core.IndexedSeq(args__4647__auto__.slice((2)),(0),null)):null);
return chromex.ext.runtime.on_update_available_STAR_.cljs$core$IFn$_invoke$arity$variadic((arguments[(0)]),(arguments[(1)]),argseq__4648__auto__);
});

chromex.ext.runtime.on_update_available_STAR_.cljs$core$IFn$_invoke$arity$variadic = (function (config,channel,args){
var event_fn_23358 = (function (){var config__6143__auto__ = config;
var handler_key__6144__auto__ = cljs.core.cst$kw$event_DASH_listener_DASH_factory;
var handler__6145__auto__ = handler_key__6144__auto__.cljs$core$IFn$_invoke$arity$1(config__6143__auto__);

var G__23366 = config__6143__auto__;
var G__23367 = cljs.core.cst$kw$chromex$ext$runtime_SLASH_on_DASH_update_DASH_available;
var G__23368 = channel;
return (handler__6145__auto__.cljs$core$IFn$_invoke$arity$3 ? handler__6145__auto__.cljs$core$IFn$_invoke$arity$3(G__23366,G__23367,G__23368) : handler__6145__auto__.call(null,G__23366,G__23367,G__23368));
})();
var handler_fn_23359 = ((function (event_fn_23358){
return (function (cb_details_23364){
return (event_fn_23358.cljs$core$IFn$_invoke$arity$1 ? event_fn_23358.cljs$core$IFn$_invoke$arity$1(cb_details_23364) : event_fn_23358.call(null,cb_details_23364));
});})(event_fn_23358))
;
var logging_fn_23360 = ((function (event_fn_23358,handler_fn_23359){
return (function (cb_param_details_23365){

return handler_fn_23359(cb_param_details_23365);
});})(event_fn_23358,handler_fn_23359))
;
var ns_obj_23363 = (function (){var target_obj_23369 = cljs.core.cst$kw$root.cljs$core$IFn$_invoke$arity$1(config);
var next_obj_23370 = (target_obj_23369["chrome"]);
var next_obj_23371 = (next_obj_23370["runtime"]);
return next_obj_23371;
})();
var config__6181__auto___23377 = config;
var api_check_fn__6182__auto___23378 = cljs.core.cst$kw$missing_DASH_api_DASH_check_DASH_fn.cljs$core$IFn$_invoke$arity$1(config__6181__auto___23377);

(api_check_fn__6182__auto___23378.cljs$core$IFn$_invoke$arity$3 ? api_check_fn__6182__auto___23378.cljs$core$IFn$_invoke$arity$3("chrome.runtime.onUpdateAvailable",ns_obj_23363,"onUpdateAvailable") : api_check_fn__6182__auto___23378.call(null,"chrome.runtime.onUpdateAvailable",ns_obj_23363,"onUpdateAvailable"));

var event_obj_23361 = (function (){var target_obj_23372 = ns_obj_23363;
var next_obj_23373 = (target_obj_23372["onUpdateAvailable"]);
return next_obj_23373;
})();
var result_23362 = chromex.chrome_event_subscription.make_chrome_event_subscription(event_obj_23361,logging_fn_23360,channel);
result_23362.chromex$protocols$chrome_event_subscription$IChromeEventSubscription$subscribe_BANG_$arity$2(null,args);

return result_23362;
});

chromex.ext.runtime.on_update_available_STAR_.cljs$lang$maxFixedArity = (2);

/** @this {Function} */
chromex.ext.runtime.on_update_available_STAR_.cljs$lang$applyTo = (function (seq23355){
var G__23356 = cljs.core.first(seq23355);
var seq23355__$1 = cljs.core.next(seq23355);
var G__23357 = cljs.core.first(seq23355__$1);
var seq23355__$2 = cljs.core.next(seq23355__$1);
var self__4628__auto__ = this;
return self__4628__auto__.cljs$core$IFn$_invoke$arity$variadic(G__23356,G__23357,seq23355__$2);
});

chromex.ext.runtime.on_browser_update_available_STAR_ = (function chromex$ext$runtime$on_browser_update_available_STAR_(var_args){
var args__4647__auto__ = [];
var len__4641__auto___23396 = arguments.length;
var i__4642__auto___23397 = (0);
while(true){
if((i__4642__auto___23397 < len__4641__auto___23396)){
args__4647__auto__.push((arguments[i__4642__auto___23397]));

var G__23398 = (i__4642__auto___23397 + (1));
i__4642__auto___23397 = G__23398;
continue;
} else {
}
break;
}

var argseq__4648__auto__ = ((((2) < args__4647__auto__.length))?(new cljs.core.IndexedSeq(args__4647__auto__.slice((2)),(0),null)):null);
return chromex.ext.runtime.on_browser_update_available_STAR_.cljs$core$IFn$_invoke$arity$variadic((arguments[(0)]),(arguments[(1)]),argseq__4648__auto__);
});

chromex.ext.runtime.on_browser_update_available_STAR_.cljs$core$IFn$_invoke$arity$variadic = (function (config,channel,args){
var event_fn_23382 = (function (){var config__6143__auto__ = config;
var handler_key__6144__auto__ = cljs.core.cst$kw$event_DASH_listener_DASH_factory;
var handler__6145__auto__ = handler_key__6144__auto__.cljs$core$IFn$_invoke$arity$1(config__6143__auto__);

var G__23388 = config__6143__auto__;
var G__23389 = cljs.core.cst$kw$chromex$ext$runtime_SLASH_on_DASH_browser_DASH_update_DASH_available;
var G__23390 = channel;
return (handler__6145__auto__.cljs$core$IFn$_invoke$arity$3 ? handler__6145__auto__.cljs$core$IFn$_invoke$arity$3(G__23388,G__23389,G__23390) : handler__6145__auto__.call(null,G__23388,G__23389,G__23390));
})();
var handler_fn_23383 = event_fn_23382;
var logging_fn_23384 = ((function (event_fn_23382,handler_fn_23383){
return (function (){

return (handler_fn_23383.cljs$core$IFn$_invoke$arity$0 ? handler_fn_23383.cljs$core$IFn$_invoke$arity$0() : handler_fn_23383.call(null));
});})(event_fn_23382,handler_fn_23383))
;
var ns_obj_23387 = (function (){var target_obj_23391 = cljs.core.cst$kw$root.cljs$core$IFn$_invoke$arity$1(config);
var next_obj_23392 = (target_obj_23391["chrome"]);
var next_obj_23393 = (next_obj_23392["runtime"]);
return next_obj_23393;
})();
var config__6181__auto___23399 = config;
var api_check_fn__6182__auto___23400 = cljs.core.cst$kw$missing_DASH_api_DASH_check_DASH_fn.cljs$core$IFn$_invoke$arity$1(config__6181__auto___23399);

(api_check_fn__6182__auto___23400.cljs$core$IFn$_invoke$arity$3 ? api_check_fn__6182__auto___23400.cljs$core$IFn$_invoke$arity$3("chrome.runtime.onBrowserUpdateAvailable",ns_obj_23387,"onBrowserUpdateAvailable") : api_check_fn__6182__auto___23400.call(null,"chrome.runtime.onBrowserUpdateAvailable",ns_obj_23387,"onBrowserUpdateAvailable"));

var event_obj_23385 = (function (){var target_obj_23394 = ns_obj_23387;
var next_obj_23395 = (target_obj_23394["onBrowserUpdateAvailable"]);
return next_obj_23395;
})();
var result_23386 = chromex.chrome_event_subscription.make_chrome_event_subscription(event_obj_23385,logging_fn_23384,channel);
result_23386.chromex$protocols$chrome_event_subscription$IChromeEventSubscription$subscribe_BANG_$arity$2(null,args);

return result_23386;
});

chromex.ext.runtime.on_browser_update_available_STAR_.cljs$lang$maxFixedArity = (2);

/** @this {Function} */
chromex.ext.runtime.on_browser_update_available_STAR_.cljs$lang$applyTo = (function (seq23379){
var G__23380 = cljs.core.first(seq23379);
var seq23379__$1 = cljs.core.next(seq23379);
var G__23381 = cljs.core.first(seq23379__$1);
var seq23379__$2 = cljs.core.next(seq23379__$1);
var self__4628__auto__ = this;
return self__4628__auto__.cljs$core$IFn$_invoke$arity$variadic(G__23380,G__23381,seq23379__$2);
});

chromex.ext.runtime.on_connect_STAR_ = (function chromex$ext$runtime$on_connect_STAR_(var_args){
var args__4647__auto__ = [];
var len__4641__auto___23421 = arguments.length;
var i__4642__auto___23422 = (0);
while(true){
if((i__4642__auto___23422 < len__4641__auto___23421)){
args__4647__auto__.push((arguments[i__4642__auto___23422]));

var G__23423 = (i__4642__auto___23422 + (1));
i__4642__auto___23422 = G__23423;
continue;
} else {
}
break;
}

var argseq__4648__auto__ = ((((2) < args__4647__auto__.length))?(new cljs.core.IndexedSeq(args__4647__auto__.slice((2)),(0),null)):null);
return chromex.ext.runtime.on_connect_STAR_.cljs$core$IFn$_invoke$arity$variadic((arguments[(0)]),(arguments[(1)]),argseq__4648__auto__);
});

chromex.ext.runtime.on_connect_STAR_.cljs$core$IFn$_invoke$arity$variadic = (function (config,channel,args){
var event_fn_23404 = (function (){var config__6143__auto__ = config;
var handler_key__6144__auto__ = cljs.core.cst$kw$event_DASH_listener_DASH_factory;
var handler__6145__auto__ = handler_key__6144__auto__.cljs$core$IFn$_invoke$arity$1(config__6143__auto__);

var G__23412 = config__6143__auto__;
var G__23413 = cljs.core.cst$kw$chromex$ext$runtime_SLASH_on_DASH_connect;
var G__23414 = channel;
return (handler__6145__auto__.cljs$core$IFn$_invoke$arity$3 ? handler__6145__auto__.cljs$core$IFn$_invoke$arity$3(G__23412,G__23413,G__23414) : handler__6145__auto__.call(null,G__23412,G__23413,G__23414));
})();
var handler_fn_23405 = ((function (event_fn_23404){
return (function (cb_port_23410){
var G__23415 = chromex.marshalling.from_native_chrome_port(config,cb_port_23410);
return (event_fn_23404.cljs$core$IFn$_invoke$arity$1 ? event_fn_23404.cljs$core$IFn$_invoke$arity$1(G__23415) : event_fn_23404.call(null,G__23415));
});})(event_fn_23404))
;
var logging_fn_23406 = ((function (event_fn_23404,handler_fn_23405){
return (function (cb_param_port_23411){

return handler_fn_23405(cb_param_port_23411);
});})(event_fn_23404,handler_fn_23405))
;
var ns_obj_23409 = (function (){var target_obj_23416 = cljs.core.cst$kw$root.cljs$core$IFn$_invoke$arity$1(config);
var next_obj_23417 = (target_obj_23416["chrome"]);
var next_obj_23418 = (next_obj_23417["runtime"]);
return next_obj_23418;
})();
var config__6181__auto___23424 = config;
var api_check_fn__6182__auto___23425 = cljs.core.cst$kw$missing_DASH_api_DASH_check_DASH_fn.cljs$core$IFn$_invoke$arity$1(config__6181__auto___23424);

(api_check_fn__6182__auto___23425.cljs$core$IFn$_invoke$arity$3 ? api_check_fn__6182__auto___23425.cljs$core$IFn$_invoke$arity$3("chrome.runtime.onConnect",ns_obj_23409,"onConnect") : api_check_fn__6182__auto___23425.call(null,"chrome.runtime.onConnect",ns_obj_23409,"onConnect"));

var event_obj_23407 = (function (){var target_obj_23419 = ns_obj_23409;
var next_obj_23420 = (target_obj_23419["onConnect"]);
return next_obj_23420;
})();
var result_23408 = chromex.chrome_event_subscription.make_chrome_event_subscription(event_obj_23407,logging_fn_23406,channel);
result_23408.chromex$protocols$chrome_event_subscription$IChromeEventSubscription$subscribe_BANG_$arity$2(null,args);

return result_23408;
});

chromex.ext.runtime.on_connect_STAR_.cljs$lang$maxFixedArity = (2);

/** @this {Function} */
chromex.ext.runtime.on_connect_STAR_.cljs$lang$applyTo = (function (seq23401){
var G__23402 = cljs.core.first(seq23401);
var seq23401__$1 = cljs.core.next(seq23401);
var G__23403 = cljs.core.first(seq23401__$1);
var seq23401__$2 = cljs.core.next(seq23401__$1);
var self__4628__auto__ = this;
return self__4628__auto__.cljs$core$IFn$_invoke$arity$variadic(G__23402,G__23403,seq23401__$2);
});

chromex.ext.runtime.on_connect_external_STAR_ = (function chromex$ext$runtime$on_connect_external_STAR_(var_args){
var args__4647__auto__ = [];
var len__4641__auto___23446 = arguments.length;
var i__4642__auto___23447 = (0);
while(true){
if((i__4642__auto___23447 < len__4641__auto___23446)){
args__4647__auto__.push((arguments[i__4642__auto___23447]));

var G__23448 = (i__4642__auto___23447 + (1));
i__4642__auto___23447 = G__23448;
continue;
} else {
}
break;
}

var argseq__4648__auto__ = ((((2) < args__4647__auto__.length))?(new cljs.core.IndexedSeq(args__4647__auto__.slice((2)),(0),null)):null);
return chromex.ext.runtime.on_connect_external_STAR_.cljs$core$IFn$_invoke$arity$variadic((arguments[(0)]),(arguments[(1)]),argseq__4648__auto__);
});

chromex.ext.runtime.on_connect_external_STAR_.cljs$core$IFn$_invoke$arity$variadic = (function (config,channel,args){
var event_fn_23429 = (function (){var config__6143__auto__ = config;
var handler_key__6144__auto__ = cljs.core.cst$kw$event_DASH_listener_DASH_factory;
var handler__6145__auto__ = handler_key__6144__auto__.cljs$core$IFn$_invoke$arity$1(config__6143__auto__);

var G__23437 = config__6143__auto__;
var G__23438 = cljs.core.cst$kw$chromex$ext$runtime_SLASH_on_DASH_connect_DASH_external;
var G__23439 = channel;
return (handler__6145__auto__.cljs$core$IFn$_invoke$arity$3 ? handler__6145__auto__.cljs$core$IFn$_invoke$arity$3(G__23437,G__23438,G__23439) : handler__6145__auto__.call(null,G__23437,G__23438,G__23439));
})();
var handler_fn_23430 = ((function (event_fn_23429){
return (function (cb_port_23435){
var G__23440 = chromex.marshalling.from_native_chrome_port(config,cb_port_23435);
return (event_fn_23429.cljs$core$IFn$_invoke$arity$1 ? event_fn_23429.cljs$core$IFn$_invoke$arity$1(G__23440) : event_fn_23429.call(null,G__23440));
});})(event_fn_23429))
;
var logging_fn_23431 = ((function (event_fn_23429,handler_fn_23430){
return (function (cb_param_port_23436){

return handler_fn_23430(cb_param_port_23436);
});})(event_fn_23429,handler_fn_23430))
;
var ns_obj_23434 = (function (){var target_obj_23441 = cljs.core.cst$kw$root.cljs$core$IFn$_invoke$arity$1(config);
var next_obj_23442 = (target_obj_23441["chrome"]);
var next_obj_23443 = (next_obj_23442["runtime"]);
return next_obj_23443;
})();
var config__6181__auto___23449 = config;
var api_check_fn__6182__auto___23450 = cljs.core.cst$kw$missing_DASH_api_DASH_check_DASH_fn.cljs$core$IFn$_invoke$arity$1(config__6181__auto___23449);

(api_check_fn__6182__auto___23450.cljs$core$IFn$_invoke$arity$3 ? api_check_fn__6182__auto___23450.cljs$core$IFn$_invoke$arity$3("chrome.runtime.onConnectExternal",ns_obj_23434,"onConnectExternal") : api_check_fn__6182__auto___23450.call(null,"chrome.runtime.onConnectExternal",ns_obj_23434,"onConnectExternal"));

var event_obj_23432 = (function (){var target_obj_23444 = ns_obj_23434;
var next_obj_23445 = (target_obj_23444["onConnectExternal"]);
return next_obj_23445;
})();
var result_23433 = chromex.chrome_event_subscription.make_chrome_event_subscription(event_obj_23432,logging_fn_23431,channel);
result_23433.chromex$protocols$chrome_event_subscription$IChromeEventSubscription$subscribe_BANG_$arity$2(null,args);

return result_23433;
});

chromex.ext.runtime.on_connect_external_STAR_.cljs$lang$maxFixedArity = (2);

/** @this {Function} */
chromex.ext.runtime.on_connect_external_STAR_.cljs$lang$applyTo = (function (seq23426){
var G__23427 = cljs.core.first(seq23426);
var seq23426__$1 = cljs.core.next(seq23426);
var G__23428 = cljs.core.first(seq23426__$1);
var seq23426__$2 = cljs.core.next(seq23426__$1);
var self__4628__auto__ = this;
return self__4628__auto__.cljs$core$IFn$_invoke$arity$variadic(G__23427,G__23428,seq23426__$2);
});

chromex.ext.runtime.on_message_STAR_ = (function chromex$ext$runtime$on_message_STAR_(var_args){
var args__4647__auto__ = [];
var len__4641__auto___23474 = arguments.length;
var i__4642__auto___23475 = (0);
while(true){
if((i__4642__auto___23475 < len__4641__auto___23474)){
args__4647__auto__.push((arguments[i__4642__auto___23475]));

var G__23476 = (i__4642__auto___23475 + (1));
i__4642__auto___23475 = G__23476;
continue;
} else {
}
break;
}

var argseq__4648__auto__ = ((((2) < args__4647__auto__.length))?(new cljs.core.IndexedSeq(args__4647__auto__.slice((2)),(0),null)):null);
return chromex.ext.runtime.on_message_STAR_.cljs$core$IFn$_invoke$arity$variadic((arguments[(0)]),(arguments[(1)]),argseq__4648__auto__);
});

chromex.ext.runtime.on_message_STAR_.cljs$core$IFn$_invoke$arity$variadic = (function (config,channel,args){
var event_fn_23454 = (function (){var config__6143__auto__ = config;
var handler_key__6144__auto__ = cljs.core.cst$kw$event_DASH_listener_DASH_factory;
var handler__6145__auto__ = handler_key__6144__auto__.cljs$core$IFn$_invoke$arity$1(config__6143__auto__);

var G__23466 = config__6143__auto__;
var G__23467 = cljs.core.cst$kw$chromex$ext$runtime_SLASH_on_DASH_message;
var G__23468 = channel;
return (handler__6145__auto__.cljs$core$IFn$_invoke$arity$3 ? handler__6145__auto__.cljs$core$IFn$_invoke$arity$3(G__23466,G__23467,G__23468) : handler__6145__auto__.call(null,G__23466,G__23467,G__23468));
})();
var handler_fn_23455 = ((function (event_fn_23454){
return (function (cb_message_23460,cb_sender_23461,cb_send_response_23462){
return (event_fn_23454.cljs$core$IFn$_invoke$arity$3 ? event_fn_23454.cljs$core$IFn$_invoke$arity$3(cb_message_23460,cb_sender_23461,cb_send_response_23462) : event_fn_23454.call(null,cb_message_23460,cb_sender_23461,cb_send_response_23462));
});})(event_fn_23454))
;
var logging_fn_23456 = ((function (event_fn_23454,handler_fn_23455){
return (function (cb_param_message_23463,cb_param_sender_23464,cb_param_send_response_23465){

return handler_fn_23455(cb_param_message_23463,cb_param_sender_23464,cb_param_send_response_23465);
});})(event_fn_23454,handler_fn_23455))
;
var ns_obj_23459 = (function (){var target_obj_23469 = cljs.core.cst$kw$root.cljs$core$IFn$_invoke$arity$1(config);
var next_obj_23470 = (target_obj_23469["chrome"]);
var next_obj_23471 = (next_obj_23470["runtime"]);
return next_obj_23471;
})();
var config__6181__auto___23477 = config;
var api_check_fn__6182__auto___23478 = cljs.core.cst$kw$missing_DASH_api_DASH_check_DASH_fn.cljs$core$IFn$_invoke$arity$1(config__6181__auto___23477);

(api_check_fn__6182__auto___23478.cljs$core$IFn$_invoke$arity$3 ? api_check_fn__6182__auto___23478.cljs$core$IFn$_invoke$arity$3("chrome.runtime.onMessage",ns_obj_23459,"onMessage") : api_check_fn__6182__auto___23478.call(null,"chrome.runtime.onMessage",ns_obj_23459,"onMessage"));

var event_obj_23457 = (function (){var target_obj_23472 = ns_obj_23459;
var next_obj_23473 = (target_obj_23472["onMessage"]);
return next_obj_23473;
})();
var result_23458 = chromex.chrome_event_subscription.make_chrome_event_subscription(event_obj_23457,logging_fn_23456,channel);
result_23458.chromex$protocols$chrome_event_subscription$IChromeEventSubscription$subscribe_BANG_$arity$2(null,args);

return result_23458;
});

chromex.ext.runtime.on_message_STAR_.cljs$lang$maxFixedArity = (2);

/** @this {Function} */
chromex.ext.runtime.on_message_STAR_.cljs$lang$applyTo = (function (seq23451){
var G__23452 = cljs.core.first(seq23451);
var seq23451__$1 = cljs.core.next(seq23451);
var G__23453 = cljs.core.first(seq23451__$1);
var seq23451__$2 = cljs.core.next(seq23451__$1);
var self__4628__auto__ = this;
return self__4628__auto__.cljs$core$IFn$_invoke$arity$variadic(G__23452,G__23453,seq23451__$2);
});

chromex.ext.runtime.on_message_external_STAR_ = (function chromex$ext$runtime$on_message_external_STAR_(var_args){
var args__4647__auto__ = [];
var len__4641__auto___23502 = arguments.length;
var i__4642__auto___23503 = (0);
while(true){
if((i__4642__auto___23503 < len__4641__auto___23502)){
args__4647__auto__.push((arguments[i__4642__auto___23503]));

var G__23504 = (i__4642__auto___23503 + (1));
i__4642__auto___23503 = G__23504;
continue;
} else {
}
break;
}

var argseq__4648__auto__ = ((((2) < args__4647__auto__.length))?(new cljs.core.IndexedSeq(args__4647__auto__.slice((2)),(0),null)):null);
return chromex.ext.runtime.on_message_external_STAR_.cljs$core$IFn$_invoke$arity$variadic((arguments[(0)]),(arguments[(1)]),argseq__4648__auto__);
});

chromex.ext.runtime.on_message_external_STAR_.cljs$core$IFn$_invoke$arity$variadic = (function (config,channel,args){
var event_fn_23482 = (function (){var config__6143__auto__ = config;
var handler_key__6144__auto__ = cljs.core.cst$kw$event_DASH_listener_DASH_factory;
var handler__6145__auto__ = handler_key__6144__auto__.cljs$core$IFn$_invoke$arity$1(config__6143__auto__);

var G__23494 = config__6143__auto__;
var G__23495 = cljs.core.cst$kw$chromex$ext$runtime_SLASH_on_DASH_message_DASH_external;
var G__23496 = channel;
return (handler__6145__auto__.cljs$core$IFn$_invoke$arity$3 ? handler__6145__auto__.cljs$core$IFn$_invoke$arity$3(G__23494,G__23495,G__23496) : handler__6145__auto__.call(null,G__23494,G__23495,G__23496));
})();
var handler_fn_23483 = ((function (event_fn_23482){
return (function (cb_message_23488,cb_sender_23489,cb_send_response_23490){
return (event_fn_23482.cljs$core$IFn$_invoke$arity$3 ? event_fn_23482.cljs$core$IFn$_invoke$arity$3(cb_message_23488,cb_sender_23489,cb_send_response_23490) : event_fn_23482.call(null,cb_message_23488,cb_sender_23489,cb_send_response_23490));
});})(event_fn_23482))
;
var logging_fn_23484 = ((function (event_fn_23482,handler_fn_23483){
return (function (cb_param_message_23491,cb_param_sender_23492,cb_param_send_response_23493){

return handler_fn_23483(cb_param_message_23491,cb_param_sender_23492,cb_param_send_response_23493);
});})(event_fn_23482,handler_fn_23483))
;
var ns_obj_23487 = (function (){var target_obj_23497 = cljs.core.cst$kw$root.cljs$core$IFn$_invoke$arity$1(config);
var next_obj_23498 = (target_obj_23497["chrome"]);
var next_obj_23499 = (next_obj_23498["runtime"]);
return next_obj_23499;
})();
var config__6181__auto___23505 = config;
var api_check_fn__6182__auto___23506 = cljs.core.cst$kw$missing_DASH_api_DASH_check_DASH_fn.cljs$core$IFn$_invoke$arity$1(config__6181__auto___23505);

(api_check_fn__6182__auto___23506.cljs$core$IFn$_invoke$arity$3 ? api_check_fn__6182__auto___23506.cljs$core$IFn$_invoke$arity$3("chrome.runtime.onMessageExternal",ns_obj_23487,"onMessageExternal") : api_check_fn__6182__auto___23506.call(null,"chrome.runtime.onMessageExternal",ns_obj_23487,"onMessageExternal"));

var event_obj_23485 = (function (){var target_obj_23500 = ns_obj_23487;
var next_obj_23501 = (target_obj_23500["onMessageExternal"]);
return next_obj_23501;
})();
var result_23486 = chromex.chrome_event_subscription.make_chrome_event_subscription(event_obj_23485,logging_fn_23484,channel);
result_23486.chromex$protocols$chrome_event_subscription$IChromeEventSubscription$subscribe_BANG_$arity$2(null,args);

return result_23486;
});

chromex.ext.runtime.on_message_external_STAR_.cljs$lang$maxFixedArity = (2);

/** @this {Function} */
chromex.ext.runtime.on_message_external_STAR_.cljs$lang$applyTo = (function (seq23479){
var G__23480 = cljs.core.first(seq23479);
var seq23479__$1 = cljs.core.next(seq23479);
var G__23481 = cljs.core.first(seq23479__$1);
var seq23479__$2 = cljs.core.next(seq23479__$1);
var self__4628__auto__ = this;
return self__4628__auto__.cljs$core$IFn$_invoke$arity$variadic(G__23480,G__23481,seq23479__$2);
});

chromex.ext.runtime.on_restart_required_STAR_ = (function chromex$ext$runtime$on_restart_required_STAR_(var_args){
var args__4647__auto__ = [];
var len__4641__auto___23526 = arguments.length;
var i__4642__auto___23527 = (0);
while(true){
if((i__4642__auto___23527 < len__4641__auto___23526)){
args__4647__auto__.push((arguments[i__4642__auto___23527]));

var G__23528 = (i__4642__auto___23527 + (1));
i__4642__auto___23527 = G__23528;
continue;
} else {
}
break;
}

var argseq__4648__auto__ = ((((2) < args__4647__auto__.length))?(new cljs.core.IndexedSeq(args__4647__auto__.slice((2)),(0),null)):null);
return chromex.ext.runtime.on_restart_required_STAR_.cljs$core$IFn$_invoke$arity$variadic((arguments[(0)]),(arguments[(1)]),argseq__4648__auto__);
});

chromex.ext.runtime.on_restart_required_STAR_.cljs$core$IFn$_invoke$arity$variadic = (function (config,channel,args){
var event_fn_23510 = (function (){var config__6143__auto__ = config;
var handler_key__6144__auto__ = cljs.core.cst$kw$event_DASH_listener_DASH_factory;
var handler__6145__auto__ = handler_key__6144__auto__.cljs$core$IFn$_invoke$arity$1(config__6143__auto__);

var G__23518 = config__6143__auto__;
var G__23519 = cljs.core.cst$kw$chromex$ext$runtime_SLASH_on_DASH_restart_DASH_required;
var G__23520 = channel;
return (handler__6145__auto__.cljs$core$IFn$_invoke$arity$3 ? handler__6145__auto__.cljs$core$IFn$_invoke$arity$3(G__23518,G__23519,G__23520) : handler__6145__auto__.call(null,G__23518,G__23519,G__23520));
})();
var handler_fn_23511 = ((function (event_fn_23510){
return (function (cb_reason_23516){
return (event_fn_23510.cljs$core$IFn$_invoke$arity$1 ? event_fn_23510.cljs$core$IFn$_invoke$arity$1(cb_reason_23516) : event_fn_23510.call(null,cb_reason_23516));
});})(event_fn_23510))
;
var logging_fn_23512 = ((function (event_fn_23510,handler_fn_23511){
return (function (cb_param_reason_23517){

return handler_fn_23511(cb_param_reason_23517);
});})(event_fn_23510,handler_fn_23511))
;
var ns_obj_23515 = (function (){var target_obj_23521 = cljs.core.cst$kw$root.cljs$core$IFn$_invoke$arity$1(config);
var next_obj_23522 = (target_obj_23521["chrome"]);
var next_obj_23523 = (next_obj_23522["runtime"]);
return next_obj_23523;
})();
var config__6181__auto___23529 = config;
var api_check_fn__6182__auto___23530 = cljs.core.cst$kw$missing_DASH_api_DASH_check_DASH_fn.cljs$core$IFn$_invoke$arity$1(config__6181__auto___23529);

(api_check_fn__6182__auto___23530.cljs$core$IFn$_invoke$arity$3 ? api_check_fn__6182__auto___23530.cljs$core$IFn$_invoke$arity$3("chrome.runtime.onRestartRequired",ns_obj_23515,"onRestartRequired") : api_check_fn__6182__auto___23530.call(null,"chrome.runtime.onRestartRequired",ns_obj_23515,"onRestartRequired"));

var event_obj_23513 = (function (){var target_obj_23524 = ns_obj_23515;
var next_obj_23525 = (target_obj_23524["onRestartRequired"]);
return next_obj_23525;
})();
var result_23514 = chromex.chrome_event_subscription.make_chrome_event_subscription(event_obj_23513,logging_fn_23512,channel);
result_23514.chromex$protocols$chrome_event_subscription$IChromeEventSubscription$subscribe_BANG_$arity$2(null,args);

return result_23514;
});

chromex.ext.runtime.on_restart_required_STAR_.cljs$lang$maxFixedArity = (2);

/** @this {Function} */
chromex.ext.runtime.on_restart_required_STAR_.cljs$lang$applyTo = (function (seq23507){
var G__23508 = cljs.core.first(seq23507);
var seq23507__$1 = cljs.core.next(seq23507);
var G__23509 = cljs.core.first(seq23507__$1);
var seq23507__$2 = cljs.core.next(seq23507__$1);
var self__4628__auto__ = this;
return self__4628__auto__.cljs$core$IFn$_invoke$arity$variadic(G__23508,G__23509,seq23507__$2);
});

