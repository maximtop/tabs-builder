// Compiled by ClojureScript 1.10.439 {:static-fns true, :optimize-constants true, :elide-asserts true}
goog.provide('chromex.chrome_content_setting');
goog.require('cljs.core');
goog.require('cljs.core.constants');
goog.require('chromex.support');
goog.require('oops.core');
goog.require('chromex.protocols.chrome_content_setting');

/**
* @constructor
 * @implements {chromex.protocols.chrome_content_setting.IChromeContentSetting}
*/
chromex.chrome_content_setting.ChromeContentSetting = (function (native_chrome_content_setting,channel_factory,callback_factory){
this.native_chrome_content_setting = native_chrome_content_setting;
this.channel_factory = channel_factory;
this.callback_factory = callback_factory;
});
chromex.chrome_content_setting.ChromeContentSetting.prototype.chromex$protocols$chrome_content_setting$IChromeContentSetting$ = cljs.core.PROTOCOL_SENTINEL;

chromex.chrome_content_setting.ChromeContentSetting.prototype.chromex$protocols$chrome_content_setting$IChromeContentSetting$get_native_content_setting$arity$1 = (function (_this){
var self__ = this;
var _this__$1 = this;
return self__.native_chrome_content_setting;
});

chromex.chrome_content_setting.ChromeContentSetting.prototype.chromex$protocols$chrome_content_setting$IChromeContentSetting$get$arity$2 = (function (_this,details){
var self__ = this;
var _this__$1 = this;
var channel = (self__.channel_factory.cljs$core$IFn$_invoke$arity$0 ? self__.channel_factory.cljs$core$IFn$_invoke$arity$0() : self__.channel_factory.call(null));
var target_obj_22884_22900 = self__.native_chrome_content_setting;
var call_info_22886_22901 = [target_obj_22884_22900,(function (){var next_obj_22887 = (target_obj_22884_22900["get"]);
return next_obj_22887;
})()];
var fn_22885_22902 = (call_info_22886_22901[(1)]);
if((!((fn_22885_22902 == null)))){
fn_22885_22902.call((call_info_22886_22901[(0)]),details,(self__.callback_factory.cljs$core$IFn$_invoke$arity$1 ? self__.callback_factory.cljs$core$IFn$_invoke$arity$1(channel) : self__.callback_factory.call(null,channel)));
} else {
}

return channel;
});

chromex.chrome_content_setting.ChromeContentSetting.prototype.chromex$protocols$chrome_content_setting$IChromeContentSetting$set$arity$2 = (function (_this,details){
var self__ = this;
var _this__$1 = this;
var channel = (self__.channel_factory.cljs$core$IFn$_invoke$arity$0 ? self__.channel_factory.cljs$core$IFn$_invoke$arity$0() : self__.channel_factory.call(null));
var target_obj_22888_22903 = self__.native_chrome_content_setting;
var call_info_22890_22904 = [target_obj_22888_22903,(function (){var next_obj_22891 = (target_obj_22888_22903["set"]);
return next_obj_22891;
})()];
var fn_22889_22905 = (call_info_22890_22904[(1)]);
if((!((fn_22889_22905 == null)))){
fn_22889_22905.call((call_info_22890_22904[(0)]),details,(self__.callback_factory.cljs$core$IFn$_invoke$arity$1 ? self__.callback_factory.cljs$core$IFn$_invoke$arity$1(channel) : self__.callback_factory.call(null,channel)));
} else {
}

return channel;
});

chromex.chrome_content_setting.ChromeContentSetting.prototype.chromex$protocols$chrome_content_setting$IChromeContentSetting$clear$arity$2 = (function (_this,details){
var self__ = this;
var _this__$1 = this;
var channel = (self__.channel_factory.cljs$core$IFn$_invoke$arity$0 ? self__.channel_factory.cljs$core$IFn$_invoke$arity$0() : self__.channel_factory.call(null));
var target_obj_22892_22906 = self__.native_chrome_content_setting;
var call_info_22894_22907 = [target_obj_22892_22906,(function (){var next_obj_22895 = (target_obj_22892_22906["clear"]);
return next_obj_22895;
})()];
var fn_22893_22908 = (call_info_22894_22907[(1)]);
if((!((fn_22893_22908 == null)))){
fn_22893_22908.call((call_info_22894_22907[(0)]),details,(self__.callback_factory.cljs$core$IFn$_invoke$arity$1 ? self__.callback_factory.cljs$core$IFn$_invoke$arity$1(channel) : self__.callback_factory.call(null,channel)));
} else {
}

return channel;
});

chromex.chrome_content_setting.ChromeContentSetting.prototype.chromex$protocols$chrome_content_setting$IChromeContentSetting$get_resource_identifiers$arity$1 = (function (_this){
var self__ = this;
var _this__$1 = this;
var channel = (self__.channel_factory.cljs$core$IFn$_invoke$arity$0 ? self__.channel_factory.cljs$core$IFn$_invoke$arity$0() : self__.channel_factory.call(null));
var target_obj_22896_22909 = self__.native_chrome_content_setting;
var call_info_22898_22910 = [target_obj_22896_22909,(function (){var next_obj_22899 = (target_obj_22896_22909["getResourceIdentifiers"]);
return next_obj_22899;
})()];
var fn_22897_22911 = (call_info_22898_22910[(1)]);
if((!((fn_22897_22911 == null)))){
fn_22897_22911.call((call_info_22898_22910[(0)]),(self__.callback_factory.cljs$core$IFn$_invoke$arity$1 ? self__.callback_factory.cljs$core$IFn$_invoke$arity$1(channel) : self__.callback_factory.call(null,channel)));
} else {
}

return channel;
});

chromex.chrome_content_setting.ChromeContentSetting.getBasis = (function (){
return new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [cljs.core.cst$sym$native_DASH_chrome_DASH_content_DASH_setting,cljs.core.cst$sym$channel_DASH_factory,cljs.core.cst$sym$callback_DASH_factory], null);
});

chromex.chrome_content_setting.ChromeContentSetting.cljs$lang$type = true;

chromex.chrome_content_setting.ChromeContentSetting.cljs$lang$ctorStr = "chromex.chrome-content-setting/ChromeContentSetting";

chromex.chrome_content_setting.ChromeContentSetting.cljs$lang$ctorPrWriter = (function (this__4290__auto__,writer__4291__auto__,opt__4292__auto__){
return cljs.core._write(writer__4291__auto__,"chromex.chrome-content-setting/ChromeContentSetting");
});

/**
 * Positional factory function for chromex.chrome-content-setting/ChromeContentSetting.
 */
chromex.chrome_content_setting.__GT_ChromeContentSetting = (function chromex$chrome_content_setting$__GT_ChromeContentSetting(native_chrome_content_setting,channel_factory,callback_factory){
return (new chromex.chrome_content_setting.ChromeContentSetting(native_chrome_content_setting,channel_factory,callback_factory));
});

chromex.chrome_content_setting.make_chrome_content_setting = (function chromex$chrome_content_setting$make_chrome_content_setting(config,native_chrome_content_setting){

return (new chromex.chrome_content_setting.ChromeContentSetting(native_chrome_content_setting,(function (){var config__6152__auto__ = config;
var handler_key__6153__auto__ = cljs.core.cst$kw$chrome_DASH_content_DASH_setting_DASH_callback_DASH_channel_DASH_factory;
var handler__6154__auto__ = handler_key__6153__auto__.cljs$core$IFn$_invoke$arity$1(config__6152__auto__);

return cljs.core.partial.cljs$core$IFn$_invoke$arity$2(handler__6154__auto__,config__6152__auto__);
})(),(function (){var config__6152__auto__ = config;
var handler_key__6153__auto__ = cljs.core.cst$kw$chrome_DASH_content_DASH_setting_DASH_callback_DASH_fn_DASH_factory;
var handler__6154__auto__ = handler_key__6153__auto__.cljs$core$IFn$_invoke$arity$1(config__6152__auto__);

return cljs.core.partial.cljs$core$IFn$_invoke$arity$2(handler__6154__auto__,config__6152__auto__);
})()));
});
