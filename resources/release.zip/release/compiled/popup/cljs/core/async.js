// Compiled by ClojureScript 1.10.439 {:static-fns true, :optimize-constants true, :elide-asserts true}
goog.provide('cljs.core.async');
goog.require('cljs.core');
goog.require('cljs.core.constants');
goog.require('cljs.core.async.impl.protocols');
goog.require('cljs.core.async.impl.channels');
goog.require('cljs.core.async.impl.buffers');
goog.require('cljs.core.async.impl.timers');
goog.require('cljs.core.async.impl.dispatch');
goog.require('cljs.core.async.impl.ioc_helpers');
cljs.core.async.fn_handler = (function cljs$core$async$fn_handler(var_args){
var G__19798 = arguments.length;
switch (G__19798) {
case 1:
return cljs.core.async.fn_handler.cljs$core$IFn$_invoke$arity$1((arguments[(0)]));

break;
case 2:
return cljs.core.async.fn_handler.cljs$core$IFn$_invoke$arity$2((arguments[(0)]),(arguments[(1)]));

break;
default:
throw (new Error(["Invalid arity: ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(arguments.length)].join('')));

}
});

cljs.core.async.fn_handler.cljs$core$IFn$_invoke$arity$1 = (function (f){
return cljs.core.async.fn_handler.cljs$core$IFn$_invoke$arity$2(f,true);
});

cljs.core.async.fn_handler.cljs$core$IFn$_invoke$arity$2 = (function (f,blockable){
if((typeof cljs !== 'undefined') && (typeof cljs.core !== 'undefined') && (typeof cljs.core.async !== 'undefined') && (typeof cljs.core.async.t_cljs$core$async19799 !== 'undefined')){
} else {

/**
* @constructor
 * @implements {cljs.core.async.impl.protocols.Handler}
 * @implements {cljs.core.IMeta}
 * @implements {cljs.core.IWithMeta}
*/
cljs.core.async.t_cljs$core$async19799 = (function (f,blockable,meta19800){
this.f = f;
this.blockable = blockable;
this.meta19800 = meta19800;
this.cljs$lang$protocol_mask$partition0$ = 393216;
this.cljs$lang$protocol_mask$partition1$ = 0;
});
cljs.core.async.t_cljs$core$async19799.prototype.cljs$core$IWithMeta$_with_meta$arity$2 = (function (_19801,meta19800__$1){
var self__ = this;
var _19801__$1 = this;
return (new cljs.core.async.t_cljs$core$async19799(self__.f,self__.blockable,meta19800__$1));
});

cljs.core.async.t_cljs$core$async19799.prototype.cljs$core$IMeta$_meta$arity$1 = (function (_19801){
var self__ = this;
var _19801__$1 = this;
return self__.meta19800;
});

cljs.core.async.t_cljs$core$async19799.prototype.cljs$core$async$impl$protocols$Handler$ = cljs.core.PROTOCOL_SENTINEL;

cljs.core.async.t_cljs$core$async19799.prototype.cljs$core$async$impl$protocols$Handler$active_QMARK_$arity$1 = (function (_){
var self__ = this;
var ___$1 = this;
return true;
});

cljs.core.async.t_cljs$core$async19799.prototype.cljs$core$async$impl$protocols$Handler$blockable_QMARK_$arity$1 = (function (_){
var self__ = this;
var ___$1 = this;
return self__.blockable;
});

cljs.core.async.t_cljs$core$async19799.prototype.cljs$core$async$impl$protocols$Handler$commit$arity$1 = (function (_){
var self__ = this;
var ___$1 = this;
return self__.f;
});

cljs.core.async.t_cljs$core$async19799.getBasis = (function (){
return new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [cljs.core.cst$sym$f,cljs.core.cst$sym$blockable,cljs.core.cst$sym$meta19800], null);
});

cljs.core.async.t_cljs$core$async19799.cljs$lang$type = true;

cljs.core.async.t_cljs$core$async19799.cljs$lang$ctorStr = "cljs.core.async/t_cljs$core$async19799";

cljs.core.async.t_cljs$core$async19799.cljs$lang$ctorPrWriter = (function (this__4290__auto__,writer__4291__auto__,opt__4292__auto__){
return cljs.core._write(writer__4291__auto__,"cljs.core.async/t_cljs$core$async19799");
});

/**
 * Positional factory function for cljs.core.async/t_cljs$core$async19799.
 */
cljs.core.async.__GT_t_cljs$core$async19799 = (function cljs$core$async$__GT_t_cljs$core$async19799(f__$1,blockable__$1,meta19800){
return (new cljs.core.async.t_cljs$core$async19799(f__$1,blockable__$1,meta19800));
});

}

return (new cljs.core.async.t_cljs$core$async19799(f,blockable,cljs.core.PersistentArrayMap.EMPTY));
});

cljs.core.async.fn_handler.cljs$lang$maxFixedArity = 2;

/**
 * Returns a fixed buffer of size n. When full, puts will block/park.
 */
cljs.core.async.buffer = (function cljs$core$async$buffer(n){
return cljs.core.async.impl.buffers.fixed_buffer(n);
});
/**
 * Returns a buffer of size n. When full, puts will complete but
 *   val will be dropped (no transfer).
 */
cljs.core.async.dropping_buffer = (function cljs$core$async$dropping_buffer(n){
return cljs.core.async.impl.buffers.dropping_buffer(n);
});
/**
 * Returns a buffer of size n. When full, puts will complete, and be
 *   buffered, but oldest elements in buffer will be dropped (not
 *   transferred).
 */
cljs.core.async.sliding_buffer = (function cljs$core$async$sliding_buffer(n){
return cljs.core.async.impl.buffers.sliding_buffer(n);
});
/**
 * Returns true if a channel created with buff will never block. That is to say,
 * puts into this buffer will never cause the buffer to be full. 
 */
cljs.core.async.unblocking_buffer_QMARK_ = (function cljs$core$async$unblocking_buffer_QMARK_(buff){
if((!((buff == null)))){
if(((false) || ((cljs.core.PROTOCOL_SENTINEL === buff.cljs$core$async$impl$protocols$UnblockingBuffer$)))){
return true;
} else {
if((!buff.cljs$lang$protocol_mask$partition$)){
return cljs.core.native_satisfies_QMARK_(cljs.core.async.impl.protocols.UnblockingBuffer,buff);
} else {
return false;
}
}
} else {
return cljs.core.native_satisfies_QMARK_(cljs.core.async.impl.protocols.UnblockingBuffer,buff);
}
});
/**
 * Creates a channel with an optional buffer, an optional transducer (like (map f),
 *   (filter p) etc or a composition thereof), and an optional exception handler.
 *   If buf-or-n is a number, will create and use a fixed buffer of that size. If a
 *   transducer is supplied a buffer must be specified. ex-handler must be a
 *   fn of one argument - if an exception occurs during transformation it will be called
 *   with the thrown value as an argument, and any non-nil return value will be placed
 *   in the channel.
 */
cljs.core.async.chan = (function cljs$core$async$chan(var_args){
var G__19805 = arguments.length;
switch (G__19805) {
case 0:
return cljs.core.async.chan.cljs$core$IFn$_invoke$arity$0();

break;
case 1:
return cljs.core.async.chan.cljs$core$IFn$_invoke$arity$1((arguments[(0)]));

break;
case 2:
return cljs.core.async.chan.cljs$core$IFn$_invoke$arity$2((arguments[(0)]),(arguments[(1)]));

break;
case 3:
return cljs.core.async.chan.cljs$core$IFn$_invoke$arity$3((arguments[(0)]),(arguments[(1)]),(arguments[(2)]));

break;
default:
throw (new Error(["Invalid arity: ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(arguments.length)].join('')));

}
});

cljs.core.async.chan.cljs$core$IFn$_invoke$arity$0 = (function (){
return cljs.core.async.chan.cljs$core$IFn$_invoke$arity$1(null);
});

cljs.core.async.chan.cljs$core$IFn$_invoke$arity$1 = (function (buf_or_n){
return cljs.core.async.chan.cljs$core$IFn$_invoke$arity$3(buf_or_n,null,null);
});

cljs.core.async.chan.cljs$core$IFn$_invoke$arity$2 = (function (buf_or_n,xform){
return cljs.core.async.chan.cljs$core$IFn$_invoke$arity$3(buf_or_n,xform,null);
});

cljs.core.async.chan.cljs$core$IFn$_invoke$arity$3 = (function (buf_or_n,xform,ex_handler){
var buf_or_n__$1 = ((cljs.core._EQ_.cljs$core$IFn$_invoke$arity$2(buf_or_n,(0)))?null:buf_or_n);
if(cljs.core.truth_(xform)){
} else {
}

return cljs.core.async.impl.channels.chan.cljs$core$IFn$_invoke$arity$3(((typeof buf_or_n__$1 === 'number')?cljs.core.async.buffer(buf_or_n__$1):buf_or_n__$1),xform,ex_handler);
});

cljs.core.async.chan.cljs$lang$maxFixedArity = 3;

/**
 * Creates a promise channel with an optional transducer, and an optional
 *   exception-handler. A promise channel can take exactly one value that consumers
 *   will receive. Once full, puts complete but val is dropped (no transfer).
 *   Consumers will block until either a value is placed in the channel or the
 *   channel is closed. See chan for the semantics of xform and ex-handler.
 */
cljs.core.async.promise_chan = (function cljs$core$async$promise_chan(var_args){
var G__19808 = arguments.length;
switch (G__19808) {
case 0:
return cljs.core.async.promise_chan.cljs$core$IFn$_invoke$arity$0();

break;
case 1:
return cljs.core.async.promise_chan.cljs$core$IFn$_invoke$arity$1((arguments[(0)]));

break;
case 2:
return cljs.core.async.promise_chan.cljs$core$IFn$_invoke$arity$2((arguments[(0)]),(arguments[(1)]));

break;
default:
throw (new Error(["Invalid arity: ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(arguments.length)].join('')));

}
});

cljs.core.async.promise_chan.cljs$core$IFn$_invoke$arity$0 = (function (){
return cljs.core.async.promise_chan.cljs$core$IFn$_invoke$arity$1(null);
});

cljs.core.async.promise_chan.cljs$core$IFn$_invoke$arity$1 = (function (xform){
return cljs.core.async.promise_chan.cljs$core$IFn$_invoke$arity$2(xform,null);
});

cljs.core.async.promise_chan.cljs$core$IFn$_invoke$arity$2 = (function (xform,ex_handler){
return cljs.core.async.chan.cljs$core$IFn$_invoke$arity$3(cljs.core.async.impl.buffers.promise_buffer(),xform,ex_handler);
});

cljs.core.async.promise_chan.cljs$lang$maxFixedArity = 2;

/**
 * Returns a channel that will close after msecs
 */
cljs.core.async.timeout = (function cljs$core$async$timeout(msecs){
return cljs.core.async.impl.timers.timeout(msecs);
});
/**
 * takes a val from port. Must be called inside a (go ...) block. Will
 *   return nil if closed. Will park if nothing is available.
 *   Returns true unless port is already closed
 */
cljs.core.async._LT__BANG_ = (function cljs$core$async$_LT__BANG_(port){
throw (new Error("<! used not in (go ...) block"));
});
/**
 * Asynchronously takes a val from port, passing to fn1. Will pass nil
 * if closed. If on-caller? (default true) is true, and value is
 * immediately available, will call fn1 on calling thread.
 * Returns nil.
 */
cljs.core.async.take_BANG_ = (function cljs$core$async$take_BANG_(var_args){
var G__19811 = arguments.length;
switch (G__19811) {
case 2:
return cljs.core.async.take_BANG_.cljs$core$IFn$_invoke$arity$2((arguments[(0)]),(arguments[(1)]));

break;
case 3:
return cljs.core.async.take_BANG_.cljs$core$IFn$_invoke$arity$3((arguments[(0)]),(arguments[(1)]),(arguments[(2)]));

break;
default:
throw (new Error(["Invalid arity: ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(arguments.length)].join('')));

}
});

cljs.core.async.take_BANG_.cljs$core$IFn$_invoke$arity$2 = (function (port,fn1){
return cljs.core.async.take_BANG_.cljs$core$IFn$_invoke$arity$3(port,fn1,true);
});

cljs.core.async.take_BANG_.cljs$core$IFn$_invoke$arity$3 = (function (port,fn1,on_caller_QMARK_){
var ret = cljs.core.async.impl.protocols.take_BANG_(port,cljs.core.async.fn_handler.cljs$core$IFn$_invoke$arity$1(fn1));
if(cljs.core.truth_(ret)){
var val_19813 = cljs.core.deref(ret);
if(cljs.core.truth_(on_caller_QMARK_)){
(fn1.cljs$core$IFn$_invoke$arity$1 ? fn1.cljs$core$IFn$_invoke$arity$1(val_19813) : fn1.call(null,val_19813));
} else {
cljs.core.async.impl.dispatch.run(((function (val_19813,ret){
return (function (){
return (fn1.cljs$core$IFn$_invoke$arity$1 ? fn1.cljs$core$IFn$_invoke$arity$1(val_19813) : fn1.call(null,val_19813));
});})(val_19813,ret))
);
}
} else {
}

return null;
});

cljs.core.async.take_BANG_.cljs$lang$maxFixedArity = 3;

cljs.core.async.nop = (function cljs$core$async$nop(_){
return null;
});
cljs.core.async.fhnop = cljs.core.async.fn_handler.cljs$core$IFn$_invoke$arity$1(cljs.core.async.nop);
/**
 * puts a val into port. nil values are not allowed. Must be called
 *   inside a (go ...) block. Will park if no buffer space is available.
 *   Returns true unless port is already closed.
 */
cljs.core.async._GT__BANG_ = (function cljs$core$async$_GT__BANG_(port,val){
throw (new Error(">! used not in (go ...) block"));
});
/**
 * Asynchronously puts a val into port, calling fn1 (if supplied) when
 * complete. nil values are not allowed. Will throw if closed. If
 * on-caller? (default true) is true, and the put is immediately
 * accepted, will call fn1 on calling thread.  Returns nil.
 */
cljs.core.async.put_BANG_ = (function cljs$core$async$put_BANG_(var_args){
var G__19815 = arguments.length;
switch (G__19815) {
case 2:
return cljs.core.async.put_BANG_.cljs$core$IFn$_invoke$arity$2((arguments[(0)]),(arguments[(1)]));

break;
case 3:
return cljs.core.async.put_BANG_.cljs$core$IFn$_invoke$arity$3((arguments[(0)]),(arguments[(1)]),(arguments[(2)]));

break;
case 4:
return cljs.core.async.put_BANG_.cljs$core$IFn$_invoke$arity$4((arguments[(0)]),(arguments[(1)]),(arguments[(2)]),(arguments[(3)]));

break;
default:
throw (new Error(["Invalid arity: ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(arguments.length)].join('')));

}
});

cljs.core.async.put_BANG_.cljs$core$IFn$_invoke$arity$2 = (function (port,val){
var temp__5455__auto__ = cljs.core.async.impl.protocols.put_BANG_(port,val,cljs.core.async.fhnop);
if(cljs.core.truth_(temp__5455__auto__)){
var ret = temp__5455__auto__;
return cljs.core.deref(ret);
} else {
return true;
}
});

cljs.core.async.put_BANG_.cljs$core$IFn$_invoke$arity$3 = (function (port,val,fn1){
return cljs.core.async.put_BANG_.cljs$core$IFn$_invoke$arity$4(port,val,fn1,true);
});

cljs.core.async.put_BANG_.cljs$core$IFn$_invoke$arity$4 = (function (port,val,fn1,on_caller_QMARK_){
var temp__5455__auto__ = cljs.core.async.impl.protocols.put_BANG_(port,val,cljs.core.async.fn_handler.cljs$core$IFn$_invoke$arity$1(fn1));
if(cljs.core.truth_(temp__5455__auto__)){
var retb = temp__5455__auto__;
var ret = cljs.core.deref(retb);
if(cljs.core.truth_(on_caller_QMARK_)){
(fn1.cljs$core$IFn$_invoke$arity$1 ? fn1.cljs$core$IFn$_invoke$arity$1(ret) : fn1.call(null,ret));
} else {
cljs.core.async.impl.dispatch.run(((function (ret,retb,temp__5455__auto__){
return (function (){
return (fn1.cljs$core$IFn$_invoke$arity$1 ? fn1.cljs$core$IFn$_invoke$arity$1(ret) : fn1.call(null,ret));
});})(ret,retb,temp__5455__auto__))
);
}

return ret;
} else {
return true;
}
});

cljs.core.async.put_BANG_.cljs$lang$maxFixedArity = 4;

cljs.core.async.close_BANG_ = (function cljs$core$async$close_BANG_(port){
return cljs.core.async.impl.protocols.close_BANG_(port);
});
cljs.core.async.random_array = (function cljs$core$async$random_array(n){
var a = (new Array(n));
var n__4518__auto___19817 = n;
var x_19818 = (0);
while(true){
if((x_19818 < n__4518__auto___19817)){
(a[x_19818] = (0));

var G__19819 = (x_19818 + (1));
x_19818 = G__19819;
continue;
} else {
}
break;
}

var i = (1);
while(true){
if(cljs.core._EQ_.cljs$core$IFn$_invoke$arity$2(i,n)){
return a;
} else {
var j = cljs.core.rand_int(i);
(a[i] = (a[j]));

(a[j] = i);

var G__19820 = (i + (1));
i = G__19820;
continue;
}
break;
}
});
cljs.core.async.alt_flag = (function cljs$core$async$alt_flag(){
var flag = cljs.core.atom.cljs$core$IFn$_invoke$arity$1(true);
if((typeof cljs !== 'undefined') && (typeof cljs.core !== 'undefined') && (typeof cljs.core.async !== 'undefined') && (typeof cljs.core.async.t_cljs$core$async19821 !== 'undefined')){
} else {

/**
* @constructor
 * @implements {cljs.core.async.impl.protocols.Handler}
 * @implements {cljs.core.IMeta}
 * @implements {cljs.core.IWithMeta}
*/
cljs.core.async.t_cljs$core$async19821 = (function (flag,meta19822){
this.flag = flag;
this.meta19822 = meta19822;
this.cljs$lang$protocol_mask$partition0$ = 393216;
this.cljs$lang$protocol_mask$partition1$ = 0;
});
cljs.core.async.t_cljs$core$async19821.prototype.cljs$core$IWithMeta$_with_meta$arity$2 = ((function (flag){
return (function (_19823,meta19822__$1){
var self__ = this;
var _19823__$1 = this;
return (new cljs.core.async.t_cljs$core$async19821(self__.flag,meta19822__$1));
});})(flag))
;

cljs.core.async.t_cljs$core$async19821.prototype.cljs$core$IMeta$_meta$arity$1 = ((function (flag){
return (function (_19823){
var self__ = this;
var _19823__$1 = this;
return self__.meta19822;
});})(flag))
;

cljs.core.async.t_cljs$core$async19821.prototype.cljs$core$async$impl$protocols$Handler$ = cljs.core.PROTOCOL_SENTINEL;

cljs.core.async.t_cljs$core$async19821.prototype.cljs$core$async$impl$protocols$Handler$active_QMARK_$arity$1 = ((function (flag){
return (function (_){
var self__ = this;
var ___$1 = this;
return cljs.core.deref(self__.flag);
});})(flag))
;

cljs.core.async.t_cljs$core$async19821.prototype.cljs$core$async$impl$protocols$Handler$blockable_QMARK_$arity$1 = ((function (flag){
return (function (_){
var self__ = this;
var ___$1 = this;
return true;
});})(flag))
;

cljs.core.async.t_cljs$core$async19821.prototype.cljs$core$async$impl$protocols$Handler$commit$arity$1 = ((function (flag){
return (function (_){
var self__ = this;
var ___$1 = this;
cljs.core.reset_BANG_(self__.flag,null);

return true;
});})(flag))
;

cljs.core.async.t_cljs$core$async19821.getBasis = ((function (flag){
return (function (){
return new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [cljs.core.cst$sym$flag,cljs.core.cst$sym$meta19822], null);
});})(flag))
;

cljs.core.async.t_cljs$core$async19821.cljs$lang$type = true;

cljs.core.async.t_cljs$core$async19821.cljs$lang$ctorStr = "cljs.core.async/t_cljs$core$async19821";

cljs.core.async.t_cljs$core$async19821.cljs$lang$ctorPrWriter = ((function (flag){
return (function (this__4290__auto__,writer__4291__auto__,opt__4292__auto__){
return cljs.core._write(writer__4291__auto__,"cljs.core.async/t_cljs$core$async19821");
});})(flag))
;

/**
 * Positional factory function for cljs.core.async/t_cljs$core$async19821.
 */
cljs.core.async.__GT_t_cljs$core$async19821 = ((function (flag){
return (function cljs$core$async$alt_flag_$___GT_t_cljs$core$async19821(flag__$1,meta19822){
return (new cljs.core.async.t_cljs$core$async19821(flag__$1,meta19822));
});})(flag))
;

}

return (new cljs.core.async.t_cljs$core$async19821(flag,cljs.core.PersistentArrayMap.EMPTY));
});
cljs.core.async.alt_handler = (function cljs$core$async$alt_handler(flag,cb){
if((typeof cljs !== 'undefined') && (typeof cljs.core !== 'undefined') && (typeof cljs.core.async !== 'undefined') && (typeof cljs.core.async.t_cljs$core$async19824 !== 'undefined')){
} else {

/**
* @constructor
 * @implements {cljs.core.async.impl.protocols.Handler}
 * @implements {cljs.core.IMeta}
 * @implements {cljs.core.IWithMeta}
*/
cljs.core.async.t_cljs$core$async19824 = (function (flag,cb,meta19825){
this.flag = flag;
this.cb = cb;
this.meta19825 = meta19825;
this.cljs$lang$protocol_mask$partition0$ = 393216;
this.cljs$lang$protocol_mask$partition1$ = 0;
});
cljs.core.async.t_cljs$core$async19824.prototype.cljs$core$IWithMeta$_with_meta$arity$2 = (function (_19826,meta19825__$1){
var self__ = this;
var _19826__$1 = this;
return (new cljs.core.async.t_cljs$core$async19824(self__.flag,self__.cb,meta19825__$1));
});

cljs.core.async.t_cljs$core$async19824.prototype.cljs$core$IMeta$_meta$arity$1 = (function (_19826){
var self__ = this;
var _19826__$1 = this;
return self__.meta19825;
});

cljs.core.async.t_cljs$core$async19824.prototype.cljs$core$async$impl$protocols$Handler$ = cljs.core.PROTOCOL_SENTINEL;

cljs.core.async.t_cljs$core$async19824.prototype.cljs$core$async$impl$protocols$Handler$active_QMARK_$arity$1 = (function (_){
var self__ = this;
var ___$1 = this;
return cljs.core.async.impl.protocols.active_QMARK_(self__.flag);
});

cljs.core.async.t_cljs$core$async19824.prototype.cljs$core$async$impl$protocols$Handler$blockable_QMARK_$arity$1 = (function (_){
var self__ = this;
var ___$1 = this;
return true;
});

cljs.core.async.t_cljs$core$async19824.prototype.cljs$core$async$impl$protocols$Handler$commit$arity$1 = (function (_){
var self__ = this;
var ___$1 = this;
cljs.core.async.impl.protocols.commit(self__.flag);

return self__.cb;
});

cljs.core.async.t_cljs$core$async19824.getBasis = (function (){
return new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [cljs.core.cst$sym$flag,cljs.core.cst$sym$cb,cljs.core.cst$sym$meta19825], null);
});

cljs.core.async.t_cljs$core$async19824.cljs$lang$type = true;

cljs.core.async.t_cljs$core$async19824.cljs$lang$ctorStr = "cljs.core.async/t_cljs$core$async19824";

cljs.core.async.t_cljs$core$async19824.cljs$lang$ctorPrWriter = (function (this__4290__auto__,writer__4291__auto__,opt__4292__auto__){
return cljs.core._write(writer__4291__auto__,"cljs.core.async/t_cljs$core$async19824");
});

/**
 * Positional factory function for cljs.core.async/t_cljs$core$async19824.
 */
cljs.core.async.__GT_t_cljs$core$async19824 = (function cljs$core$async$alt_handler_$___GT_t_cljs$core$async19824(flag__$1,cb__$1,meta19825){
return (new cljs.core.async.t_cljs$core$async19824(flag__$1,cb__$1,meta19825));
});

}

return (new cljs.core.async.t_cljs$core$async19824(flag,cb,cljs.core.PersistentArrayMap.EMPTY));
});
/**
 * returns derefable [val port] if immediate, nil if enqueued
 */
cljs.core.async.do_alts = (function cljs$core$async$do_alts(fret,ports,opts){
var flag = cljs.core.async.alt_flag();
var n = cljs.core.count(ports);
var idxs = cljs.core.async.random_array(n);
var priority = cljs.core.cst$kw$priority.cljs$core$IFn$_invoke$arity$1(opts);
var ret = (function (){var i = (0);
while(true){
if((i < n)){
var idx = (cljs.core.truth_(priority)?i:(idxs[i]));
var port = cljs.core.nth.cljs$core$IFn$_invoke$arity$2(ports,idx);
var wport = ((cljs.core.vector_QMARK_(port))?(port.cljs$core$IFn$_invoke$arity$1 ? port.cljs$core$IFn$_invoke$arity$1((0)) : port.call(null,(0))):null);
var vbox = (cljs.core.truth_(wport)?(function (){var val = (port.cljs$core$IFn$_invoke$arity$1 ? port.cljs$core$IFn$_invoke$arity$1((1)) : port.call(null,(1)));
return cljs.core.async.impl.protocols.put_BANG_(wport,val,cljs.core.async.alt_handler(flag,((function (i,val,idx,port,wport,flag,n,idxs,priority){
return (function (p1__19827_SHARP_){
var G__19829 = new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [p1__19827_SHARP_,wport], null);
return (fret.cljs$core$IFn$_invoke$arity$1 ? fret.cljs$core$IFn$_invoke$arity$1(G__19829) : fret.call(null,G__19829));
});})(i,val,idx,port,wport,flag,n,idxs,priority))
));
})():cljs.core.async.impl.protocols.take_BANG_(port,cljs.core.async.alt_handler(flag,((function (i,idx,port,wport,flag,n,idxs,priority){
return (function (p1__19828_SHARP_){
var G__19830 = new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [p1__19828_SHARP_,port], null);
return (fret.cljs$core$IFn$_invoke$arity$1 ? fret.cljs$core$IFn$_invoke$arity$1(G__19830) : fret.call(null,G__19830));
});})(i,idx,port,wport,flag,n,idxs,priority))
)));
if(cljs.core.truth_(vbox)){
return cljs.core.async.impl.channels.box(new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [cljs.core.deref(vbox),(function (){var or__4047__auto__ = wport;
if(cljs.core.truth_(or__4047__auto__)){
return or__4047__auto__;
} else {
return port;
}
})()], null));
} else {
var G__19831 = (i + (1));
i = G__19831;
continue;
}
} else {
return null;
}
break;
}
})();
var or__4047__auto__ = ret;
if(cljs.core.truth_(or__4047__auto__)){
return or__4047__auto__;
} else {
if(cljs.core.contains_QMARK_(opts,cljs.core.cst$kw$default)){
var temp__5457__auto__ = (function (){var and__4036__auto__ = flag.cljs$core$async$impl$protocols$Handler$active_QMARK_$arity$1(null);
if(cljs.core.truth_(and__4036__auto__)){
return flag.cljs$core$async$impl$protocols$Handler$commit$arity$1(null);
} else {
return and__4036__auto__;
}
})();
if(cljs.core.truth_(temp__5457__auto__)){
var got = temp__5457__auto__;
return cljs.core.async.impl.channels.box(new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [cljs.core.cst$kw$default.cljs$core$IFn$_invoke$arity$1(opts),cljs.core.cst$kw$default], null));
} else {
return null;
}
} else {
return null;
}
}
});
/**
 * Completes at most one of several channel operations. Must be called
 * inside a (go ...) block. ports is a vector of channel endpoints,
 * which can be either a channel to take from or a vector of
 *   [channel-to-put-to val-to-put], in any combination. Takes will be
 *   made as if by <!, and puts will be made as if by >!. Unless
 *   the :priority option is true, if more than one port operation is
 *   ready a non-deterministic choice will be made. If no operation is
 *   ready and a :default value is supplied, [default-val :default] will
 *   be returned, otherwise alts! will park until the first operation to
 *   become ready completes. Returns [val port] of the completed
 *   operation, where val is the value taken for takes, and a
 *   boolean (true unless already closed, as per put!) for puts.
 * 
 *   opts are passed as :key val ... Supported options:
 * 
 *   :default val - the value to use if none of the operations are immediately ready
 *   :priority true - (default nil) when true, the operations will be tried in order.
 * 
 *   Note: there is no guarantee that the port exps or val exprs will be
 *   used, nor in what order should they be, so they should not be
 *   depended upon for side effects.
 */
cljs.core.async.alts_BANG_ = (function cljs$core$async$alts_BANG_(var_args){
var args__4647__auto__ = [];
var len__4641__auto___19837 = arguments.length;
var i__4642__auto___19838 = (0);
while(true){
if((i__4642__auto___19838 < len__4641__auto___19837)){
args__4647__auto__.push((arguments[i__4642__auto___19838]));

var G__19839 = (i__4642__auto___19838 + (1));
i__4642__auto___19838 = G__19839;
continue;
} else {
}
break;
}

var argseq__4648__auto__ = ((((1) < args__4647__auto__.length))?(new cljs.core.IndexedSeq(args__4647__auto__.slice((1)),(0),null)):null);
return cljs.core.async.alts_BANG_.cljs$core$IFn$_invoke$arity$variadic((arguments[(0)]),argseq__4648__auto__);
});

cljs.core.async.alts_BANG_.cljs$core$IFn$_invoke$arity$variadic = (function (ports,p__19834){
var map__19835 = p__19834;
var map__19835__$1 = (((((!((map__19835 == null))))?(((((map__19835.cljs$lang$protocol_mask$partition0$ & (64))) || ((cljs.core.PROTOCOL_SENTINEL === map__19835.cljs$core$ISeq$))))?true:false):false))?cljs.core.apply.cljs$core$IFn$_invoke$arity$2(cljs.core.hash_map,map__19835):map__19835);
var opts = map__19835__$1;
throw (new Error("alts! used not in (go ...) block"));
});

cljs.core.async.alts_BANG_.cljs$lang$maxFixedArity = (1);

/** @this {Function} */
cljs.core.async.alts_BANG_.cljs$lang$applyTo = (function (seq19832){
var G__19833 = cljs.core.first(seq19832);
var seq19832__$1 = cljs.core.next(seq19832);
var self__4628__auto__ = this;
return self__4628__auto__.cljs$core$IFn$_invoke$arity$variadic(G__19833,seq19832__$1);
});

/**
 * Puts a val into port if it's possible to do so immediately.
 *   nil values are not allowed. Never blocks. Returns true if offer succeeds.
 */
cljs.core.async.offer_BANG_ = (function cljs$core$async$offer_BANG_(port,val){
var ret = cljs.core.async.impl.protocols.put_BANG_(port,val,cljs.core.async.fn_handler.cljs$core$IFn$_invoke$arity$2(cljs.core.async.nop,false));
if(cljs.core.truth_(ret)){
return cljs.core.deref(ret);
} else {
return null;
}
});
/**
 * Takes a val from port if it's possible to do so immediately.
 *   Never blocks. Returns value if successful, nil otherwise.
 */
cljs.core.async.poll_BANG_ = (function cljs$core$async$poll_BANG_(port){
var ret = cljs.core.async.impl.protocols.take_BANG_(port,cljs.core.async.fn_handler.cljs$core$IFn$_invoke$arity$2(cljs.core.async.nop,false));
if(cljs.core.truth_(ret)){
return cljs.core.deref(ret);
} else {
return null;
}
});
/**
 * Takes elements from the from channel and supplies them to the to
 * channel. By default, the to channel will be closed when the from
 * channel closes, but can be determined by the close?  parameter. Will
 * stop consuming the from channel if the to channel closes
 */
cljs.core.async.pipe = (function cljs$core$async$pipe(var_args){
var G__19841 = arguments.length;
switch (G__19841) {
case 2:
return cljs.core.async.pipe.cljs$core$IFn$_invoke$arity$2((arguments[(0)]),(arguments[(1)]));

break;
case 3:
return cljs.core.async.pipe.cljs$core$IFn$_invoke$arity$3((arguments[(0)]),(arguments[(1)]),(arguments[(2)]));

break;
default:
throw (new Error(["Invalid arity: ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(arguments.length)].join('')));

}
});

cljs.core.async.pipe.cljs$core$IFn$_invoke$arity$2 = (function (from,to){
return cljs.core.async.pipe.cljs$core$IFn$_invoke$arity$3(from,to,true);
});

cljs.core.async.pipe.cljs$core$IFn$_invoke$arity$3 = (function (from,to,close_QMARK_){
var c__7992__auto___19887 = cljs.core.async.chan.cljs$core$IFn$_invoke$arity$1((1));
cljs.core.async.impl.dispatch.run(((function (c__7992__auto___19887){
return (function (){
var f__7993__auto__ = (function (){var switch__7885__auto__ = ((function (c__7992__auto___19887){
return (function (state_19865){
var state_val_19866 = (state_19865[(1)]);
if((state_val_19866 === (7))){
var inst_19861 = (state_19865[(2)]);
var state_19865__$1 = state_19865;
var statearr_19867_19888 = state_19865__$1;
(statearr_19867_19888[(2)] = inst_19861);

(statearr_19867_19888[(1)] = (3));


return cljs.core.cst$kw$recur;
} else {
if((state_val_19866 === (1))){
var state_19865__$1 = state_19865;
var statearr_19868_19889 = state_19865__$1;
(statearr_19868_19889[(2)] = null);

(statearr_19868_19889[(1)] = (2));


return cljs.core.cst$kw$recur;
} else {
if((state_val_19866 === (4))){
var inst_19844 = (state_19865[(7)]);
var inst_19844__$1 = (state_19865[(2)]);
var inst_19845 = (inst_19844__$1 == null);
var state_19865__$1 = (function (){var statearr_19869 = state_19865;
(statearr_19869[(7)] = inst_19844__$1);

return statearr_19869;
})();
if(cljs.core.truth_(inst_19845)){
var statearr_19870_19890 = state_19865__$1;
(statearr_19870_19890[(1)] = (5));

} else {
var statearr_19871_19891 = state_19865__$1;
(statearr_19871_19891[(1)] = (6));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_19866 === (13))){
var state_19865__$1 = state_19865;
var statearr_19872_19892 = state_19865__$1;
(statearr_19872_19892[(2)] = null);

(statearr_19872_19892[(1)] = (14));


return cljs.core.cst$kw$recur;
} else {
if((state_val_19866 === (6))){
var inst_19844 = (state_19865[(7)]);
var state_19865__$1 = state_19865;
return cljs.core.async.impl.ioc_helpers.put_BANG_(state_19865__$1,(11),to,inst_19844);
} else {
if((state_val_19866 === (3))){
var inst_19863 = (state_19865[(2)]);
var state_19865__$1 = state_19865;
return cljs.core.async.impl.ioc_helpers.return_chan(state_19865__$1,inst_19863);
} else {
if((state_val_19866 === (12))){
var state_19865__$1 = state_19865;
var statearr_19873_19893 = state_19865__$1;
(statearr_19873_19893[(2)] = null);

(statearr_19873_19893[(1)] = (2));


return cljs.core.cst$kw$recur;
} else {
if((state_val_19866 === (2))){
var state_19865__$1 = state_19865;
return cljs.core.async.impl.ioc_helpers.take_BANG_(state_19865__$1,(4),from);
} else {
if((state_val_19866 === (11))){
var inst_19854 = (state_19865[(2)]);
var state_19865__$1 = state_19865;
if(cljs.core.truth_(inst_19854)){
var statearr_19874_19894 = state_19865__$1;
(statearr_19874_19894[(1)] = (12));

} else {
var statearr_19875_19895 = state_19865__$1;
(statearr_19875_19895[(1)] = (13));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_19866 === (9))){
var state_19865__$1 = state_19865;
var statearr_19876_19896 = state_19865__$1;
(statearr_19876_19896[(2)] = null);

(statearr_19876_19896[(1)] = (10));


return cljs.core.cst$kw$recur;
} else {
if((state_val_19866 === (5))){
var state_19865__$1 = state_19865;
if(cljs.core.truth_(close_QMARK_)){
var statearr_19877_19897 = state_19865__$1;
(statearr_19877_19897[(1)] = (8));

} else {
var statearr_19878_19898 = state_19865__$1;
(statearr_19878_19898[(1)] = (9));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_19866 === (14))){
var inst_19859 = (state_19865[(2)]);
var state_19865__$1 = state_19865;
var statearr_19879_19899 = state_19865__$1;
(statearr_19879_19899[(2)] = inst_19859);

(statearr_19879_19899[(1)] = (7));


return cljs.core.cst$kw$recur;
} else {
if((state_val_19866 === (10))){
var inst_19851 = (state_19865[(2)]);
var state_19865__$1 = state_19865;
var statearr_19880_19900 = state_19865__$1;
(statearr_19880_19900[(2)] = inst_19851);

(statearr_19880_19900[(1)] = (7));


return cljs.core.cst$kw$recur;
} else {
if((state_val_19866 === (8))){
var inst_19848 = cljs.core.async.close_BANG_(to);
var state_19865__$1 = state_19865;
var statearr_19881_19901 = state_19865__$1;
(statearr_19881_19901[(2)] = inst_19848);

(statearr_19881_19901[(1)] = (10));


return cljs.core.cst$kw$recur;
} else {
return null;
}
}
}
}
}
}
}
}
}
}
}
}
}
}
});})(c__7992__auto___19887))
;
return ((function (switch__7885__auto__,c__7992__auto___19887){
return (function() {
var cljs$core$async$state_machine__7886__auto__ = null;
var cljs$core$async$state_machine__7886__auto____0 = (function (){
var statearr_19882 = [null,null,null,null,null,null,null,null];
(statearr_19882[(0)] = cljs$core$async$state_machine__7886__auto__);

(statearr_19882[(1)] = (1));

return statearr_19882;
});
var cljs$core$async$state_machine__7886__auto____1 = (function (state_19865){
while(true){
var ret_value__7887__auto__ = (function (){try{while(true){
var result__7888__auto__ = switch__7885__auto__(state_19865);
if(cljs.core.keyword_identical_QMARK_(result__7888__auto__,cljs.core.cst$kw$recur)){
continue;
} else {
return result__7888__auto__;
}
break;
}
}catch (e19883){if((e19883 instanceof Object)){
var ex__7889__auto__ = e19883;
var statearr_19884_19902 = state_19865;
(statearr_19884_19902[(5)] = ex__7889__auto__);


cljs.core.async.impl.ioc_helpers.process_exception(state_19865);

return cljs.core.cst$kw$recur;
} else {
throw e19883;

}
}})();
if(cljs.core.keyword_identical_QMARK_(ret_value__7887__auto__,cljs.core.cst$kw$recur)){
var G__19903 = state_19865;
state_19865 = G__19903;
continue;
} else {
return ret_value__7887__auto__;
}
break;
}
});
cljs$core$async$state_machine__7886__auto__ = function(state_19865){
switch(arguments.length){
case 0:
return cljs$core$async$state_machine__7886__auto____0.call(this);
case 1:
return cljs$core$async$state_machine__7886__auto____1.call(this,state_19865);
}
throw(new Error('Invalid arity: ' + arguments.length));
};
cljs$core$async$state_machine__7886__auto__.cljs$core$IFn$_invoke$arity$0 = cljs$core$async$state_machine__7886__auto____0;
cljs$core$async$state_machine__7886__auto__.cljs$core$IFn$_invoke$arity$1 = cljs$core$async$state_machine__7886__auto____1;
return cljs$core$async$state_machine__7886__auto__;
})()
;})(switch__7885__auto__,c__7992__auto___19887))
})();
var state__7994__auto__ = (function (){var statearr_19885 = (f__7993__auto__.cljs$core$IFn$_invoke$arity$0 ? f__7993__auto__.cljs$core$IFn$_invoke$arity$0() : f__7993__auto__.call(null));
(statearr_19885[(6)] = c__7992__auto___19887);

return statearr_19885;
})();
return cljs.core.async.impl.ioc_helpers.run_state_machine_wrapped(state__7994__auto__);
});})(c__7992__auto___19887))
);


return to;
});

cljs.core.async.pipe.cljs$lang$maxFixedArity = 3;

cljs.core.async.pipeline_STAR_ = (function cljs$core$async$pipeline_STAR_(n,to,xf,from,close_QMARK_,ex_handler,type){

var jobs = cljs.core.async.chan.cljs$core$IFn$_invoke$arity$1(n);
var results = cljs.core.async.chan.cljs$core$IFn$_invoke$arity$1(n);
var process = ((function (jobs,results){
return (function (p__19904){
var vec__19905 = p__19904;
var v = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(vec__19905,(0),null);
var p = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(vec__19905,(1),null);
var job = vec__19905;
if((job == null)){
cljs.core.async.close_BANG_(results);

return null;
} else {
var res = cljs.core.async.chan.cljs$core$IFn$_invoke$arity$3((1),xf,ex_handler);
var c__7992__auto___20076 = cljs.core.async.chan.cljs$core$IFn$_invoke$arity$1((1));
cljs.core.async.impl.dispatch.run(((function (c__7992__auto___20076,res,vec__19905,v,p,job,jobs,results){
return (function (){
var f__7993__auto__ = (function (){var switch__7885__auto__ = ((function (c__7992__auto___20076,res,vec__19905,v,p,job,jobs,results){
return (function (state_19912){
var state_val_19913 = (state_19912[(1)]);
if((state_val_19913 === (1))){
var state_19912__$1 = state_19912;
return cljs.core.async.impl.ioc_helpers.put_BANG_(state_19912__$1,(2),res,v);
} else {
if((state_val_19913 === (2))){
var inst_19909 = (state_19912[(2)]);
var inst_19910 = cljs.core.async.close_BANG_(res);
var state_19912__$1 = (function (){var statearr_19914 = state_19912;
(statearr_19914[(7)] = inst_19909);

return statearr_19914;
})();
return cljs.core.async.impl.ioc_helpers.return_chan(state_19912__$1,inst_19910);
} else {
return null;
}
}
});})(c__7992__auto___20076,res,vec__19905,v,p,job,jobs,results))
;
return ((function (switch__7885__auto__,c__7992__auto___20076,res,vec__19905,v,p,job,jobs,results){
return (function() {
var cljs$core$async$pipeline_STAR__$_state_machine__7886__auto__ = null;
var cljs$core$async$pipeline_STAR__$_state_machine__7886__auto____0 = (function (){
var statearr_19915 = [null,null,null,null,null,null,null,null];
(statearr_19915[(0)] = cljs$core$async$pipeline_STAR__$_state_machine__7886__auto__);

(statearr_19915[(1)] = (1));

return statearr_19915;
});
var cljs$core$async$pipeline_STAR__$_state_machine__7886__auto____1 = (function (state_19912){
while(true){
var ret_value__7887__auto__ = (function (){try{while(true){
var result__7888__auto__ = switch__7885__auto__(state_19912);
if(cljs.core.keyword_identical_QMARK_(result__7888__auto__,cljs.core.cst$kw$recur)){
continue;
} else {
return result__7888__auto__;
}
break;
}
}catch (e19916){if((e19916 instanceof Object)){
var ex__7889__auto__ = e19916;
var statearr_19917_20077 = state_19912;
(statearr_19917_20077[(5)] = ex__7889__auto__);


cljs.core.async.impl.ioc_helpers.process_exception(state_19912);

return cljs.core.cst$kw$recur;
} else {
throw e19916;

}
}})();
if(cljs.core.keyword_identical_QMARK_(ret_value__7887__auto__,cljs.core.cst$kw$recur)){
var G__20078 = state_19912;
state_19912 = G__20078;
continue;
} else {
return ret_value__7887__auto__;
}
break;
}
});
cljs$core$async$pipeline_STAR__$_state_machine__7886__auto__ = function(state_19912){
switch(arguments.length){
case 0:
return cljs$core$async$pipeline_STAR__$_state_machine__7886__auto____0.call(this);
case 1:
return cljs$core$async$pipeline_STAR__$_state_machine__7886__auto____1.call(this,state_19912);
}
throw(new Error('Invalid arity: ' + arguments.length));
};
cljs$core$async$pipeline_STAR__$_state_machine__7886__auto__.cljs$core$IFn$_invoke$arity$0 = cljs$core$async$pipeline_STAR__$_state_machine__7886__auto____0;
cljs$core$async$pipeline_STAR__$_state_machine__7886__auto__.cljs$core$IFn$_invoke$arity$1 = cljs$core$async$pipeline_STAR__$_state_machine__7886__auto____1;
return cljs$core$async$pipeline_STAR__$_state_machine__7886__auto__;
})()
;})(switch__7885__auto__,c__7992__auto___20076,res,vec__19905,v,p,job,jobs,results))
})();
var state__7994__auto__ = (function (){var statearr_19918 = (f__7993__auto__.cljs$core$IFn$_invoke$arity$0 ? f__7993__auto__.cljs$core$IFn$_invoke$arity$0() : f__7993__auto__.call(null));
(statearr_19918[(6)] = c__7992__auto___20076);

return statearr_19918;
})();
return cljs.core.async.impl.ioc_helpers.run_state_machine_wrapped(state__7994__auto__);
});})(c__7992__auto___20076,res,vec__19905,v,p,job,jobs,results))
);


cljs.core.async.put_BANG_.cljs$core$IFn$_invoke$arity$2(p,res);

return true;
}
});})(jobs,results))
;
var async = ((function (jobs,results,process){
return (function (p__19919){
var vec__19920 = p__19919;
var v = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(vec__19920,(0),null);
var p = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(vec__19920,(1),null);
var job = vec__19920;
if((job == null)){
cljs.core.async.close_BANG_(results);

return null;
} else {
var res = cljs.core.async.chan.cljs$core$IFn$_invoke$arity$1((1));
(xf.cljs$core$IFn$_invoke$arity$2 ? xf.cljs$core$IFn$_invoke$arity$2(v,res) : xf.call(null,v,res));

cljs.core.async.put_BANG_.cljs$core$IFn$_invoke$arity$2(p,res);

return true;
}
});})(jobs,results,process))
;
var n__4518__auto___20079 = n;
var __20080 = (0);
while(true){
if((__20080 < n__4518__auto___20079)){
var G__19923_20081 = type;
var G__19923_20082__$1 = (((G__19923_20081 instanceof cljs.core.Keyword))?G__19923_20081.fqn:null);
switch (G__19923_20082__$1) {
case "compute":
var c__7992__auto___20084 = cljs.core.async.chan.cljs$core$IFn$_invoke$arity$1((1));
cljs.core.async.impl.dispatch.run(((function (__20080,c__7992__auto___20084,G__19923_20081,G__19923_20082__$1,n__4518__auto___20079,jobs,results,process,async){
return (function (){
var f__7993__auto__ = (function (){var switch__7885__auto__ = ((function (__20080,c__7992__auto___20084,G__19923_20081,G__19923_20082__$1,n__4518__auto___20079,jobs,results,process,async){
return (function (state_19936){
var state_val_19937 = (state_19936[(1)]);
if((state_val_19937 === (1))){
var state_19936__$1 = state_19936;
var statearr_19938_20085 = state_19936__$1;
(statearr_19938_20085[(2)] = null);

(statearr_19938_20085[(1)] = (2));


return cljs.core.cst$kw$recur;
} else {
if((state_val_19937 === (2))){
var state_19936__$1 = state_19936;
return cljs.core.async.impl.ioc_helpers.take_BANG_(state_19936__$1,(4),jobs);
} else {
if((state_val_19937 === (3))){
var inst_19934 = (state_19936[(2)]);
var state_19936__$1 = state_19936;
return cljs.core.async.impl.ioc_helpers.return_chan(state_19936__$1,inst_19934);
} else {
if((state_val_19937 === (4))){
var inst_19926 = (state_19936[(2)]);
var inst_19927 = process(inst_19926);
var state_19936__$1 = state_19936;
if(cljs.core.truth_(inst_19927)){
var statearr_19939_20086 = state_19936__$1;
(statearr_19939_20086[(1)] = (5));

} else {
var statearr_19940_20087 = state_19936__$1;
(statearr_19940_20087[(1)] = (6));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_19937 === (5))){
var state_19936__$1 = state_19936;
var statearr_19941_20088 = state_19936__$1;
(statearr_19941_20088[(2)] = null);

(statearr_19941_20088[(1)] = (2));


return cljs.core.cst$kw$recur;
} else {
if((state_val_19937 === (6))){
var state_19936__$1 = state_19936;
var statearr_19942_20089 = state_19936__$1;
(statearr_19942_20089[(2)] = null);

(statearr_19942_20089[(1)] = (7));


return cljs.core.cst$kw$recur;
} else {
if((state_val_19937 === (7))){
var inst_19932 = (state_19936[(2)]);
var state_19936__$1 = state_19936;
var statearr_19943_20090 = state_19936__$1;
(statearr_19943_20090[(2)] = inst_19932);

(statearr_19943_20090[(1)] = (3));


return cljs.core.cst$kw$recur;
} else {
return null;
}
}
}
}
}
}
}
});})(__20080,c__7992__auto___20084,G__19923_20081,G__19923_20082__$1,n__4518__auto___20079,jobs,results,process,async))
;
return ((function (__20080,switch__7885__auto__,c__7992__auto___20084,G__19923_20081,G__19923_20082__$1,n__4518__auto___20079,jobs,results,process,async){
return (function() {
var cljs$core$async$pipeline_STAR__$_state_machine__7886__auto__ = null;
var cljs$core$async$pipeline_STAR__$_state_machine__7886__auto____0 = (function (){
var statearr_19944 = [null,null,null,null,null,null,null];
(statearr_19944[(0)] = cljs$core$async$pipeline_STAR__$_state_machine__7886__auto__);

(statearr_19944[(1)] = (1));

return statearr_19944;
});
var cljs$core$async$pipeline_STAR__$_state_machine__7886__auto____1 = (function (state_19936){
while(true){
var ret_value__7887__auto__ = (function (){try{while(true){
var result__7888__auto__ = switch__7885__auto__(state_19936);
if(cljs.core.keyword_identical_QMARK_(result__7888__auto__,cljs.core.cst$kw$recur)){
continue;
} else {
return result__7888__auto__;
}
break;
}
}catch (e19945){if((e19945 instanceof Object)){
var ex__7889__auto__ = e19945;
var statearr_19946_20091 = state_19936;
(statearr_19946_20091[(5)] = ex__7889__auto__);


cljs.core.async.impl.ioc_helpers.process_exception(state_19936);

return cljs.core.cst$kw$recur;
} else {
throw e19945;

}
}})();
if(cljs.core.keyword_identical_QMARK_(ret_value__7887__auto__,cljs.core.cst$kw$recur)){
var G__20092 = state_19936;
state_19936 = G__20092;
continue;
} else {
return ret_value__7887__auto__;
}
break;
}
});
cljs$core$async$pipeline_STAR__$_state_machine__7886__auto__ = function(state_19936){
switch(arguments.length){
case 0:
return cljs$core$async$pipeline_STAR__$_state_machine__7886__auto____0.call(this);
case 1:
return cljs$core$async$pipeline_STAR__$_state_machine__7886__auto____1.call(this,state_19936);
}
throw(new Error('Invalid arity: ' + arguments.length));
};
cljs$core$async$pipeline_STAR__$_state_machine__7886__auto__.cljs$core$IFn$_invoke$arity$0 = cljs$core$async$pipeline_STAR__$_state_machine__7886__auto____0;
cljs$core$async$pipeline_STAR__$_state_machine__7886__auto__.cljs$core$IFn$_invoke$arity$1 = cljs$core$async$pipeline_STAR__$_state_machine__7886__auto____1;
return cljs$core$async$pipeline_STAR__$_state_machine__7886__auto__;
})()
;})(__20080,switch__7885__auto__,c__7992__auto___20084,G__19923_20081,G__19923_20082__$1,n__4518__auto___20079,jobs,results,process,async))
})();
var state__7994__auto__ = (function (){var statearr_19947 = (f__7993__auto__.cljs$core$IFn$_invoke$arity$0 ? f__7993__auto__.cljs$core$IFn$_invoke$arity$0() : f__7993__auto__.call(null));
(statearr_19947[(6)] = c__7992__auto___20084);

return statearr_19947;
})();
return cljs.core.async.impl.ioc_helpers.run_state_machine_wrapped(state__7994__auto__);
});})(__20080,c__7992__auto___20084,G__19923_20081,G__19923_20082__$1,n__4518__auto___20079,jobs,results,process,async))
);


break;
case "async":
var c__7992__auto___20093 = cljs.core.async.chan.cljs$core$IFn$_invoke$arity$1((1));
cljs.core.async.impl.dispatch.run(((function (__20080,c__7992__auto___20093,G__19923_20081,G__19923_20082__$1,n__4518__auto___20079,jobs,results,process,async){
return (function (){
var f__7993__auto__ = (function (){var switch__7885__auto__ = ((function (__20080,c__7992__auto___20093,G__19923_20081,G__19923_20082__$1,n__4518__auto___20079,jobs,results,process,async){
return (function (state_19960){
var state_val_19961 = (state_19960[(1)]);
if((state_val_19961 === (1))){
var state_19960__$1 = state_19960;
var statearr_19962_20094 = state_19960__$1;
(statearr_19962_20094[(2)] = null);

(statearr_19962_20094[(1)] = (2));


return cljs.core.cst$kw$recur;
} else {
if((state_val_19961 === (2))){
var state_19960__$1 = state_19960;
return cljs.core.async.impl.ioc_helpers.take_BANG_(state_19960__$1,(4),jobs);
} else {
if((state_val_19961 === (3))){
var inst_19958 = (state_19960[(2)]);
var state_19960__$1 = state_19960;
return cljs.core.async.impl.ioc_helpers.return_chan(state_19960__$1,inst_19958);
} else {
if((state_val_19961 === (4))){
var inst_19950 = (state_19960[(2)]);
var inst_19951 = async(inst_19950);
var state_19960__$1 = state_19960;
if(cljs.core.truth_(inst_19951)){
var statearr_19963_20095 = state_19960__$1;
(statearr_19963_20095[(1)] = (5));

} else {
var statearr_19964_20096 = state_19960__$1;
(statearr_19964_20096[(1)] = (6));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_19961 === (5))){
var state_19960__$1 = state_19960;
var statearr_19965_20097 = state_19960__$1;
(statearr_19965_20097[(2)] = null);

(statearr_19965_20097[(1)] = (2));


return cljs.core.cst$kw$recur;
} else {
if((state_val_19961 === (6))){
var state_19960__$1 = state_19960;
var statearr_19966_20098 = state_19960__$1;
(statearr_19966_20098[(2)] = null);

(statearr_19966_20098[(1)] = (7));


return cljs.core.cst$kw$recur;
} else {
if((state_val_19961 === (7))){
var inst_19956 = (state_19960[(2)]);
var state_19960__$1 = state_19960;
var statearr_19967_20099 = state_19960__$1;
(statearr_19967_20099[(2)] = inst_19956);

(statearr_19967_20099[(1)] = (3));


return cljs.core.cst$kw$recur;
} else {
return null;
}
}
}
}
}
}
}
});})(__20080,c__7992__auto___20093,G__19923_20081,G__19923_20082__$1,n__4518__auto___20079,jobs,results,process,async))
;
return ((function (__20080,switch__7885__auto__,c__7992__auto___20093,G__19923_20081,G__19923_20082__$1,n__4518__auto___20079,jobs,results,process,async){
return (function() {
var cljs$core$async$pipeline_STAR__$_state_machine__7886__auto__ = null;
var cljs$core$async$pipeline_STAR__$_state_machine__7886__auto____0 = (function (){
var statearr_19968 = [null,null,null,null,null,null,null];
(statearr_19968[(0)] = cljs$core$async$pipeline_STAR__$_state_machine__7886__auto__);

(statearr_19968[(1)] = (1));

return statearr_19968;
});
var cljs$core$async$pipeline_STAR__$_state_machine__7886__auto____1 = (function (state_19960){
while(true){
var ret_value__7887__auto__ = (function (){try{while(true){
var result__7888__auto__ = switch__7885__auto__(state_19960);
if(cljs.core.keyword_identical_QMARK_(result__7888__auto__,cljs.core.cst$kw$recur)){
continue;
} else {
return result__7888__auto__;
}
break;
}
}catch (e19969){if((e19969 instanceof Object)){
var ex__7889__auto__ = e19969;
var statearr_19970_20100 = state_19960;
(statearr_19970_20100[(5)] = ex__7889__auto__);


cljs.core.async.impl.ioc_helpers.process_exception(state_19960);

return cljs.core.cst$kw$recur;
} else {
throw e19969;

}
}})();
if(cljs.core.keyword_identical_QMARK_(ret_value__7887__auto__,cljs.core.cst$kw$recur)){
var G__20101 = state_19960;
state_19960 = G__20101;
continue;
} else {
return ret_value__7887__auto__;
}
break;
}
});
cljs$core$async$pipeline_STAR__$_state_machine__7886__auto__ = function(state_19960){
switch(arguments.length){
case 0:
return cljs$core$async$pipeline_STAR__$_state_machine__7886__auto____0.call(this);
case 1:
return cljs$core$async$pipeline_STAR__$_state_machine__7886__auto____1.call(this,state_19960);
}
throw(new Error('Invalid arity: ' + arguments.length));
};
cljs$core$async$pipeline_STAR__$_state_machine__7886__auto__.cljs$core$IFn$_invoke$arity$0 = cljs$core$async$pipeline_STAR__$_state_machine__7886__auto____0;
cljs$core$async$pipeline_STAR__$_state_machine__7886__auto__.cljs$core$IFn$_invoke$arity$1 = cljs$core$async$pipeline_STAR__$_state_machine__7886__auto____1;
return cljs$core$async$pipeline_STAR__$_state_machine__7886__auto__;
})()
;})(__20080,switch__7885__auto__,c__7992__auto___20093,G__19923_20081,G__19923_20082__$1,n__4518__auto___20079,jobs,results,process,async))
})();
var state__7994__auto__ = (function (){var statearr_19971 = (f__7993__auto__.cljs$core$IFn$_invoke$arity$0 ? f__7993__auto__.cljs$core$IFn$_invoke$arity$0() : f__7993__auto__.call(null));
(statearr_19971[(6)] = c__7992__auto___20093);

return statearr_19971;
})();
return cljs.core.async.impl.ioc_helpers.run_state_machine_wrapped(state__7994__auto__);
});})(__20080,c__7992__auto___20093,G__19923_20081,G__19923_20082__$1,n__4518__auto___20079,jobs,results,process,async))
);


break;
default:
throw (new Error(["No matching clause: ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(G__19923_20082__$1)].join('')));

}

var G__20102 = (__20080 + (1));
__20080 = G__20102;
continue;
} else {
}
break;
}

var c__7992__auto___20103 = cljs.core.async.chan.cljs$core$IFn$_invoke$arity$1((1));
cljs.core.async.impl.dispatch.run(((function (c__7992__auto___20103,jobs,results,process,async){
return (function (){
var f__7993__auto__ = (function (){var switch__7885__auto__ = ((function (c__7992__auto___20103,jobs,results,process,async){
return (function (state_19993){
var state_val_19994 = (state_19993[(1)]);
if((state_val_19994 === (1))){
var state_19993__$1 = state_19993;
var statearr_19995_20104 = state_19993__$1;
(statearr_19995_20104[(2)] = null);

(statearr_19995_20104[(1)] = (2));


return cljs.core.cst$kw$recur;
} else {
if((state_val_19994 === (2))){
var state_19993__$1 = state_19993;
return cljs.core.async.impl.ioc_helpers.take_BANG_(state_19993__$1,(4),from);
} else {
if((state_val_19994 === (3))){
var inst_19991 = (state_19993[(2)]);
var state_19993__$1 = state_19993;
return cljs.core.async.impl.ioc_helpers.return_chan(state_19993__$1,inst_19991);
} else {
if((state_val_19994 === (4))){
var inst_19974 = (state_19993[(7)]);
var inst_19974__$1 = (state_19993[(2)]);
var inst_19975 = (inst_19974__$1 == null);
var state_19993__$1 = (function (){var statearr_19996 = state_19993;
(statearr_19996[(7)] = inst_19974__$1);

return statearr_19996;
})();
if(cljs.core.truth_(inst_19975)){
var statearr_19997_20105 = state_19993__$1;
(statearr_19997_20105[(1)] = (5));

} else {
var statearr_19998_20106 = state_19993__$1;
(statearr_19998_20106[(1)] = (6));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_19994 === (5))){
var inst_19977 = cljs.core.async.close_BANG_(jobs);
var state_19993__$1 = state_19993;
var statearr_19999_20107 = state_19993__$1;
(statearr_19999_20107[(2)] = inst_19977);

(statearr_19999_20107[(1)] = (7));


return cljs.core.cst$kw$recur;
} else {
if((state_val_19994 === (6))){
var inst_19979 = (state_19993[(8)]);
var inst_19974 = (state_19993[(7)]);
var inst_19979__$1 = cljs.core.async.chan.cljs$core$IFn$_invoke$arity$1((1));
var inst_19980 = cljs.core.PersistentVector.EMPTY_NODE;
var inst_19981 = [inst_19974,inst_19979__$1];
var inst_19982 = (new cljs.core.PersistentVector(null,2,(5),inst_19980,inst_19981,null));
var state_19993__$1 = (function (){var statearr_20000 = state_19993;
(statearr_20000[(8)] = inst_19979__$1);

return statearr_20000;
})();
return cljs.core.async.impl.ioc_helpers.put_BANG_(state_19993__$1,(8),jobs,inst_19982);
} else {
if((state_val_19994 === (7))){
var inst_19989 = (state_19993[(2)]);
var state_19993__$1 = state_19993;
var statearr_20001_20108 = state_19993__$1;
(statearr_20001_20108[(2)] = inst_19989);

(statearr_20001_20108[(1)] = (3));


return cljs.core.cst$kw$recur;
} else {
if((state_val_19994 === (8))){
var inst_19979 = (state_19993[(8)]);
var inst_19984 = (state_19993[(2)]);
var state_19993__$1 = (function (){var statearr_20002 = state_19993;
(statearr_20002[(9)] = inst_19984);

return statearr_20002;
})();
return cljs.core.async.impl.ioc_helpers.put_BANG_(state_19993__$1,(9),results,inst_19979);
} else {
if((state_val_19994 === (9))){
var inst_19986 = (state_19993[(2)]);
var state_19993__$1 = (function (){var statearr_20003 = state_19993;
(statearr_20003[(10)] = inst_19986);

return statearr_20003;
})();
var statearr_20004_20109 = state_19993__$1;
(statearr_20004_20109[(2)] = null);

(statearr_20004_20109[(1)] = (2));


return cljs.core.cst$kw$recur;
} else {
return null;
}
}
}
}
}
}
}
}
}
});})(c__7992__auto___20103,jobs,results,process,async))
;
return ((function (switch__7885__auto__,c__7992__auto___20103,jobs,results,process,async){
return (function() {
var cljs$core$async$pipeline_STAR__$_state_machine__7886__auto__ = null;
var cljs$core$async$pipeline_STAR__$_state_machine__7886__auto____0 = (function (){
var statearr_20005 = [null,null,null,null,null,null,null,null,null,null,null];
(statearr_20005[(0)] = cljs$core$async$pipeline_STAR__$_state_machine__7886__auto__);

(statearr_20005[(1)] = (1));

return statearr_20005;
});
var cljs$core$async$pipeline_STAR__$_state_machine__7886__auto____1 = (function (state_19993){
while(true){
var ret_value__7887__auto__ = (function (){try{while(true){
var result__7888__auto__ = switch__7885__auto__(state_19993);
if(cljs.core.keyword_identical_QMARK_(result__7888__auto__,cljs.core.cst$kw$recur)){
continue;
} else {
return result__7888__auto__;
}
break;
}
}catch (e20006){if((e20006 instanceof Object)){
var ex__7889__auto__ = e20006;
var statearr_20007_20110 = state_19993;
(statearr_20007_20110[(5)] = ex__7889__auto__);


cljs.core.async.impl.ioc_helpers.process_exception(state_19993);

return cljs.core.cst$kw$recur;
} else {
throw e20006;

}
}})();
if(cljs.core.keyword_identical_QMARK_(ret_value__7887__auto__,cljs.core.cst$kw$recur)){
var G__20111 = state_19993;
state_19993 = G__20111;
continue;
} else {
return ret_value__7887__auto__;
}
break;
}
});
cljs$core$async$pipeline_STAR__$_state_machine__7886__auto__ = function(state_19993){
switch(arguments.length){
case 0:
return cljs$core$async$pipeline_STAR__$_state_machine__7886__auto____0.call(this);
case 1:
return cljs$core$async$pipeline_STAR__$_state_machine__7886__auto____1.call(this,state_19993);
}
throw(new Error('Invalid arity: ' + arguments.length));
};
cljs$core$async$pipeline_STAR__$_state_machine__7886__auto__.cljs$core$IFn$_invoke$arity$0 = cljs$core$async$pipeline_STAR__$_state_machine__7886__auto____0;
cljs$core$async$pipeline_STAR__$_state_machine__7886__auto__.cljs$core$IFn$_invoke$arity$1 = cljs$core$async$pipeline_STAR__$_state_machine__7886__auto____1;
return cljs$core$async$pipeline_STAR__$_state_machine__7886__auto__;
})()
;})(switch__7885__auto__,c__7992__auto___20103,jobs,results,process,async))
})();
var state__7994__auto__ = (function (){var statearr_20008 = (f__7993__auto__.cljs$core$IFn$_invoke$arity$0 ? f__7993__auto__.cljs$core$IFn$_invoke$arity$0() : f__7993__auto__.call(null));
(statearr_20008[(6)] = c__7992__auto___20103);

return statearr_20008;
})();
return cljs.core.async.impl.ioc_helpers.run_state_machine_wrapped(state__7994__auto__);
});})(c__7992__auto___20103,jobs,results,process,async))
);


var c__7992__auto__ = cljs.core.async.chan.cljs$core$IFn$_invoke$arity$1((1));
cljs.core.async.impl.dispatch.run(((function (c__7992__auto__,jobs,results,process,async){
return (function (){
var f__7993__auto__ = (function (){var switch__7885__auto__ = ((function (c__7992__auto__,jobs,results,process,async){
return (function (state_20046){
var state_val_20047 = (state_20046[(1)]);
if((state_val_20047 === (7))){
var inst_20042 = (state_20046[(2)]);
var state_20046__$1 = state_20046;
var statearr_20048_20112 = state_20046__$1;
(statearr_20048_20112[(2)] = inst_20042);

(statearr_20048_20112[(1)] = (3));


return cljs.core.cst$kw$recur;
} else {
if((state_val_20047 === (20))){
var state_20046__$1 = state_20046;
var statearr_20049_20113 = state_20046__$1;
(statearr_20049_20113[(2)] = null);

(statearr_20049_20113[(1)] = (21));


return cljs.core.cst$kw$recur;
} else {
if((state_val_20047 === (1))){
var state_20046__$1 = state_20046;
var statearr_20050_20114 = state_20046__$1;
(statearr_20050_20114[(2)] = null);

(statearr_20050_20114[(1)] = (2));


return cljs.core.cst$kw$recur;
} else {
if((state_val_20047 === (4))){
var inst_20011 = (state_20046[(7)]);
var inst_20011__$1 = (state_20046[(2)]);
var inst_20012 = (inst_20011__$1 == null);
var state_20046__$1 = (function (){var statearr_20051 = state_20046;
(statearr_20051[(7)] = inst_20011__$1);

return statearr_20051;
})();
if(cljs.core.truth_(inst_20012)){
var statearr_20052_20115 = state_20046__$1;
(statearr_20052_20115[(1)] = (5));

} else {
var statearr_20053_20116 = state_20046__$1;
(statearr_20053_20116[(1)] = (6));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_20047 === (15))){
var inst_20024 = (state_20046[(8)]);
var state_20046__$1 = state_20046;
return cljs.core.async.impl.ioc_helpers.put_BANG_(state_20046__$1,(18),to,inst_20024);
} else {
if((state_val_20047 === (21))){
var inst_20037 = (state_20046[(2)]);
var state_20046__$1 = state_20046;
var statearr_20054_20117 = state_20046__$1;
(statearr_20054_20117[(2)] = inst_20037);

(statearr_20054_20117[(1)] = (13));


return cljs.core.cst$kw$recur;
} else {
if((state_val_20047 === (13))){
var inst_20039 = (state_20046[(2)]);
var state_20046__$1 = (function (){var statearr_20055 = state_20046;
(statearr_20055[(9)] = inst_20039);

return statearr_20055;
})();
var statearr_20056_20118 = state_20046__$1;
(statearr_20056_20118[(2)] = null);

(statearr_20056_20118[(1)] = (2));


return cljs.core.cst$kw$recur;
} else {
if((state_val_20047 === (6))){
var inst_20011 = (state_20046[(7)]);
var state_20046__$1 = state_20046;
return cljs.core.async.impl.ioc_helpers.take_BANG_(state_20046__$1,(11),inst_20011);
} else {
if((state_val_20047 === (17))){
var inst_20032 = (state_20046[(2)]);
var state_20046__$1 = state_20046;
if(cljs.core.truth_(inst_20032)){
var statearr_20057_20119 = state_20046__$1;
(statearr_20057_20119[(1)] = (19));

} else {
var statearr_20058_20120 = state_20046__$1;
(statearr_20058_20120[(1)] = (20));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_20047 === (3))){
var inst_20044 = (state_20046[(2)]);
var state_20046__$1 = state_20046;
return cljs.core.async.impl.ioc_helpers.return_chan(state_20046__$1,inst_20044);
} else {
if((state_val_20047 === (12))){
var inst_20021 = (state_20046[(10)]);
var state_20046__$1 = state_20046;
return cljs.core.async.impl.ioc_helpers.take_BANG_(state_20046__$1,(14),inst_20021);
} else {
if((state_val_20047 === (2))){
var state_20046__$1 = state_20046;
return cljs.core.async.impl.ioc_helpers.take_BANG_(state_20046__$1,(4),results);
} else {
if((state_val_20047 === (19))){
var state_20046__$1 = state_20046;
var statearr_20059_20121 = state_20046__$1;
(statearr_20059_20121[(2)] = null);

(statearr_20059_20121[(1)] = (12));


return cljs.core.cst$kw$recur;
} else {
if((state_val_20047 === (11))){
var inst_20021 = (state_20046[(2)]);
var state_20046__$1 = (function (){var statearr_20060 = state_20046;
(statearr_20060[(10)] = inst_20021);

return statearr_20060;
})();
var statearr_20061_20122 = state_20046__$1;
(statearr_20061_20122[(2)] = null);

(statearr_20061_20122[(1)] = (12));


return cljs.core.cst$kw$recur;
} else {
if((state_val_20047 === (9))){
var state_20046__$1 = state_20046;
var statearr_20062_20123 = state_20046__$1;
(statearr_20062_20123[(2)] = null);

(statearr_20062_20123[(1)] = (10));


return cljs.core.cst$kw$recur;
} else {
if((state_val_20047 === (5))){
var state_20046__$1 = state_20046;
if(cljs.core.truth_(close_QMARK_)){
var statearr_20063_20124 = state_20046__$1;
(statearr_20063_20124[(1)] = (8));

} else {
var statearr_20064_20125 = state_20046__$1;
(statearr_20064_20125[(1)] = (9));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_20047 === (14))){
var inst_20026 = (state_20046[(11)]);
var inst_20024 = (state_20046[(8)]);
var inst_20024__$1 = (state_20046[(2)]);
var inst_20025 = (inst_20024__$1 == null);
var inst_20026__$1 = cljs.core.not(inst_20025);
var state_20046__$1 = (function (){var statearr_20065 = state_20046;
(statearr_20065[(11)] = inst_20026__$1);

(statearr_20065[(8)] = inst_20024__$1);

return statearr_20065;
})();
if(inst_20026__$1){
var statearr_20066_20126 = state_20046__$1;
(statearr_20066_20126[(1)] = (15));

} else {
var statearr_20067_20127 = state_20046__$1;
(statearr_20067_20127[(1)] = (16));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_20047 === (16))){
var inst_20026 = (state_20046[(11)]);
var state_20046__$1 = state_20046;
var statearr_20068_20128 = state_20046__$1;
(statearr_20068_20128[(2)] = inst_20026);

(statearr_20068_20128[(1)] = (17));


return cljs.core.cst$kw$recur;
} else {
if((state_val_20047 === (10))){
var inst_20018 = (state_20046[(2)]);
var state_20046__$1 = state_20046;
var statearr_20069_20129 = state_20046__$1;
(statearr_20069_20129[(2)] = inst_20018);

(statearr_20069_20129[(1)] = (7));


return cljs.core.cst$kw$recur;
} else {
if((state_val_20047 === (18))){
var inst_20029 = (state_20046[(2)]);
var state_20046__$1 = state_20046;
var statearr_20070_20130 = state_20046__$1;
(statearr_20070_20130[(2)] = inst_20029);

(statearr_20070_20130[(1)] = (17));


return cljs.core.cst$kw$recur;
} else {
if((state_val_20047 === (8))){
var inst_20015 = cljs.core.async.close_BANG_(to);
var state_20046__$1 = state_20046;
var statearr_20071_20131 = state_20046__$1;
(statearr_20071_20131[(2)] = inst_20015);

(statearr_20071_20131[(1)] = (10));


return cljs.core.cst$kw$recur;
} else {
return null;
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
});})(c__7992__auto__,jobs,results,process,async))
;
return ((function (switch__7885__auto__,c__7992__auto__,jobs,results,process,async){
return (function() {
var cljs$core$async$pipeline_STAR__$_state_machine__7886__auto__ = null;
var cljs$core$async$pipeline_STAR__$_state_machine__7886__auto____0 = (function (){
var statearr_20072 = [null,null,null,null,null,null,null,null,null,null,null,null];
(statearr_20072[(0)] = cljs$core$async$pipeline_STAR__$_state_machine__7886__auto__);

(statearr_20072[(1)] = (1));

return statearr_20072;
});
var cljs$core$async$pipeline_STAR__$_state_machine__7886__auto____1 = (function (state_20046){
while(true){
var ret_value__7887__auto__ = (function (){try{while(true){
var result__7888__auto__ = switch__7885__auto__(state_20046);
if(cljs.core.keyword_identical_QMARK_(result__7888__auto__,cljs.core.cst$kw$recur)){
continue;
} else {
return result__7888__auto__;
}
break;
}
}catch (e20073){if((e20073 instanceof Object)){
var ex__7889__auto__ = e20073;
var statearr_20074_20132 = state_20046;
(statearr_20074_20132[(5)] = ex__7889__auto__);


cljs.core.async.impl.ioc_helpers.process_exception(state_20046);

return cljs.core.cst$kw$recur;
} else {
throw e20073;

}
}})();
if(cljs.core.keyword_identical_QMARK_(ret_value__7887__auto__,cljs.core.cst$kw$recur)){
var G__20133 = state_20046;
state_20046 = G__20133;
continue;
} else {
return ret_value__7887__auto__;
}
break;
}
});
cljs$core$async$pipeline_STAR__$_state_machine__7886__auto__ = function(state_20046){
switch(arguments.length){
case 0:
return cljs$core$async$pipeline_STAR__$_state_machine__7886__auto____0.call(this);
case 1:
return cljs$core$async$pipeline_STAR__$_state_machine__7886__auto____1.call(this,state_20046);
}
throw(new Error('Invalid arity: ' + arguments.length));
};
cljs$core$async$pipeline_STAR__$_state_machine__7886__auto__.cljs$core$IFn$_invoke$arity$0 = cljs$core$async$pipeline_STAR__$_state_machine__7886__auto____0;
cljs$core$async$pipeline_STAR__$_state_machine__7886__auto__.cljs$core$IFn$_invoke$arity$1 = cljs$core$async$pipeline_STAR__$_state_machine__7886__auto____1;
return cljs$core$async$pipeline_STAR__$_state_machine__7886__auto__;
})()
;})(switch__7885__auto__,c__7992__auto__,jobs,results,process,async))
})();
var state__7994__auto__ = (function (){var statearr_20075 = (f__7993__auto__.cljs$core$IFn$_invoke$arity$0 ? f__7993__auto__.cljs$core$IFn$_invoke$arity$0() : f__7993__auto__.call(null));
(statearr_20075[(6)] = c__7992__auto__);

return statearr_20075;
})();
return cljs.core.async.impl.ioc_helpers.run_state_machine_wrapped(state__7994__auto__);
});})(c__7992__auto__,jobs,results,process,async))
);

return c__7992__auto__;
});
/**
 * Takes elements from the from channel and supplies them to the to
 *   channel, subject to the async function af, with parallelism n. af
 *   must be a function of two arguments, the first an input value and
 *   the second a channel on which to place the result(s). af must close!
 *   the channel before returning.  The presumption is that af will
 *   return immediately, having launched some asynchronous operation
 *   whose completion/callback will manipulate the result channel. Outputs
 *   will be returned in order relative to  the inputs. By default, the to
 *   channel will be closed when the from channel closes, but can be
 *   determined by the close?  parameter. Will stop consuming the from
 *   channel if the to channel closes.
 */
cljs.core.async.pipeline_async = (function cljs$core$async$pipeline_async(var_args){
var G__20135 = arguments.length;
switch (G__20135) {
case 4:
return cljs.core.async.pipeline_async.cljs$core$IFn$_invoke$arity$4((arguments[(0)]),(arguments[(1)]),(arguments[(2)]),(arguments[(3)]));

break;
case 5:
return cljs.core.async.pipeline_async.cljs$core$IFn$_invoke$arity$5((arguments[(0)]),(arguments[(1)]),(arguments[(2)]),(arguments[(3)]),(arguments[(4)]));

break;
default:
throw (new Error(["Invalid arity: ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(arguments.length)].join('')));

}
});

cljs.core.async.pipeline_async.cljs$core$IFn$_invoke$arity$4 = (function (n,to,af,from){
return cljs.core.async.pipeline_async.cljs$core$IFn$_invoke$arity$5(n,to,af,from,true);
});

cljs.core.async.pipeline_async.cljs$core$IFn$_invoke$arity$5 = (function (n,to,af,from,close_QMARK_){
return cljs.core.async.pipeline_STAR_(n,to,af,from,close_QMARK_,null,cljs.core.cst$kw$async);
});

cljs.core.async.pipeline_async.cljs$lang$maxFixedArity = 5;

/**
 * Takes elements from the from channel and supplies them to the to
 *   channel, subject to the transducer xf, with parallelism n. Because
 *   it is parallel, the transducer will be applied independently to each
 *   element, not across elements, and may produce zero or more outputs
 *   per input.  Outputs will be returned in order relative to the
 *   inputs. By default, the to channel will be closed when the from
 *   channel closes, but can be determined by the close?  parameter. Will
 *   stop consuming the from channel if the to channel closes.
 * 
 *   Note this is supplied for API compatibility with the Clojure version.
 *   Values of N > 1 will not result in actual concurrency in a
 *   single-threaded runtime.
 */
cljs.core.async.pipeline = (function cljs$core$async$pipeline(var_args){
var G__20138 = arguments.length;
switch (G__20138) {
case 4:
return cljs.core.async.pipeline.cljs$core$IFn$_invoke$arity$4((arguments[(0)]),(arguments[(1)]),(arguments[(2)]),(arguments[(3)]));

break;
case 5:
return cljs.core.async.pipeline.cljs$core$IFn$_invoke$arity$5((arguments[(0)]),(arguments[(1)]),(arguments[(2)]),(arguments[(3)]),(arguments[(4)]));

break;
case 6:
return cljs.core.async.pipeline.cljs$core$IFn$_invoke$arity$6((arguments[(0)]),(arguments[(1)]),(arguments[(2)]),(arguments[(3)]),(arguments[(4)]),(arguments[(5)]));

break;
default:
throw (new Error(["Invalid arity: ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(arguments.length)].join('')));

}
});

cljs.core.async.pipeline.cljs$core$IFn$_invoke$arity$4 = (function (n,to,xf,from){
return cljs.core.async.pipeline.cljs$core$IFn$_invoke$arity$5(n,to,xf,from,true);
});

cljs.core.async.pipeline.cljs$core$IFn$_invoke$arity$5 = (function (n,to,xf,from,close_QMARK_){
return cljs.core.async.pipeline.cljs$core$IFn$_invoke$arity$6(n,to,xf,from,close_QMARK_,null);
});

cljs.core.async.pipeline.cljs$core$IFn$_invoke$arity$6 = (function (n,to,xf,from,close_QMARK_,ex_handler){
return cljs.core.async.pipeline_STAR_(n,to,xf,from,close_QMARK_,ex_handler,cljs.core.cst$kw$compute);
});

cljs.core.async.pipeline.cljs$lang$maxFixedArity = 6;

/**
 * Takes a predicate and a source channel and returns a vector of two
 *   channels, the first of which will contain the values for which the
 *   predicate returned true, the second those for which it returned
 *   false.
 * 
 *   The out channels will be unbuffered by default, or two buf-or-ns can
 *   be supplied. The channels will close after the source channel has
 *   closed.
 */
cljs.core.async.split = (function cljs$core$async$split(var_args){
var G__20141 = arguments.length;
switch (G__20141) {
case 2:
return cljs.core.async.split.cljs$core$IFn$_invoke$arity$2((arguments[(0)]),(arguments[(1)]));

break;
case 4:
return cljs.core.async.split.cljs$core$IFn$_invoke$arity$4((arguments[(0)]),(arguments[(1)]),(arguments[(2)]),(arguments[(3)]));

break;
default:
throw (new Error(["Invalid arity: ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(arguments.length)].join('')));

}
});

cljs.core.async.split.cljs$core$IFn$_invoke$arity$2 = (function (p,ch){
return cljs.core.async.split.cljs$core$IFn$_invoke$arity$4(p,ch,null,null);
});

cljs.core.async.split.cljs$core$IFn$_invoke$arity$4 = (function (p,ch,t_buf_or_n,f_buf_or_n){
var tc = cljs.core.async.chan.cljs$core$IFn$_invoke$arity$1(t_buf_or_n);
var fc = cljs.core.async.chan.cljs$core$IFn$_invoke$arity$1(f_buf_or_n);
var c__7992__auto___20190 = cljs.core.async.chan.cljs$core$IFn$_invoke$arity$1((1));
cljs.core.async.impl.dispatch.run(((function (c__7992__auto___20190,tc,fc){
return (function (){
var f__7993__auto__ = (function (){var switch__7885__auto__ = ((function (c__7992__auto___20190,tc,fc){
return (function (state_20167){
var state_val_20168 = (state_20167[(1)]);
if((state_val_20168 === (7))){
var inst_20163 = (state_20167[(2)]);
var state_20167__$1 = state_20167;
var statearr_20169_20191 = state_20167__$1;
(statearr_20169_20191[(2)] = inst_20163);

(statearr_20169_20191[(1)] = (3));


return cljs.core.cst$kw$recur;
} else {
if((state_val_20168 === (1))){
var state_20167__$1 = state_20167;
var statearr_20170_20192 = state_20167__$1;
(statearr_20170_20192[(2)] = null);

(statearr_20170_20192[(1)] = (2));


return cljs.core.cst$kw$recur;
} else {
if((state_val_20168 === (4))){
var inst_20144 = (state_20167[(7)]);
var inst_20144__$1 = (state_20167[(2)]);
var inst_20145 = (inst_20144__$1 == null);
var state_20167__$1 = (function (){var statearr_20171 = state_20167;
(statearr_20171[(7)] = inst_20144__$1);

return statearr_20171;
})();
if(cljs.core.truth_(inst_20145)){
var statearr_20172_20193 = state_20167__$1;
(statearr_20172_20193[(1)] = (5));

} else {
var statearr_20173_20194 = state_20167__$1;
(statearr_20173_20194[(1)] = (6));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_20168 === (13))){
var state_20167__$1 = state_20167;
var statearr_20174_20195 = state_20167__$1;
(statearr_20174_20195[(2)] = null);

(statearr_20174_20195[(1)] = (14));


return cljs.core.cst$kw$recur;
} else {
if((state_val_20168 === (6))){
var inst_20144 = (state_20167[(7)]);
var inst_20150 = (p.cljs$core$IFn$_invoke$arity$1 ? p.cljs$core$IFn$_invoke$arity$1(inst_20144) : p.call(null,inst_20144));
var state_20167__$1 = state_20167;
if(cljs.core.truth_(inst_20150)){
var statearr_20175_20196 = state_20167__$1;
(statearr_20175_20196[(1)] = (9));

} else {
var statearr_20176_20197 = state_20167__$1;
(statearr_20176_20197[(1)] = (10));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_20168 === (3))){
var inst_20165 = (state_20167[(2)]);
var state_20167__$1 = state_20167;
return cljs.core.async.impl.ioc_helpers.return_chan(state_20167__$1,inst_20165);
} else {
if((state_val_20168 === (12))){
var state_20167__$1 = state_20167;
var statearr_20177_20198 = state_20167__$1;
(statearr_20177_20198[(2)] = null);

(statearr_20177_20198[(1)] = (2));


return cljs.core.cst$kw$recur;
} else {
if((state_val_20168 === (2))){
var state_20167__$1 = state_20167;
return cljs.core.async.impl.ioc_helpers.take_BANG_(state_20167__$1,(4),ch);
} else {
if((state_val_20168 === (11))){
var inst_20144 = (state_20167[(7)]);
var inst_20154 = (state_20167[(2)]);
var state_20167__$1 = state_20167;
return cljs.core.async.impl.ioc_helpers.put_BANG_(state_20167__$1,(8),inst_20154,inst_20144);
} else {
if((state_val_20168 === (9))){
var state_20167__$1 = state_20167;
var statearr_20178_20199 = state_20167__$1;
(statearr_20178_20199[(2)] = tc);

(statearr_20178_20199[(1)] = (11));


return cljs.core.cst$kw$recur;
} else {
if((state_val_20168 === (5))){
var inst_20147 = cljs.core.async.close_BANG_(tc);
var inst_20148 = cljs.core.async.close_BANG_(fc);
var state_20167__$1 = (function (){var statearr_20179 = state_20167;
(statearr_20179[(8)] = inst_20147);

return statearr_20179;
})();
var statearr_20180_20200 = state_20167__$1;
(statearr_20180_20200[(2)] = inst_20148);

(statearr_20180_20200[(1)] = (7));


return cljs.core.cst$kw$recur;
} else {
if((state_val_20168 === (14))){
var inst_20161 = (state_20167[(2)]);
var state_20167__$1 = state_20167;
var statearr_20181_20201 = state_20167__$1;
(statearr_20181_20201[(2)] = inst_20161);

(statearr_20181_20201[(1)] = (7));


return cljs.core.cst$kw$recur;
} else {
if((state_val_20168 === (10))){
var state_20167__$1 = state_20167;
var statearr_20182_20202 = state_20167__$1;
(statearr_20182_20202[(2)] = fc);

(statearr_20182_20202[(1)] = (11));


return cljs.core.cst$kw$recur;
} else {
if((state_val_20168 === (8))){
var inst_20156 = (state_20167[(2)]);
var state_20167__$1 = state_20167;
if(cljs.core.truth_(inst_20156)){
var statearr_20183_20203 = state_20167__$1;
(statearr_20183_20203[(1)] = (12));

} else {
var statearr_20184_20204 = state_20167__$1;
(statearr_20184_20204[(1)] = (13));

}

return cljs.core.cst$kw$recur;
} else {
return null;
}
}
}
}
}
}
}
}
}
}
}
}
}
}
});})(c__7992__auto___20190,tc,fc))
;
return ((function (switch__7885__auto__,c__7992__auto___20190,tc,fc){
return (function() {
var cljs$core$async$state_machine__7886__auto__ = null;
var cljs$core$async$state_machine__7886__auto____0 = (function (){
var statearr_20185 = [null,null,null,null,null,null,null,null,null];
(statearr_20185[(0)] = cljs$core$async$state_machine__7886__auto__);

(statearr_20185[(1)] = (1));

return statearr_20185;
});
var cljs$core$async$state_machine__7886__auto____1 = (function (state_20167){
while(true){
var ret_value__7887__auto__ = (function (){try{while(true){
var result__7888__auto__ = switch__7885__auto__(state_20167);
if(cljs.core.keyword_identical_QMARK_(result__7888__auto__,cljs.core.cst$kw$recur)){
continue;
} else {
return result__7888__auto__;
}
break;
}
}catch (e20186){if((e20186 instanceof Object)){
var ex__7889__auto__ = e20186;
var statearr_20187_20205 = state_20167;
(statearr_20187_20205[(5)] = ex__7889__auto__);


cljs.core.async.impl.ioc_helpers.process_exception(state_20167);

return cljs.core.cst$kw$recur;
} else {
throw e20186;

}
}})();
if(cljs.core.keyword_identical_QMARK_(ret_value__7887__auto__,cljs.core.cst$kw$recur)){
var G__20206 = state_20167;
state_20167 = G__20206;
continue;
} else {
return ret_value__7887__auto__;
}
break;
}
});
cljs$core$async$state_machine__7886__auto__ = function(state_20167){
switch(arguments.length){
case 0:
return cljs$core$async$state_machine__7886__auto____0.call(this);
case 1:
return cljs$core$async$state_machine__7886__auto____1.call(this,state_20167);
}
throw(new Error('Invalid arity: ' + arguments.length));
};
cljs$core$async$state_machine__7886__auto__.cljs$core$IFn$_invoke$arity$0 = cljs$core$async$state_machine__7886__auto____0;
cljs$core$async$state_machine__7886__auto__.cljs$core$IFn$_invoke$arity$1 = cljs$core$async$state_machine__7886__auto____1;
return cljs$core$async$state_machine__7886__auto__;
})()
;})(switch__7885__auto__,c__7992__auto___20190,tc,fc))
})();
var state__7994__auto__ = (function (){var statearr_20188 = (f__7993__auto__.cljs$core$IFn$_invoke$arity$0 ? f__7993__auto__.cljs$core$IFn$_invoke$arity$0() : f__7993__auto__.call(null));
(statearr_20188[(6)] = c__7992__auto___20190);

return statearr_20188;
})();
return cljs.core.async.impl.ioc_helpers.run_state_machine_wrapped(state__7994__auto__);
});})(c__7992__auto___20190,tc,fc))
);


return new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [tc,fc], null);
});

cljs.core.async.split.cljs$lang$maxFixedArity = 4;

/**
 * f should be a function of 2 arguments. Returns a channel containing
 *   the single result of applying f to init and the first item from the
 *   channel, then applying f to that result and the 2nd item, etc. If
 *   the channel closes without yielding items, returns init and f is not
 *   called. ch must close before reduce produces a result.
 */
cljs.core.async.reduce = (function cljs$core$async$reduce(f,init,ch){
var c__7992__auto__ = cljs.core.async.chan.cljs$core$IFn$_invoke$arity$1((1));
cljs.core.async.impl.dispatch.run(((function (c__7992__auto__){
return (function (){
var f__7993__auto__ = (function (){var switch__7885__auto__ = ((function (c__7992__auto__){
return (function (state_20227){
var state_val_20228 = (state_20227[(1)]);
if((state_val_20228 === (7))){
var inst_20223 = (state_20227[(2)]);
var state_20227__$1 = state_20227;
var statearr_20229_20247 = state_20227__$1;
(statearr_20229_20247[(2)] = inst_20223);

(statearr_20229_20247[(1)] = (3));


return cljs.core.cst$kw$recur;
} else {
if((state_val_20228 === (1))){
var inst_20207 = init;
var state_20227__$1 = (function (){var statearr_20230 = state_20227;
(statearr_20230[(7)] = inst_20207);

return statearr_20230;
})();
var statearr_20231_20248 = state_20227__$1;
(statearr_20231_20248[(2)] = null);

(statearr_20231_20248[(1)] = (2));


return cljs.core.cst$kw$recur;
} else {
if((state_val_20228 === (4))){
var inst_20210 = (state_20227[(8)]);
var inst_20210__$1 = (state_20227[(2)]);
var inst_20211 = (inst_20210__$1 == null);
var state_20227__$1 = (function (){var statearr_20232 = state_20227;
(statearr_20232[(8)] = inst_20210__$1);

return statearr_20232;
})();
if(cljs.core.truth_(inst_20211)){
var statearr_20233_20249 = state_20227__$1;
(statearr_20233_20249[(1)] = (5));

} else {
var statearr_20234_20250 = state_20227__$1;
(statearr_20234_20250[(1)] = (6));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_20228 === (6))){
var inst_20207 = (state_20227[(7)]);
var inst_20210 = (state_20227[(8)]);
var inst_20214 = (state_20227[(9)]);
var inst_20214__$1 = (f.cljs$core$IFn$_invoke$arity$2 ? f.cljs$core$IFn$_invoke$arity$2(inst_20207,inst_20210) : f.call(null,inst_20207,inst_20210));
var inst_20215 = cljs.core.reduced_QMARK_(inst_20214__$1);
var state_20227__$1 = (function (){var statearr_20235 = state_20227;
(statearr_20235[(9)] = inst_20214__$1);

return statearr_20235;
})();
if(inst_20215){
var statearr_20236_20251 = state_20227__$1;
(statearr_20236_20251[(1)] = (8));

} else {
var statearr_20237_20252 = state_20227__$1;
(statearr_20237_20252[(1)] = (9));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_20228 === (3))){
var inst_20225 = (state_20227[(2)]);
var state_20227__$1 = state_20227;
return cljs.core.async.impl.ioc_helpers.return_chan(state_20227__$1,inst_20225);
} else {
if((state_val_20228 === (2))){
var state_20227__$1 = state_20227;
return cljs.core.async.impl.ioc_helpers.take_BANG_(state_20227__$1,(4),ch);
} else {
if((state_val_20228 === (9))){
var inst_20214 = (state_20227[(9)]);
var inst_20207 = inst_20214;
var state_20227__$1 = (function (){var statearr_20238 = state_20227;
(statearr_20238[(7)] = inst_20207);

return statearr_20238;
})();
var statearr_20239_20253 = state_20227__$1;
(statearr_20239_20253[(2)] = null);

(statearr_20239_20253[(1)] = (2));


return cljs.core.cst$kw$recur;
} else {
if((state_val_20228 === (5))){
var inst_20207 = (state_20227[(7)]);
var state_20227__$1 = state_20227;
var statearr_20240_20254 = state_20227__$1;
(statearr_20240_20254[(2)] = inst_20207);

(statearr_20240_20254[(1)] = (7));


return cljs.core.cst$kw$recur;
} else {
if((state_val_20228 === (10))){
var inst_20221 = (state_20227[(2)]);
var state_20227__$1 = state_20227;
var statearr_20241_20255 = state_20227__$1;
(statearr_20241_20255[(2)] = inst_20221);

(statearr_20241_20255[(1)] = (7));


return cljs.core.cst$kw$recur;
} else {
if((state_val_20228 === (8))){
var inst_20214 = (state_20227[(9)]);
var inst_20217 = cljs.core.deref(inst_20214);
var state_20227__$1 = state_20227;
var statearr_20242_20256 = state_20227__$1;
(statearr_20242_20256[(2)] = inst_20217);

(statearr_20242_20256[(1)] = (10));


return cljs.core.cst$kw$recur;
} else {
return null;
}
}
}
}
}
}
}
}
}
}
});})(c__7992__auto__))
;
return ((function (switch__7885__auto__,c__7992__auto__){
return (function() {
var cljs$core$async$reduce_$_state_machine__7886__auto__ = null;
var cljs$core$async$reduce_$_state_machine__7886__auto____0 = (function (){
var statearr_20243 = [null,null,null,null,null,null,null,null,null,null];
(statearr_20243[(0)] = cljs$core$async$reduce_$_state_machine__7886__auto__);

(statearr_20243[(1)] = (1));

return statearr_20243;
});
var cljs$core$async$reduce_$_state_machine__7886__auto____1 = (function (state_20227){
while(true){
var ret_value__7887__auto__ = (function (){try{while(true){
var result__7888__auto__ = switch__7885__auto__(state_20227);
if(cljs.core.keyword_identical_QMARK_(result__7888__auto__,cljs.core.cst$kw$recur)){
continue;
} else {
return result__7888__auto__;
}
break;
}
}catch (e20244){if((e20244 instanceof Object)){
var ex__7889__auto__ = e20244;
var statearr_20245_20257 = state_20227;
(statearr_20245_20257[(5)] = ex__7889__auto__);


cljs.core.async.impl.ioc_helpers.process_exception(state_20227);

return cljs.core.cst$kw$recur;
} else {
throw e20244;

}
}})();
if(cljs.core.keyword_identical_QMARK_(ret_value__7887__auto__,cljs.core.cst$kw$recur)){
var G__20258 = state_20227;
state_20227 = G__20258;
continue;
} else {
return ret_value__7887__auto__;
}
break;
}
});
cljs$core$async$reduce_$_state_machine__7886__auto__ = function(state_20227){
switch(arguments.length){
case 0:
return cljs$core$async$reduce_$_state_machine__7886__auto____0.call(this);
case 1:
return cljs$core$async$reduce_$_state_machine__7886__auto____1.call(this,state_20227);
}
throw(new Error('Invalid arity: ' + arguments.length));
};
cljs$core$async$reduce_$_state_machine__7886__auto__.cljs$core$IFn$_invoke$arity$0 = cljs$core$async$reduce_$_state_machine__7886__auto____0;
cljs$core$async$reduce_$_state_machine__7886__auto__.cljs$core$IFn$_invoke$arity$1 = cljs$core$async$reduce_$_state_machine__7886__auto____1;
return cljs$core$async$reduce_$_state_machine__7886__auto__;
})()
;})(switch__7885__auto__,c__7992__auto__))
})();
var state__7994__auto__ = (function (){var statearr_20246 = (f__7993__auto__.cljs$core$IFn$_invoke$arity$0 ? f__7993__auto__.cljs$core$IFn$_invoke$arity$0() : f__7993__auto__.call(null));
(statearr_20246[(6)] = c__7992__auto__);

return statearr_20246;
})();
return cljs.core.async.impl.ioc_helpers.run_state_machine_wrapped(state__7994__auto__);
});})(c__7992__auto__))
);

return c__7992__auto__;
});
/**
 * async/reduces a channel with a transformation (xform f).
 *   Returns a channel containing the result.  ch must close before
 *   transduce produces a result.
 */
cljs.core.async.transduce = (function cljs$core$async$transduce(xform,f,init,ch){
var f__$1 = (xform.cljs$core$IFn$_invoke$arity$1 ? xform.cljs$core$IFn$_invoke$arity$1(f) : xform.call(null,f));
var c__7992__auto__ = cljs.core.async.chan.cljs$core$IFn$_invoke$arity$1((1));
cljs.core.async.impl.dispatch.run(((function (c__7992__auto__,f__$1){
return (function (){
var f__7993__auto__ = (function (){var switch__7885__auto__ = ((function (c__7992__auto__,f__$1){
return (function (state_20264){
var state_val_20265 = (state_20264[(1)]);
if((state_val_20265 === (1))){
var inst_20259 = cljs.core.async.reduce(f__$1,init,ch);
var state_20264__$1 = state_20264;
return cljs.core.async.impl.ioc_helpers.take_BANG_(state_20264__$1,(2),inst_20259);
} else {
if((state_val_20265 === (2))){
var inst_20261 = (state_20264[(2)]);
var inst_20262 = (f__$1.cljs$core$IFn$_invoke$arity$1 ? f__$1.cljs$core$IFn$_invoke$arity$1(inst_20261) : f__$1.call(null,inst_20261));
var state_20264__$1 = state_20264;
return cljs.core.async.impl.ioc_helpers.return_chan(state_20264__$1,inst_20262);
} else {
return null;
}
}
});})(c__7992__auto__,f__$1))
;
return ((function (switch__7885__auto__,c__7992__auto__,f__$1){
return (function() {
var cljs$core$async$transduce_$_state_machine__7886__auto__ = null;
var cljs$core$async$transduce_$_state_machine__7886__auto____0 = (function (){
var statearr_20266 = [null,null,null,null,null,null,null];
(statearr_20266[(0)] = cljs$core$async$transduce_$_state_machine__7886__auto__);

(statearr_20266[(1)] = (1));

return statearr_20266;
});
var cljs$core$async$transduce_$_state_machine__7886__auto____1 = (function (state_20264){
while(true){
var ret_value__7887__auto__ = (function (){try{while(true){
var result__7888__auto__ = switch__7885__auto__(state_20264);
if(cljs.core.keyword_identical_QMARK_(result__7888__auto__,cljs.core.cst$kw$recur)){
continue;
} else {
return result__7888__auto__;
}
break;
}
}catch (e20267){if((e20267 instanceof Object)){
var ex__7889__auto__ = e20267;
var statearr_20268_20270 = state_20264;
(statearr_20268_20270[(5)] = ex__7889__auto__);


cljs.core.async.impl.ioc_helpers.process_exception(state_20264);

return cljs.core.cst$kw$recur;
} else {
throw e20267;

}
}})();
if(cljs.core.keyword_identical_QMARK_(ret_value__7887__auto__,cljs.core.cst$kw$recur)){
var G__20271 = state_20264;
state_20264 = G__20271;
continue;
} else {
return ret_value__7887__auto__;
}
break;
}
});
cljs$core$async$transduce_$_state_machine__7886__auto__ = function(state_20264){
switch(arguments.length){
case 0:
return cljs$core$async$transduce_$_state_machine__7886__auto____0.call(this);
case 1:
return cljs$core$async$transduce_$_state_machine__7886__auto____1.call(this,state_20264);
}
throw(new Error('Invalid arity: ' + arguments.length));
};
cljs$core$async$transduce_$_state_machine__7886__auto__.cljs$core$IFn$_invoke$arity$0 = cljs$core$async$transduce_$_state_machine__7886__auto____0;
cljs$core$async$transduce_$_state_machine__7886__auto__.cljs$core$IFn$_invoke$arity$1 = cljs$core$async$transduce_$_state_machine__7886__auto____1;
return cljs$core$async$transduce_$_state_machine__7886__auto__;
})()
;})(switch__7885__auto__,c__7992__auto__,f__$1))
})();
var state__7994__auto__ = (function (){var statearr_20269 = (f__7993__auto__.cljs$core$IFn$_invoke$arity$0 ? f__7993__auto__.cljs$core$IFn$_invoke$arity$0() : f__7993__auto__.call(null));
(statearr_20269[(6)] = c__7992__auto__);

return statearr_20269;
})();
return cljs.core.async.impl.ioc_helpers.run_state_machine_wrapped(state__7994__auto__);
});})(c__7992__auto__,f__$1))
);

return c__7992__auto__;
});
/**
 * Puts the contents of coll into the supplied channel.
 * 
 *   By default the channel will be closed after the items are copied,
 *   but can be determined by the close? parameter.
 * 
 *   Returns a channel which will close after the items are copied.
 */
cljs.core.async.onto_chan = (function cljs$core$async$onto_chan(var_args){
var G__20273 = arguments.length;
switch (G__20273) {
case 2:
return cljs.core.async.onto_chan.cljs$core$IFn$_invoke$arity$2((arguments[(0)]),(arguments[(1)]));

break;
case 3:
return cljs.core.async.onto_chan.cljs$core$IFn$_invoke$arity$3((arguments[(0)]),(arguments[(1)]),(arguments[(2)]));

break;
default:
throw (new Error(["Invalid arity: ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(arguments.length)].join('')));

}
});

cljs.core.async.onto_chan.cljs$core$IFn$_invoke$arity$2 = (function (ch,coll){
return cljs.core.async.onto_chan.cljs$core$IFn$_invoke$arity$3(ch,coll,true);
});

cljs.core.async.onto_chan.cljs$core$IFn$_invoke$arity$3 = (function (ch,coll,close_QMARK_){
var c__7992__auto__ = cljs.core.async.chan.cljs$core$IFn$_invoke$arity$1((1));
cljs.core.async.impl.dispatch.run(((function (c__7992__auto__){
return (function (){
var f__7993__auto__ = (function (){var switch__7885__auto__ = ((function (c__7992__auto__){
return (function (state_20298){
var state_val_20299 = (state_20298[(1)]);
if((state_val_20299 === (7))){
var inst_20280 = (state_20298[(2)]);
var state_20298__$1 = state_20298;
var statearr_20300_20321 = state_20298__$1;
(statearr_20300_20321[(2)] = inst_20280);

(statearr_20300_20321[(1)] = (6));


return cljs.core.cst$kw$recur;
} else {
if((state_val_20299 === (1))){
var inst_20274 = cljs.core.seq(coll);
var inst_20275 = inst_20274;
var state_20298__$1 = (function (){var statearr_20301 = state_20298;
(statearr_20301[(7)] = inst_20275);

return statearr_20301;
})();
var statearr_20302_20322 = state_20298__$1;
(statearr_20302_20322[(2)] = null);

(statearr_20302_20322[(1)] = (2));


return cljs.core.cst$kw$recur;
} else {
if((state_val_20299 === (4))){
var inst_20275 = (state_20298[(7)]);
var inst_20278 = cljs.core.first(inst_20275);
var state_20298__$1 = state_20298;
return cljs.core.async.impl.ioc_helpers.put_BANG_(state_20298__$1,(7),ch,inst_20278);
} else {
if((state_val_20299 === (13))){
var inst_20292 = (state_20298[(2)]);
var state_20298__$1 = state_20298;
var statearr_20303_20323 = state_20298__$1;
(statearr_20303_20323[(2)] = inst_20292);

(statearr_20303_20323[(1)] = (10));


return cljs.core.cst$kw$recur;
} else {
if((state_val_20299 === (6))){
var inst_20283 = (state_20298[(2)]);
var state_20298__$1 = state_20298;
if(cljs.core.truth_(inst_20283)){
var statearr_20304_20324 = state_20298__$1;
(statearr_20304_20324[(1)] = (8));

} else {
var statearr_20305_20325 = state_20298__$1;
(statearr_20305_20325[(1)] = (9));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_20299 === (3))){
var inst_20296 = (state_20298[(2)]);
var state_20298__$1 = state_20298;
return cljs.core.async.impl.ioc_helpers.return_chan(state_20298__$1,inst_20296);
} else {
if((state_val_20299 === (12))){
var state_20298__$1 = state_20298;
var statearr_20306_20326 = state_20298__$1;
(statearr_20306_20326[(2)] = null);

(statearr_20306_20326[(1)] = (13));


return cljs.core.cst$kw$recur;
} else {
if((state_val_20299 === (2))){
var inst_20275 = (state_20298[(7)]);
var state_20298__$1 = state_20298;
if(cljs.core.truth_(inst_20275)){
var statearr_20307_20327 = state_20298__$1;
(statearr_20307_20327[(1)] = (4));

} else {
var statearr_20308_20328 = state_20298__$1;
(statearr_20308_20328[(1)] = (5));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_20299 === (11))){
var inst_20289 = cljs.core.async.close_BANG_(ch);
var state_20298__$1 = state_20298;
var statearr_20309_20329 = state_20298__$1;
(statearr_20309_20329[(2)] = inst_20289);

(statearr_20309_20329[(1)] = (13));


return cljs.core.cst$kw$recur;
} else {
if((state_val_20299 === (9))){
var state_20298__$1 = state_20298;
if(cljs.core.truth_(close_QMARK_)){
var statearr_20310_20330 = state_20298__$1;
(statearr_20310_20330[(1)] = (11));

} else {
var statearr_20311_20331 = state_20298__$1;
(statearr_20311_20331[(1)] = (12));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_20299 === (5))){
var inst_20275 = (state_20298[(7)]);
var state_20298__$1 = state_20298;
var statearr_20312_20332 = state_20298__$1;
(statearr_20312_20332[(2)] = inst_20275);

(statearr_20312_20332[(1)] = (6));


return cljs.core.cst$kw$recur;
} else {
if((state_val_20299 === (10))){
var inst_20294 = (state_20298[(2)]);
var state_20298__$1 = state_20298;
var statearr_20313_20333 = state_20298__$1;
(statearr_20313_20333[(2)] = inst_20294);

(statearr_20313_20333[(1)] = (3));


return cljs.core.cst$kw$recur;
} else {
if((state_val_20299 === (8))){
var inst_20275 = (state_20298[(7)]);
var inst_20285 = cljs.core.next(inst_20275);
var inst_20275__$1 = inst_20285;
var state_20298__$1 = (function (){var statearr_20314 = state_20298;
(statearr_20314[(7)] = inst_20275__$1);

return statearr_20314;
})();
var statearr_20315_20334 = state_20298__$1;
(statearr_20315_20334[(2)] = null);

(statearr_20315_20334[(1)] = (2));


return cljs.core.cst$kw$recur;
} else {
return null;
}
}
}
}
}
}
}
}
}
}
}
}
}
});})(c__7992__auto__))
;
return ((function (switch__7885__auto__,c__7992__auto__){
return (function() {
var cljs$core$async$state_machine__7886__auto__ = null;
var cljs$core$async$state_machine__7886__auto____0 = (function (){
var statearr_20316 = [null,null,null,null,null,null,null,null];
(statearr_20316[(0)] = cljs$core$async$state_machine__7886__auto__);

(statearr_20316[(1)] = (1));

return statearr_20316;
});
var cljs$core$async$state_machine__7886__auto____1 = (function (state_20298){
while(true){
var ret_value__7887__auto__ = (function (){try{while(true){
var result__7888__auto__ = switch__7885__auto__(state_20298);
if(cljs.core.keyword_identical_QMARK_(result__7888__auto__,cljs.core.cst$kw$recur)){
continue;
} else {
return result__7888__auto__;
}
break;
}
}catch (e20317){if((e20317 instanceof Object)){
var ex__7889__auto__ = e20317;
var statearr_20318_20335 = state_20298;
(statearr_20318_20335[(5)] = ex__7889__auto__);


cljs.core.async.impl.ioc_helpers.process_exception(state_20298);

return cljs.core.cst$kw$recur;
} else {
throw e20317;

}
}})();
if(cljs.core.keyword_identical_QMARK_(ret_value__7887__auto__,cljs.core.cst$kw$recur)){
var G__20336 = state_20298;
state_20298 = G__20336;
continue;
} else {
return ret_value__7887__auto__;
}
break;
}
});
cljs$core$async$state_machine__7886__auto__ = function(state_20298){
switch(arguments.length){
case 0:
return cljs$core$async$state_machine__7886__auto____0.call(this);
case 1:
return cljs$core$async$state_machine__7886__auto____1.call(this,state_20298);
}
throw(new Error('Invalid arity: ' + arguments.length));
};
cljs$core$async$state_machine__7886__auto__.cljs$core$IFn$_invoke$arity$0 = cljs$core$async$state_machine__7886__auto____0;
cljs$core$async$state_machine__7886__auto__.cljs$core$IFn$_invoke$arity$1 = cljs$core$async$state_machine__7886__auto____1;
return cljs$core$async$state_machine__7886__auto__;
})()
;})(switch__7885__auto__,c__7992__auto__))
})();
var state__7994__auto__ = (function (){var statearr_20319 = (f__7993__auto__.cljs$core$IFn$_invoke$arity$0 ? f__7993__auto__.cljs$core$IFn$_invoke$arity$0() : f__7993__auto__.call(null));
(statearr_20319[(6)] = c__7992__auto__);

return statearr_20319;
})();
return cljs.core.async.impl.ioc_helpers.run_state_machine_wrapped(state__7994__auto__);
});})(c__7992__auto__))
);

return c__7992__auto__;
});

cljs.core.async.onto_chan.cljs$lang$maxFixedArity = 3;

/**
 * Creates and returns a channel which contains the contents of coll,
 *   closing when exhausted.
 */
cljs.core.async.to_chan = (function cljs$core$async$to_chan(coll){
var ch = cljs.core.async.chan.cljs$core$IFn$_invoke$arity$1(cljs.core.bounded_count((100),coll));
cljs.core.async.onto_chan.cljs$core$IFn$_invoke$arity$2(ch,coll);

return ch;
});

/**
 * @interface
 */
cljs.core.async.Mux = function(){};

cljs.core.async.muxch_STAR_ = (function cljs$core$async$muxch_STAR_(_){
if((((!((_ == null)))) && ((!((_.cljs$core$async$Mux$muxch_STAR_$arity$1 == null)))))){
return _.cljs$core$async$Mux$muxch_STAR_$arity$1(_);
} else {
var x__4347__auto__ = (((_ == null))?null:_);
var m__4348__auto__ = (cljs.core.async.muxch_STAR_[goog.typeOf(x__4347__auto__)]);
if((!((m__4348__auto__ == null)))){
return (m__4348__auto__.cljs$core$IFn$_invoke$arity$1 ? m__4348__auto__.cljs$core$IFn$_invoke$arity$1(_) : m__4348__auto__.call(null,_));
} else {
var m__4348__auto____$1 = (cljs.core.async.muxch_STAR_["_"]);
if((!((m__4348__auto____$1 == null)))){
return (m__4348__auto____$1.cljs$core$IFn$_invoke$arity$1 ? m__4348__auto____$1.cljs$core$IFn$_invoke$arity$1(_) : m__4348__auto____$1.call(null,_));
} else {
throw cljs.core.missing_protocol("Mux.muxch*",_);
}
}
}
});


/**
 * @interface
 */
cljs.core.async.Mult = function(){};

cljs.core.async.tap_STAR_ = (function cljs$core$async$tap_STAR_(m,ch,close_QMARK_){
if((((!((m == null)))) && ((!((m.cljs$core$async$Mult$tap_STAR_$arity$3 == null)))))){
return m.cljs$core$async$Mult$tap_STAR_$arity$3(m,ch,close_QMARK_);
} else {
var x__4347__auto__ = (((m == null))?null:m);
var m__4348__auto__ = (cljs.core.async.tap_STAR_[goog.typeOf(x__4347__auto__)]);
if((!((m__4348__auto__ == null)))){
return (m__4348__auto__.cljs$core$IFn$_invoke$arity$3 ? m__4348__auto__.cljs$core$IFn$_invoke$arity$3(m,ch,close_QMARK_) : m__4348__auto__.call(null,m,ch,close_QMARK_));
} else {
var m__4348__auto____$1 = (cljs.core.async.tap_STAR_["_"]);
if((!((m__4348__auto____$1 == null)))){
return (m__4348__auto____$1.cljs$core$IFn$_invoke$arity$3 ? m__4348__auto____$1.cljs$core$IFn$_invoke$arity$3(m,ch,close_QMARK_) : m__4348__auto____$1.call(null,m,ch,close_QMARK_));
} else {
throw cljs.core.missing_protocol("Mult.tap*",m);
}
}
}
});

cljs.core.async.untap_STAR_ = (function cljs$core$async$untap_STAR_(m,ch){
if((((!((m == null)))) && ((!((m.cljs$core$async$Mult$untap_STAR_$arity$2 == null)))))){
return m.cljs$core$async$Mult$untap_STAR_$arity$2(m,ch);
} else {
var x__4347__auto__ = (((m == null))?null:m);
var m__4348__auto__ = (cljs.core.async.untap_STAR_[goog.typeOf(x__4347__auto__)]);
if((!((m__4348__auto__ == null)))){
return (m__4348__auto__.cljs$core$IFn$_invoke$arity$2 ? m__4348__auto__.cljs$core$IFn$_invoke$arity$2(m,ch) : m__4348__auto__.call(null,m,ch));
} else {
var m__4348__auto____$1 = (cljs.core.async.untap_STAR_["_"]);
if((!((m__4348__auto____$1 == null)))){
return (m__4348__auto____$1.cljs$core$IFn$_invoke$arity$2 ? m__4348__auto____$1.cljs$core$IFn$_invoke$arity$2(m,ch) : m__4348__auto____$1.call(null,m,ch));
} else {
throw cljs.core.missing_protocol("Mult.untap*",m);
}
}
}
});

cljs.core.async.untap_all_STAR_ = (function cljs$core$async$untap_all_STAR_(m){
if((((!((m == null)))) && ((!((m.cljs$core$async$Mult$untap_all_STAR_$arity$1 == null)))))){
return m.cljs$core$async$Mult$untap_all_STAR_$arity$1(m);
} else {
var x__4347__auto__ = (((m == null))?null:m);
var m__4348__auto__ = (cljs.core.async.untap_all_STAR_[goog.typeOf(x__4347__auto__)]);
if((!((m__4348__auto__ == null)))){
return (m__4348__auto__.cljs$core$IFn$_invoke$arity$1 ? m__4348__auto__.cljs$core$IFn$_invoke$arity$1(m) : m__4348__auto__.call(null,m));
} else {
var m__4348__auto____$1 = (cljs.core.async.untap_all_STAR_["_"]);
if((!((m__4348__auto____$1 == null)))){
return (m__4348__auto____$1.cljs$core$IFn$_invoke$arity$1 ? m__4348__auto____$1.cljs$core$IFn$_invoke$arity$1(m) : m__4348__auto____$1.call(null,m));
} else {
throw cljs.core.missing_protocol("Mult.untap-all*",m);
}
}
}
});

/**
 * Creates and returns a mult(iple) of the supplied channel. Channels
 *   containing copies of the channel can be created with 'tap', and
 *   detached with 'untap'.
 * 
 *   Each item is distributed to all taps in parallel and synchronously,
 *   i.e. each tap must accept before the next item is distributed. Use
 *   buffering/windowing to prevent slow taps from holding up the mult.
 * 
 *   Items received when there are no taps get dropped.
 * 
 *   If a tap puts to a closed channel, it will be removed from the mult.
 */
cljs.core.async.mult = (function cljs$core$async$mult(ch){
var cs = cljs.core.atom.cljs$core$IFn$_invoke$arity$1(cljs.core.PersistentArrayMap.EMPTY);
var m = (function (){
if((typeof cljs !== 'undefined') && (typeof cljs.core !== 'undefined') && (typeof cljs.core.async !== 'undefined') && (typeof cljs.core.async.t_cljs$core$async20337 !== 'undefined')){
} else {

/**
* @constructor
 * @implements {cljs.core.async.Mult}
 * @implements {cljs.core.IMeta}
 * @implements {cljs.core.async.Mux}
 * @implements {cljs.core.IWithMeta}
*/
cljs.core.async.t_cljs$core$async20337 = (function (ch,cs,meta20338){
this.ch = ch;
this.cs = cs;
this.meta20338 = meta20338;
this.cljs$lang$protocol_mask$partition0$ = 393216;
this.cljs$lang$protocol_mask$partition1$ = 0;
});
cljs.core.async.t_cljs$core$async20337.prototype.cljs$core$IWithMeta$_with_meta$arity$2 = ((function (cs){
return (function (_20339,meta20338__$1){
var self__ = this;
var _20339__$1 = this;
return (new cljs.core.async.t_cljs$core$async20337(self__.ch,self__.cs,meta20338__$1));
});})(cs))
;

cljs.core.async.t_cljs$core$async20337.prototype.cljs$core$IMeta$_meta$arity$1 = ((function (cs){
return (function (_20339){
var self__ = this;
var _20339__$1 = this;
return self__.meta20338;
});})(cs))
;

cljs.core.async.t_cljs$core$async20337.prototype.cljs$core$async$Mux$ = cljs.core.PROTOCOL_SENTINEL;

cljs.core.async.t_cljs$core$async20337.prototype.cljs$core$async$Mux$muxch_STAR_$arity$1 = ((function (cs){
return (function (_){
var self__ = this;
var ___$1 = this;
return self__.ch;
});})(cs))
;

cljs.core.async.t_cljs$core$async20337.prototype.cljs$core$async$Mult$ = cljs.core.PROTOCOL_SENTINEL;

cljs.core.async.t_cljs$core$async20337.prototype.cljs$core$async$Mult$tap_STAR_$arity$3 = ((function (cs){
return (function (_,ch__$1,close_QMARK_){
var self__ = this;
var ___$1 = this;
cljs.core.swap_BANG_.cljs$core$IFn$_invoke$arity$4(self__.cs,cljs.core.assoc,ch__$1,close_QMARK_);

return null;
});})(cs))
;

cljs.core.async.t_cljs$core$async20337.prototype.cljs$core$async$Mult$untap_STAR_$arity$2 = ((function (cs){
return (function (_,ch__$1){
var self__ = this;
var ___$1 = this;
cljs.core.swap_BANG_.cljs$core$IFn$_invoke$arity$3(self__.cs,cljs.core.dissoc,ch__$1);

return null;
});})(cs))
;

cljs.core.async.t_cljs$core$async20337.prototype.cljs$core$async$Mult$untap_all_STAR_$arity$1 = ((function (cs){
return (function (_){
var self__ = this;
var ___$1 = this;
cljs.core.reset_BANG_(self__.cs,cljs.core.PersistentArrayMap.EMPTY);

return null;
});})(cs))
;

cljs.core.async.t_cljs$core$async20337.getBasis = ((function (cs){
return (function (){
return new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [cljs.core.cst$sym$ch,cljs.core.cst$sym$cs,cljs.core.cst$sym$meta20338], null);
});})(cs))
;

cljs.core.async.t_cljs$core$async20337.cljs$lang$type = true;

cljs.core.async.t_cljs$core$async20337.cljs$lang$ctorStr = "cljs.core.async/t_cljs$core$async20337";

cljs.core.async.t_cljs$core$async20337.cljs$lang$ctorPrWriter = ((function (cs){
return (function (this__4290__auto__,writer__4291__auto__,opt__4292__auto__){
return cljs.core._write(writer__4291__auto__,"cljs.core.async/t_cljs$core$async20337");
});})(cs))
;

/**
 * Positional factory function for cljs.core.async/t_cljs$core$async20337.
 */
cljs.core.async.__GT_t_cljs$core$async20337 = ((function (cs){
return (function cljs$core$async$mult_$___GT_t_cljs$core$async20337(ch__$1,cs__$1,meta20338){
return (new cljs.core.async.t_cljs$core$async20337(ch__$1,cs__$1,meta20338));
});})(cs))
;

}

return (new cljs.core.async.t_cljs$core$async20337(ch,cs,cljs.core.PersistentArrayMap.EMPTY));
})()
;
var dchan = cljs.core.async.chan.cljs$core$IFn$_invoke$arity$1((1));
var dctr = cljs.core.atom.cljs$core$IFn$_invoke$arity$1(null);
var done = ((function (cs,m,dchan,dctr){
return (function (_){
if((cljs.core.swap_BANG_.cljs$core$IFn$_invoke$arity$2(dctr,cljs.core.dec) === (0))){
return cljs.core.async.put_BANG_.cljs$core$IFn$_invoke$arity$2(dchan,true);
} else {
return null;
}
});})(cs,m,dchan,dctr))
;
var c__7992__auto___20559 = cljs.core.async.chan.cljs$core$IFn$_invoke$arity$1((1));
cljs.core.async.impl.dispatch.run(((function (c__7992__auto___20559,cs,m,dchan,dctr,done){
return (function (){
var f__7993__auto__ = (function (){var switch__7885__auto__ = ((function (c__7992__auto___20559,cs,m,dchan,dctr,done){
return (function (state_20474){
var state_val_20475 = (state_20474[(1)]);
if((state_val_20475 === (7))){
var inst_20470 = (state_20474[(2)]);
var state_20474__$1 = state_20474;
var statearr_20476_20560 = state_20474__$1;
(statearr_20476_20560[(2)] = inst_20470);

(statearr_20476_20560[(1)] = (3));


return cljs.core.cst$kw$recur;
} else {
if((state_val_20475 === (20))){
var inst_20373 = (state_20474[(7)]);
var inst_20385 = cljs.core.first(inst_20373);
var inst_20386 = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(inst_20385,(0),null);
var inst_20387 = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(inst_20385,(1),null);
var state_20474__$1 = (function (){var statearr_20477 = state_20474;
(statearr_20477[(8)] = inst_20386);

return statearr_20477;
})();
if(cljs.core.truth_(inst_20387)){
var statearr_20478_20561 = state_20474__$1;
(statearr_20478_20561[(1)] = (22));

} else {
var statearr_20479_20562 = state_20474__$1;
(statearr_20479_20562[(1)] = (23));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_20475 === (27))){
var inst_20342 = (state_20474[(9)]);
var inst_20417 = (state_20474[(10)]);
var inst_20422 = (state_20474[(11)]);
var inst_20415 = (state_20474[(12)]);
var inst_20422__$1 = cljs.core._nth.cljs$core$IFn$_invoke$arity$2(inst_20415,inst_20417);
var inst_20423 = cljs.core.async.put_BANG_.cljs$core$IFn$_invoke$arity$3(inst_20422__$1,inst_20342,done);
var state_20474__$1 = (function (){var statearr_20480 = state_20474;
(statearr_20480[(11)] = inst_20422__$1);

return statearr_20480;
})();
if(cljs.core.truth_(inst_20423)){
var statearr_20481_20563 = state_20474__$1;
(statearr_20481_20563[(1)] = (30));

} else {
var statearr_20482_20564 = state_20474__$1;
(statearr_20482_20564[(1)] = (31));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_20475 === (1))){
var state_20474__$1 = state_20474;
var statearr_20483_20565 = state_20474__$1;
(statearr_20483_20565[(2)] = null);

(statearr_20483_20565[(1)] = (2));


return cljs.core.cst$kw$recur;
} else {
if((state_val_20475 === (24))){
var inst_20373 = (state_20474[(7)]);
var inst_20392 = (state_20474[(2)]);
var inst_20393 = cljs.core.next(inst_20373);
var inst_20351 = inst_20393;
var inst_20352 = null;
var inst_20353 = (0);
var inst_20354 = (0);
var state_20474__$1 = (function (){var statearr_20484 = state_20474;
(statearr_20484[(13)] = inst_20354);

(statearr_20484[(14)] = inst_20392);

(statearr_20484[(15)] = inst_20351);

(statearr_20484[(16)] = inst_20352);

(statearr_20484[(17)] = inst_20353);

return statearr_20484;
})();
var statearr_20485_20566 = state_20474__$1;
(statearr_20485_20566[(2)] = null);

(statearr_20485_20566[(1)] = (8));


return cljs.core.cst$kw$recur;
} else {
if((state_val_20475 === (39))){
var state_20474__$1 = state_20474;
var statearr_20489_20567 = state_20474__$1;
(statearr_20489_20567[(2)] = null);

(statearr_20489_20567[(1)] = (41));


return cljs.core.cst$kw$recur;
} else {
if((state_val_20475 === (4))){
var inst_20342 = (state_20474[(9)]);
var inst_20342__$1 = (state_20474[(2)]);
var inst_20343 = (inst_20342__$1 == null);
var state_20474__$1 = (function (){var statearr_20490 = state_20474;
(statearr_20490[(9)] = inst_20342__$1);

return statearr_20490;
})();
if(cljs.core.truth_(inst_20343)){
var statearr_20491_20568 = state_20474__$1;
(statearr_20491_20568[(1)] = (5));

} else {
var statearr_20492_20569 = state_20474__$1;
(statearr_20492_20569[(1)] = (6));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_20475 === (15))){
var inst_20354 = (state_20474[(13)]);
var inst_20351 = (state_20474[(15)]);
var inst_20352 = (state_20474[(16)]);
var inst_20353 = (state_20474[(17)]);
var inst_20369 = (state_20474[(2)]);
var inst_20370 = (inst_20354 + (1));
var tmp20486 = inst_20351;
var tmp20487 = inst_20352;
var tmp20488 = inst_20353;
var inst_20351__$1 = tmp20486;
var inst_20352__$1 = tmp20487;
var inst_20353__$1 = tmp20488;
var inst_20354__$1 = inst_20370;
var state_20474__$1 = (function (){var statearr_20493 = state_20474;
(statearr_20493[(18)] = inst_20369);

(statearr_20493[(13)] = inst_20354__$1);

(statearr_20493[(15)] = inst_20351__$1);

(statearr_20493[(16)] = inst_20352__$1);

(statearr_20493[(17)] = inst_20353__$1);

return statearr_20493;
})();
var statearr_20494_20570 = state_20474__$1;
(statearr_20494_20570[(2)] = null);

(statearr_20494_20570[(1)] = (8));


return cljs.core.cst$kw$recur;
} else {
if((state_val_20475 === (21))){
var inst_20396 = (state_20474[(2)]);
var state_20474__$1 = state_20474;
var statearr_20498_20571 = state_20474__$1;
(statearr_20498_20571[(2)] = inst_20396);

(statearr_20498_20571[(1)] = (18));


return cljs.core.cst$kw$recur;
} else {
if((state_val_20475 === (31))){
var inst_20422 = (state_20474[(11)]);
var inst_20426 = done(null);
var inst_20427 = m.cljs$core$async$Mult$untap_STAR_$arity$2(null,inst_20422);
var state_20474__$1 = (function (){var statearr_20499 = state_20474;
(statearr_20499[(19)] = inst_20426);

return statearr_20499;
})();
var statearr_20500_20572 = state_20474__$1;
(statearr_20500_20572[(2)] = inst_20427);

(statearr_20500_20572[(1)] = (32));


return cljs.core.cst$kw$recur;
} else {
if((state_val_20475 === (32))){
var inst_20417 = (state_20474[(10)]);
var inst_20416 = (state_20474[(20)]);
var inst_20414 = (state_20474[(21)]);
var inst_20415 = (state_20474[(12)]);
var inst_20429 = (state_20474[(2)]);
var inst_20430 = (inst_20417 + (1));
var tmp20495 = inst_20416;
var tmp20496 = inst_20414;
var tmp20497 = inst_20415;
var inst_20414__$1 = tmp20496;
var inst_20415__$1 = tmp20497;
var inst_20416__$1 = tmp20495;
var inst_20417__$1 = inst_20430;
var state_20474__$1 = (function (){var statearr_20501 = state_20474;
(statearr_20501[(22)] = inst_20429);

(statearr_20501[(10)] = inst_20417__$1);

(statearr_20501[(20)] = inst_20416__$1);

(statearr_20501[(21)] = inst_20414__$1);

(statearr_20501[(12)] = inst_20415__$1);

return statearr_20501;
})();
var statearr_20502_20573 = state_20474__$1;
(statearr_20502_20573[(2)] = null);

(statearr_20502_20573[(1)] = (25));


return cljs.core.cst$kw$recur;
} else {
if((state_val_20475 === (40))){
var inst_20442 = (state_20474[(23)]);
var inst_20446 = done(null);
var inst_20447 = m.cljs$core$async$Mult$untap_STAR_$arity$2(null,inst_20442);
var state_20474__$1 = (function (){var statearr_20503 = state_20474;
(statearr_20503[(24)] = inst_20446);

return statearr_20503;
})();
var statearr_20504_20574 = state_20474__$1;
(statearr_20504_20574[(2)] = inst_20447);

(statearr_20504_20574[(1)] = (41));


return cljs.core.cst$kw$recur;
} else {
if((state_val_20475 === (33))){
var inst_20433 = (state_20474[(25)]);
var inst_20435 = cljs.core.chunked_seq_QMARK_(inst_20433);
var state_20474__$1 = state_20474;
if(inst_20435){
var statearr_20505_20575 = state_20474__$1;
(statearr_20505_20575[(1)] = (36));

} else {
var statearr_20506_20576 = state_20474__$1;
(statearr_20506_20576[(1)] = (37));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_20475 === (13))){
var inst_20363 = (state_20474[(26)]);
var inst_20366 = cljs.core.async.close_BANG_(inst_20363);
var state_20474__$1 = state_20474;
var statearr_20507_20577 = state_20474__$1;
(statearr_20507_20577[(2)] = inst_20366);

(statearr_20507_20577[(1)] = (15));


return cljs.core.cst$kw$recur;
} else {
if((state_val_20475 === (22))){
var inst_20386 = (state_20474[(8)]);
var inst_20389 = cljs.core.async.close_BANG_(inst_20386);
var state_20474__$1 = state_20474;
var statearr_20508_20578 = state_20474__$1;
(statearr_20508_20578[(2)] = inst_20389);

(statearr_20508_20578[(1)] = (24));


return cljs.core.cst$kw$recur;
} else {
if((state_val_20475 === (36))){
var inst_20433 = (state_20474[(25)]);
var inst_20437 = cljs.core.chunk_first(inst_20433);
var inst_20438 = cljs.core.chunk_rest(inst_20433);
var inst_20439 = cljs.core.count(inst_20437);
var inst_20414 = inst_20438;
var inst_20415 = inst_20437;
var inst_20416 = inst_20439;
var inst_20417 = (0);
var state_20474__$1 = (function (){var statearr_20509 = state_20474;
(statearr_20509[(10)] = inst_20417);

(statearr_20509[(20)] = inst_20416);

(statearr_20509[(21)] = inst_20414);

(statearr_20509[(12)] = inst_20415);

return statearr_20509;
})();
var statearr_20510_20579 = state_20474__$1;
(statearr_20510_20579[(2)] = null);

(statearr_20510_20579[(1)] = (25));


return cljs.core.cst$kw$recur;
} else {
if((state_val_20475 === (41))){
var inst_20433 = (state_20474[(25)]);
var inst_20449 = (state_20474[(2)]);
var inst_20450 = cljs.core.next(inst_20433);
var inst_20414 = inst_20450;
var inst_20415 = null;
var inst_20416 = (0);
var inst_20417 = (0);
var state_20474__$1 = (function (){var statearr_20511 = state_20474;
(statearr_20511[(27)] = inst_20449);

(statearr_20511[(10)] = inst_20417);

(statearr_20511[(20)] = inst_20416);

(statearr_20511[(21)] = inst_20414);

(statearr_20511[(12)] = inst_20415);

return statearr_20511;
})();
var statearr_20512_20580 = state_20474__$1;
(statearr_20512_20580[(2)] = null);

(statearr_20512_20580[(1)] = (25));


return cljs.core.cst$kw$recur;
} else {
if((state_val_20475 === (43))){
var state_20474__$1 = state_20474;
var statearr_20513_20581 = state_20474__$1;
(statearr_20513_20581[(2)] = null);

(statearr_20513_20581[(1)] = (44));


return cljs.core.cst$kw$recur;
} else {
if((state_val_20475 === (29))){
var inst_20458 = (state_20474[(2)]);
var state_20474__$1 = state_20474;
var statearr_20514_20582 = state_20474__$1;
(statearr_20514_20582[(2)] = inst_20458);

(statearr_20514_20582[(1)] = (26));


return cljs.core.cst$kw$recur;
} else {
if((state_val_20475 === (44))){
var inst_20467 = (state_20474[(2)]);
var state_20474__$1 = (function (){var statearr_20515 = state_20474;
(statearr_20515[(28)] = inst_20467);

return statearr_20515;
})();
var statearr_20516_20583 = state_20474__$1;
(statearr_20516_20583[(2)] = null);

(statearr_20516_20583[(1)] = (2));


return cljs.core.cst$kw$recur;
} else {
if((state_val_20475 === (6))){
var inst_20406 = (state_20474[(29)]);
var inst_20405 = cljs.core.deref(cs);
var inst_20406__$1 = cljs.core.keys(inst_20405);
var inst_20407 = cljs.core.count(inst_20406__$1);
var inst_20408 = cljs.core.reset_BANG_(dctr,inst_20407);
var inst_20413 = cljs.core.seq(inst_20406__$1);
var inst_20414 = inst_20413;
var inst_20415 = null;
var inst_20416 = (0);
var inst_20417 = (0);
var state_20474__$1 = (function (){var statearr_20517 = state_20474;
(statearr_20517[(30)] = inst_20408);

(statearr_20517[(10)] = inst_20417);

(statearr_20517[(20)] = inst_20416);

(statearr_20517[(21)] = inst_20414);

(statearr_20517[(29)] = inst_20406__$1);

(statearr_20517[(12)] = inst_20415);

return statearr_20517;
})();
var statearr_20518_20584 = state_20474__$1;
(statearr_20518_20584[(2)] = null);

(statearr_20518_20584[(1)] = (25));


return cljs.core.cst$kw$recur;
} else {
if((state_val_20475 === (28))){
var inst_20433 = (state_20474[(25)]);
var inst_20414 = (state_20474[(21)]);
var inst_20433__$1 = cljs.core.seq(inst_20414);
var state_20474__$1 = (function (){var statearr_20519 = state_20474;
(statearr_20519[(25)] = inst_20433__$1);

return statearr_20519;
})();
if(inst_20433__$1){
var statearr_20520_20585 = state_20474__$1;
(statearr_20520_20585[(1)] = (33));

} else {
var statearr_20521_20586 = state_20474__$1;
(statearr_20521_20586[(1)] = (34));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_20475 === (25))){
var inst_20417 = (state_20474[(10)]);
var inst_20416 = (state_20474[(20)]);
var inst_20419 = (inst_20417 < inst_20416);
var inst_20420 = inst_20419;
var state_20474__$1 = state_20474;
if(cljs.core.truth_(inst_20420)){
var statearr_20522_20587 = state_20474__$1;
(statearr_20522_20587[(1)] = (27));

} else {
var statearr_20523_20588 = state_20474__$1;
(statearr_20523_20588[(1)] = (28));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_20475 === (34))){
var state_20474__$1 = state_20474;
var statearr_20524_20589 = state_20474__$1;
(statearr_20524_20589[(2)] = null);

(statearr_20524_20589[(1)] = (35));


return cljs.core.cst$kw$recur;
} else {
if((state_val_20475 === (17))){
var state_20474__$1 = state_20474;
var statearr_20525_20590 = state_20474__$1;
(statearr_20525_20590[(2)] = null);

(statearr_20525_20590[(1)] = (18));


return cljs.core.cst$kw$recur;
} else {
if((state_val_20475 === (3))){
var inst_20472 = (state_20474[(2)]);
var state_20474__$1 = state_20474;
return cljs.core.async.impl.ioc_helpers.return_chan(state_20474__$1,inst_20472);
} else {
if((state_val_20475 === (12))){
var inst_20401 = (state_20474[(2)]);
var state_20474__$1 = state_20474;
var statearr_20526_20591 = state_20474__$1;
(statearr_20526_20591[(2)] = inst_20401);

(statearr_20526_20591[(1)] = (9));


return cljs.core.cst$kw$recur;
} else {
if((state_val_20475 === (2))){
var state_20474__$1 = state_20474;
return cljs.core.async.impl.ioc_helpers.take_BANG_(state_20474__$1,(4),ch);
} else {
if((state_val_20475 === (23))){
var state_20474__$1 = state_20474;
var statearr_20527_20592 = state_20474__$1;
(statearr_20527_20592[(2)] = null);

(statearr_20527_20592[(1)] = (24));


return cljs.core.cst$kw$recur;
} else {
if((state_val_20475 === (35))){
var inst_20456 = (state_20474[(2)]);
var state_20474__$1 = state_20474;
var statearr_20528_20593 = state_20474__$1;
(statearr_20528_20593[(2)] = inst_20456);

(statearr_20528_20593[(1)] = (29));


return cljs.core.cst$kw$recur;
} else {
if((state_val_20475 === (19))){
var inst_20373 = (state_20474[(7)]);
var inst_20377 = cljs.core.chunk_first(inst_20373);
var inst_20378 = cljs.core.chunk_rest(inst_20373);
var inst_20379 = cljs.core.count(inst_20377);
var inst_20351 = inst_20378;
var inst_20352 = inst_20377;
var inst_20353 = inst_20379;
var inst_20354 = (0);
var state_20474__$1 = (function (){var statearr_20529 = state_20474;
(statearr_20529[(13)] = inst_20354);

(statearr_20529[(15)] = inst_20351);

(statearr_20529[(16)] = inst_20352);

(statearr_20529[(17)] = inst_20353);

return statearr_20529;
})();
var statearr_20530_20594 = state_20474__$1;
(statearr_20530_20594[(2)] = null);

(statearr_20530_20594[(1)] = (8));


return cljs.core.cst$kw$recur;
} else {
if((state_val_20475 === (11))){
var inst_20373 = (state_20474[(7)]);
var inst_20351 = (state_20474[(15)]);
var inst_20373__$1 = cljs.core.seq(inst_20351);
var state_20474__$1 = (function (){var statearr_20531 = state_20474;
(statearr_20531[(7)] = inst_20373__$1);

return statearr_20531;
})();
if(inst_20373__$1){
var statearr_20532_20595 = state_20474__$1;
(statearr_20532_20595[(1)] = (16));

} else {
var statearr_20533_20596 = state_20474__$1;
(statearr_20533_20596[(1)] = (17));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_20475 === (9))){
var inst_20403 = (state_20474[(2)]);
var state_20474__$1 = state_20474;
var statearr_20534_20597 = state_20474__$1;
(statearr_20534_20597[(2)] = inst_20403);

(statearr_20534_20597[(1)] = (7));


return cljs.core.cst$kw$recur;
} else {
if((state_val_20475 === (5))){
var inst_20349 = cljs.core.deref(cs);
var inst_20350 = cljs.core.seq(inst_20349);
var inst_20351 = inst_20350;
var inst_20352 = null;
var inst_20353 = (0);
var inst_20354 = (0);
var state_20474__$1 = (function (){var statearr_20535 = state_20474;
(statearr_20535[(13)] = inst_20354);

(statearr_20535[(15)] = inst_20351);

(statearr_20535[(16)] = inst_20352);

(statearr_20535[(17)] = inst_20353);

return statearr_20535;
})();
var statearr_20536_20598 = state_20474__$1;
(statearr_20536_20598[(2)] = null);

(statearr_20536_20598[(1)] = (8));


return cljs.core.cst$kw$recur;
} else {
if((state_val_20475 === (14))){
var state_20474__$1 = state_20474;
var statearr_20537_20599 = state_20474__$1;
(statearr_20537_20599[(2)] = null);

(statearr_20537_20599[(1)] = (15));


return cljs.core.cst$kw$recur;
} else {
if((state_val_20475 === (45))){
var inst_20464 = (state_20474[(2)]);
var state_20474__$1 = state_20474;
var statearr_20538_20600 = state_20474__$1;
(statearr_20538_20600[(2)] = inst_20464);

(statearr_20538_20600[(1)] = (44));


return cljs.core.cst$kw$recur;
} else {
if((state_val_20475 === (26))){
var inst_20406 = (state_20474[(29)]);
var inst_20460 = (state_20474[(2)]);
var inst_20461 = cljs.core.seq(inst_20406);
var state_20474__$1 = (function (){var statearr_20539 = state_20474;
(statearr_20539[(31)] = inst_20460);

return statearr_20539;
})();
if(inst_20461){
var statearr_20540_20601 = state_20474__$1;
(statearr_20540_20601[(1)] = (42));

} else {
var statearr_20541_20602 = state_20474__$1;
(statearr_20541_20602[(1)] = (43));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_20475 === (16))){
var inst_20373 = (state_20474[(7)]);
var inst_20375 = cljs.core.chunked_seq_QMARK_(inst_20373);
var state_20474__$1 = state_20474;
if(inst_20375){
var statearr_20542_20603 = state_20474__$1;
(statearr_20542_20603[(1)] = (19));

} else {
var statearr_20543_20604 = state_20474__$1;
(statearr_20543_20604[(1)] = (20));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_20475 === (38))){
var inst_20453 = (state_20474[(2)]);
var state_20474__$1 = state_20474;
var statearr_20544_20605 = state_20474__$1;
(statearr_20544_20605[(2)] = inst_20453);

(statearr_20544_20605[(1)] = (35));


return cljs.core.cst$kw$recur;
} else {
if((state_val_20475 === (30))){
var state_20474__$1 = state_20474;
var statearr_20545_20606 = state_20474__$1;
(statearr_20545_20606[(2)] = null);

(statearr_20545_20606[(1)] = (32));


return cljs.core.cst$kw$recur;
} else {
if((state_val_20475 === (10))){
var inst_20354 = (state_20474[(13)]);
var inst_20352 = (state_20474[(16)]);
var inst_20362 = cljs.core._nth.cljs$core$IFn$_invoke$arity$2(inst_20352,inst_20354);
var inst_20363 = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(inst_20362,(0),null);
var inst_20364 = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(inst_20362,(1),null);
var state_20474__$1 = (function (){var statearr_20546 = state_20474;
(statearr_20546[(26)] = inst_20363);

return statearr_20546;
})();
if(cljs.core.truth_(inst_20364)){
var statearr_20547_20607 = state_20474__$1;
(statearr_20547_20607[(1)] = (13));

} else {
var statearr_20548_20608 = state_20474__$1;
(statearr_20548_20608[(1)] = (14));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_20475 === (18))){
var inst_20399 = (state_20474[(2)]);
var state_20474__$1 = state_20474;
var statearr_20549_20609 = state_20474__$1;
(statearr_20549_20609[(2)] = inst_20399);

(statearr_20549_20609[(1)] = (12));


return cljs.core.cst$kw$recur;
} else {
if((state_val_20475 === (42))){
var state_20474__$1 = state_20474;
return cljs.core.async.impl.ioc_helpers.take_BANG_(state_20474__$1,(45),dchan);
} else {
if((state_val_20475 === (37))){
var inst_20433 = (state_20474[(25)]);
var inst_20342 = (state_20474[(9)]);
var inst_20442 = (state_20474[(23)]);
var inst_20442__$1 = cljs.core.first(inst_20433);
var inst_20443 = cljs.core.async.put_BANG_.cljs$core$IFn$_invoke$arity$3(inst_20442__$1,inst_20342,done);
var state_20474__$1 = (function (){var statearr_20550 = state_20474;
(statearr_20550[(23)] = inst_20442__$1);

return statearr_20550;
})();
if(cljs.core.truth_(inst_20443)){
var statearr_20551_20610 = state_20474__$1;
(statearr_20551_20610[(1)] = (39));

} else {
var statearr_20552_20611 = state_20474__$1;
(statearr_20552_20611[(1)] = (40));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_20475 === (8))){
var inst_20354 = (state_20474[(13)]);
var inst_20353 = (state_20474[(17)]);
var inst_20356 = (inst_20354 < inst_20353);
var inst_20357 = inst_20356;
var state_20474__$1 = state_20474;
if(cljs.core.truth_(inst_20357)){
var statearr_20553_20612 = state_20474__$1;
(statearr_20553_20612[(1)] = (10));

} else {
var statearr_20554_20613 = state_20474__$1;
(statearr_20554_20613[(1)] = (11));

}

return cljs.core.cst$kw$recur;
} else {
return null;
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
});})(c__7992__auto___20559,cs,m,dchan,dctr,done))
;
return ((function (switch__7885__auto__,c__7992__auto___20559,cs,m,dchan,dctr,done){
return (function() {
var cljs$core$async$mult_$_state_machine__7886__auto__ = null;
var cljs$core$async$mult_$_state_machine__7886__auto____0 = (function (){
var statearr_20555 = [null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null];
(statearr_20555[(0)] = cljs$core$async$mult_$_state_machine__7886__auto__);

(statearr_20555[(1)] = (1));

return statearr_20555;
});
var cljs$core$async$mult_$_state_machine__7886__auto____1 = (function (state_20474){
while(true){
var ret_value__7887__auto__ = (function (){try{while(true){
var result__7888__auto__ = switch__7885__auto__(state_20474);
if(cljs.core.keyword_identical_QMARK_(result__7888__auto__,cljs.core.cst$kw$recur)){
continue;
} else {
return result__7888__auto__;
}
break;
}
}catch (e20556){if((e20556 instanceof Object)){
var ex__7889__auto__ = e20556;
var statearr_20557_20614 = state_20474;
(statearr_20557_20614[(5)] = ex__7889__auto__);


cljs.core.async.impl.ioc_helpers.process_exception(state_20474);

return cljs.core.cst$kw$recur;
} else {
throw e20556;

}
}})();
if(cljs.core.keyword_identical_QMARK_(ret_value__7887__auto__,cljs.core.cst$kw$recur)){
var G__20615 = state_20474;
state_20474 = G__20615;
continue;
} else {
return ret_value__7887__auto__;
}
break;
}
});
cljs$core$async$mult_$_state_machine__7886__auto__ = function(state_20474){
switch(arguments.length){
case 0:
return cljs$core$async$mult_$_state_machine__7886__auto____0.call(this);
case 1:
return cljs$core$async$mult_$_state_machine__7886__auto____1.call(this,state_20474);
}
throw(new Error('Invalid arity: ' + arguments.length));
};
cljs$core$async$mult_$_state_machine__7886__auto__.cljs$core$IFn$_invoke$arity$0 = cljs$core$async$mult_$_state_machine__7886__auto____0;
cljs$core$async$mult_$_state_machine__7886__auto__.cljs$core$IFn$_invoke$arity$1 = cljs$core$async$mult_$_state_machine__7886__auto____1;
return cljs$core$async$mult_$_state_machine__7886__auto__;
})()
;})(switch__7885__auto__,c__7992__auto___20559,cs,m,dchan,dctr,done))
})();
var state__7994__auto__ = (function (){var statearr_20558 = (f__7993__auto__.cljs$core$IFn$_invoke$arity$0 ? f__7993__auto__.cljs$core$IFn$_invoke$arity$0() : f__7993__auto__.call(null));
(statearr_20558[(6)] = c__7992__auto___20559);

return statearr_20558;
})();
return cljs.core.async.impl.ioc_helpers.run_state_machine_wrapped(state__7994__auto__);
});})(c__7992__auto___20559,cs,m,dchan,dctr,done))
);


return m;
});
/**
 * Copies the mult source onto the supplied channel.
 * 
 *   By default the channel will be closed when the source closes,
 *   but can be determined by the close? parameter.
 */
cljs.core.async.tap = (function cljs$core$async$tap(var_args){
var G__20617 = arguments.length;
switch (G__20617) {
case 2:
return cljs.core.async.tap.cljs$core$IFn$_invoke$arity$2((arguments[(0)]),(arguments[(1)]));

break;
case 3:
return cljs.core.async.tap.cljs$core$IFn$_invoke$arity$3((arguments[(0)]),(arguments[(1)]),(arguments[(2)]));

break;
default:
throw (new Error(["Invalid arity: ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(arguments.length)].join('')));

}
});

cljs.core.async.tap.cljs$core$IFn$_invoke$arity$2 = (function (mult,ch){
return cljs.core.async.tap.cljs$core$IFn$_invoke$arity$3(mult,ch,true);
});

cljs.core.async.tap.cljs$core$IFn$_invoke$arity$3 = (function (mult,ch,close_QMARK_){
cljs.core.async.tap_STAR_(mult,ch,close_QMARK_);

return ch;
});

cljs.core.async.tap.cljs$lang$maxFixedArity = 3;

/**
 * Disconnects a target channel from a mult
 */
cljs.core.async.untap = (function cljs$core$async$untap(mult,ch){
return cljs.core.async.untap_STAR_(mult,ch);
});
/**
 * Disconnects all target channels from a mult
 */
cljs.core.async.untap_all = (function cljs$core$async$untap_all(mult){
return cljs.core.async.untap_all_STAR_(mult);
});

/**
 * @interface
 */
cljs.core.async.Mix = function(){};

cljs.core.async.admix_STAR_ = (function cljs$core$async$admix_STAR_(m,ch){
if((((!((m == null)))) && ((!((m.cljs$core$async$Mix$admix_STAR_$arity$2 == null)))))){
return m.cljs$core$async$Mix$admix_STAR_$arity$2(m,ch);
} else {
var x__4347__auto__ = (((m == null))?null:m);
var m__4348__auto__ = (cljs.core.async.admix_STAR_[goog.typeOf(x__4347__auto__)]);
if((!((m__4348__auto__ == null)))){
return (m__4348__auto__.cljs$core$IFn$_invoke$arity$2 ? m__4348__auto__.cljs$core$IFn$_invoke$arity$2(m,ch) : m__4348__auto__.call(null,m,ch));
} else {
var m__4348__auto____$1 = (cljs.core.async.admix_STAR_["_"]);
if((!((m__4348__auto____$1 == null)))){
return (m__4348__auto____$1.cljs$core$IFn$_invoke$arity$2 ? m__4348__auto____$1.cljs$core$IFn$_invoke$arity$2(m,ch) : m__4348__auto____$1.call(null,m,ch));
} else {
throw cljs.core.missing_protocol("Mix.admix*",m);
}
}
}
});

cljs.core.async.unmix_STAR_ = (function cljs$core$async$unmix_STAR_(m,ch){
if((((!((m == null)))) && ((!((m.cljs$core$async$Mix$unmix_STAR_$arity$2 == null)))))){
return m.cljs$core$async$Mix$unmix_STAR_$arity$2(m,ch);
} else {
var x__4347__auto__ = (((m == null))?null:m);
var m__4348__auto__ = (cljs.core.async.unmix_STAR_[goog.typeOf(x__4347__auto__)]);
if((!((m__4348__auto__ == null)))){
return (m__4348__auto__.cljs$core$IFn$_invoke$arity$2 ? m__4348__auto__.cljs$core$IFn$_invoke$arity$2(m,ch) : m__4348__auto__.call(null,m,ch));
} else {
var m__4348__auto____$1 = (cljs.core.async.unmix_STAR_["_"]);
if((!((m__4348__auto____$1 == null)))){
return (m__4348__auto____$1.cljs$core$IFn$_invoke$arity$2 ? m__4348__auto____$1.cljs$core$IFn$_invoke$arity$2(m,ch) : m__4348__auto____$1.call(null,m,ch));
} else {
throw cljs.core.missing_protocol("Mix.unmix*",m);
}
}
}
});

cljs.core.async.unmix_all_STAR_ = (function cljs$core$async$unmix_all_STAR_(m){
if((((!((m == null)))) && ((!((m.cljs$core$async$Mix$unmix_all_STAR_$arity$1 == null)))))){
return m.cljs$core$async$Mix$unmix_all_STAR_$arity$1(m);
} else {
var x__4347__auto__ = (((m == null))?null:m);
var m__4348__auto__ = (cljs.core.async.unmix_all_STAR_[goog.typeOf(x__4347__auto__)]);
if((!((m__4348__auto__ == null)))){
return (m__4348__auto__.cljs$core$IFn$_invoke$arity$1 ? m__4348__auto__.cljs$core$IFn$_invoke$arity$1(m) : m__4348__auto__.call(null,m));
} else {
var m__4348__auto____$1 = (cljs.core.async.unmix_all_STAR_["_"]);
if((!((m__4348__auto____$1 == null)))){
return (m__4348__auto____$1.cljs$core$IFn$_invoke$arity$1 ? m__4348__auto____$1.cljs$core$IFn$_invoke$arity$1(m) : m__4348__auto____$1.call(null,m));
} else {
throw cljs.core.missing_protocol("Mix.unmix-all*",m);
}
}
}
});

cljs.core.async.toggle_STAR_ = (function cljs$core$async$toggle_STAR_(m,state_map){
if((((!((m == null)))) && ((!((m.cljs$core$async$Mix$toggle_STAR_$arity$2 == null)))))){
return m.cljs$core$async$Mix$toggle_STAR_$arity$2(m,state_map);
} else {
var x__4347__auto__ = (((m == null))?null:m);
var m__4348__auto__ = (cljs.core.async.toggle_STAR_[goog.typeOf(x__4347__auto__)]);
if((!((m__4348__auto__ == null)))){
return (m__4348__auto__.cljs$core$IFn$_invoke$arity$2 ? m__4348__auto__.cljs$core$IFn$_invoke$arity$2(m,state_map) : m__4348__auto__.call(null,m,state_map));
} else {
var m__4348__auto____$1 = (cljs.core.async.toggle_STAR_["_"]);
if((!((m__4348__auto____$1 == null)))){
return (m__4348__auto____$1.cljs$core$IFn$_invoke$arity$2 ? m__4348__auto____$1.cljs$core$IFn$_invoke$arity$2(m,state_map) : m__4348__auto____$1.call(null,m,state_map));
} else {
throw cljs.core.missing_protocol("Mix.toggle*",m);
}
}
}
});

cljs.core.async.solo_mode_STAR_ = (function cljs$core$async$solo_mode_STAR_(m,mode){
if((((!((m == null)))) && ((!((m.cljs$core$async$Mix$solo_mode_STAR_$arity$2 == null)))))){
return m.cljs$core$async$Mix$solo_mode_STAR_$arity$2(m,mode);
} else {
var x__4347__auto__ = (((m == null))?null:m);
var m__4348__auto__ = (cljs.core.async.solo_mode_STAR_[goog.typeOf(x__4347__auto__)]);
if((!((m__4348__auto__ == null)))){
return (m__4348__auto__.cljs$core$IFn$_invoke$arity$2 ? m__4348__auto__.cljs$core$IFn$_invoke$arity$2(m,mode) : m__4348__auto__.call(null,m,mode));
} else {
var m__4348__auto____$1 = (cljs.core.async.solo_mode_STAR_["_"]);
if((!((m__4348__auto____$1 == null)))){
return (m__4348__auto____$1.cljs$core$IFn$_invoke$arity$2 ? m__4348__auto____$1.cljs$core$IFn$_invoke$arity$2(m,mode) : m__4348__auto____$1.call(null,m,mode));
} else {
throw cljs.core.missing_protocol("Mix.solo-mode*",m);
}
}
}
});

cljs.core.async.ioc_alts_BANG_ = (function cljs$core$async$ioc_alts_BANG_(var_args){
var args__4647__auto__ = [];
var len__4641__auto___20629 = arguments.length;
var i__4642__auto___20630 = (0);
while(true){
if((i__4642__auto___20630 < len__4641__auto___20629)){
args__4647__auto__.push((arguments[i__4642__auto___20630]));

var G__20631 = (i__4642__auto___20630 + (1));
i__4642__auto___20630 = G__20631;
continue;
} else {
}
break;
}

var argseq__4648__auto__ = ((((3) < args__4647__auto__.length))?(new cljs.core.IndexedSeq(args__4647__auto__.slice((3)),(0),null)):null);
return cljs.core.async.ioc_alts_BANG_.cljs$core$IFn$_invoke$arity$variadic((arguments[(0)]),(arguments[(1)]),(arguments[(2)]),argseq__4648__auto__);
});

cljs.core.async.ioc_alts_BANG_.cljs$core$IFn$_invoke$arity$variadic = (function (state,cont_block,ports,p__20623){
var map__20624 = p__20623;
var map__20624__$1 = (((((!((map__20624 == null))))?(((((map__20624.cljs$lang$protocol_mask$partition0$ & (64))) || ((cljs.core.PROTOCOL_SENTINEL === map__20624.cljs$core$ISeq$))))?true:false):false))?cljs.core.apply.cljs$core$IFn$_invoke$arity$2(cljs.core.hash_map,map__20624):map__20624);
var opts = map__20624__$1;
var statearr_20626_20632 = state;
(statearr_20626_20632[(1)] = cont_block);


var temp__5457__auto__ = cljs.core.async.do_alts(((function (map__20624,map__20624__$1,opts){
return (function (val){
var statearr_20627_20633 = state;
(statearr_20627_20633[(2)] = val);


return cljs.core.async.impl.ioc_helpers.run_state_machine_wrapped(state);
});})(map__20624,map__20624__$1,opts))
,ports,opts);
if(cljs.core.truth_(temp__5457__auto__)){
var cb = temp__5457__auto__;
var statearr_20628_20634 = state;
(statearr_20628_20634[(2)] = cljs.core.deref(cb));


return cljs.core.cst$kw$recur;
} else {
return null;
}
});

cljs.core.async.ioc_alts_BANG_.cljs$lang$maxFixedArity = (3);

/** @this {Function} */
cljs.core.async.ioc_alts_BANG_.cljs$lang$applyTo = (function (seq20619){
var G__20620 = cljs.core.first(seq20619);
var seq20619__$1 = cljs.core.next(seq20619);
var G__20621 = cljs.core.first(seq20619__$1);
var seq20619__$2 = cljs.core.next(seq20619__$1);
var G__20622 = cljs.core.first(seq20619__$2);
var seq20619__$3 = cljs.core.next(seq20619__$2);
var self__4628__auto__ = this;
return self__4628__auto__.cljs$core$IFn$_invoke$arity$variadic(G__20620,G__20621,G__20622,seq20619__$3);
});

/**
 * Creates and returns a mix of one or more input channels which will
 *   be put on the supplied out channel. Input sources can be added to
 *   the mix with 'admix', and removed with 'unmix'. A mix supports
 *   soloing, muting and pausing multiple inputs atomically using
 *   'toggle', and can solo using either muting or pausing as determined
 *   by 'solo-mode'.
 * 
 *   Each channel can have zero or more boolean modes set via 'toggle':
 * 
 *   :solo - when true, only this (ond other soloed) channel(s) will appear
 *        in the mix output channel. :mute and :pause states of soloed
 *        channels are ignored. If solo-mode is :mute, non-soloed
 *        channels are muted, if :pause, non-soloed channels are
 *        paused.
 * 
 *   :mute - muted channels will have their contents consumed but not included in the mix
 *   :pause - paused channels will not have their contents consumed (and thus also not included in the mix)
 */
cljs.core.async.mix = (function cljs$core$async$mix(out){
var cs = cljs.core.atom.cljs$core$IFn$_invoke$arity$1(cljs.core.PersistentArrayMap.EMPTY);
var solo_modes = new cljs.core.PersistentHashSet(null, new cljs.core.PersistentArrayMap(null, 2, [cljs.core.cst$kw$pause,null,cljs.core.cst$kw$mute,null], null), null);
var attrs = cljs.core.conj.cljs$core$IFn$_invoke$arity$2(solo_modes,cljs.core.cst$kw$solo);
var solo_mode = cljs.core.atom.cljs$core$IFn$_invoke$arity$1(cljs.core.cst$kw$mute);
var change = cljs.core.async.chan.cljs$core$IFn$_invoke$arity$0();
var changed = ((function (cs,solo_modes,attrs,solo_mode,change){
return (function (){
return cljs.core.async.put_BANG_.cljs$core$IFn$_invoke$arity$2(change,true);
});})(cs,solo_modes,attrs,solo_mode,change))
;
var pick = ((function (cs,solo_modes,attrs,solo_mode,change,changed){
return (function (attr,chs){
return cljs.core.reduce_kv(((function (cs,solo_modes,attrs,solo_mode,change,changed){
return (function (ret,c,v){
if(cljs.core.truth_((attr.cljs$core$IFn$_invoke$arity$1 ? attr.cljs$core$IFn$_invoke$arity$1(v) : attr.call(null,v)))){
return cljs.core.conj.cljs$core$IFn$_invoke$arity$2(ret,c);
} else {
return ret;
}
});})(cs,solo_modes,attrs,solo_mode,change,changed))
,cljs.core.PersistentHashSet.EMPTY,chs);
});})(cs,solo_modes,attrs,solo_mode,change,changed))
;
var calc_state = ((function (cs,solo_modes,attrs,solo_mode,change,changed,pick){
return (function (){
var chs = cljs.core.deref(cs);
var mode = cljs.core.deref(solo_mode);
var solos = pick(cljs.core.cst$kw$solo,chs);
var pauses = pick(cljs.core.cst$kw$pause,chs);
return new cljs.core.PersistentArrayMap(null, 3, [cljs.core.cst$kw$solos,solos,cljs.core.cst$kw$mutes,pick(cljs.core.cst$kw$mute,chs),cljs.core.cst$kw$reads,cljs.core.conj.cljs$core$IFn$_invoke$arity$2(((((cljs.core._EQ_.cljs$core$IFn$_invoke$arity$2(mode,cljs.core.cst$kw$pause)) && ((!(cljs.core.empty_QMARK_(solos))))))?cljs.core.vec(solos):cljs.core.vec(cljs.core.remove.cljs$core$IFn$_invoke$arity$2(pauses,cljs.core.keys(chs)))),change)], null);
});})(cs,solo_modes,attrs,solo_mode,change,changed,pick))
;
var m = (function (){
if((typeof cljs !== 'undefined') && (typeof cljs.core !== 'undefined') && (typeof cljs.core.async !== 'undefined') && (typeof cljs.core.async.t_cljs$core$async20635 !== 'undefined')){
} else {

/**
* @constructor
 * @implements {cljs.core.IMeta}
 * @implements {cljs.core.async.Mix}
 * @implements {cljs.core.async.Mux}
 * @implements {cljs.core.IWithMeta}
*/
cljs.core.async.t_cljs$core$async20635 = (function (out,cs,solo_modes,attrs,solo_mode,change,changed,pick,calc_state,meta20636){
this.out = out;
this.cs = cs;
this.solo_modes = solo_modes;
this.attrs = attrs;
this.solo_mode = solo_mode;
this.change = change;
this.changed = changed;
this.pick = pick;
this.calc_state = calc_state;
this.meta20636 = meta20636;
this.cljs$lang$protocol_mask$partition0$ = 393216;
this.cljs$lang$protocol_mask$partition1$ = 0;
});
cljs.core.async.t_cljs$core$async20635.prototype.cljs$core$IWithMeta$_with_meta$arity$2 = ((function (cs,solo_modes,attrs,solo_mode,change,changed,pick,calc_state){
return (function (_20637,meta20636__$1){
var self__ = this;
var _20637__$1 = this;
return (new cljs.core.async.t_cljs$core$async20635(self__.out,self__.cs,self__.solo_modes,self__.attrs,self__.solo_mode,self__.change,self__.changed,self__.pick,self__.calc_state,meta20636__$1));
});})(cs,solo_modes,attrs,solo_mode,change,changed,pick,calc_state))
;

cljs.core.async.t_cljs$core$async20635.prototype.cljs$core$IMeta$_meta$arity$1 = ((function (cs,solo_modes,attrs,solo_mode,change,changed,pick,calc_state){
return (function (_20637){
var self__ = this;
var _20637__$1 = this;
return self__.meta20636;
});})(cs,solo_modes,attrs,solo_mode,change,changed,pick,calc_state))
;

cljs.core.async.t_cljs$core$async20635.prototype.cljs$core$async$Mux$ = cljs.core.PROTOCOL_SENTINEL;

cljs.core.async.t_cljs$core$async20635.prototype.cljs$core$async$Mux$muxch_STAR_$arity$1 = ((function (cs,solo_modes,attrs,solo_mode,change,changed,pick,calc_state){
return (function (_){
var self__ = this;
var ___$1 = this;
return self__.out;
});})(cs,solo_modes,attrs,solo_mode,change,changed,pick,calc_state))
;

cljs.core.async.t_cljs$core$async20635.prototype.cljs$core$async$Mix$ = cljs.core.PROTOCOL_SENTINEL;

cljs.core.async.t_cljs$core$async20635.prototype.cljs$core$async$Mix$admix_STAR_$arity$2 = ((function (cs,solo_modes,attrs,solo_mode,change,changed,pick,calc_state){
return (function (_,ch){
var self__ = this;
var ___$1 = this;
cljs.core.swap_BANG_.cljs$core$IFn$_invoke$arity$4(self__.cs,cljs.core.assoc,ch,cljs.core.PersistentArrayMap.EMPTY);

return (self__.changed.cljs$core$IFn$_invoke$arity$0 ? self__.changed.cljs$core$IFn$_invoke$arity$0() : self__.changed.call(null));
});})(cs,solo_modes,attrs,solo_mode,change,changed,pick,calc_state))
;

cljs.core.async.t_cljs$core$async20635.prototype.cljs$core$async$Mix$unmix_STAR_$arity$2 = ((function (cs,solo_modes,attrs,solo_mode,change,changed,pick,calc_state){
return (function (_,ch){
var self__ = this;
var ___$1 = this;
cljs.core.swap_BANG_.cljs$core$IFn$_invoke$arity$3(self__.cs,cljs.core.dissoc,ch);

return (self__.changed.cljs$core$IFn$_invoke$arity$0 ? self__.changed.cljs$core$IFn$_invoke$arity$0() : self__.changed.call(null));
});})(cs,solo_modes,attrs,solo_mode,change,changed,pick,calc_state))
;

cljs.core.async.t_cljs$core$async20635.prototype.cljs$core$async$Mix$unmix_all_STAR_$arity$1 = ((function (cs,solo_modes,attrs,solo_mode,change,changed,pick,calc_state){
return (function (_){
var self__ = this;
var ___$1 = this;
cljs.core.reset_BANG_(self__.cs,cljs.core.PersistentArrayMap.EMPTY);

return (self__.changed.cljs$core$IFn$_invoke$arity$0 ? self__.changed.cljs$core$IFn$_invoke$arity$0() : self__.changed.call(null));
});})(cs,solo_modes,attrs,solo_mode,change,changed,pick,calc_state))
;

cljs.core.async.t_cljs$core$async20635.prototype.cljs$core$async$Mix$toggle_STAR_$arity$2 = ((function (cs,solo_modes,attrs,solo_mode,change,changed,pick,calc_state){
return (function (_,state_map){
var self__ = this;
var ___$1 = this;
cljs.core.swap_BANG_.cljs$core$IFn$_invoke$arity$3(self__.cs,cljs.core.partial.cljs$core$IFn$_invoke$arity$2(cljs.core.merge_with,cljs.core.merge),state_map);

return (self__.changed.cljs$core$IFn$_invoke$arity$0 ? self__.changed.cljs$core$IFn$_invoke$arity$0() : self__.changed.call(null));
});})(cs,solo_modes,attrs,solo_mode,change,changed,pick,calc_state))
;

cljs.core.async.t_cljs$core$async20635.prototype.cljs$core$async$Mix$solo_mode_STAR_$arity$2 = ((function (cs,solo_modes,attrs,solo_mode,change,changed,pick,calc_state){
return (function (_,mode){
var self__ = this;
var ___$1 = this;

cljs.core.reset_BANG_(self__.solo_mode,mode);

return (self__.changed.cljs$core$IFn$_invoke$arity$0 ? self__.changed.cljs$core$IFn$_invoke$arity$0() : self__.changed.call(null));
});})(cs,solo_modes,attrs,solo_mode,change,changed,pick,calc_state))
;

cljs.core.async.t_cljs$core$async20635.getBasis = ((function (cs,solo_modes,attrs,solo_mode,change,changed,pick,calc_state){
return (function (){
return new cljs.core.PersistentVector(null, 10, 5, cljs.core.PersistentVector.EMPTY_NODE, [cljs.core.cst$sym$out,cljs.core.cst$sym$cs,cljs.core.cst$sym$solo_DASH_modes,cljs.core.cst$sym$attrs,cljs.core.cst$sym$solo_DASH_mode,cljs.core.cst$sym$change,cljs.core.cst$sym$changed,cljs.core.cst$sym$pick,cljs.core.cst$sym$calc_DASH_state,cljs.core.cst$sym$meta20636], null);
});})(cs,solo_modes,attrs,solo_mode,change,changed,pick,calc_state))
;

cljs.core.async.t_cljs$core$async20635.cljs$lang$type = true;

cljs.core.async.t_cljs$core$async20635.cljs$lang$ctorStr = "cljs.core.async/t_cljs$core$async20635";

cljs.core.async.t_cljs$core$async20635.cljs$lang$ctorPrWriter = ((function (cs,solo_modes,attrs,solo_mode,change,changed,pick,calc_state){
return (function (this__4290__auto__,writer__4291__auto__,opt__4292__auto__){
return cljs.core._write(writer__4291__auto__,"cljs.core.async/t_cljs$core$async20635");
});})(cs,solo_modes,attrs,solo_mode,change,changed,pick,calc_state))
;

/**
 * Positional factory function for cljs.core.async/t_cljs$core$async20635.
 */
cljs.core.async.__GT_t_cljs$core$async20635 = ((function (cs,solo_modes,attrs,solo_mode,change,changed,pick,calc_state){
return (function cljs$core$async$mix_$___GT_t_cljs$core$async20635(out__$1,cs__$1,solo_modes__$1,attrs__$1,solo_mode__$1,change__$1,changed__$1,pick__$1,calc_state__$1,meta20636){
return (new cljs.core.async.t_cljs$core$async20635(out__$1,cs__$1,solo_modes__$1,attrs__$1,solo_mode__$1,change__$1,changed__$1,pick__$1,calc_state__$1,meta20636));
});})(cs,solo_modes,attrs,solo_mode,change,changed,pick,calc_state))
;

}

return (new cljs.core.async.t_cljs$core$async20635(out,cs,solo_modes,attrs,solo_mode,change,changed,pick,calc_state,cljs.core.PersistentArrayMap.EMPTY));
})()
;
var c__7992__auto___20799 = cljs.core.async.chan.cljs$core$IFn$_invoke$arity$1((1));
cljs.core.async.impl.dispatch.run(((function (c__7992__auto___20799,cs,solo_modes,attrs,solo_mode,change,changed,pick,calc_state,m){
return (function (){
var f__7993__auto__ = (function (){var switch__7885__auto__ = ((function (c__7992__auto___20799,cs,solo_modes,attrs,solo_mode,change,changed,pick,calc_state,m){
return (function (state_20739){
var state_val_20740 = (state_20739[(1)]);
if((state_val_20740 === (7))){
var inst_20654 = (state_20739[(2)]);
var state_20739__$1 = state_20739;
var statearr_20741_20800 = state_20739__$1;
(statearr_20741_20800[(2)] = inst_20654);

(statearr_20741_20800[(1)] = (4));


return cljs.core.cst$kw$recur;
} else {
if((state_val_20740 === (20))){
var inst_20666 = (state_20739[(7)]);
var state_20739__$1 = state_20739;
var statearr_20742_20801 = state_20739__$1;
(statearr_20742_20801[(2)] = inst_20666);

(statearr_20742_20801[(1)] = (21));


return cljs.core.cst$kw$recur;
} else {
if((state_val_20740 === (27))){
var state_20739__$1 = state_20739;
var statearr_20743_20802 = state_20739__$1;
(statearr_20743_20802[(2)] = null);

(statearr_20743_20802[(1)] = (28));


return cljs.core.cst$kw$recur;
} else {
if((state_val_20740 === (1))){
var inst_20641 = (state_20739[(8)]);
var inst_20641__$1 = calc_state();
var inst_20643 = (inst_20641__$1 == null);
var inst_20644 = cljs.core.not(inst_20643);
var state_20739__$1 = (function (){var statearr_20744 = state_20739;
(statearr_20744[(8)] = inst_20641__$1);

return statearr_20744;
})();
if(inst_20644){
var statearr_20745_20803 = state_20739__$1;
(statearr_20745_20803[(1)] = (2));

} else {
var statearr_20746_20804 = state_20739__$1;
(statearr_20746_20804[(1)] = (3));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_20740 === (24))){
var inst_20713 = (state_20739[(9)]);
var inst_20690 = (state_20739[(10)]);
var inst_20699 = (state_20739[(11)]);
var inst_20713__$1 = (inst_20690.cljs$core$IFn$_invoke$arity$1 ? inst_20690.cljs$core$IFn$_invoke$arity$1(inst_20699) : inst_20690.call(null,inst_20699));
var state_20739__$1 = (function (){var statearr_20747 = state_20739;
(statearr_20747[(9)] = inst_20713__$1);

return statearr_20747;
})();
if(cljs.core.truth_(inst_20713__$1)){
var statearr_20748_20805 = state_20739__$1;
(statearr_20748_20805[(1)] = (29));

} else {
var statearr_20749_20806 = state_20739__$1;
(statearr_20749_20806[(1)] = (30));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_20740 === (4))){
var inst_20657 = (state_20739[(2)]);
var state_20739__$1 = state_20739;
if(cljs.core.truth_(inst_20657)){
var statearr_20750_20807 = state_20739__$1;
(statearr_20750_20807[(1)] = (8));

} else {
var statearr_20751_20808 = state_20739__$1;
(statearr_20751_20808[(1)] = (9));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_20740 === (15))){
var inst_20684 = (state_20739[(2)]);
var state_20739__$1 = state_20739;
if(cljs.core.truth_(inst_20684)){
var statearr_20752_20809 = state_20739__$1;
(statearr_20752_20809[(1)] = (19));

} else {
var statearr_20753_20810 = state_20739__$1;
(statearr_20753_20810[(1)] = (20));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_20740 === (21))){
var inst_20689 = (state_20739[(12)]);
var inst_20689__$1 = (state_20739[(2)]);
var inst_20690 = cljs.core.get.cljs$core$IFn$_invoke$arity$2(inst_20689__$1,cljs.core.cst$kw$solos);
var inst_20691 = cljs.core.get.cljs$core$IFn$_invoke$arity$2(inst_20689__$1,cljs.core.cst$kw$mutes);
var inst_20692 = cljs.core.get.cljs$core$IFn$_invoke$arity$2(inst_20689__$1,cljs.core.cst$kw$reads);
var state_20739__$1 = (function (){var statearr_20754 = state_20739;
(statearr_20754[(12)] = inst_20689__$1);

(statearr_20754[(10)] = inst_20690);

(statearr_20754[(13)] = inst_20691);

return statearr_20754;
})();
return cljs.core.async.ioc_alts_BANG_(state_20739__$1,(22),inst_20692);
} else {
if((state_val_20740 === (31))){
var inst_20721 = (state_20739[(2)]);
var state_20739__$1 = state_20739;
if(cljs.core.truth_(inst_20721)){
var statearr_20755_20811 = state_20739__$1;
(statearr_20755_20811[(1)] = (32));

} else {
var statearr_20756_20812 = state_20739__$1;
(statearr_20756_20812[(1)] = (33));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_20740 === (32))){
var inst_20698 = (state_20739[(14)]);
var state_20739__$1 = state_20739;
return cljs.core.async.impl.ioc_helpers.put_BANG_(state_20739__$1,(35),out,inst_20698);
} else {
if((state_val_20740 === (33))){
var inst_20689 = (state_20739[(12)]);
var inst_20666 = inst_20689;
var state_20739__$1 = (function (){var statearr_20757 = state_20739;
(statearr_20757[(7)] = inst_20666);

return statearr_20757;
})();
var statearr_20758_20813 = state_20739__$1;
(statearr_20758_20813[(2)] = null);

(statearr_20758_20813[(1)] = (11));


return cljs.core.cst$kw$recur;
} else {
if((state_val_20740 === (13))){
var inst_20666 = (state_20739[(7)]);
var inst_20673 = inst_20666.cljs$lang$protocol_mask$partition0$;
var inst_20674 = (inst_20673 & (64));
var inst_20675 = inst_20666.cljs$core$ISeq$;
var inst_20676 = (cljs.core.PROTOCOL_SENTINEL === inst_20675);
var inst_20677 = ((inst_20674) || (inst_20676));
var state_20739__$1 = state_20739;
if(cljs.core.truth_(inst_20677)){
var statearr_20759_20814 = state_20739__$1;
(statearr_20759_20814[(1)] = (16));

} else {
var statearr_20760_20815 = state_20739__$1;
(statearr_20760_20815[(1)] = (17));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_20740 === (22))){
var inst_20698 = (state_20739[(14)]);
var inst_20699 = (state_20739[(11)]);
var inst_20697 = (state_20739[(2)]);
var inst_20698__$1 = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(inst_20697,(0),null);
var inst_20699__$1 = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(inst_20697,(1),null);
var inst_20700 = (inst_20698__$1 == null);
var inst_20701 = cljs.core._EQ_.cljs$core$IFn$_invoke$arity$2(inst_20699__$1,change);
var inst_20702 = ((inst_20700) || (inst_20701));
var state_20739__$1 = (function (){var statearr_20761 = state_20739;
(statearr_20761[(14)] = inst_20698__$1);

(statearr_20761[(11)] = inst_20699__$1);

return statearr_20761;
})();
if(cljs.core.truth_(inst_20702)){
var statearr_20762_20816 = state_20739__$1;
(statearr_20762_20816[(1)] = (23));

} else {
var statearr_20763_20817 = state_20739__$1;
(statearr_20763_20817[(1)] = (24));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_20740 === (36))){
var inst_20689 = (state_20739[(12)]);
var inst_20666 = inst_20689;
var state_20739__$1 = (function (){var statearr_20764 = state_20739;
(statearr_20764[(7)] = inst_20666);

return statearr_20764;
})();
var statearr_20765_20818 = state_20739__$1;
(statearr_20765_20818[(2)] = null);

(statearr_20765_20818[(1)] = (11));


return cljs.core.cst$kw$recur;
} else {
if((state_val_20740 === (29))){
var inst_20713 = (state_20739[(9)]);
var state_20739__$1 = state_20739;
var statearr_20766_20819 = state_20739__$1;
(statearr_20766_20819[(2)] = inst_20713);

(statearr_20766_20819[(1)] = (31));


return cljs.core.cst$kw$recur;
} else {
if((state_val_20740 === (6))){
var state_20739__$1 = state_20739;
var statearr_20767_20820 = state_20739__$1;
(statearr_20767_20820[(2)] = false);

(statearr_20767_20820[(1)] = (7));


return cljs.core.cst$kw$recur;
} else {
if((state_val_20740 === (28))){
var inst_20709 = (state_20739[(2)]);
var inst_20710 = calc_state();
var inst_20666 = inst_20710;
var state_20739__$1 = (function (){var statearr_20768 = state_20739;
(statearr_20768[(15)] = inst_20709);

(statearr_20768[(7)] = inst_20666);

return statearr_20768;
})();
var statearr_20769_20821 = state_20739__$1;
(statearr_20769_20821[(2)] = null);

(statearr_20769_20821[(1)] = (11));


return cljs.core.cst$kw$recur;
} else {
if((state_val_20740 === (25))){
var inst_20735 = (state_20739[(2)]);
var state_20739__$1 = state_20739;
var statearr_20770_20822 = state_20739__$1;
(statearr_20770_20822[(2)] = inst_20735);

(statearr_20770_20822[(1)] = (12));


return cljs.core.cst$kw$recur;
} else {
if((state_val_20740 === (34))){
var inst_20733 = (state_20739[(2)]);
var state_20739__$1 = state_20739;
var statearr_20771_20823 = state_20739__$1;
(statearr_20771_20823[(2)] = inst_20733);

(statearr_20771_20823[(1)] = (25));


return cljs.core.cst$kw$recur;
} else {
if((state_val_20740 === (17))){
var state_20739__$1 = state_20739;
var statearr_20772_20824 = state_20739__$1;
(statearr_20772_20824[(2)] = false);

(statearr_20772_20824[(1)] = (18));


return cljs.core.cst$kw$recur;
} else {
if((state_val_20740 === (3))){
var state_20739__$1 = state_20739;
var statearr_20773_20825 = state_20739__$1;
(statearr_20773_20825[(2)] = false);

(statearr_20773_20825[(1)] = (4));


return cljs.core.cst$kw$recur;
} else {
if((state_val_20740 === (12))){
var inst_20737 = (state_20739[(2)]);
var state_20739__$1 = state_20739;
return cljs.core.async.impl.ioc_helpers.return_chan(state_20739__$1,inst_20737);
} else {
if((state_val_20740 === (2))){
var inst_20641 = (state_20739[(8)]);
var inst_20646 = inst_20641.cljs$lang$protocol_mask$partition0$;
var inst_20647 = (inst_20646 & (64));
var inst_20648 = inst_20641.cljs$core$ISeq$;
var inst_20649 = (cljs.core.PROTOCOL_SENTINEL === inst_20648);
var inst_20650 = ((inst_20647) || (inst_20649));
var state_20739__$1 = state_20739;
if(cljs.core.truth_(inst_20650)){
var statearr_20774_20826 = state_20739__$1;
(statearr_20774_20826[(1)] = (5));

} else {
var statearr_20775_20827 = state_20739__$1;
(statearr_20775_20827[(1)] = (6));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_20740 === (23))){
var inst_20698 = (state_20739[(14)]);
var inst_20704 = (inst_20698 == null);
var state_20739__$1 = state_20739;
if(cljs.core.truth_(inst_20704)){
var statearr_20776_20828 = state_20739__$1;
(statearr_20776_20828[(1)] = (26));

} else {
var statearr_20777_20829 = state_20739__$1;
(statearr_20777_20829[(1)] = (27));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_20740 === (35))){
var inst_20724 = (state_20739[(2)]);
var state_20739__$1 = state_20739;
if(cljs.core.truth_(inst_20724)){
var statearr_20778_20830 = state_20739__$1;
(statearr_20778_20830[(1)] = (36));

} else {
var statearr_20779_20831 = state_20739__$1;
(statearr_20779_20831[(1)] = (37));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_20740 === (19))){
var inst_20666 = (state_20739[(7)]);
var inst_20686 = cljs.core.apply.cljs$core$IFn$_invoke$arity$2(cljs.core.hash_map,inst_20666);
var state_20739__$1 = state_20739;
var statearr_20780_20832 = state_20739__$1;
(statearr_20780_20832[(2)] = inst_20686);

(statearr_20780_20832[(1)] = (21));


return cljs.core.cst$kw$recur;
} else {
if((state_val_20740 === (11))){
var inst_20666 = (state_20739[(7)]);
var inst_20670 = (inst_20666 == null);
var inst_20671 = cljs.core.not(inst_20670);
var state_20739__$1 = state_20739;
if(inst_20671){
var statearr_20781_20833 = state_20739__$1;
(statearr_20781_20833[(1)] = (13));

} else {
var statearr_20782_20834 = state_20739__$1;
(statearr_20782_20834[(1)] = (14));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_20740 === (9))){
var inst_20641 = (state_20739[(8)]);
var state_20739__$1 = state_20739;
var statearr_20783_20835 = state_20739__$1;
(statearr_20783_20835[(2)] = inst_20641);

(statearr_20783_20835[(1)] = (10));


return cljs.core.cst$kw$recur;
} else {
if((state_val_20740 === (5))){
var state_20739__$1 = state_20739;
var statearr_20784_20836 = state_20739__$1;
(statearr_20784_20836[(2)] = true);

(statearr_20784_20836[(1)] = (7));


return cljs.core.cst$kw$recur;
} else {
if((state_val_20740 === (14))){
var state_20739__$1 = state_20739;
var statearr_20785_20837 = state_20739__$1;
(statearr_20785_20837[(2)] = false);

(statearr_20785_20837[(1)] = (15));


return cljs.core.cst$kw$recur;
} else {
if((state_val_20740 === (26))){
var inst_20699 = (state_20739[(11)]);
var inst_20706 = cljs.core.swap_BANG_.cljs$core$IFn$_invoke$arity$3(cs,cljs.core.dissoc,inst_20699);
var state_20739__$1 = state_20739;
var statearr_20786_20838 = state_20739__$1;
(statearr_20786_20838[(2)] = inst_20706);

(statearr_20786_20838[(1)] = (28));


return cljs.core.cst$kw$recur;
} else {
if((state_val_20740 === (16))){
var state_20739__$1 = state_20739;
var statearr_20787_20839 = state_20739__$1;
(statearr_20787_20839[(2)] = true);

(statearr_20787_20839[(1)] = (18));


return cljs.core.cst$kw$recur;
} else {
if((state_val_20740 === (38))){
var inst_20729 = (state_20739[(2)]);
var state_20739__$1 = state_20739;
var statearr_20788_20840 = state_20739__$1;
(statearr_20788_20840[(2)] = inst_20729);

(statearr_20788_20840[(1)] = (34));


return cljs.core.cst$kw$recur;
} else {
if((state_val_20740 === (30))){
var inst_20690 = (state_20739[(10)]);
var inst_20691 = (state_20739[(13)]);
var inst_20699 = (state_20739[(11)]);
var inst_20716 = cljs.core.empty_QMARK_(inst_20690);
var inst_20717 = (inst_20691.cljs$core$IFn$_invoke$arity$1 ? inst_20691.cljs$core$IFn$_invoke$arity$1(inst_20699) : inst_20691.call(null,inst_20699));
var inst_20718 = cljs.core.not(inst_20717);
var inst_20719 = ((inst_20716) && (inst_20718));
var state_20739__$1 = state_20739;
var statearr_20789_20841 = state_20739__$1;
(statearr_20789_20841[(2)] = inst_20719);

(statearr_20789_20841[(1)] = (31));


return cljs.core.cst$kw$recur;
} else {
if((state_val_20740 === (10))){
var inst_20641 = (state_20739[(8)]);
var inst_20662 = (state_20739[(2)]);
var inst_20663 = cljs.core.get.cljs$core$IFn$_invoke$arity$2(inst_20662,cljs.core.cst$kw$solos);
var inst_20664 = cljs.core.get.cljs$core$IFn$_invoke$arity$2(inst_20662,cljs.core.cst$kw$mutes);
var inst_20665 = cljs.core.get.cljs$core$IFn$_invoke$arity$2(inst_20662,cljs.core.cst$kw$reads);
var inst_20666 = inst_20641;
var state_20739__$1 = (function (){var statearr_20790 = state_20739;
(statearr_20790[(16)] = inst_20665);

(statearr_20790[(17)] = inst_20664);

(statearr_20790[(7)] = inst_20666);

(statearr_20790[(18)] = inst_20663);

return statearr_20790;
})();
var statearr_20791_20842 = state_20739__$1;
(statearr_20791_20842[(2)] = null);

(statearr_20791_20842[(1)] = (11));


return cljs.core.cst$kw$recur;
} else {
if((state_val_20740 === (18))){
var inst_20681 = (state_20739[(2)]);
var state_20739__$1 = state_20739;
var statearr_20792_20843 = state_20739__$1;
(statearr_20792_20843[(2)] = inst_20681);

(statearr_20792_20843[(1)] = (15));


return cljs.core.cst$kw$recur;
} else {
if((state_val_20740 === (37))){
var state_20739__$1 = state_20739;
var statearr_20793_20844 = state_20739__$1;
(statearr_20793_20844[(2)] = null);

(statearr_20793_20844[(1)] = (38));


return cljs.core.cst$kw$recur;
} else {
if((state_val_20740 === (8))){
var inst_20641 = (state_20739[(8)]);
var inst_20659 = cljs.core.apply.cljs$core$IFn$_invoke$arity$2(cljs.core.hash_map,inst_20641);
var state_20739__$1 = state_20739;
var statearr_20794_20845 = state_20739__$1;
(statearr_20794_20845[(2)] = inst_20659);

(statearr_20794_20845[(1)] = (10));


return cljs.core.cst$kw$recur;
} else {
return null;
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
});})(c__7992__auto___20799,cs,solo_modes,attrs,solo_mode,change,changed,pick,calc_state,m))
;
return ((function (switch__7885__auto__,c__7992__auto___20799,cs,solo_modes,attrs,solo_mode,change,changed,pick,calc_state,m){
return (function() {
var cljs$core$async$mix_$_state_machine__7886__auto__ = null;
var cljs$core$async$mix_$_state_machine__7886__auto____0 = (function (){
var statearr_20795 = [null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null];
(statearr_20795[(0)] = cljs$core$async$mix_$_state_machine__7886__auto__);

(statearr_20795[(1)] = (1));

return statearr_20795;
});
var cljs$core$async$mix_$_state_machine__7886__auto____1 = (function (state_20739){
while(true){
var ret_value__7887__auto__ = (function (){try{while(true){
var result__7888__auto__ = switch__7885__auto__(state_20739);
if(cljs.core.keyword_identical_QMARK_(result__7888__auto__,cljs.core.cst$kw$recur)){
continue;
} else {
return result__7888__auto__;
}
break;
}
}catch (e20796){if((e20796 instanceof Object)){
var ex__7889__auto__ = e20796;
var statearr_20797_20846 = state_20739;
(statearr_20797_20846[(5)] = ex__7889__auto__);


cljs.core.async.impl.ioc_helpers.process_exception(state_20739);

return cljs.core.cst$kw$recur;
} else {
throw e20796;

}
}})();
if(cljs.core.keyword_identical_QMARK_(ret_value__7887__auto__,cljs.core.cst$kw$recur)){
var G__20847 = state_20739;
state_20739 = G__20847;
continue;
} else {
return ret_value__7887__auto__;
}
break;
}
});
cljs$core$async$mix_$_state_machine__7886__auto__ = function(state_20739){
switch(arguments.length){
case 0:
return cljs$core$async$mix_$_state_machine__7886__auto____0.call(this);
case 1:
return cljs$core$async$mix_$_state_machine__7886__auto____1.call(this,state_20739);
}
throw(new Error('Invalid arity: ' + arguments.length));
};
cljs$core$async$mix_$_state_machine__7886__auto__.cljs$core$IFn$_invoke$arity$0 = cljs$core$async$mix_$_state_machine__7886__auto____0;
cljs$core$async$mix_$_state_machine__7886__auto__.cljs$core$IFn$_invoke$arity$1 = cljs$core$async$mix_$_state_machine__7886__auto____1;
return cljs$core$async$mix_$_state_machine__7886__auto__;
})()
;})(switch__7885__auto__,c__7992__auto___20799,cs,solo_modes,attrs,solo_mode,change,changed,pick,calc_state,m))
})();
var state__7994__auto__ = (function (){var statearr_20798 = (f__7993__auto__.cljs$core$IFn$_invoke$arity$0 ? f__7993__auto__.cljs$core$IFn$_invoke$arity$0() : f__7993__auto__.call(null));
(statearr_20798[(6)] = c__7992__auto___20799);

return statearr_20798;
})();
return cljs.core.async.impl.ioc_helpers.run_state_machine_wrapped(state__7994__auto__);
});})(c__7992__auto___20799,cs,solo_modes,attrs,solo_mode,change,changed,pick,calc_state,m))
);


return m;
});
/**
 * Adds ch as an input to the mix
 */
cljs.core.async.admix = (function cljs$core$async$admix(mix,ch){
return cljs.core.async.admix_STAR_(mix,ch);
});
/**
 * Removes ch as an input to the mix
 */
cljs.core.async.unmix = (function cljs$core$async$unmix(mix,ch){
return cljs.core.async.unmix_STAR_(mix,ch);
});
/**
 * removes all inputs from the mix
 */
cljs.core.async.unmix_all = (function cljs$core$async$unmix_all(mix){
return cljs.core.async.unmix_all_STAR_(mix);
});
/**
 * Atomically sets the state(s) of one or more channels in a mix. The
 *   state map is a map of channels -> channel-state-map. A
 *   channel-state-map is a map of attrs -> boolean, where attr is one or
 *   more of :mute, :pause or :solo. Any states supplied are merged with
 *   the current state.
 * 
 *   Note that channels can be added to a mix via toggle, which can be
 *   used to add channels in a particular (e.g. paused) state.
 */
cljs.core.async.toggle = (function cljs$core$async$toggle(mix,state_map){
return cljs.core.async.toggle_STAR_(mix,state_map);
});
/**
 * Sets the solo mode of the mix. mode must be one of :mute or :pause
 */
cljs.core.async.solo_mode = (function cljs$core$async$solo_mode(mix,mode){
return cljs.core.async.solo_mode_STAR_(mix,mode);
});

/**
 * @interface
 */
cljs.core.async.Pub = function(){};

cljs.core.async.sub_STAR_ = (function cljs$core$async$sub_STAR_(p,v,ch,close_QMARK_){
if((((!((p == null)))) && ((!((p.cljs$core$async$Pub$sub_STAR_$arity$4 == null)))))){
return p.cljs$core$async$Pub$sub_STAR_$arity$4(p,v,ch,close_QMARK_);
} else {
var x__4347__auto__ = (((p == null))?null:p);
var m__4348__auto__ = (cljs.core.async.sub_STAR_[goog.typeOf(x__4347__auto__)]);
if((!((m__4348__auto__ == null)))){
return (m__4348__auto__.cljs$core$IFn$_invoke$arity$4 ? m__4348__auto__.cljs$core$IFn$_invoke$arity$4(p,v,ch,close_QMARK_) : m__4348__auto__.call(null,p,v,ch,close_QMARK_));
} else {
var m__4348__auto____$1 = (cljs.core.async.sub_STAR_["_"]);
if((!((m__4348__auto____$1 == null)))){
return (m__4348__auto____$1.cljs$core$IFn$_invoke$arity$4 ? m__4348__auto____$1.cljs$core$IFn$_invoke$arity$4(p,v,ch,close_QMARK_) : m__4348__auto____$1.call(null,p,v,ch,close_QMARK_));
} else {
throw cljs.core.missing_protocol("Pub.sub*",p);
}
}
}
});

cljs.core.async.unsub_STAR_ = (function cljs$core$async$unsub_STAR_(p,v,ch){
if((((!((p == null)))) && ((!((p.cljs$core$async$Pub$unsub_STAR_$arity$3 == null)))))){
return p.cljs$core$async$Pub$unsub_STAR_$arity$3(p,v,ch);
} else {
var x__4347__auto__ = (((p == null))?null:p);
var m__4348__auto__ = (cljs.core.async.unsub_STAR_[goog.typeOf(x__4347__auto__)]);
if((!((m__4348__auto__ == null)))){
return (m__4348__auto__.cljs$core$IFn$_invoke$arity$3 ? m__4348__auto__.cljs$core$IFn$_invoke$arity$3(p,v,ch) : m__4348__auto__.call(null,p,v,ch));
} else {
var m__4348__auto____$1 = (cljs.core.async.unsub_STAR_["_"]);
if((!((m__4348__auto____$1 == null)))){
return (m__4348__auto____$1.cljs$core$IFn$_invoke$arity$3 ? m__4348__auto____$1.cljs$core$IFn$_invoke$arity$3(p,v,ch) : m__4348__auto____$1.call(null,p,v,ch));
} else {
throw cljs.core.missing_protocol("Pub.unsub*",p);
}
}
}
});

cljs.core.async.unsub_all_STAR_ = (function cljs$core$async$unsub_all_STAR_(var_args){
var G__20849 = arguments.length;
switch (G__20849) {
case 1:
return cljs.core.async.unsub_all_STAR_.cljs$core$IFn$_invoke$arity$1((arguments[(0)]));

break;
case 2:
return cljs.core.async.unsub_all_STAR_.cljs$core$IFn$_invoke$arity$2((arguments[(0)]),(arguments[(1)]));

break;
default:
throw (new Error(["Invalid arity: ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(arguments.length)].join('')));

}
});

cljs.core.async.unsub_all_STAR_.cljs$core$IFn$_invoke$arity$1 = (function (p){
if((((!((p == null)))) && ((!((p.cljs$core$async$Pub$unsub_all_STAR_$arity$1 == null)))))){
return p.cljs$core$async$Pub$unsub_all_STAR_$arity$1(p);
} else {
var x__4347__auto__ = (((p == null))?null:p);
var m__4348__auto__ = (cljs.core.async.unsub_all_STAR_[goog.typeOf(x__4347__auto__)]);
if((!((m__4348__auto__ == null)))){
return (m__4348__auto__.cljs$core$IFn$_invoke$arity$1 ? m__4348__auto__.cljs$core$IFn$_invoke$arity$1(p) : m__4348__auto__.call(null,p));
} else {
var m__4348__auto____$1 = (cljs.core.async.unsub_all_STAR_["_"]);
if((!((m__4348__auto____$1 == null)))){
return (m__4348__auto____$1.cljs$core$IFn$_invoke$arity$1 ? m__4348__auto____$1.cljs$core$IFn$_invoke$arity$1(p) : m__4348__auto____$1.call(null,p));
} else {
throw cljs.core.missing_protocol("Pub.unsub-all*",p);
}
}
}
});

cljs.core.async.unsub_all_STAR_.cljs$core$IFn$_invoke$arity$2 = (function (p,v){
if((((!((p == null)))) && ((!((p.cljs$core$async$Pub$unsub_all_STAR_$arity$2 == null)))))){
return p.cljs$core$async$Pub$unsub_all_STAR_$arity$2(p,v);
} else {
var x__4347__auto__ = (((p == null))?null:p);
var m__4348__auto__ = (cljs.core.async.unsub_all_STAR_[goog.typeOf(x__4347__auto__)]);
if((!((m__4348__auto__ == null)))){
return (m__4348__auto__.cljs$core$IFn$_invoke$arity$2 ? m__4348__auto__.cljs$core$IFn$_invoke$arity$2(p,v) : m__4348__auto__.call(null,p,v));
} else {
var m__4348__auto____$1 = (cljs.core.async.unsub_all_STAR_["_"]);
if((!((m__4348__auto____$1 == null)))){
return (m__4348__auto____$1.cljs$core$IFn$_invoke$arity$2 ? m__4348__auto____$1.cljs$core$IFn$_invoke$arity$2(p,v) : m__4348__auto____$1.call(null,p,v));
} else {
throw cljs.core.missing_protocol("Pub.unsub-all*",p);
}
}
}
});

cljs.core.async.unsub_all_STAR_.cljs$lang$maxFixedArity = 2;


/**
 * Creates and returns a pub(lication) of the supplied channel,
 *   partitioned into topics by the topic-fn. topic-fn will be applied to
 *   each value on the channel and the result will determine the 'topic'
 *   on which that value will be put. Channels can be subscribed to
 *   receive copies of topics using 'sub', and unsubscribed using
 *   'unsub'. Each topic will be handled by an internal mult on a
 *   dedicated channel. By default these internal channels are
 *   unbuffered, but a buf-fn can be supplied which, given a topic,
 *   creates a buffer with desired properties.
 * 
 *   Each item is distributed to all subs in parallel and synchronously,
 *   i.e. each sub must accept before the next item is distributed. Use
 *   buffering/windowing to prevent slow subs from holding up the pub.
 * 
 *   Items received when there are no matching subs get dropped.
 * 
 *   Note that if buf-fns are used then each topic is handled
 *   asynchronously, i.e. if a channel is subscribed to more than one
 *   topic it should not expect them to be interleaved identically with
 *   the source.
 */
cljs.core.async.pub = (function cljs$core$async$pub(var_args){
var G__20853 = arguments.length;
switch (G__20853) {
case 2:
return cljs.core.async.pub.cljs$core$IFn$_invoke$arity$2((arguments[(0)]),(arguments[(1)]));

break;
case 3:
return cljs.core.async.pub.cljs$core$IFn$_invoke$arity$3((arguments[(0)]),(arguments[(1)]),(arguments[(2)]));

break;
default:
throw (new Error(["Invalid arity: ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(arguments.length)].join('')));

}
});

cljs.core.async.pub.cljs$core$IFn$_invoke$arity$2 = (function (ch,topic_fn){
return cljs.core.async.pub.cljs$core$IFn$_invoke$arity$3(ch,topic_fn,cljs.core.constantly(null));
});

cljs.core.async.pub.cljs$core$IFn$_invoke$arity$3 = (function (ch,topic_fn,buf_fn){
var mults = cljs.core.atom.cljs$core$IFn$_invoke$arity$1(cljs.core.PersistentArrayMap.EMPTY);
var ensure_mult = ((function (mults){
return (function (topic){
var or__4047__auto__ = cljs.core.get.cljs$core$IFn$_invoke$arity$2(cljs.core.deref(mults),topic);
if(cljs.core.truth_(or__4047__auto__)){
return or__4047__auto__;
} else {
return cljs.core.get.cljs$core$IFn$_invoke$arity$2(cljs.core.swap_BANG_.cljs$core$IFn$_invoke$arity$2(mults,((function (or__4047__auto__,mults){
return (function (p1__20851_SHARP_){
if(cljs.core.truth_((p1__20851_SHARP_.cljs$core$IFn$_invoke$arity$1 ? p1__20851_SHARP_.cljs$core$IFn$_invoke$arity$1(topic) : p1__20851_SHARP_.call(null,topic)))){
return p1__20851_SHARP_;
} else {
return cljs.core.assoc.cljs$core$IFn$_invoke$arity$3(p1__20851_SHARP_,topic,cljs.core.async.mult(cljs.core.async.chan.cljs$core$IFn$_invoke$arity$1((buf_fn.cljs$core$IFn$_invoke$arity$1 ? buf_fn.cljs$core$IFn$_invoke$arity$1(topic) : buf_fn.call(null,topic)))));
}
});})(or__4047__auto__,mults))
),topic);
}
});})(mults))
;
var p = (function (){
if((typeof cljs !== 'undefined') && (typeof cljs.core !== 'undefined') && (typeof cljs.core.async !== 'undefined') && (typeof cljs.core.async.t_cljs$core$async20854 !== 'undefined')){
} else {

/**
* @constructor
 * @implements {cljs.core.async.Pub}
 * @implements {cljs.core.IMeta}
 * @implements {cljs.core.async.Mux}
 * @implements {cljs.core.IWithMeta}
*/
cljs.core.async.t_cljs$core$async20854 = (function (ch,topic_fn,buf_fn,mults,ensure_mult,meta20855){
this.ch = ch;
this.topic_fn = topic_fn;
this.buf_fn = buf_fn;
this.mults = mults;
this.ensure_mult = ensure_mult;
this.meta20855 = meta20855;
this.cljs$lang$protocol_mask$partition0$ = 393216;
this.cljs$lang$protocol_mask$partition1$ = 0;
});
cljs.core.async.t_cljs$core$async20854.prototype.cljs$core$IWithMeta$_with_meta$arity$2 = ((function (mults,ensure_mult){
return (function (_20856,meta20855__$1){
var self__ = this;
var _20856__$1 = this;
return (new cljs.core.async.t_cljs$core$async20854(self__.ch,self__.topic_fn,self__.buf_fn,self__.mults,self__.ensure_mult,meta20855__$1));
});})(mults,ensure_mult))
;

cljs.core.async.t_cljs$core$async20854.prototype.cljs$core$IMeta$_meta$arity$1 = ((function (mults,ensure_mult){
return (function (_20856){
var self__ = this;
var _20856__$1 = this;
return self__.meta20855;
});})(mults,ensure_mult))
;

cljs.core.async.t_cljs$core$async20854.prototype.cljs$core$async$Mux$ = cljs.core.PROTOCOL_SENTINEL;

cljs.core.async.t_cljs$core$async20854.prototype.cljs$core$async$Mux$muxch_STAR_$arity$1 = ((function (mults,ensure_mult){
return (function (_){
var self__ = this;
var ___$1 = this;
return self__.ch;
});})(mults,ensure_mult))
;

cljs.core.async.t_cljs$core$async20854.prototype.cljs$core$async$Pub$ = cljs.core.PROTOCOL_SENTINEL;

cljs.core.async.t_cljs$core$async20854.prototype.cljs$core$async$Pub$sub_STAR_$arity$4 = ((function (mults,ensure_mult){
return (function (p,topic,ch__$1,close_QMARK_){
var self__ = this;
var p__$1 = this;
var m = (self__.ensure_mult.cljs$core$IFn$_invoke$arity$1 ? self__.ensure_mult.cljs$core$IFn$_invoke$arity$1(topic) : self__.ensure_mult.call(null,topic));
return cljs.core.async.tap.cljs$core$IFn$_invoke$arity$3(m,ch__$1,close_QMARK_);
});})(mults,ensure_mult))
;

cljs.core.async.t_cljs$core$async20854.prototype.cljs$core$async$Pub$unsub_STAR_$arity$3 = ((function (mults,ensure_mult){
return (function (p,topic,ch__$1){
var self__ = this;
var p__$1 = this;
var temp__5457__auto__ = cljs.core.get.cljs$core$IFn$_invoke$arity$2(cljs.core.deref(self__.mults),topic);
if(cljs.core.truth_(temp__5457__auto__)){
var m = temp__5457__auto__;
return cljs.core.async.untap(m,ch__$1);
} else {
return null;
}
});})(mults,ensure_mult))
;

cljs.core.async.t_cljs$core$async20854.prototype.cljs$core$async$Pub$unsub_all_STAR_$arity$1 = ((function (mults,ensure_mult){
return (function (_){
var self__ = this;
var ___$1 = this;
return cljs.core.reset_BANG_(self__.mults,cljs.core.PersistentArrayMap.EMPTY);
});})(mults,ensure_mult))
;

cljs.core.async.t_cljs$core$async20854.prototype.cljs$core$async$Pub$unsub_all_STAR_$arity$2 = ((function (mults,ensure_mult){
return (function (_,topic){
var self__ = this;
var ___$1 = this;
return cljs.core.swap_BANG_.cljs$core$IFn$_invoke$arity$3(self__.mults,cljs.core.dissoc,topic);
});})(mults,ensure_mult))
;

cljs.core.async.t_cljs$core$async20854.getBasis = ((function (mults,ensure_mult){
return (function (){
return new cljs.core.PersistentVector(null, 6, 5, cljs.core.PersistentVector.EMPTY_NODE, [cljs.core.cst$sym$ch,cljs.core.cst$sym$topic_DASH_fn,cljs.core.cst$sym$buf_DASH_fn,cljs.core.cst$sym$mults,cljs.core.cst$sym$ensure_DASH_mult,cljs.core.cst$sym$meta20855], null);
});})(mults,ensure_mult))
;

cljs.core.async.t_cljs$core$async20854.cljs$lang$type = true;

cljs.core.async.t_cljs$core$async20854.cljs$lang$ctorStr = "cljs.core.async/t_cljs$core$async20854";

cljs.core.async.t_cljs$core$async20854.cljs$lang$ctorPrWriter = ((function (mults,ensure_mult){
return (function (this__4290__auto__,writer__4291__auto__,opt__4292__auto__){
return cljs.core._write(writer__4291__auto__,"cljs.core.async/t_cljs$core$async20854");
});})(mults,ensure_mult))
;

/**
 * Positional factory function for cljs.core.async/t_cljs$core$async20854.
 */
cljs.core.async.__GT_t_cljs$core$async20854 = ((function (mults,ensure_mult){
return (function cljs$core$async$__GT_t_cljs$core$async20854(ch__$1,topic_fn__$1,buf_fn__$1,mults__$1,ensure_mult__$1,meta20855){
return (new cljs.core.async.t_cljs$core$async20854(ch__$1,topic_fn__$1,buf_fn__$1,mults__$1,ensure_mult__$1,meta20855));
});})(mults,ensure_mult))
;

}

return (new cljs.core.async.t_cljs$core$async20854(ch,topic_fn,buf_fn,mults,ensure_mult,cljs.core.PersistentArrayMap.EMPTY));
})()
;
var c__7992__auto___20974 = cljs.core.async.chan.cljs$core$IFn$_invoke$arity$1((1));
cljs.core.async.impl.dispatch.run(((function (c__7992__auto___20974,mults,ensure_mult,p){
return (function (){
var f__7993__auto__ = (function (){var switch__7885__auto__ = ((function (c__7992__auto___20974,mults,ensure_mult,p){
return (function (state_20928){
var state_val_20929 = (state_20928[(1)]);
if((state_val_20929 === (7))){
var inst_20924 = (state_20928[(2)]);
var state_20928__$1 = state_20928;
var statearr_20930_20975 = state_20928__$1;
(statearr_20930_20975[(2)] = inst_20924);

(statearr_20930_20975[(1)] = (3));


return cljs.core.cst$kw$recur;
} else {
if((state_val_20929 === (20))){
var state_20928__$1 = state_20928;
var statearr_20931_20976 = state_20928__$1;
(statearr_20931_20976[(2)] = null);

(statearr_20931_20976[(1)] = (21));


return cljs.core.cst$kw$recur;
} else {
if((state_val_20929 === (1))){
var state_20928__$1 = state_20928;
var statearr_20932_20977 = state_20928__$1;
(statearr_20932_20977[(2)] = null);

(statearr_20932_20977[(1)] = (2));


return cljs.core.cst$kw$recur;
} else {
if((state_val_20929 === (24))){
var inst_20907 = (state_20928[(7)]);
var inst_20916 = cljs.core.swap_BANG_.cljs$core$IFn$_invoke$arity$3(mults,cljs.core.dissoc,inst_20907);
var state_20928__$1 = state_20928;
var statearr_20933_20978 = state_20928__$1;
(statearr_20933_20978[(2)] = inst_20916);

(statearr_20933_20978[(1)] = (25));


return cljs.core.cst$kw$recur;
} else {
if((state_val_20929 === (4))){
var inst_20859 = (state_20928[(8)]);
var inst_20859__$1 = (state_20928[(2)]);
var inst_20860 = (inst_20859__$1 == null);
var state_20928__$1 = (function (){var statearr_20934 = state_20928;
(statearr_20934[(8)] = inst_20859__$1);

return statearr_20934;
})();
if(cljs.core.truth_(inst_20860)){
var statearr_20935_20979 = state_20928__$1;
(statearr_20935_20979[(1)] = (5));

} else {
var statearr_20936_20980 = state_20928__$1;
(statearr_20936_20980[(1)] = (6));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_20929 === (15))){
var inst_20901 = (state_20928[(2)]);
var state_20928__$1 = state_20928;
var statearr_20937_20981 = state_20928__$1;
(statearr_20937_20981[(2)] = inst_20901);

(statearr_20937_20981[(1)] = (12));


return cljs.core.cst$kw$recur;
} else {
if((state_val_20929 === (21))){
var inst_20921 = (state_20928[(2)]);
var state_20928__$1 = (function (){var statearr_20938 = state_20928;
(statearr_20938[(9)] = inst_20921);

return statearr_20938;
})();
var statearr_20939_20982 = state_20928__$1;
(statearr_20939_20982[(2)] = null);

(statearr_20939_20982[(1)] = (2));


return cljs.core.cst$kw$recur;
} else {
if((state_val_20929 === (13))){
var inst_20883 = (state_20928[(10)]);
var inst_20885 = cljs.core.chunked_seq_QMARK_(inst_20883);
var state_20928__$1 = state_20928;
if(inst_20885){
var statearr_20940_20983 = state_20928__$1;
(statearr_20940_20983[(1)] = (16));

} else {
var statearr_20941_20984 = state_20928__$1;
(statearr_20941_20984[(1)] = (17));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_20929 === (22))){
var inst_20913 = (state_20928[(2)]);
var state_20928__$1 = state_20928;
if(cljs.core.truth_(inst_20913)){
var statearr_20942_20985 = state_20928__$1;
(statearr_20942_20985[(1)] = (23));

} else {
var statearr_20943_20986 = state_20928__$1;
(statearr_20943_20986[(1)] = (24));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_20929 === (6))){
var inst_20859 = (state_20928[(8)]);
var inst_20909 = (state_20928[(11)]);
var inst_20907 = (state_20928[(7)]);
var inst_20907__$1 = (topic_fn.cljs$core$IFn$_invoke$arity$1 ? topic_fn.cljs$core$IFn$_invoke$arity$1(inst_20859) : topic_fn.call(null,inst_20859));
var inst_20908 = cljs.core.deref(mults);
var inst_20909__$1 = cljs.core.get.cljs$core$IFn$_invoke$arity$2(inst_20908,inst_20907__$1);
var state_20928__$1 = (function (){var statearr_20944 = state_20928;
(statearr_20944[(11)] = inst_20909__$1);

(statearr_20944[(7)] = inst_20907__$1);

return statearr_20944;
})();
if(cljs.core.truth_(inst_20909__$1)){
var statearr_20945_20987 = state_20928__$1;
(statearr_20945_20987[(1)] = (19));

} else {
var statearr_20946_20988 = state_20928__$1;
(statearr_20946_20988[(1)] = (20));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_20929 === (25))){
var inst_20918 = (state_20928[(2)]);
var state_20928__$1 = state_20928;
var statearr_20947_20989 = state_20928__$1;
(statearr_20947_20989[(2)] = inst_20918);

(statearr_20947_20989[(1)] = (21));


return cljs.core.cst$kw$recur;
} else {
if((state_val_20929 === (17))){
var inst_20883 = (state_20928[(10)]);
var inst_20892 = cljs.core.first(inst_20883);
var inst_20893 = cljs.core.async.muxch_STAR_(inst_20892);
var inst_20894 = cljs.core.async.close_BANG_(inst_20893);
var inst_20895 = cljs.core.next(inst_20883);
var inst_20869 = inst_20895;
var inst_20870 = null;
var inst_20871 = (0);
var inst_20872 = (0);
var state_20928__$1 = (function (){var statearr_20948 = state_20928;
(statearr_20948[(12)] = inst_20869);

(statearr_20948[(13)] = inst_20870);

(statearr_20948[(14)] = inst_20871);

(statearr_20948[(15)] = inst_20894);

(statearr_20948[(16)] = inst_20872);

return statearr_20948;
})();
var statearr_20949_20990 = state_20928__$1;
(statearr_20949_20990[(2)] = null);

(statearr_20949_20990[(1)] = (8));


return cljs.core.cst$kw$recur;
} else {
if((state_val_20929 === (3))){
var inst_20926 = (state_20928[(2)]);
var state_20928__$1 = state_20928;
return cljs.core.async.impl.ioc_helpers.return_chan(state_20928__$1,inst_20926);
} else {
if((state_val_20929 === (12))){
var inst_20903 = (state_20928[(2)]);
var state_20928__$1 = state_20928;
var statearr_20950_20991 = state_20928__$1;
(statearr_20950_20991[(2)] = inst_20903);

(statearr_20950_20991[(1)] = (9));


return cljs.core.cst$kw$recur;
} else {
if((state_val_20929 === (2))){
var state_20928__$1 = state_20928;
return cljs.core.async.impl.ioc_helpers.take_BANG_(state_20928__$1,(4),ch);
} else {
if((state_val_20929 === (23))){
var state_20928__$1 = state_20928;
var statearr_20951_20992 = state_20928__$1;
(statearr_20951_20992[(2)] = null);

(statearr_20951_20992[(1)] = (25));


return cljs.core.cst$kw$recur;
} else {
if((state_val_20929 === (19))){
var inst_20859 = (state_20928[(8)]);
var inst_20909 = (state_20928[(11)]);
var inst_20911 = cljs.core.async.muxch_STAR_(inst_20909);
var state_20928__$1 = state_20928;
return cljs.core.async.impl.ioc_helpers.put_BANG_(state_20928__$1,(22),inst_20911,inst_20859);
} else {
if((state_val_20929 === (11))){
var inst_20869 = (state_20928[(12)]);
var inst_20883 = (state_20928[(10)]);
var inst_20883__$1 = cljs.core.seq(inst_20869);
var state_20928__$1 = (function (){var statearr_20952 = state_20928;
(statearr_20952[(10)] = inst_20883__$1);

return statearr_20952;
})();
if(inst_20883__$1){
var statearr_20953_20993 = state_20928__$1;
(statearr_20953_20993[(1)] = (13));

} else {
var statearr_20954_20994 = state_20928__$1;
(statearr_20954_20994[(1)] = (14));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_20929 === (9))){
var inst_20905 = (state_20928[(2)]);
var state_20928__$1 = state_20928;
var statearr_20955_20995 = state_20928__$1;
(statearr_20955_20995[(2)] = inst_20905);

(statearr_20955_20995[(1)] = (7));


return cljs.core.cst$kw$recur;
} else {
if((state_val_20929 === (5))){
var inst_20866 = cljs.core.deref(mults);
var inst_20867 = cljs.core.vals(inst_20866);
var inst_20868 = cljs.core.seq(inst_20867);
var inst_20869 = inst_20868;
var inst_20870 = null;
var inst_20871 = (0);
var inst_20872 = (0);
var state_20928__$1 = (function (){var statearr_20956 = state_20928;
(statearr_20956[(12)] = inst_20869);

(statearr_20956[(13)] = inst_20870);

(statearr_20956[(14)] = inst_20871);

(statearr_20956[(16)] = inst_20872);

return statearr_20956;
})();
var statearr_20957_20996 = state_20928__$1;
(statearr_20957_20996[(2)] = null);

(statearr_20957_20996[(1)] = (8));


return cljs.core.cst$kw$recur;
} else {
if((state_val_20929 === (14))){
var state_20928__$1 = state_20928;
var statearr_20961_20997 = state_20928__$1;
(statearr_20961_20997[(2)] = null);

(statearr_20961_20997[(1)] = (15));


return cljs.core.cst$kw$recur;
} else {
if((state_val_20929 === (16))){
var inst_20883 = (state_20928[(10)]);
var inst_20887 = cljs.core.chunk_first(inst_20883);
var inst_20888 = cljs.core.chunk_rest(inst_20883);
var inst_20889 = cljs.core.count(inst_20887);
var inst_20869 = inst_20888;
var inst_20870 = inst_20887;
var inst_20871 = inst_20889;
var inst_20872 = (0);
var state_20928__$1 = (function (){var statearr_20962 = state_20928;
(statearr_20962[(12)] = inst_20869);

(statearr_20962[(13)] = inst_20870);

(statearr_20962[(14)] = inst_20871);

(statearr_20962[(16)] = inst_20872);

return statearr_20962;
})();
var statearr_20963_20998 = state_20928__$1;
(statearr_20963_20998[(2)] = null);

(statearr_20963_20998[(1)] = (8));


return cljs.core.cst$kw$recur;
} else {
if((state_val_20929 === (10))){
var inst_20869 = (state_20928[(12)]);
var inst_20870 = (state_20928[(13)]);
var inst_20871 = (state_20928[(14)]);
var inst_20872 = (state_20928[(16)]);
var inst_20877 = cljs.core._nth.cljs$core$IFn$_invoke$arity$2(inst_20870,inst_20872);
var inst_20878 = cljs.core.async.muxch_STAR_(inst_20877);
var inst_20879 = cljs.core.async.close_BANG_(inst_20878);
var inst_20880 = (inst_20872 + (1));
var tmp20958 = inst_20869;
var tmp20959 = inst_20870;
var tmp20960 = inst_20871;
var inst_20869__$1 = tmp20958;
var inst_20870__$1 = tmp20959;
var inst_20871__$1 = tmp20960;
var inst_20872__$1 = inst_20880;
var state_20928__$1 = (function (){var statearr_20964 = state_20928;
(statearr_20964[(12)] = inst_20869__$1);

(statearr_20964[(13)] = inst_20870__$1);

(statearr_20964[(14)] = inst_20871__$1);

(statearr_20964[(17)] = inst_20879);

(statearr_20964[(16)] = inst_20872__$1);

return statearr_20964;
})();
var statearr_20965_20999 = state_20928__$1;
(statearr_20965_20999[(2)] = null);

(statearr_20965_20999[(1)] = (8));


return cljs.core.cst$kw$recur;
} else {
if((state_val_20929 === (18))){
var inst_20898 = (state_20928[(2)]);
var state_20928__$1 = state_20928;
var statearr_20966_21000 = state_20928__$1;
(statearr_20966_21000[(2)] = inst_20898);

(statearr_20966_21000[(1)] = (15));


return cljs.core.cst$kw$recur;
} else {
if((state_val_20929 === (8))){
var inst_20871 = (state_20928[(14)]);
var inst_20872 = (state_20928[(16)]);
var inst_20874 = (inst_20872 < inst_20871);
var inst_20875 = inst_20874;
var state_20928__$1 = state_20928;
if(cljs.core.truth_(inst_20875)){
var statearr_20967_21001 = state_20928__$1;
(statearr_20967_21001[(1)] = (10));

} else {
var statearr_20968_21002 = state_20928__$1;
(statearr_20968_21002[(1)] = (11));

}

return cljs.core.cst$kw$recur;
} else {
return null;
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
});})(c__7992__auto___20974,mults,ensure_mult,p))
;
return ((function (switch__7885__auto__,c__7992__auto___20974,mults,ensure_mult,p){
return (function() {
var cljs$core$async$state_machine__7886__auto__ = null;
var cljs$core$async$state_machine__7886__auto____0 = (function (){
var statearr_20969 = [null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null];
(statearr_20969[(0)] = cljs$core$async$state_machine__7886__auto__);

(statearr_20969[(1)] = (1));

return statearr_20969;
});
var cljs$core$async$state_machine__7886__auto____1 = (function (state_20928){
while(true){
var ret_value__7887__auto__ = (function (){try{while(true){
var result__7888__auto__ = switch__7885__auto__(state_20928);
if(cljs.core.keyword_identical_QMARK_(result__7888__auto__,cljs.core.cst$kw$recur)){
continue;
} else {
return result__7888__auto__;
}
break;
}
}catch (e20970){if((e20970 instanceof Object)){
var ex__7889__auto__ = e20970;
var statearr_20971_21003 = state_20928;
(statearr_20971_21003[(5)] = ex__7889__auto__);


cljs.core.async.impl.ioc_helpers.process_exception(state_20928);

return cljs.core.cst$kw$recur;
} else {
throw e20970;

}
}})();
if(cljs.core.keyword_identical_QMARK_(ret_value__7887__auto__,cljs.core.cst$kw$recur)){
var G__21004 = state_20928;
state_20928 = G__21004;
continue;
} else {
return ret_value__7887__auto__;
}
break;
}
});
cljs$core$async$state_machine__7886__auto__ = function(state_20928){
switch(arguments.length){
case 0:
return cljs$core$async$state_machine__7886__auto____0.call(this);
case 1:
return cljs$core$async$state_machine__7886__auto____1.call(this,state_20928);
}
throw(new Error('Invalid arity: ' + arguments.length));
};
cljs$core$async$state_machine__7886__auto__.cljs$core$IFn$_invoke$arity$0 = cljs$core$async$state_machine__7886__auto____0;
cljs$core$async$state_machine__7886__auto__.cljs$core$IFn$_invoke$arity$1 = cljs$core$async$state_machine__7886__auto____1;
return cljs$core$async$state_machine__7886__auto__;
})()
;})(switch__7885__auto__,c__7992__auto___20974,mults,ensure_mult,p))
})();
var state__7994__auto__ = (function (){var statearr_20972 = (f__7993__auto__.cljs$core$IFn$_invoke$arity$0 ? f__7993__auto__.cljs$core$IFn$_invoke$arity$0() : f__7993__auto__.call(null));
(statearr_20972[(6)] = c__7992__auto___20974);

return statearr_20972;
})();
return cljs.core.async.impl.ioc_helpers.run_state_machine_wrapped(state__7994__auto__);
});})(c__7992__auto___20974,mults,ensure_mult,p))
);


return p;
});

cljs.core.async.pub.cljs$lang$maxFixedArity = 3;

/**
 * Subscribes a channel to a topic of a pub.
 * 
 *   By default the channel will be closed when the source closes,
 *   but can be determined by the close? parameter.
 */
cljs.core.async.sub = (function cljs$core$async$sub(var_args){
var G__21006 = arguments.length;
switch (G__21006) {
case 3:
return cljs.core.async.sub.cljs$core$IFn$_invoke$arity$3((arguments[(0)]),(arguments[(1)]),(arguments[(2)]));

break;
case 4:
return cljs.core.async.sub.cljs$core$IFn$_invoke$arity$4((arguments[(0)]),(arguments[(1)]),(arguments[(2)]),(arguments[(3)]));

break;
default:
throw (new Error(["Invalid arity: ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(arguments.length)].join('')));

}
});

cljs.core.async.sub.cljs$core$IFn$_invoke$arity$3 = (function (p,topic,ch){
return cljs.core.async.sub.cljs$core$IFn$_invoke$arity$4(p,topic,ch,true);
});

cljs.core.async.sub.cljs$core$IFn$_invoke$arity$4 = (function (p,topic,ch,close_QMARK_){
return cljs.core.async.sub_STAR_(p,topic,ch,close_QMARK_);
});

cljs.core.async.sub.cljs$lang$maxFixedArity = 4;

/**
 * Unsubscribes a channel from a topic of a pub
 */
cljs.core.async.unsub = (function cljs$core$async$unsub(p,topic,ch){
return cljs.core.async.unsub_STAR_(p,topic,ch);
});
/**
 * Unsubscribes all channels from a pub, or a topic of a pub
 */
cljs.core.async.unsub_all = (function cljs$core$async$unsub_all(var_args){
var G__21009 = arguments.length;
switch (G__21009) {
case 1:
return cljs.core.async.unsub_all.cljs$core$IFn$_invoke$arity$1((arguments[(0)]));

break;
case 2:
return cljs.core.async.unsub_all.cljs$core$IFn$_invoke$arity$2((arguments[(0)]),(arguments[(1)]));

break;
default:
throw (new Error(["Invalid arity: ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(arguments.length)].join('')));

}
});

cljs.core.async.unsub_all.cljs$core$IFn$_invoke$arity$1 = (function (p){
return cljs.core.async.unsub_all_STAR_.cljs$core$IFn$_invoke$arity$1(p);
});

cljs.core.async.unsub_all.cljs$core$IFn$_invoke$arity$2 = (function (p,topic){
return cljs.core.async.unsub_all_STAR_.cljs$core$IFn$_invoke$arity$2(p,topic);
});

cljs.core.async.unsub_all.cljs$lang$maxFixedArity = 2;

/**
 * Takes a function and a collection of source channels, and returns a
 *   channel which contains the values produced by applying f to the set
 *   of first items taken from each source channel, followed by applying
 *   f to the set of second items from each channel, until any one of the
 *   channels is closed, at which point the output channel will be
 *   closed. The returned channel will be unbuffered by default, or a
 *   buf-or-n can be supplied
 */
cljs.core.async.map = (function cljs$core$async$map(var_args){
var G__21012 = arguments.length;
switch (G__21012) {
case 2:
return cljs.core.async.map.cljs$core$IFn$_invoke$arity$2((arguments[(0)]),(arguments[(1)]));

break;
case 3:
return cljs.core.async.map.cljs$core$IFn$_invoke$arity$3((arguments[(0)]),(arguments[(1)]),(arguments[(2)]));

break;
default:
throw (new Error(["Invalid arity: ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(arguments.length)].join('')));

}
});

cljs.core.async.map.cljs$core$IFn$_invoke$arity$2 = (function (f,chs){
return cljs.core.async.map.cljs$core$IFn$_invoke$arity$3(f,chs,null);
});

cljs.core.async.map.cljs$core$IFn$_invoke$arity$3 = (function (f,chs,buf_or_n){
var chs__$1 = cljs.core.vec(chs);
var out = cljs.core.async.chan.cljs$core$IFn$_invoke$arity$1(buf_or_n);
var cnt = cljs.core.count(chs__$1);
var rets = cljs.core.object_array.cljs$core$IFn$_invoke$arity$1(cnt);
var dchan = cljs.core.async.chan.cljs$core$IFn$_invoke$arity$1((1));
var dctr = cljs.core.atom.cljs$core$IFn$_invoke$arity$1(null);
var done = cljs.core.mapv.cljs$core$IFn$_invoke$arity$2(((function (chs__$1,out,cnt,rets,dchan,dctr){
return (function (i){
return ((function (chs__$1,out,cnt,rets,dchan,dctr){
return (function (ret){
(rets[i] = ret);

if((cljs.core.swap_BANG_.cljs$core$IFn$_invoke$arity$2(dctr,cljs.core.dec) === (0))){
return cljs.core.async.put_BANG_.cljs$core$IFn$_invoke$arity$2(dchan,rets.slice((0)));
} else {
return null;
}
});
;})(chs__$1,out,cnt,rets,dchan,dctr))
});})(chs__$1,out,cnt,rets,dchan,dctr))
,cljs.core.range.cljs$core$IFn$_invoke$arity$1(cnt));
var c__7992__auto___21079 = cljs.core.async.chan.cljs$core$IFn$_invoke$arity$1((1));
cljs.core.async.impl.dispatch.run(((function (c__7992__auto___21079,chs__$1,out,cnt,rets,dchan,dctr,done){
return (function (){
var f__7993__auto__ = (function (){var switch__7885__auto__ = ((function (c__7992__auto___21079,chs__$1,out,cnt,rets,dchan,dctr,done){
return (function (state_21051){
var state_val_21052 = (state_21051[(1)]);
if((state_val_21052 === (7))){
var state_21051__$1 = state_21051;
var statearr_21053_21080 = state_21051__$1;
(statearr_21053_21080[(2)] = null);

(statearr_21053_21080[(1)] = (8));


return cljs.core.cst$kw$recur;
} else {
if((state_val_21052 === (1))){
var state_21051__$1 = state_21051;
var statearr_21054_21081 = state_21051__$1;
(statearr_21054_21081[(2)] = null);

(statearr_21054_21081[(1)] = (2));


return cljs.core.cst$kw$recur;
} else {
if((state_val_21052 === (4))){
var inst_21015 = (state_21051[(7)]);
var inst_21017 = (inst_21015 < cnt);
var state_21051__$1 = state_21051;
if(cljs.core.truth_(inst_21017)){
var statearr_21055_21082 = state_21051__$1;
(statearr_21055_21082[(1)] = (6));

} else {
var statearr_21056_21083 = state_21051__$1;
(statearr_21056_21083[(1)] = (7));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_21052 === (15))){
var inst_21047 = (state_21051[(2)]);
var state_21051__$1 = state_21051;
var statearr_21057_21084 = state_21051__$1;
(statearr_21057_21084[(2)] = inst_21047);

(statearr_21057_21084[(1)] = (3));


return cljs.core.cst$kw$recur;
} else {
if((state_val_21052 === (13))){
var inst_21040 = cljs.core.async.close_BANG_(out);
var state_21051__$1 = state_21051;
var statearr_21058_21085 = state_21051__$1;
(statearr_21058_21085[(2)] = inst_21040);

(statearr_21058_21085[(1)] = (15));


return cljs.core.cst$kw$recur;
} else {
if((state_val_21052 === (6))){
var state_21051__$1 = state_21051;
var statearr_21059_21086 = state_21051__$1;
(statearr_21059_21086[(2)] = null);

(statearr_21059_21086[(1)] = (11));


return cljs.core.cst$kw$recur;
} else {
if((state_val_21052 === (3))){
var inst_21049 = (state_21051[(2)]);
var state_21051__$1 = state_21051;
return cljs.core.async.impl.ioc_helpers.return_chan(state_21051__$1,inst_21049);
} else {
if((state_val_21052 === (12))){
var inst_21037 = (state_21051[(8)]);
var inst_21037__$1 = (state_21051[(2)]);
var inst_21038 = cljs.core.some(cljs.core.nil_QMARK_,inst_21037__$1);
var state_21051__$1 = (function (){var statearr_21060 = state_21051;
(statearr_21060[(8)] = inst_21037__$1);

return statearr_21060;
})();
if(cljs.core.truth_(inst_21038)){
var statearr_21061_21087 = state_21051__$1;
(statearr_21061_21087[(1)] = (13));

} else {
var statearr_21062_21088 = state_21051__$1;
(statearr_21062_21088[(1)] = (14));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_21052 === (2))){
var inst_21014 = cljs.core.reset_BANG_(dctr,cnt);
var inst_21015 = (0);
var state_21051__$1 = (function (){var statearr_21063 = state_21051;
(statearr_21063[(7)] = inst_21015);

(statearr_21063[(9)] = inst_21014);

return statearr_21063;
})();
var statearr_21064_21089 = state_21051__$1;
(statearr_21064_21089[(2)] = null);

(statearr_21064_21089[(1)] = (4));


return cljs.core.cst$kw$recur;
} else {
if((state_val_21052 === (11))){
var inst_21015 = (state_21051[(7)]);
var _ = cljs.core.async.impl.ioc_helpers.add_exception_frame(state_21051,(10),Object,null,(9));
var inst_21024 = (chs__$1.cljs$core$IFn$_invoke$arity$1 ? chs__$1.cljs$core$IFn$_invoke$arity$1(inst_21015) : chs__$1.call(null,inst_21015));
var inst_21025 = (done.cljs$core$IFn$_invoke$arity$1 ? done.cljs$core$IFn$_invoke$arity$1(inst_21015) : done.call(null,inst_21015));
var inst_21026 = cljs.core.async.take_BANG_.cljs$core$IFn$_invoke$arity$2(inst_21024,inst_21025);
var state_21051__$1 = state_21051;
var statearr_21065_21090 = state_21051__$1;
(statearr_21065_21090[(2)] = inst_21026);


cljs.core.async.impl.ioc_helpers.process_exception(state_21051__$1);

return cljs.core.cst$kw$recur;
} else {
if((state_val_21052 === (9))){
var inst_21015 = (state_21051[(7)]);
var inst_21028 = (state_21051[(2)]);
var inst_21029 = (inst_21015 + (1));
var inst_21015__$1 = inst_21029;
var state_21051__$1 = (function (){var statearr_21066 = state_21051;
(statearr_21066[(10)] = inst_21028);

(statearr_21066[(7)] = inst_21015__$1);

return statearr_21066;
})();
var statearr_21067_21091 = state_21051__$1;
(statearr_21067_21091[(2)] = null);

(statearr_21067_21091[(1)] = (4));


return cljs.core.cst$kw$recur;
} else {
if((state_val_21052 === (5))){
var inst_21035 = (state_21051[(2)]);
var state_21051__$1 = (function (){var statearr_21068 = state_21051;
(statearr_21068[(11)] = inst_21035);

return statearr_21068;
})();
return cljs.core.async.impl.ioc_helpers.take_BANG_(state_21051__$1,(12),dchan);
} else {
if((state_val_21052 === (14))){
var inst_21037 = (state_21051[(8)]);
var inst_21042 = cljs.core.apply.cljs$core$IFn$_invoke$arity$2(f,inst_21037);
var state_21051__$1 = state_21051;
return cljs.core.async.impl.ioc_helpers.put_BANG_(state_21051__$1,(16),out,inst_21042);
} else {
if((state_val_21052 === (16))){
var inst_21044 = (state_21051[(2)]);
var state_21051__$1 = (function (){var statearr_21069 = state_21051;
(statearr_21069[(12)] = inst_21044);

return statearr_21069;
})();
var statearr_21070_21092 = state_21051__$1;
(statearr_21070_21092[(2)] = null);

(statearr_21070_21092[(1)] = (2));


return cljs.core.cst$kw$recur;
} else {
if((state_val_21052 === (10))){
var inst_21019 = (state_21051[(2)]);
var inst_21020 = cljs.core.swap_BANG_.cljs$core$IFn$_invoke$arity$2(dctr,cljs.core.dec);
var state_21051__$1 = (function (){var statearr_21071 = state_21051;
(statearr_21071[(13)] = inst_21019);

return statearr_21071;
})();
var statearr_21072_21093 = state_21051__$1;
(statearr_21072_21093[(2)] = inst_21020);


cljs.core.async.impl.ioc_helpers.process_exception(state_21051__$1);

return cljs.core.cst$kw$recur;
} else {
if((state_val_21052 === (8))){
var inst_21033 = (state_21051[(2)]);
var state_21051__$1 = state_21051;
var statearr_21073_21094 = state_21051__$1;
(statearr_21073_21094[(2)] = inst_21033);

(statearr_21073_21094[(1)] = (5));


return cljs.core.cst$kw$recur;
} else {
return null;
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
});})(c__7992__auto___21079,chs__$1,out,cnt,rets,dchan,dctr,done))
;
return ((function (switch__7885__auto__,c__7992__auto___21079,chs__$1,out,cnt,rets,dchan,dctr,done){
return (function() {
var cljs$core$async$state_machine__7886__auto__ = null;
var cljs$core$async$state_machine__7886__auto____0 = (function (){
var statearr_21074 = [null,null,null,null,null,null,null,null,null,null,null,null,null,null];
(statearr_21074[(0)] = cljs$core$async$state_machine__7886__auto__);

(statearr_21074[(1)] = (1));

return statearr_21074;
});
var cljs$core$async$state_machine__7886__auto____1 = (function (state_21051){
while(true){
var ret_value__7887__auto__ = (function (){try{while(true){
var result__7888__auto__ = switch__7885__auto__(state_21051);
if(cljs.core.keyword_identical_QMARK_(result__7888__auto__,cljs.core.cst$kw$recur)){
continue;
} else {
return result__7888__auto__;
}
break;
}
}catch (e21075){if((e21075 instanceof Object)){
var ex__7889__auto__ = e21075;
var statearr_21076_21095 = state_21051;
(statearr_21076_21095[(5)] = ex__7889__auto__);


cljs.core.async.impl.ioc_helpers.process_exception(state_21051);

return cljs.core.cst$kw$recur;
} else {
throw e21075;

}
}})();
if(cljs.core.keyword_identical_QMARK_(ret_value__7887__auto__,cljs.core.cst$kw$recur)){
var G__21096 = state_21051;
state_21051 = G__21096;
continue;
} else {
return ret_value__7887__auto__;
}
break;
}
});
cljs$core$async$state_machine__7886__auto__ = function(state_21051){
switch(arguments.length){
case 0:
return cljs$core$async$state_machine__7886__auto____0.call(this);
case 1:
return cljs$core$async$state_machine__7886__auto____1.call(this,state_21051);
}
throw(new Error('Invalid arity: ' + arguments.length));
};
cljs$core$async$state_machine__7886__auto__.cljs$core$IFn$_invoke$arity$0 = cljs$core$async$state_machine__7886__auto____0;
cljs$core$async$state_machine__7886__auto__.cljs$core$IFn$_invoke$arity$1 = cljs$core$async$state_machine__7886__auto____1;
return cljs$core$async$state_machine__7886__auto__;
})()
;})(switch__7885__auto__,c__7992__auto___21079,chs__$1,out,cnt,rets,dchan,dctr,done))
})();
var state__7994__auto__ = (function (){var statearr_21077 = (f__7993__auto__.cljs$core$IFn$_invoke$arity$0 ? f__7993__auto__.cljs$core$IFn$_invoke$arity$0() : f__7993__auto__.call(null));
(statearr_21077[(6)] = c__7992__auto___21079);

return statearr_21077;
})();
return cljs.core.async.impl.ioc_helpers.run_state_machine_wrapped(state__7994__auto__);
});})(c__7992__auto___21079,chs__$1,out,cnt,rets,dchan,dctr,done))
);


return out;
});

cljs.core.async.map.cljs$lang$maxFixedArity = 3;

/**
 * Takes a collection of source channels and returns a channel which
 *   contains all values taken from them. The returned channel will be
 *   unbuffered by default, or a buf-or-n can be supplied. The channel
 *   will close after all the source channels have closed.
 */
cljs.core.async.merge = (function cljs$core$async$merge(var_args){
var G__21099 = arguments.length;
switch (G__21099) {
case 1:
return cljs.core.async.merge.cljs$core$IFn$_invoke$arity$1((arguments[(0)]));

break;
case 2:
return cljs.core.async.merge.cljs$core$IFn$_invoke$arity$2((arguments[(0)]),(arguments[(1)]));

break;
default:
throw (new Error(["Invalid arity: ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(arguments.length)].join('')));

}
});

cljs.core.async.merge.cljs$core$IFn$_invoke$arity$1 = (function (chs){
return cljs.core.async.merge.cljs$core$IFn$_invoke$arity$2(chs,null);
});

cljs.core.async.merge.cljs$core$IFn$_invoke$arity$2 = (function (chs,buf_or_n){
var out = cljs.core.async.chan.cljs$core$IFn$_invoke$arity$1(buf_or_n);
var c__7992__auto___21153 = cljs.core.async.chan.cljs$core$IFn$_invoke$arity$1((1));
cljs.core.async.impl.dispatch.run(((function (c__7992__auto___21153,out){
return (function (){
var f__7993__auto__ = (function (){var switch__7885__auto__ = ((function (c__7992__auto___21153,out){
return (function (state_21131){
var state_val_21132 = (state_21131[(1)]);
if((state_val_21132 === (7))){
var inst_21111 = (state_21131[(7)]);
var inst_21110 = (state_21131[(8)]);
var inst_21110__$1 = (state_21131[(2)]);
var inst_21111__$1 = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(inst_21110__$1,(0),null);
var inst_21112 = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(inst_21110__$1,(1),null);
var inst_21113 = (inst_21111__$1 == null);
var state_21131__$1 = (function (){var statearr_21133 = state_21131;
(statearr_21133[(9)] = inst_21112);

(statearr_21133[(7)] = inst_21111__$1);

(statearr_21133[(8)] = inst_21110__$1);

return statearr_21133;
})();
if(cljs.core.truth_(inst_21113)){
var statearr_21134_21154 = state_21131__$1;
(statearr_21134_21154[(1)] = (8));

} else {
var statearr_21135_21155 = state_21131__$1;
(statearr_21135_21155[(1)] = (9));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_21132 === (1))){
var inst_21100 = cljs.core.vec(chs);
var inst_21101 = inst_21100;
var state_21131__$1 = (function (){var statearr_21136 = state_21131;
(statearr_21136[(10)] = inst_21101);

return statearr_21136;
})();
var statearr_21137_21156 = state_21131__$1;
(statearr_21137_21156[(2)] = null);

(statearr_21137_21156[(1)] = (2));


return cljs.core.cst$kw$recur;
} else {
if((state_val_21132 === (4))){
var inst_21101 = (state_21131[(10)]);
var state_21131__$1 = state_21131;
return cljs.core.async.ioc_alts_BANG_(state_21131__$1,(7),inst_21101);
} else {
if((state_val_21132 === (6))){
var inst_21127 = (state_21131[(2)]);
var state_21131__$1 = state_21131;
var statearr_21138_21157 = state_21131__$1;
(statearr_21138_21157[(2)] = inst_21127);

(statearr_21138_21157[(1)] = (3));


return cljs.core.cst$kw$recur;
} else {
if((state_val_21132 === (3))){
var inst_21129 = (state_21131[(2)]);
var state_21131__$1 = state_21131;
return cljs.core.async.impl.ioc_helpers.return_chan(state_21131__$1,inst_21129);
} else {
if((state_val_21132 === (2))){
var inst_21101 = (state_21131[(10)]);
var inst_21103 = cljs.core.count(inst_21101);
var inst_21104 = (inst_21103 > (0));
var state_21131__$1 = state_21131;
if(cljs.core.truth_(inst_21104)){
var statearr_21140_21158 = state_21131__$1;
(statearr_21140_21158[(1)] = (4));

} else {
var statearr_21141_21159 = state_21131__$1;
(statearr_21141_21159[(1)] = (5));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_21132 === (11))){
var inst_21101 = (state_21131[(10)]);
var inst_21120 = (state_21131[(2)]);
var tmp21139 = inst_21101;
var inst_21101__$1 = tmp21139;
var state_21131__$1 = (function (){var statearr_21142 = state_21131;
(statearr_21142[(10)] = inst_21101__$1);

(statearr_21142[(11)] = inst_21120);

return statearr_21142;
})();
var statearr_21143_21160 = state_21131__$1;
(statearr_21143_21160[(2)] = null);

(statearr_21143_21160[(1)] = (2));


return cljs.core.cst$kw$recur;
} else {
if((state_val_21132 === (9))){
var inst_21111 = (state_21131[(7)]);
var state_21131__$1 = state_21131;
return cljs.core.async.impl.ioc_helpers.put_BANG_(state_21131__$1,(11),out,inst_21111);
} else {
if((state_val_21132 === (5))){
var inst_21125 = cljs.core.async.close_BANG_(out);
var state_21131__$1 = state_21131;
var statearr_21144_21161 = state_21131__$1;
(statearr_21144_21161[(2)] = inst_21125);

(statearr_21144_21161[(1)] = (6));


return cljs.core.cst$kw$recur;
} else {
if((state_val_21132 === (10))){
var inst_21123 = (state_21131[(2)]);
var state_21131__$1 = state_21131;
var statearr_21145_21162 = state_21131__$1;
(statearr_21145_21162[(2)] = inst_21123);

(statearr_21145_21162[(1)] = (6));


return cljs.core.cst$kw$recur;
} else {
if((state_val_21132 === (8))){
var inst_21101 = (state_21131[(10)]);
var inst_21112 = (state_21131[(9)]);
var inst_21111 = (state_21131[(7)]);
var inst_21110 = (state_21131[(8)]);
var inst_21115 = (function (){var cs = inst_21101;
var vec__21106 = inst_21110;
var v = inst_21111;
var c = inst_21112;
return ((function (cs,vec__21106,v,c,inst_21101,inst_21112,inst_21111,inst_21110,state_val_21132,c__7992__auto___21153,out){
return (function (p1__21097_SHARP_){
return cljs.core.not_EQ_.cljs$core$IFn$_invoke$arity$2(c,p1__21097_SHARP_);
});
;})(cs,vec__21106,v,c,inst_21101,inst_21112,inst_21111,inst_21110,state_val_21132,c__7992__auto___21153,out))
})();
var inst_21116 = cljs.core.filterv(inst_21115,inst_21101);
var inst_21101__$1 = inst_21116;
var state_21131__$1 = (function (){var statearr_21146 = state_21131;
(statearr_21146[(10)] = inst_21101__$1);

return statearr_21146;
})();
var statearr_21147_21163 = state_21131__$1;
(statearr_21147_21163[(2)] = null);

(statearr_21147_21163[(1)] = (2));


return cljs.core.cst$kw$recur;
} else {
return null;
}
}
}
}
}
}
}
}
}
}
}
});})(c__7992__auto___21153,out))
;
return ((function (switch__7885__auto__,c__7992__auto___21153,out){
return (function() {
var cljs$core$async$state_machine__7886__auto__ = null;
var cljs$core$async$state_machine__7886__auto____0 = (function (){
var statearr_21148 = [null,null,null,null,null,null,null,null,null,null,null,null];
(statearr_21148[(0)] = cljs$core$async$state_machine__7886__auto__);

(statearr_21148[(1)] = (1));

return statearr_21148;
});
var cljs$core$async$state_machine__7886__auto____1 = (function (state_21131){
while(true){
var ret_value__7887__auto__ = (function (){try{while(true){
var result__7888__auto__ = switch__7885__auto__(state_21131);
if(cljs.core.keyword_identical_QMARK_(result__7888__auto__,cljs.core.cst$kw$recur)){
continue;
} else {
return result__7888__auto__;
}
break;
}
}catch (e21149){if((e21149 instanceof Object)){
var ex__7889__auto__ = e21149;
var statearr_21150_21164 = state_21131;
(statearr_21150_21164[(5)] = ex__7889__auto__);


cljs.core.async.impl.ioc_helpers.process_exception(state_21131);

return cljs.core.cst$kw$recur;
} else {
throw e21149;

}
}})();
if(cljs.core.keyword_identical_QMARK_(ret_value__7887__auto__,cljs.core.cst$kw$recur)){
var G__21165 = state_21131;
state_21131 = G__21165;
continue;
} else {
return ret_value__7887__auto__;
}
break;
}
});
cljs$core$async$state_machine__7886__auto__ = function(state_21131){
switch(arguments.length){
case 0:
return cljs$core$async$state_machine__7886__auto____0.call(this);
case 1:
return cljs$core$async$state_machine__7886__auto____1.call(this,state_21131);
}
throw(new Error('Invalid arity: ' + arguments.length));
};
cljs$core$async$state_machine__7886__auto__.cljs$core$IFn$_invoke$arity$0 = cljs$core$async$state_machine__7886__auto____0;
cljs$core$async$state_machine__7886__auto__.cljs$core$IFn$_invoke$arity$1 = cljs$core$async$state_machine__7886__auto____1;
return cljs$core$async$state_machine__7886__auto__;
})()
;})(switch__7885__auto__,c__7992__auto___21153,out))
})();
var state__7994__auto__ = (function (){var statearr_21151 = (f__7993__auto__.cljs$core$IFn$_invoke$arity$0 ? f__7993__auto__.cljs$core$IFn$_invoke$arity$0() : f__7993__auto__.call(null));
(statearr_21151[(6)] = c__7992__auto___21153);

return statearr_21151;
})();
return cljs.core.async.impl.ioc_helpers.run_state_machine_wrapped(state__7994__auto__);
});})(c__7992__auto___21153,out))
);


return out;
});

cljs.core.async.merge.cljs$lang$maxFixedArity = 2;

/**
 * Returns a channel containing the single (collection) result of the
 *   items taken from the channel conjoined to the supplied
 *   collection. ch must close before into produces a result.
 */
cljs.core.async.into = (function cljs$core$async$into(coll,ch){
return cljs.core.async.reduce(cljs.core.conj,coll,ch);
});
/**
 * Returns a channel that will return, at most, n items from ch. After n items
 * have been returned, or ch has been closed, the return chanel will close.
 * 
 *   The output channel is unbuffered by default, unless buf-or-n is given.
 */
cljs.core.async.take = (function cljs$core$async$take(var_args){
var G__21167 = arguments.length;
switch (G__21167) {
case 2:
return cljs.core.async.take.cljs$core$IFn$_invoke$arity$2((arguments[(0)]),(arguments[(1)]));

break;
case 3:
return cljs.core.async.take.cljs$core$IFn$_invoke$arity$3((arguments[(0)]),(arguments[(1)]),(arguments[(2)]));

break;
default:
throw (new Error(["Invalid arity: ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(arguments.length)].join('')));

}
});

cljs.core.async.take.cljs$core$IFn$_invoke$arity$2 = (function (n,ch){
return cljs.core.async.take.cljs$core$IFn$_invoke$arity$3(n,ch,null);
});

cljs.core.async.take.cljs$core$IFn$_invoke$arity$3 = (function (n,ch,buf_or_n){
var out = cljs.core.async.chan.cljs$core$IFn$_invoke$arity$1(buf_or_n);
var c__7992__auto___21212 = cljs.core.async.chan.cljs$core$IFn$_invoke$arity$1((1));
cljs.core.async.impl.dispatch.run(((function (c__7992__auto___21212,out){
return (function (){
var f__7993__auto__ = (function (){var switch__7885__auto__ = ((function (c__7992__auto___21212,out){
return (function (state_21191){
var state_val_21192 = (state_21191[(1)]);
if((state_val_21192 === (7))){
var inst_21173 = (state_21191[(7)]);
var inst_21173__$1 = (state_21191[(2)]);
var inst_21174 = (inst_21173__$1 == null);
var inst_21175 = cljs.core.not(inst_21174);
var state_21191__$1 = (function (){var statearr_21193 = state_21191;
(statearr_21193[(7)] = inst_21173__$1);

return statearr_21193;
})();
if(inst_21175){
var statearr_21194_21213 = state_21191__$1;
(statearr_21194_21213[(1)] = (8));

} else {
var statearr_21195_21214 = state_21191__$1;
(statearr_21195_21214[(1)] = (9));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_21192 === (1))){
var inst_21168 = (0);
var state_21191__$1 = (function (){var statearr_21196 = state_21191;
(statearr_21196[(8)] = inst_21168);

return statearr_21196;
})();
var statearr_21197_21215 = state_21191__$1;
(statearr_21197_21215[(2)] = null);

(statearr_21197_21215[(1)] = (2));


return cljs.core.cst$kw$recur;
} else {
if((state_val_21192 === (4))){
var state_21191__$1 = state_21191;
return cljs.core.async.impl.ioc_helpers.take_BANG_(state_21191__$1,(7),ch);
} else {
if((state_val_21192 === (6))){
var inst_21186 = (state_21191[(2)]);
var state_21191__$1 = state_21191;
var statearr_21198_21216 = state_21191__$1;
(statearr_21198_21216[(2)] = inst_21186);

(statearr_21198_21216[(1)] = (3));


return cljs.core.cst$kw$recur;
} else {
if((state_val_21192 === (3))){
var inst_21188 = (state_21191[(2)]);
var inst_21189 = cljs.core.async.close_BANG_(out);
var state_21191__$1 = (function (){var statearr_21199 = state_21191;
(statearr_21199[(9)] = inst_21188);

return statearr_21199;
})();
return cljs.core.async.impl.ioc_helpers.return_chan(state_21191__$1,inst_21189);
} else {
if((state_val_21192 === (2))){
var inst_21168 = (state_21191[(8)]);
var inst_21170 = (inst_21168 < n);
var state_21191__$1 = state_21191;
if(cljs.core.truth_(inst_21170)){
var statearr_21200_21217 = state_21191__$1;
(statearr_21200_21217[(1)] = (4));

} else {
var statearr_21201_21218 = state_21191__$1;
(statearr_21201_21218[(1)] = (5));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_21192 === (11))){
var inst_21168 = (state_21191[(8)]);
var inst_21178 = (state_21191[(2)]);
var inst_21179 = (inst_21168 + (1));
var inst_21168__$1 = inst_21179;
var state_21191__$1 = (function (){var statearr_21202 = state_21191;
(statearr_21202[(10)] = inst_21178);

(statearr_21202[(8)] = inst_21168__$1);

return statearr_21202;
})();
var statearr_21203_21219 = state_21191__$1;
(statearr_21203_21219[(2)] = null);

(statearr_21203_21219[(1)] = (2));


return cljs.core.cst$kw$recur;
} else {
if((state_val_21192 === (9))){
var state_21191__$1 = state_21191;
var statearr_21204_21220 = state_21191__$1;
(statearr_21204_21220[(2)] = null);

(statearr_21204_21220[(1)] = (10));


return cljs.core.cst$kw$recur;
} else {
if((state_val_21192 === (5))){
var state_21191__$1 = state_21191;
var statearr_21205_21221 = state_21191__$1;
(statearr_21205_21221[(2)] = null);

(statearr_21205_21221[(1)] = (6));


return cljs.core.cst$kw$recur;
} else {
if((state_val_21192 === (10))){
var inst_21183 = (state_21191[(2)]);
var state_21191__$1 = state_21191;
var statearr_21206_21222 = state_21191__$1;
(statearr_21206_21222[(2)] = inst_21183);

(statearr_21206_21222[(1)] = (6));


return cljs.core.cst$kw$recur;
} else {
if((state_val_21192 === (8))){
var inst_21173 = (state_21191[(7)]);
var state_21191__$1 = state_21191;
return cljs.core.async.impl.ioc_helpers.put_BANG_(state_21191__$1,(11),out,inst_21173);
} else {
return null;
}
}
}
}
}
}
}
}
}
}
}
});})(c__7992__auto___21212,out))
;
return ((function (switch__7885__auto__,c__7992__auto___21212,out){
return (function() {
var cljs$core$async$state_machine__7886__auto__ = null;
var cljs$core$async$state_machine__7886__auto____0 = (function (){
var statearr_21207 = [null,null,null,null,null,null,null,null,null,null,null];
(statearr_21207[(0)] = cljs$core$async$state_machine__7886__auto__);

(statearr_21207[(1)] = (1));

return statearr_21207;
});
var cljs$core$async$state_machine__7886__auto____1 = (function (state_21191){
while(true){
var ret_value__7887__auto__ = (function (){try{while(true){
var result__7888__auto__ = switch__7885__auto__(state_21191);
if(cljs.core.keyword_identical_QMARK_(result__7888__auto__,cljs.core.cst$kw$recur)){
continue;
} else {
return result__7888__auto__;
}
break;
}
}catch (e21208){if((e21208 instanceof Object)){
var ex__7889__auto__ = e21208;
var statearr_21209_21223 = state_21191;
(statearr_21209_21223[(5)] = ex__7889__auto__);


cljs.core.async.impl.ioc_helpers.process_exception(state_21191);

return cljs.core.cst$kw$recur;
} else {
throw e21208;

}
}})();
if(cljs.core.keyword_identical_QMARK_(ret_value__7887__auto__,cljs.core.cst$kw$recur)){
var G__21224 = state_21191;
state_21191 = G__21224;
continue;
} else {
return ret_value__7887__auto__;
}
break;
}
});
cljs$core$async$state_machine__7886__auto__ = function(state_21191){
switch(arguments.length){
case 0:
return cljs$core$async$state_machine__7886__auto____0.call(this);
case 1:
return cljs$core$async$state_machine__7886__auto____1.call(this,state_21191);
}
throw(new Error('Invalid arity: ' + arguments.length));
};
cljs$core$async$state_machine__7886__auto__.cljs$core$IFn$_invoke$arity$0 = cljs$core$async$state_machine__7886__auto____0;
cljs$core$async$state_machine__7886__auto__.cljs$core$IFn$_invoke$arity$1 = cljs$core$async$state_machine__7886__auto____1;
return cljs$core$async$state_machine__7886__auto__;
})()
;})(switch__7885__auto__,c__7992__auto___21212,out))
})();
var state__7994__auto__ = (function (){var statearr_21210 = (f__7993__auto__.cljs$core$IFn$_invoke$arity$0 ? f__7993__auto__.cljs$core$IFn$_invoke$arity$0() : f__7993__auto__.call(null));
(statearr_21210[(6)] = c__7992__auto___21212);

return statearr_21210;
})();
return cljs.core.async.impl.ioc_helpers.run_state_machine_wrapped(state__7994__auto__);
});})(c__7992__auto___21212,out))
);


return out;
});

cljs.core.async.take.cljs$lang$maxFixedArity = 3;

/**
 * Deprecated - this function will be removed. Use transducer instead
 */
cljs.core.async.map_LT_ = (function cljs$core$async$map_LT_(f,ch){
if((typeof cljs !== 'undefined') && (typeof cljs.core !== 'undefined') && (typeof cljs.core.async !== 'undefined') && (typeof cljs.core.async.t_cljs$core$async21226 !== 'undefined')){
} else {

/**
* @constructor
 * @implements {cljs.core.async.impl.protocols.Channel}
 * @implements {cljs.core.async.impl.protocols.WritePort}
 * @implements {cljs.core.async.impl.protocols.ReadPort}
 * @implements {cljs.core.IMeta}
 * @implements {cljs.core.IWithMeta}
*/
cljs.core.async.t_cljs$core$async21226 = (function (f,ch,meta21227){
this.f = f;
this.ch = ch;
this.meta21227 = meta21227;
this.cljs$lang$protocol_mask$partition0$ = 393216;
this.cljs$lang$protocol_mask$partition1$ = 0;
});
cljs.core.async.t_cljs$core$async21226.prototype.cljs$core$IWithMeta$_with_meta$arity$2 = (function (_21228,meta21227__$1){
var self__ = this;
var _21228__$1 = this;
return (new cljs.core.async.t_cljs$core$async21226(self__.f,self__.ch,meta21227__$1));
});

cljs.core.async.t_cljs$core$async21226.prototype.cljs$core$IMeta$_meta$arity$1 = (function (_21228){
var self__ = this;
var _21228__$1 = this;
return self__.meta21227;
});

cljs.core.async.t_cljs$core$async21226.prototype.cljs$core$async$impl$protocols$Channel$ = cljs.core.PROTOCOL_SENTINEL;

cljs.core.async.t_cljs$core$async21226.prototype.cljs$core$async$impl$protocols$Channel$close_BANG_$arity$1 = (function (_){
var self__ = this;
var ___$1 = this;
return cljs.core.async.impl.protocols.close_BANG_(self__.ch);
});

cljs.core.async.t_cljs$core$async21226.prototype.cljs$core$async$impl$protocols$Channel$closed_QMARK_$arity$1 = (function (_){
var self__ = this;
var ___$1 = this;
return cljs.core.async.impl.protocols.closed_QMARK_(self__.ch);
});

cljs.core.async.t_cljs$core$async21226.prototype.cljs$core$async$impl$protocols$ReadPort$ = cljs.core.PROTOCOL_SENTINEL;

cljs.core.async.t_cljs$core$async21226.prototype.cljs$core$async$impl$protocols$ReadPort$take_BANG_$arity$2 = (function (_,fn1){
var self__ = this;
var ___$1 = this;
var ret = cljs.core.async.impl.protocols.take_BANG_(self__.ch,(function (){
if((typeof cljs !== 'undefined') && (typeof cljs.core !== 'undefined') && (typeof cljs.core.async !== 'undefined') && (typeof cljs.core.async.t_cljs$core$async21229 !== 'undefined')){
} else {

/**
* @constructor
 * @implements {cljs.core.async.impl.protocols.Handler}
 * @implements {cljs.core.IMeta}
 * @implements {cljs.core.IWithMeta}
*/
cljs.core.async.t_cljs$core$async21229 = (function (f,ch,meta21227,_,fn1,meta21230){
this.f = f;
this.ch = ch;
this.meta21227 = meta21227;
this._ = _;
this.fn1 = fn1;
this.meta21230 = meta21230;
this.cljs$lang$protocol_mask$partition0$ = 393216;
this.cljs$lang$protocol_mask$partition1$ = 0;
});
cljs.core.async.t_cljs$core$async21229.prototype.cljs$core$IWithMeta$_with_meta$arity$2 = ((function (___$1){
return (function (_21231,meta21230__$1){
var self__ = this;
var _21231__$1 = this;
return (new cljs.core.async.t_cljs$core$async21229(self__.f,self__.ch,self__.meta21227,self__._,self__.fn1,meta21230__$1));
});})(___$1))
;

cljs.core.async.t_cljs$core$async21229.prototype.cljs$core$IMeta$_meta$arity$1 = ((function (___$1){
return (function (_21231){
var self__ = this;
var _21231__$1 = this;
return self__.meta21230;
});})(___$1))
;

cljs.core.async.t_cljs$core$async21229.prototype.cljs$core$async$impl$protocols$Handler$ = cljs.core.PROTOCOL_SENTINEL;

cljs.core.async.t_cljs$core$async21229.prototype.cljs$core$async$impl$protocols$Handler$active_QMARK_$arity$1 = ((function (___$1){
return (function (___$1){
var self__ = this;
var ___$2 = this;
return cljs.core.async.impl.protocols.active_QMARK_(self__.fn1);
});})(___$1))
;

cljs.core.async.t_cljs$core$async21229.prototype.cljs$core$async$impl$protocols$Handler$blockable_QMARK_$arity$1 = ((function (___$1){
return (function (___$1){
var self__ = this;
var ___$2 = this;
return true;
});})(___$1))
;

cljs.core.async.t_cljs$core$async21229.prototype.cljs$core$async$impl$protocols$Handler$commit$arity$1 = ((function (___$1){
return (function (___$1){
var self__ = this;
var ___$2 = this;
var f1 = cljs.core.async.impl.protocols.commit(self__.fn1);
return ((function (f1,___$2,___$1){
return (function (p1__21225_SHARP_){
var G__21232 = (((p1__21225_SHARP_ == null))?null:(self__.f.cljs$core$IFn$_invoke$arity$1 ? self__.f.cljs$core$IFn$_invoke$arity$1(p1__21225_SHARP_) : self__.f.call(null,p1__21225_SHARP_)));
return (f1.cljs$core$IFn$_invoke$arity$1 ? f1.cljs$core$IFn$_invoke$arity$1(G__21232) : f1.call(null,G__21232));
});
;})(f1,___$2,___$1))
});})(___$1))
;

cljs.core.async.t_cljs$core$async21229.getBasis = ((function (___$1){
return (function (){
return new cljs.core.PersistentVector(null, 6, 5, cljs.core.PersistentVector.EMPTY_NODE, [cljs.core.cst$sym$f,cljs.core.cst$sym$ch,cljs.core.cst$sym$meta21227,cljs.core.with_meta(cljs.core.cst$sym$_,new cljs.core.PersistentArrayMap(null, 1, [cljs.core.cst$kw$tag,cljs.core.cst$sym$cljs$core$async_SLASH_t_cljs$core$async21226], null)),cljs.core.cst$sym$fn1,cljs.core.cst$sym$meta21230], null);
});})(___$1))
;

cljs.core.async.t_cljs$core$async21229.cljs$lang$type = true;

cljs.core.async.t_cljs$core$async21229.cljs$lang$ctorStr = "cljs.core.async/t_cljs$core$async21229";

cljs.core.async.t_cljs$core$async21229.cljs$lang$ctorPrWriter = ((function (___$1){
return (function (this__4290__auto__,writer__4291__auto__,opt__4292__auto__){
return cljs.core._write(writer__4291__auto__,"cljs.core.async/t_cljs$core$async21229");
});})(___$1))
;

/**
 * Positional factory function for cljs.core.async/t_cljs$core$async21229.
 */
cljs.core.async.__GT_t_cljs$core$async21229 = ((function (___$1){
return (function cljs$core$async$map_LT__$___GT_t_cljs$core$async21229(f__$1,ch__$1,meta21227__$1,___$2,fn1__$1,meta21230){
return (new cljs.core.async.t_cljs$core$async21229(f__$1,ch__$1,meta21227__$1,___$2,fn1__$1,meta21230));
});})(___$1))
;

}

return (new cljs.core.async.t_cljs$core$async21229(self__.f,self__.ch,self__.meta21227,___$1,fn1,cljs.core.PersistentArrayMap.EMPTY));
})()
);
if(cljs.core.truth_((function (){var and__4036__auto__ = ret;
if(cljs.core.truth_(and__4036__auto__)){
return (!((cljs.core.deref(ret) == null)));
} else {
return and__4036__auto__;
}
})())){
return cljs.core.async.impl.channels.box((function (){var G__21233 = cljs.core.deref(ret);
return (self__.f.cljs$core$IFn$_invoke$arity$1 ? self__.f.cljs$core$IFn$_invoke$arity$1(G__21233) : self__.f.call(null,G__21233));
})());
} else {
return ret;
}
});

cljs.core.async.t_cljs$core$async21226.prototype.cljs$core$async$impl$protocols$WritePort$ = cljs.core.PROTOCOL_SENTINEL;

cljs.core.async.t_cljs$core$async21226.prototype.cljs$core$async$impl$protocols$WritePort$put_BANG_$arity$3 = (function (_,val,fn1){
var self__ = this;
var ___$1 = this;
return cljs.core.async.impl.protocols.put_BANG_(self__.ch,val,fn1);
});

cljs.core.async.t_cljs$core$async21226.getBasis = (function (){
return new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [cljs.core.cst$sym$f,cljs.core.cst$sym$ch,cljs.core.cst$sym$meta21227], null);
});

cljs.core.async.t_cljs$core$async21226.cljs$lang$type = true;

cljs.core.async.t_cljs$core$async21226.cljs$lang$ctorStr = "cljs.core.async/t_cljs$core$async21226";

cljs.core.async.t_cljs$core$async21226.cljs$lang$ctorPrWriter = (function (this__4290__auto__,writer__4291__auto__,opt__4292__auto__){
return cljs.core._write(writer__4291__auto__,"cljs.core.async/t_cljs$core$async21226");
});

/**
 * Positional factory function for cljs.core.async/t_cljs$core$async21226.
 */
cljs.core.async.__GT_t_cljs$core$async21226 = (function cljs$core$async$map_LT__$___GT_t_cljs$core$async21226(f__$1,ch__$1,meta21227){
return (new cljs.core.async.t_cljs$core$async21226(f__$1,ch__$1,meta21227));
});

}

return (new cljs.core.async.t_cljs$core$async21226(f,ch,cljs.core.PersistentArrayMap.EMPTY));
});
/**
 * Deprecated - this function will be removed. Use transducer instead
 */
cljs.core.async.map_GT_ = (function cljs$core$async$map_GT_(f,ch){
if((typeof cljs !== 'undefined') && (typeof cljs.core !== 'undefined') && (typeof cljs.core.async !== 'undefined') && (typeof cljs.core.async.t_cljs$core$async21234 !== 'undefined')){
} else {

/**
* @constructor
 * @implements {cljs.core.async.impl.protocols.Channel}
 * @implements {cljs.core.async.impl.protocols.WritePort}
 * @implements {cljs.core.async.impl.protocols.ReadPort}
 * @implements {cljs.core.IMeta}
 * @implements {cljs.core.IWithMeta}
*/
cljs.core.async.t_cljs$core$async21234 = (function (f,ch,meta21235){
this.f = f;
this.ch = ch;
this.meta21235 = meta21235;
this.cljs$lang$protocol_mask$partition0$ = 393216;
this.cljs$lang$protocol_mask$partition1$ = 0;
});
cljs.core.async.t_cljs$core$async21234.prototype.cljs$core$IWithMeta$_with_meta$arity$2 = (function (_21236,meta21235__$1){
var self__ = this;
var _21236__$1 = this;
return (new cljs.core.async.t_cljs$core$async21234(self__.f,self__.ch,meta21235__$1));
});

cljs.core.async.t_cljs$core$async21234.prototype.cljs$core$IMeta$_meta$arity$1 = (function (_21236){
var self__ = this;
var _21236__$1 = this;
return self__.meta21235;
});

cljs.core.async.t_cljs$core$async21234.prototype.cljs$core$async$impl$protocols$Channel$ = cljs.core.PROTOCOL_SENTINEL;

cljs.core.async.t_cljs$core$async21234.prototype.cljs$core$async$impl$protocols$Channel$close_BANG_$arity$1 = (function (_){
var self__ = this;
var ___$1 = this;
return cljs.core.async.impl.protocols.close_BANG_(self__.ch);
});

cljs.core.async.t_cljs$core$async21234.prototype.cljs$core$async$impl$protocols$ReadPort$ = cljs.core.PROTOCOL_SENTINEL;

cljs.core.async.t_cljs$core$async21234.prototype.cljs$core$async$impl$protocols$ReadPort$take_BANG_$arity$2 = (function (_,fn1){
var self__ = this;
var ___$1 = this;
return cljs.core.async.impl.protocols.take_BANG_(self__.ch,fn1);
});

cljs.core.async.t_cljs$core$async21234.prototype.cljs$core$async$impl$protocols$WritePort$ = cljs.core.PROTOCOL_SENTINEL;

cljs.core.async.t_cljs$core$async21234.prototype.cljs$core$async$impl$protocols$WritePort$put_BANG_$arity$3 = (function (_,val,fn1){
var self__ = this;
var ___$1 = this;
return cljs.core.async.impl.protocols.put_BANG_(self__.ch,(self__.f.cljs$core$IFn$_invoke$arity$1 ? self__.f.cljs$core$IFn$_invoke$arity$1(val) : self__.f.call(null,val)),fn1);
});

cljs.core.async.t_cljs$core$async21234.getBasis = (function (){
return new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [cljs.core.cst$sym$f,cljs.core.cst$sym$ch,cljs.core.cst$sym$meta21235], null);
});

cljs.core.async.t_cljs$core$async21234.cljs$lang$type = true;

cljs.core.async.t_cljs$core$async21234.cljs$lang$ctorStr = "cljs.core.async/t_cljs$core$async21234";

cljs.core.async.t_cljs$core$async21234.cljs$lang$ctorPrWriter = (function (this__4290__auto__,writer__4291__auto__,opt__4292__auto__){
return cljs.core._write(writer__4291__auto__,"cljs.core.async/t_cljs$core$async21234");
});

/**
 * Positional factory function for cljs.core.async/t_cljs$core$async21234.
 */
cljs.core.async.__GT_t_cljs$core$async21234 = (function cljs$core$async$map_GT__$___GT_t_cljs$core$async21234(f__$1,ch__$1,meta21235){
return (new cljs.core.async.t_cljs$core$async21234(f__$1,ch__$1,meta21235));
});

}

return (new cljs.core.async.t_cljs$core$async21234(f,ch,cljs.core.PersistentArrayMap.EMPTY));
});
/**
 * Deprecated - this function will be removed. Use transducer instead
 */
cljs.core.async.filter_GT_ = (function cljs$core$async$filter_GT_(p,ch){
if((typeof cljs !== 'undefined') && (typeof cljs.core !== 'undefined') && (typeof cljs.core.async !== 'undefined') && (typeof cljs.core.async.t_cljs$core$async21237 !== 'undefined')){
} else {

/**
* @constructor
 * @implements {cljs.core.async.impl.protocols.Channel}
 * @implements {cljs.core.async.impl.protocols.WritePort}
 * @implements {cljs.core.async.impl.protocols.ReadPort}
 * @implements {cljs.core.IMeta}
 * @implements {cljs.core.IWithMeta}
*/
cljs.core.async.t_cljs$core$async21237 = (function (p,ch,meta21238){
this.p = p;
this.ch = ch;
this.meta21238 = meta21238;
this.cljs$lang$protocol_mask$partition0$ = 393216;
this.cljs$lang$protocol_mask$partition1$ = 0;
});
cljs.core.async.t_cljs$core$async21237.prototype.cljs$core$IWithMeta$_with_meta$arity$2 = (function (_21239,meta21238__$1){
var self__ = this;
var _21239__$1 = this;
return (new cljs.core.async.t_cljs$core$async21237(self__.p,self__.ch,meta21238__$1));
});

cljs.core.async.t_cljs$core$async21237.prototype.cljs$core$IMeta$_meta$arity$1 = (function (_21239){
var self__ = this;
var _21239__$1 = this;
return self__.meta21238;
});

cljs.core.async.t_cljs$core$async21237.prototype.cljs$core$async$impl$protocols$Channel$ = cljs.core.PROTOCOL_SENTINEL;

cljs.core.async.t_cljs$core$async21237.prototype.cljs$core$async$impl$protocols$Channel$close_BANG_$arity$1 = (function (_){
var self__ = this;
var ___$1 = this;
return cljs.core.async.impl.protocols.close_BANG_(self__.ch);
});

cljs.core.async.t_cljs$core$async21237.prototype.cljs$core$async$impl$protocols$Channel$closed_QMARK_$arity$1 = (function (_){
var self__ = this;
var ___$1 = this;
return cljs.core.async.impl.protocols.closed_QMARK_(self__.ch);
});

cljs.core.async.t_cljs$core$async21237.prototype.cljs$core$async$impl$protocols$ReadPort$ = cljs.core.PROTOCOL_SENTINEL;

cljs.core.async.t_cljs$core$async21237.prototype.cljs$core$async$impl$protocols$ReadPort$take_BANG_$arity$2 = (function (_,fn1){
var self__ = this;
var ___$1 = this;
return cljs.core.async.impl.protocols.take_BANG_(self__.ch,fn1);
});

cljs.core.async.t_cljs$core$async21237.prototype.cljs$core$async$impl$protocols$WritePort$ = cljs.core.PROTOCOL_SENTINEL;

cljs.core.async.t_cljs$core$async21237.prototype.cljs$core$async$impl$protocols$WritePort$put_BANG_$arity$3 = (function (_,val,fn1){
var self__ = this;
var ___$1 = this;
if(cljs.core.truth_((self__.p.cljs$core$IFn$_invoke$arity$1 ? self__.p.cljs$core$IFn$_invoke$arity$1(val) : self__.p.call(null,val)))){
return cljs.core.async.impl.protocols.put_BANG_(self__.ch,val,fn1);
} else {
return cljs.core.async.impl.channels.box(cljs.core.not(cljs.core.async.impl.protocols.closed_QMARK_(self__.ch)));
}
});

cljs.core.async.t_cljs$core$async21237.getBasis = (function (){
return new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [cljs.core.cst$sym$p,cljs.core.cst$sym$ch,cljs.core.cst$sym$meta21238], null);
});

cljs.core.async.t_cljs$core$async21237.cljs$lang$type = true;

cljs.core.async.t_cljs$core$async21237.cljs$lang$ctorStr = "cljs.core.async/t_cljs$core$async21237";

cljs.core.async.t_cljs$core$async21237.cljs$lang$ctorPrWriter = (function (this__4290__auto__,writer__4291__auto__,opt__4292__auto__){
return cljs.core._write(writer__4291__auto__,"cljs.core.async/t_cljs$core$async21237");
});

/**
 * Positional factory function for cljs.core.async/t_cljs$core$async21237.
 */
cljs.core.async.__GT_t_cljs$core$async21237 = (function cljs$core$async$filter_GT__$___GT_t_cljs$core$async21237(p__$1,ch__$1,meta21238){
return (new cljs.core.async.t_cljs$core$async21237(p__$1,ch__$1,meta21238));
});

}

return (new cljs.core.async.t_cljs$core$async21237(p,ch,cljs.core.PersistentArrayMap.EMPTY));
});
/**
 * Deprecated - this function will be removed. Use transducer instead
 */
cljs.core.async.remove_GT_ = (function cljs$core$async$remove_GT_(p,ch){
return cljs.core.async.filter_GT_(cljs.core.complement(p),ch);
});
/**
 * Deprecated - this function will be removed. Use transducer instead
 */
cljs.core.async.filter_LT_ = (function cljs$core$async$filter_LT_(var_args){
var G__21241 = arguments.length;
switch (G__21241) {
case 2:
return cljs.core.async.filter_LT_.cljs$core$IFn$_invoke$arity$2((arguments[(0)]),(arguments[(1)]));

break;
case 3:
return cljs.core.async.filter_LT_.cljs$core$IFn$_invoke$arity$3((arguments[(0)]),(arguments[(1)]),(arguments[(2)]));

break;
default:
throw (new Error(["Invalid arity: ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(arguments.length)].join('')));

}
});

cljs.core.async.filter_LT_.cljs$core$IFn$_invoke$arity$2 = (function (p,ch){
return cljs.core.async.filter_LT_.cljs$core$IFn$_invoke$arity$3(p,ch,null);
});

cljs.core.async.filter_LT_.cljs$core$IFn$_invoke$arity$3 = (function (p,ch,buf_or_n){
var out = cljs.core.async.chan.cljs$core$IFn$_invoke$arity$1(buf_or_n);
var c__7992__auto___21281 = cljs.core.async.chan.cljs$core$IFn$_invoke$arity$1((1));
cljs.core.async.impl.dispatch.run(((function (c__7992__auto___21281,out){
return (function (){
var f__7993__auto__ = (function (){var switch__7885__auto__ = ((function (c__7992__auto___21281,out){
return (function (state_21262){
var state_val_21263 = (state_21262[(1)]);
if((state_val_21263 === (7))){
var inst_21258 = (state_21262[(2)]);
var state_21262__$1 = state_21262;
var statearr_21264_21282 = state_21262__$1;
(statearr_21264_21282[(2)] = inst_21258);

(statearr_21264_21282[(1)] = (3));


return cljs.core.cst$kw$recur;
} else {
if((state_val_21263 === (1))){
var state_21262__$1 = state_21262;
var statearr_21265_21283 = state_21262__$1;
(statearr_21265_21283[(2)] = null);

(statearr_21265_21283[(1)] = (2));


return cljs.core.cst$kw$recur;
} else {
if((state_val_21263 === (4))){
var inst_21244 = (state_21262[(7)]);
var inst_21244__$1 = (state_21262[(2)]);
var inst_21245 = (inst_21244__$1 == null);
var state_21262__$1 = (function (){var statearr_21266 = state_21262;
(statearr_21266[(7)] = inst_21244__$1);

return statearr_21266;
})();
if(cljs.core.truth_(inst_21245)){
var statearr_21267_21284 = state_21262__$1;
(statearr_21267_21284[(1)] = (5));

} else {
var statearr_21268_21285 = state_21262__$1;
(statearr_21268_21285[(1)] = (6));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_21263 === (6))){
var inst_21244 = (state_21262[(7)]);
var inst_21249 = (p.cljs$core$IFn$_invoke$arity$1 ? p.cljs$core$IFn$_invoke$arity$1(inst_21244) : p.call(null,inst_21244));
var state_21262__$1 = state_21262;
if(cljs.core.truth_(inst_21249)){
var statearr_21269_21286 = state_21262__$1;
(statearr_21269_21286[(1)] = (8));

} else {
var statearr_21270_21287 = state_21262__$1;
(statearr_21270_21287[(1)] = (9));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_21263 === (3))){
var inst_21260 = (state_21262[(2)]);
var state_21262__$1 = state_21262;
return cljs.core.async.impl.ioc_helpers.return_chan(state_21262__$1,inst_21260);
} else {
if((state_val_21263 === (2))){
var state_21262__$1 = state_21262;
return cljs.core.async.impl.ioc_helpers.take_BANG_(state_21262__$1,(4),ch);
} else {
if((state_val_21263 === (11))){
var inst_21252 = (state_21262[(2)]);
var state_21262__$1 = state_21262;
var statearr_21271_21288 = state_21262__$1;
(statearr_21271_21288[(2)] = inst_21252);

(statearr_21271_21288[(1)] = (10));


return cljs.core.cst$kw$recur;
} else {
if((state_val_21263 === (9))){
var state_21262__$1 = state_21262;
var statearr_21272_21289 = state_21262__$1;
(statearr_21272_21289[(2)] = null);

(statearr_21272_21289[(1)] = (10));


return cljs.core.cst$kw$recur;
} else {
if((state_val_21263 === (5))){
var inst_21247 = cljs.core.async.close_BANG_(out);
var state_21262__$1 = state_21262;
var statearr_21273_21290 = state_21262__$1;
(statearr_21273_21290[(2)] = inst_21247);

(statearr_21273_21290[(1)] = (7));


return cljs.core.cst$kw$recur;
} else {
if((state_val_21263 === (10))){
var inst_21255 = (state_21262[(2)]);
var state_21262__$1 = (function (){var statearr_21274 = state_21262;
(statearr_21274[(8)] = inst_21255);

return statearr_21274;
})();
var statearr_21275_21291 = state_21262__$1;
(statearr_21275_21291[(2)] = null);

(statearr_21275_21291[(1)] = (2));


return cljs.core.cst$kw$recur;
} else {
if((state_val_21263 === (8))){
var inst_21244 = (state_21262[(7)]);
var state_21262__$1 = state_21262;
return cljs.core.async.impl.ioc_helpers.put_BANG_(state_21262__$1,(11),out,inst_21244);
} else {
return null;
}
}
}
}
}
}
}
}
}
}
}
});})(c__7992__auto___21281,out))
;
return ((function (switch__7885__auto__,c__7992__auto___21281,out){
return (function() {
var cljs$core$async$state_machine__7886__auto__ = null;
var cljs$core$async$state_machine__7886__auto____0 = (function (){
var statearr_21276 = [null,null,null,null,null,null,null,null,null];
(statearr_21276[(0)] = cljs$core$async$state_machine__7886__auto__);

(statearr_21276[(1)] = (1));

return statearr_21276;
});
var cljs$core$async$state_machine__7886__auto____1 = (function (state_21262){
while(true){
var ret_value__7887__auto__ = (function (){try{while(true){
var result__7888__auto__ = switch__7885__auto__(state_21262);
if(cljs.core.keyword_identical_QMARK_(result__7888__auto__,cljs.core.cst$kw$recur)){
continue;
} else {
return result__7888__auto__;
}
break;
}
}catch (e21277){if((e21277 instanceof Object)){
var ex__7889__auto__ = e21277;
var statearr_21278_21292 = state_21262;
(statearr_21278_21292[(5)] = ex__7889__auto__);


cljs.core.async.impl.ioc_helpers.process_exception(state_21262);

return cljs.core.cst$kw$recur;
} else {
throw e21277;

}
}})();
if(cljs.core.keyword_identical_QMARK_(ret_value__7887__auto__,cljs.core.cst$kw$recur)){
var G__21293 = state_21262;
state_21262 = G__21293;
continue;
} else {
return ret_value__7887__auto__;
}
break;
}
});
cljs$core$async$state_machine__7886__auto__ = function(state_21262){
switch(arguments.length){
case 0:
return cljs$core$async$state_machine__7886__auto____0.call(this);
case 1:
return cljs$core$async$state_machine__7886__auto____1.call(this,state_21262);
}
throw(new Error('Invalid arity: ' + arguments.length));
};
cljs$core$async$state_machine__7886__auto__.cljs$core$IFn$_invoke$arity$0 = cljs$core$async$state_machine__7886__auto____0;
cljs$core$async$state_machine__7886__auto__.cljs$core$IFn$_invoke$arity$1 = cljs$core$async$state_machine__7886__auto____1;
return cljs$core$async$state_machine__7886__auto__;
})()
;})(switch__7885__auto__,c__7992__auto___21281,out))
})();
var state__7994__auto__ = (function (){var statearr_21279 = (f__7993__auto__.cljs$core$IFn$_invoke$arity$0 ? f__7993__auto__.cljs$core$IFn$_invoke$arity$0() : f__7993__auto__.call(null));
(statearr_21279[(6)] = c__7992__auto___21281);

return statearr_21279;
})();
return cljs.core.async.impl.ioc_helpers.run_state_machine_wrapped(state__7994__auto__);
});})(c__7992__auto___21281,out))
);


return out;
});

cljs.core.async.filter_LT_.cljs$lang$maxFixedArity = 3;

/**
 * Deprecated - this function will be removed. Use transducer instead
 */
cljs.core.async.remove_LT_ = (function cljs$core$async$remove_LT_(var_args){
var G__21295 = arguments.length;
switch (G__21295) {
case 2:
return cljs.core.async.remove_LT_.cljs$core$IFn$_invoke$arity$2((arguments[(0)]),(arguments[(1)]));

break;
case 3:
return cljs.core.async.remove_LT_.cljs$core$IFn$_invoke$arity$3((arguments[(0)]),(arguments[(1)]),(arguments[(2)]));

break;
default:
throw (new Error(["Invalid arity: ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(arguments.length)].join('')));

}
});

cljs.core.async.remove_LT_.cljs$core$IFn$_invoke$arity$2 = (function (p,ch){
return cljs.core.async.remove_LT_.cljs$core$IFn$_invoke$arity$3(p,ch,null);
});

cljs.core.async.remove_LT_.cljs$core$IFn$_invoke$arity$3 = (function (p,ch,buf_or_n){
return cljs.core.async.filter_LT_.cljs$core$IFn$_invoke$arity$3(cljs.core.complement(p),ch,buf_or_n);
});

cljs.core.async.remove_LT_.cljs$lang$maxFixedArity = 3;

cljs.core.async.mapcat_STAR_ = (function cljs$core$async$mapcat_STAR_(f,in$,out){
var c__7992__auto__ = cljs.core.async.chan.cljs$core$IFn$_invoke$arity$1((1));
cljs.core.async.impl.dispatch.run(((function (c__7992__auto__){
return (function (){
var f__7993__auto__ = (function (){var switch__7885__auto__ = ((function (c__7992__auto__){
return (function (state_21358){
var state_val_21359 = (state_21358[(1)]);
if((state_val_21359 === (7))){
var inst_21354 = (state_21358[(2)]);
var state_21358__$1 = state_21358;
var statearr_21360_21398 = state_21358__$1;
(statearr_21360_21398[(2)] = inst_21354);

(statearr_21360_21398[(1)] = (3));


return cljs.core.cst$kw$recur;
} else {
if((state_val_21359 === (20))){
var inst_21324 = (state_21358[(7)]);
var inst_21335 = (state_21358[(2)]);
var inst_21336 = cljs.core.next(inst_21324);
var inst_21310 = inst_21336;
var inst_21311 = null;
var inst_21312 = (0);
var inst_21313 = (0);
var state_21358__$1 = (function (){var statearr_21361 = state_21358;
(statearr_21361[(8)] = inst_21313);

(statearr_21361[(9)] = inst_21310);

(statearr_21361[(10)] = inst_21312);

(statearr_21361[(11)] = inst_21335);

(statearr_21361[(12)] = inst_21311);

return statearr_21361;
})();
var statearr_21362_21399 = state_21358__$1;
(statearr_21362_21399[(2)] = null);

(statearr_21362_21399[(1)] = (8));


return cljs.core.cst$kw$recur;
} else {
if((state_val_21359 === (1))){
var state_21358__$1 = state_21358;
var statearr_21363_21400 = state_21358__$1;
(statearr_21363_21400[(2)] = null);

(statearr_21363_21400[(1)] = (2));


return cljs.core.cst$kw$recur;
} else {
if((state_val_21359 === (4))){
var inst_21299 = (state_21358[(13)]);
var inst_21299__$1 = (state_21358[(2)]);
var inst_21300 = (inst_21299__$1 == null);
var state_21358__$1 = (function (){var statearr_21364 = state_21358;
(statearr_21364[(13)] = inst_21299__$1);

return statearr_21364;
})();
if(cljs.core.truth_(inst_21300)){
var statearr_21365_21401 = state_21358__$1;
(statearr_21365_21401[(1)] = (5));

} else {
var statearr_21366_21402 = state_21358__$1;
(statearr_21366_21402[(1)] = (6));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_21359 === (15))){
var state_21358__$1 = state_21358;
var statearr_21370_21403 = state_21358__$1;
(statearr_21370_21403[(2)] = null);

(statearr_21370_21403[(1)] = (16));


return cljs.core.cst$kw$recur;
} else {
if((state_val_21359 === (21))){
var state_21358__$1 = state_21358;
var statearr_21371_21404 = state_21358__$1;
(statearr_21371_21404[(2)] = null);

(statearr_21371_21404[(1)] = (23));


return cljs.core.cst$kw$recur;
} else {
if((state_val_21359 === (13))){
var inst_21313 = (state_21358[(8)]);
var inst_21310 = (state_21358[(9)]);
var inst_21312 = (state_21358[(10)]);
var inst_21311 = (state_21358[(12)]);
var inst_21320 = (state_21358[(2)]);
var inst_21321 = (inst_21313 + (1));
var tmp21367 = inst_21310;
var tmp21368 = inst_21312;
var tmp21369 = inst_21311;
var inst_21310__$1 = tmp21367;
var inst_21311__$1 = tmp21369;
var inst_21312__$1 = tmp21368;
var inst_21313__$1 = inst_21321;
var state_21358__$1 = (function (){var statearr_21372 = state_21358;
(statearr_21372[(14)] = inst_21320);

(statearr_21372[(8)] = inst_21313__$1);

(statearr_21372[(9)] = inst_21310__$1);

(statearr_21372[(10)] = inst_21312__$1);

(statearr_21372[(12)] = inst_21311__$1);

return statearr_21372;
})();
var statearr_21373_21405 = state_21358__$1;
(statearr_21373_21405[(2)] = null);

(statearr_21373_21405[(1)] = (8));


return cljs.core.cst$kw$recur;
} else {
if((state_val_21359 === (22))){
var state_21358__$1 = state_21358;
var statearr_21374_21406 = state_21358__$1;
(statearr_21374_21406[(2)] = null);

(statearr_21374_21406[(1)] = (2));


return cljs.core.cst$kw$recur;
} else {
if((state_val_21359 === (6))){
var inst_21299 = (state_21358[(13)]);
var inst_21308 = (f.cljs$core$IFn$_invoke$arity$1 ? f.cljs$core$IFn$_invoke$arity$1(inst_21299) : f.call(null,inst_21299));
var inst_21309 = cljs.core.seq(inst_21308);
var inst_21310 = inst_21309;
var inst_21311 = null;
var inst_21312 = (0);
var inst_21313 = (0);
var state_21358__$1 = (function (){var statearr_21375 = state_21358;
(statearr_21375[(8)] = inst_21313);

(statearr_21375[(9)] = inst_21310);

(statearr_21375[(10)] = inst_21312);

(statearr_21375[(12)] = inst_21311);

return statearr_21375;
})();
var statearr_21376_21407 = state_21358__$1;
(statearr_21376_21407[(2)] = null);

(statearr_21376_21407[(1)] = (8));


return cljs.core.cst$kw$recur;
} else {
if((state_val_21359 === (17))){
var inst_21324 = (state_21358[(7)]);
var inst_21328 = cljs.core.chunk_first(inst_21324);
var inst_21329 = cljs.core.chunk_rest(inst_21324);
var inst_21330 = cljs.core.count(inst_21328);
var inst_21310 = inst_21329;
var inst_21311 = inst_21328;
var inst_21312 = inst_21330;
var inst_21313 = (0);
var state_21358__$1 = (function (){var statearr_21377 = state_21358;
(statearr_21377[(8)] = inst_21313);

(statearr_21377[(9)] = inst_21310);

(statearr_21377[(10)] = inst_21312);

(statearr_21377[(12)] = inst_21311);

return statearr_21377;
})();
var statearr_21378_21408 = state_21358__$1;
(statearr_21378_21408[(2)] = null);

(statearr_21378_21408[(1)] = (8));


return cljs.core.cst$kw$recur;
} else {
if((state_val_21359 === (3))){
var inst_21356 = (state_21358[(2)]);
var state_21358__$1 = state_21358;
return cljs.core.async.impl.ioc_helpers.return_chan(state_21358__$1,inst_21356);
} else {
if((state_val_21359 === (12))){
var inst_21344 = (state_21358[(2)]);
var state_21358__$1 = state_21358;
var statearr_21379_21409 = state_21358__$1;
(statearr_21379_21409[(2)] = inst_21344);

(statearr_21379_21409[(1)] = (9));


return cljs.core.cst$kw$recur;
} else {
if((state_val_21359 === (2))){
var state_21358__$1 = state_21358;
return cljs.core.async.impl.ioc_helpers.take_BANG_(state_21358__$1,(4),in$);
} else {
if((state_val_21359 === (23))){
var inst_21352 = (state_21358[(2)]);
var state_21358__$1 = state_21358;
var statearr_21380_21410 = state_21358__$1;
(statearr_21380_21410[(2)] = inst_21352);

(statearr_21380_21410[(1)] = (7));


return cljs.core.cst$kw$recur;
} else {
if((state_val_21359 === (19))){
var inst_21339 = (state_21358[(2)]);
var state_21358__$1 = state_21358;
var statearr_21381_21411 = state_21358__$1;
(statearr_21381_21411[(2)] = inst_21339);

(statearr_21381_21411[(1)] = (16));


return cljs.core.cst$kw$recur;
} else {
if((state_val_21359 === (11))){
var inst_21324 = (state_21358[(7)]);
var inst_21310 = (state_21358[(9)]);
var inst_21324__$1 = cljs.core.seq(inst_21310);
var state_21358__$1 = (function (){var statearr_21382 = state_21358;
(statearr_21382[(7)] = inst_21324__$1);

return statearr_21382;
})();
if(inst_21324__$1){
var statearr_21383_21412 = state_21358__$1;
(statearr_21383_21412[(1)] = (14));

} else {
var statearr_21384_21413 = state_21358__$1;
(statearr_21384_21413[(1)] = (15));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_21359 === (9))){
var inst_21346 = (state_21358[(2)]);
var inst_21347 = cljs.core.async.impl.protocols.closed_QMARK_(out);
var state_21358__$1 = (function (){var statearr_21385 = state_21358;
(statearr_21385[(15)] = inst_21346);

return statearr_21385;
})();
if(cljs.core.truth_(inst_21347)){
var statearr_21386_21414 = state_21358__$1;
(statearr_21386_21414[(1)] = (21));

} else {
var statearr_21387_21415 = state_21358__$1;
(statearr_21387_21415[(1)] = (22));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_21359 === (5))){
var inst_21302 = cljs.core.async.close_BANG_(out);
var state_21358__$1 = state_21358;
var statearr_21388_21416 = state_21358__$1;
(statearr_21388_21416[(2)] = inst_21302);

(statearr_21388_21416[(1)] = (7));


return cljs.core.cst$kw$recur;
} else {
if((state_val_21359 === (14))){
var inst_21324 = (state_21358[(7)]);
var inst_21326 = cljs.core.chunked_seq_QMARK_(inst_21324);
var state_21358__$1 = state_21358;
if(inst_21326){
var statearr_21389_21417 = state_21358__$1;
(statearr_21389_21417[(1)] = (17));

} else {
var statearr_21390_21418 = state_21358__$1;
(statearr_21390_21418[(1)] = (18));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_21359 === (16))){
var inst_21342 = (state_21358[(2)]);
var state_21358__$1 = state_21358;
var statearr_21391_21419 = state_21358__$1;
(statearr_21391_21419[(2)] = inst_21342);

(statearr_21391_21419[(1)] = (12));


return cljs.core.cst$kw$recur;
} else {
if((state_val_21359 === (10))){
var inst_21313 = (state_21358[(8)]);
var inst_21311 = (state_21358[(12)]);
var inst_21318 = cljs.core._nth.cljs$core$IFn$_invoke$arity$2(inst_21311,inst_21313);
var state_21358__$1 = state_21358;
return cljs.core.async.impl.ioc_helpers.put_BANG_(state_21358__$1,(13),out,inst_21318);
} else {
if((state_val_21359 === (18))){
var inst_21324 = (state_21358[(7)]);
var inst_21333 = cljs.core.first(inst_21324);
var state_21358__$1 = state_21358;
return cljs.core.async.impl.ioc_helpers.put_BANG_(state_21358__$1,(20),out,inst_21333);
} else {
if((state_val_21359 === (8))){
var inst_21313 = (state_21358[(8)]);
var inst_21312 = (state_21358[(10)]);
var inst_21315 = (inst_21313 < inst_21312);
var inst_21316 = inst_21315;
var state_21358__$1 = state_21358;
if(cljs.core.truth_(inst_21316)){
var statearr_21392_21420 = state_21358__$1;
(statearr_21392_21420[(1)] = (10));

} else {
var statearr_21393_21421 = state_21358__$1;
(statearr_21393_21421[(1)] = (11));

}

return cljs.core.cst$kw$recur;
} else {
return null;
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
});})(c__7992__auto__))
;
return ((function (switch__7885__auto__,c__7992__auto__){
return (function() {
var cljs$core$async$mapcat_STAR__$_state_machine__7886__auto__ = null;
var cljs$core$async$mapcat_STAR__$_state_machine__7886__auto____0 = (function (){
var statearr_21394 = [null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null];
(statearr_21394[(0)] = cljs$core$async$mapcat_STAR__$_state_machine__7886__auto__);

(statearr_21394[(1)] = (1));

return statearr_21394;
});
var cljs$core$async$mapcat_STAR__$_state_machine__7886__auto____1 = (function (state_21358){
while(true){
var ret_value__7887__auto__ = (function (){try{while(true){
var result__7888__auto__ = switch__7885__auto__(state_21358);
if(cljs.core.keyword_identical_QMARK_(result__7888__auto__,cljs.core.cst$kw$recur)){
continue;
} else {
return result__7888__auto__;
}
break;
}
}catch (e21395){if((e21395 instanceof Object)){
var ex__7889__auto__ = e21395;
var statearr_21396_21422 = state_21358;
(statearr_21396_21422[(5)] = ex__7889__auto__);


cljs.core.async.impl.ioc_helpers.process_exception(state_21358);

return cljs.core.cst$kw$recur;
} else {
throw e21395;

}
}})();
if(cljs.core.keyword_identical_QMARK_(ret_value__7887__auto__,cljs.core.cst$kw$recur)){
var G__21423 = state_21358;
state_21358 = G__21423;
continue;
} else {
return ret_value__7887__auto__;
}
break;
}
});
cljs$core$async$mapcat_STAR__$_state_machine__7886__auto__ = function(state_21358){
switch(arguments.length){
case 0:
return cljs$core$async$mapcat_STAR__$_state_machine__7886__auto____0.call(this);
case 1:
return cljs$core$async$mapcat_STAR__$_state_machine__7886__auto____1.call(this,state_21358);
}
throw(new Error('Invalid arity: ' + arguments.length));
};
cljs$core$async$mapcat_STAR__$_state_machine__7886__auto__.cljs$core$IFn$_invoke$arity$0 = cljs$core$async$mapcat_STAR__$_state_machine__7886__auto____0;
cljs$core$async$mapcat_STAR__$_state_machine__7886__auto__.cljs$core$IFn$_invoke$arity$1 = cljs$core$async$mapcat_STAR__$_state_machine__7886__auto____1;
return cljs$core$async$mapcat_STAR__$_state_machine__7886__auto__;
})()
;})(switch__7885__auto__,c__7992__auto__))
})();
var state__7994__auto__ = (function (){var statearr_21397 = (f__7993__auto__.cljs$core$IFn$_invoke$arity$0 ? f__7993__auto__.cljs$core$IFn$_invoke$arity$0() : f__7993__auto__.call(null));
(statearr_21397[(6)] = c__7992__auto__);

return statearr_21397;
})();
return cljs.core.async.impl.ioc_helpers.run_state_machine_wrapped(state__7994__auto__);
});})(c__7992__auto__))
);

return c__7992__auto__;
});
/**
 * Deprecated - this function will be removed. Use transducer instead
 */
cljs.core.async.mapcat_LT_ = (function cljs$core$async$mapcat_LT_(var_args){
var G__21425 = arguments.length;
switch (G__21425) {
case 2:
return cljs.core.async.mapcat_LT_.cljs$core$IFn$_invoke$arity$2((arguments[(0)]),(arguments[(1)]));

break;
case 3:
return cljs.core.async.mapcat_LT_.cljs$core$IFn$_invoke$arity$3((arguments[(0)]),(arguments[(1)]),(arguments[(2)]));

break;
default:
throw (new Error(["Invalid arity: ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(arguments.length)].join('')));

}
});

cljs.core.async.mapcat_LT_.cljs$core$IFn$_invoke$arity$2 = (function (f,in$){
return cljs.core.async.mapcat_LT_.cljs$core$IFn$_invoke$arity$3(f,in$,null);
});

cljs.core.async.mapcat_LT_.cljs$core$IFn$_invoke$arity$3 = (function (f,in$,buf_or_n){
var out = cljs.core.async.chan.cljs$core$IFn$_invoke$arity$1(buf_or_n);
cljs.core.async.mapcat_STAR_(f,in$,out);

return out;
});

cljs.core.async.mapcat_LT_.cljs$lang$maxFixedArity = 3;

/**
 * Deprecated - this function will be removed. Use transducer instead
 */
cljs.core.async.mapcat_GT_ = (function cljs$core$async$mapcat_GT_(var_args){
var G__21428 = arguments.length;
switch (G__21428) {
case 2:
return cljs.core.async.mapcat_GT_.cljs$core$IFn$_invoke$arity$2((arguments[(0)]),(arguments[(1)]));

break;
case 3:
return cljs.core.async.mapcat_GT_.cljs$core$IFn$_invoke$arity$3((arguments[(0)]),(arguments[(1)]),(arguments[(2)]));

break;
default:
throw (new Error(["Invalid arity: ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(arguments.length)].join('')));

}
});

cljs.core.async.mapcat_GT_.cljs$core$IFn$_invoke$arity$2 = (function (f,out){
return cljs.core.async.mapcat_GT_.cljs$core$IFn$_invoke$arity$3(f,out,null);
});

cljs.core.async.mapcat_GT_.cljs$core$IFn$_invoke$arity$3 = (function (f,out,buf_or_n){
var in$ = cljs.core.async.chan.cljs$core$IFn$_invoke$arity$1(buf_or_n);
cljs.core.async.mapcat_STAR_(f,in$,out);

return in$;
});

cljs.core.async.mapcat_GT_.cljs$lang$maxFixedArity = 3;

/**
 * Deprecated - this function will be removed. Use transducer instead
 */
cljs.core.async.unique = (function cljs$core$async$unique(var_args){
var G__21431 = arguments.length;
switch (G__21431) {
case 1:
return cljs.core.async.unique.cljs$core$IFn$_invoke$arity$1((arguments[(0)]));

break;
case 2:
return cljs.core.async.unique.cljs$core$IFn$_invoke$arity$2((arguments[(0)]),(arguments[(1)]));

break;
default:
throw (new Error(["Invalid arity: ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(arguments.length)].join('')));

}
});

cljs.core.async.unique.cljs$core$IFn$_invoke$arity$1 = (function (ch){
return cljs.core.async.unique.cljs$core$IFn$_invoke$arity$2(ch,null);
});

cljs.core.async.unique.cljs$core$IFn$_invoke$arity$2 = (function (ch,buf_or_n){
var out = cljs.core.async.chan.cljs$core$IFn$_invoke$arity$1(buf_or_n);
var c__7992__auto___21478 = cljs.core.async.chan.cljs$core$IFn$_invoke$arity$1((1));
cljs.core.async.impl.dispatch.run(((function (c__7992__auto___21478,out){
return (function (){
var f__7993__auto__ = (function (){var switch__7885__auto__ = ((function (c__7992__auto___21478,out){
return (function (state_21455){
var state_val_21456 = (state_21455[(1)]);
if((state_val_21456 === (7))){
var inst_21450 = (state_21455[(2)]);
var state_21455__$1 = state_21455;
var statearr_21457_21479 = state_21455__$1;
(statearr_21457_21479[(2)] = inst_21450);

(statearr_21457_21479[(1)] = (3));


return cljs.core.cst$kw$recur;
} else {
if((state_val_21456 === (1))){
var inst_21432 = null;
var state_21455__$1 = (function (){var statearr_21458 = state_21455;
(statearr_21458[(7)] = inst_21432);

return statearr_21458;
})();
var statearr_21459_21480 = state_21455__$1;
(statearr_21459_21480[(2)] = null);

(statearr_21459_21480[(1)] = (2));


return cljs.core.cst$kw$recur;
} else {
if((state_val_21456 === (4))){
var inst_21435 = (state_21455[(8)]);
var inst_21435__$1 = (state_21455[(2)]);
var inst_21436 = (inst_21435__$1 == null);
var inst_21437 = cljs.core.not(inst_21436);
var state_21455__$1 = (function (){var statearr_21460 = state_21455;
(statearr_21460[(8)] = inst_21435__$1);

return statearr_21460;
})();
if(inst_21437){
var statearr_21461_21481 = state_21455__$1;
(statearr_21461_21481[(1)] = (5));

} else {
var statearr_21462_21482 = state_21455__$1;
(statearr_21462_21482[(1)] = (6));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_21456 === (6))){
var state_21455__$1 = state_21455;
var statearr_21463_21483 = state_21455__$1;
(statearr_21463_21483[(2)] = null);

(statearr_21463_21483[(1)] = (7));


return cljs.core.cst$kw$recur;
} else {
if((state_val_21456 === (3))){
var inst_21452 = (state_21455[(2)]);
var inst_21453 = cljs.core.async.close_BANG_(out);
var state_21455__$1 = (function (){var statearr_21464 = state_21455;
(statearr_21464[(9)] = inst_21452);

return statearr_21464;
})();
return cljs.core.async.impl.ioc_helpers.return_chan(state_21455__$1,inst_21453);
} else {
if((state_val_21456 === (2))){
var state_21455__$1 = state_21455;
return cljs.core.async.impl.ioc_helpers.take_BANG_(state_21455__$1,(4),ch);
} else {
if((state_val_21456 === (11))){
var inst_21435 = (state_21455[(8)]);
var inst_21444 = (state_21455[(2)]);
var inst_21432 = inst_21435;
var state_21455__$1 = (function (){var statearr_21465 = state_21455;
(statearr_21465[(7)] = inst_21432);

(statearr_21465[(10)] = inst_21444);

return statearr_21465;
})();
var statearr_21466_21484 = state_21455__$1;
(statearr_21466_21484[(2)] = null);

(statearr_21466_21484[(1)] = (2));


return cljs.core.cst$kw$recur;
} else {
if((state_val_21456 === (9))){
var inst_21435 = (state_21455[(8)]);
var state_21455__$1 = state_21455;
return cljs.core.async.impl.ioc_helpers.put_BANG_(state_21455__$1,(11),out,inst_21435);
} else {
if((state_val_21456 === (5))){
var inst_21432 = (state_21455[(7)]);
var inst_21435 = (state_21455[(8)]);
var inst_21439 = cljs.core._EQ_.cljs$core$IFn$_invoke$arity$2(inst_21435,inst_21432);
var state_21455__$1 = state_21455;
if(inst_21439){
var statearr_21468_21485 = state_21455__$1;
(statearr_21468_21485[(1)] = (8));

} else {
var statearr_21469_21486 = state_21455__$1;
(statearr_21469_21486[(1)] = (9));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_21456 === (10))){
var inst_21447 = (state_21455[(2)]);
var state_21455__$1 = state_21455;
var statearr_21470_21487 = state_21455__$1;
(statearr_21470_21487[(2)] = inst_21447);

(statearr_21470_21487[(1)] = (7));


return cljs.core.cst$kw$recur;
} else {
if((state_val_21456 === (8))){
var inst_21432 = (state_21455[(7)]);
var tmp21467 = inst_21432;
var inst_21432__$1 = tmp21467;
var state_21455__$1 = (function (){var statearr_21471 = state_21455;
(statearr_21471[(7)] = inst_21432__$1);

return statearr_21471;
})();
var statearr_21472_21488 = state_21455__$1;
(statearr_21472_21488[(2)] = null);

(statearr_21472_21488[(1)] = (2));


return cljs.core.cst$kw$recur;
} else {
return null;
}
}
}
}
}
}
}
}
}
}
}
});})(c__7992__auto___21478,out))
;
return ((function (switch__7885__auto__,c__7992__auto___21478,out){
return (function() {
var cljs$core$async$state_machine__7886__auto__ = null;
var cljs$core$async$state_machine__7886__auto____0 = (function (){
var statearr_21473 = [null,null,null,null,null,null,null,null,null,null,null];
(statearr_21473[(0)] = cljs$core$async$state_machine__7886__auto__);

(statearr_21473[(1)] = (1));

return statearr_21473;
});
var cljs$core$async$state_machine__7886__auto____1 = (function (state_21455){
while(true){
var ret_value__7887__auto__ = (function (){try{while(true){
var result__7888__auto__ = switch__7885__auto__(state_21455);
if(cljs.core.keyword_identical_QMARK_(result__7888__auto__,cljs.core.cst$kw$recur)){
continue;
} else {
return result__7888__auto__;
}
break;
}
}catch (e21474){if((e21474 instanceof Object)){
var ex__7889__auto__ = e21474;
var statearr_21475_21489 = state_21455;
(statearr_21475_21489[(5)] = ex__7889__auto__);


cljs.core.async.impl.ioc_helpers.process_exception(state_21455);

return cljs.core.cst$kw$recur;
} else {
throw e21474;

}
}})();
if(cljs.core.keyword_identical_QMARK_(ret_value__7887__auto__,cljs.core.cst$kw$recur)){
var G__21490 = state_21455;
state_21455 = G__21490;
continue;
} else {
return ret_value__7887__auto__;
}
break;
}
});
cljs$core$async$state_machine__7886__auto__ = function(state_21455){
switch(arguments.length){
case 0:
return cljs$core$async$state_machine__7886__auto____0.call(this);
case 1:
return cljs$core$async$state_machine__7886__auto____1.call(this,state_21455);
}
throw(new Error('Invalid arity: ' + arguments.length));
};
cljs$core$async$state_machine__7886__auto__.cljs$core$IFn$_invoke$arity$0 = cljs$core$async$state_machine__7886__auto____0;
cljs$core$async$state_machine__7886__auto__.cljs$core$IFn$_invoke$arity$1 = cljs$core$async$state_machine__7886__auto____1;
return cljs$core$async$state_machine__7886__auto__;
})()
;})(switch__7885__auto__,c__7992__auto___21478,out))
})();
var state__7994__auto__ = (function (){var statearr_21476 = (f__7993__auto__.cljs$core$IFn$_invoke$arity$0 ? f__7993__auto__.cljs$core$IFn$_invoke$arity$0() : f__7993__auto__.call(null));
(statearr_21476[(6)] = c__7992__auto___21478);

return statearr_21476;
})();
return cljs.core.async.impl.ioc_helpers.run_state_machine_wrapped(state__7994__auto__);
});})(c__7992__auto___21478,out))
);


return out;
});

cljs.core.async.unique.cljs$lang$maxFixedArity = 2;

/**
 * Deprecated - this function will be removed. Use transducer instead
 */
cljs.core.async.partition = (function cljs$core$async$partition(var_args){
var G__21492 = arguments.length;
switch (G__21492) {
case 2:
return cljs.core.async.partition.cljs$core$IFn$_invoke$arity$2((arguments[(0)]),(arguments[(1)]));

break;
case 3:
return cljs.core.async.partition.cljs$core$IFn$_invoke$arity$3((arguments[(0)]),(arguments[(1)]),(arguments[(2)]));

break;
default:
throw (new Error(["Invalid arity: ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(arguments.length)].join('')));

}
});

cljs.core.async.partition.cljs$core$IFn$_invoke$arity$2 = (function (n,ch){
return cljs.core.async.partition.cljs$core$IFn$_invoke$arity$3(n,ch,null);
});

cljs.core.async.partition.cljs$core$IFn$_invoke$arity$3 = (function (n,ch,buf_or_n){
var out = cljs.core.async.chan.cljs$core$IFn$_invoke$arity$1(buf_or_n);
var c__7992__auto___21558 = cljs.core.async.chan.cljs$core$IFn$_invoke$arity$1((1));
cljs.core.async.impl.dispatch.run(((function (c__7992__auto___21558,out){
return (function (){
var f__7993__auto__ = (function (){var switch__7885__auto__ = ((function (c__7992__auto___21558,out){
return (function (state_21530){
var state_val_21531 = (state_21530[(1)]);
if((state_val_21531 === (7))){
var inst_21526 = (state_21530[(2)]);
var state_21530__$1 = state_21530;
var statearr_21532_21559 = state_21530__$1;
(statearr_21532_21559[(2)] = inst_21526);

(statearr_21532_21559[(1)] = (3));


return cljs.core.cst$kw$recur;
} else {
if((state_val_21531 === (1))){
var inst_21493 = (new Array(n));
var inst_21494 = inst_21493;
var inst_21495 = (0);
var state_21530__$1 = (function (){var statearr_21533 = state_21530;
(statearr_21533[(7)] = inst_21495);

(statearr_21533[(8)] = inst_21494);

return statearr_21533;
})();
var statearr_21534_21560 = state_21530__$1;
(statearr_21534_21560[(2)] = null);

(statearr_21534_21560[(1)] = (2));


return cljs.core.cst$kw$recur;
} else {
if((state_val_21531 === (4))){
var inst_21498 = (state_21530[(9)]);
var inst_21498__$1 = (state_21530[(2)]);
var inst_21499 = (inst_21498__$1 == null);
var inst_21500 = cljs.core.not(inst_21499);
var state_21530__$1 = (function (){var statearr_21535 = state_21530;
(statearr_21535[(9)] = inst_21498__$1);

return statearr_21535;
})();
if(inst_21500){
var statearr_21536_21561 = state_21530__$1;
(statearr_21536_21561[(1)] = (5));

} else {
var statearr_21537_21562 = state_21530__$1;
(statearr_21537_21562[(1)] = (6));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_21531 === (15))){
var inst_21520 = (state_21530[(2)]);
var state_21530__$1 = state_21530;
var statearr_21538_21563 = state_21530__$1;
(statearr_21538_21563[(2)] = inst_21520);

(statearr_21538_21563[(1)] = (14));


return cljs.core.cst$kw$recur;
} else {
if((state_val_21531 === (13))){
var state_21530__$1 = state_21530;
var statearr_21539_21564 = state_21530__$1;
(statearr_21539_21564[(2)] = null);

(statearr_21539_21564[(1)] = (14));


return cljs.core.cst$kw$recur;
} else {
if((state_val_21531 === (6))){
var inst_21495 = (state_21530[(7)]);
var inst_21516 = (inst_21495 > (0));
var state_21530__$1 = state_21530;
if(cljs.core.truth_(inst_21516)){
var statearr_21540_21565 = state_21530__$1;
(statearr_21540_21565[(1)] = (12));

} else {
var statearr_21541_21566 = state_21530__$1;
(statearr_21541_21566[(1)] = (13));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_21531 === (3))){
var inst_21528 = (state_21530[(2)]);
var state_21530__$1 = state_21530;
return cljs.core.async.impl.ioc_helpers.return_chan(state_21530__$1,inst_21528);
} else {
if((state_val_21531 === (12))){
var inst_21494 = (state_21530[(8)]);
var inst_21518 = cljs.core.vec(inst_21494);
var state_21530__$1 = state_21530;
return cljs.core.async.impl.ioc_helpers.put_BANG_(state_21530__$1,(15),out,inst_21518);
} else {
if((state_val_21531 === (2))){
var state_21530__$1 = state_21530;
return cljs.core.async.impl.ioc_helpers.take_BANG_(state_21530__$1,(4),ch);
} else {
if((state_val_21531 === (11))){
var inst_21510 = (state_21530[(2)]);
var inst_21511 = (new Array(n));
var inst_21494 = inst_21511;
var inst_21495 = (0);
var state_21530__$1 = (function (){var statearr_21542 = state_21530;
(statearr_21542[(10)] = inst_21510);

(statearr_21542[(7)] = inst_21495);

(statearr_21542[(8)] = inst_21494);

return statearr_21542;
})();
var statearr_21543_21567 = state_21530__$1;
(statearr_21543_21567[(2)] = null);

(statearr_21543_21567[(1)] = (2));


return cljs.core.cst$kw$recur;
} else {
if((state_val_21531 === (9))){
var inst_21494 = (state_21530[(8)]);
var inst_21508 = cljs.core.vec(inst_21494);
var state_21530__$1 = state_21530;
return cljs.core.async.impl.ioc_helpers.put_BANG_(state_21530__$1,(11),out,inst_21508);
} else {
if((state_val_21531 === (5))){
var inst_21503 = (state_21530[(11)]);
var inst_21495 = (state_21530[(7)]);
var inst_21494 = (state_21530[(8)]);
var inst_21498 = (state_21530[(9)]);
var inst_21502 = (inst_21494[inst_21495] = inst_21498);
var inst_21503__$1 = (inst_21495 + (1));
var inst_21504 = (inst_21503__$1 < n);
var state_21530__$1 = (function (){var statearr_21544 = state_21530;
(statearr_21544[(11)] = inst_21503__$1);

(statearr_21544[(12)] = inst_21502);

return statearr_21544;
})();
if(cljs.core.truth_(inst_21504)){
var statearr_21545_21568 = state_21530__$1;
(statearr_21545_21568[(1)] = (8));

} else {
var statearr_21546_21569 = state_21530__$1;
(statearr_21546_21569[(1)] = (9));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_21531 === (14))){
var inst_21523 = (state_21530[(2)]);
var inst_21524 = cljs.core.async.close_BANG_(out);
var state_21530__$1 = (function (){var statearr_21548 = state_21530;
(statearr_21548[(13)] = inst_21523);

return statearr_21548;
})();
var statearr_21549_21570 = state_21530__$1;
(statearr_21549_21570[(2)] = inst_21524);

(statearr_21549_21570[(1)] = (7));


return cljs.core.cst$kw$recur;
} else {
if((state_val_21531 === (10))){
var inst_21514 = (state_21530[(2)]);
var state_21530__$1 = state_21530;
var statearr_21550_21571 = state_21530__$1;
(statearr_21550_21571[(2)] = inst_21514);

(statearr_21550_21571[(1)] = (7));


return cljs.core.cst$kw$recur;
} else {
if((state_val_21531 === (8))){
var inst_21503 = (state_21530[(11)]);
var inst_21494 = (state_21530[(8)]);
var tmp21547 = inst_21494;
var inst_21494__$1 = tmp21547;
var inst_21495 = inst_21503;
var state_21530__$1 = (function (){var statearr_21551 = state_21530;
(statearr_21551[(7)] = inst_21495);

(statearr_21551[(8)] = inst_21494__$1);

return statearr_21551;
})();
var statearr_21552_21572 = state_21530__$1;
(statearr_21552_21572[(2)] = null);

(statearr_21552_21572[(1)] = (2));


return cljs.core.cst$kw$recur;
} else {
return null;
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
});})(c__7992__auto___21558,out))
;
return ((function (switch__7885__auto__,c__7992__auto___21558,out){
return (function() {
var cljs$core$async$state_machine__7886__auto__ = null;
var cljs$core$async$state_machine__7886__auto____0 = (function (){
var statearr_21553 = [null,null,null,null,null,null,null,null,null,null,null,null,null,null];
(statearr_21553[(0)] = cljs$core$async$state_machine__7886__auto__);

(statearr_21553[(1)] = (1));

return statearr_21553;
});
var cljs$core$async$state_machine__7886__auto____1 = (function (state_21530){
while(true){
var ret_value__7887__auto__ = (function (){try{while(true){
var result__7888__auto__ = switch__7885__auto__(state_21530);
if(cljs.core.keyword_identical_QMARK_(result__7888__auto__,cljs.core.cst$kw$recur)){
continue;
} else {
return result__7888__auto__;
}
break;
}
}catch (e21554){if((e21554 instanceof Object)){
var ex__7889__auto__ = e21554;
var statearr_21555_21573 = state_21530;
(statearr_21555_21573[(5)] = ex__7889__auto__);


cljs.core.async.impl.ioc_helpers.process_exception(state_21530);

return cljs.core.cst$kw$recur;
} else {
throw e21554;

}
}})();
if(cljs.core.keyword_identical_QMARK_(ret_value__7887__auto__,cljs.core.cst$kw$recur)){
var G__21574 = state_21530;
state_21530 = G__21574;
continue;
} else {
return ret_value__7887__auto__;
}
break;
}
});
cljs$core$async$state_machine__7886__auto__ = function(state_21530){
switch(arguments.length){
case 0:
return cljs$core$async$state_machine__7886__auto____0.call(this);
case 1:
return cljs$core$async$state_machine__7886__auto____1.call(this,state_21530);
}
throw(new Error('Invalid arity: ' + arguments.length));
};
cljs$core$async$state_machine__7886__auto__.cljs$core$IFn$_invoke$arity$0 = cljs$core$async$state_machine__7886__auto____0;
cljs$core$async$state_machine__7886__auto__.cljs$core$IFn$_invoke$arity$1 = cljs$core$async$state_machine__7886__auto____1;
return cljs$core$async$state_machine__7886__auto__;
})()
;})(switch__7885__auto__,c__7992__auto___21558,out))
})();
var state__7994__auto__ = (function (){var statearr_21556 = (f__7993__auto__.cljs$core$IFn$_invoke$arity$0 ? f__7993__auto__.cljs$core$IFn$_invoke$arity$0() : f__7993__auto__.call(null));
(statearr_21556[(6)] = c__7992__auto___21558);

return statearr_21556;
})();
return cljs.core.async.impl.ioc_helpers.run_state_machine_wrapped(state__7994__auto__);
});})(c__7992__auto___21558,out))
);


return out;
});

cljs.core.async.partition.cljs$lang$maxFixedArity = 3;

/**
 * Deprecated - this function will be removed. Use transducer instead
 */
cljs.core.async.partition_by = (function cljs$core$async$partition_by(var_args){
var G__21576 = arguments.length;
switch (G__21576) {
case 2:
return cljs.core.async.partition_by.cljs$core$IFn$_invoke$arity$2((arguments[(0)]),(arguments[(1)]));

break;
case 3:
return cljs.core.async.partition_by.cljs$core$IFn$_invoke$arity$3((arguments[(0)]),(arguments[(1)]),(arguments[(2)]));

break;
default:
throw (new Error(["Invalid arity: ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(arguments.length)].join('')));

}
});

cljs.core.async.partition_by.cljs$core$IFn$_invoke$arity$2 = (function (f,ch){
return cljs.core.async.partition_by.cljs$core$IFn$_invoke$arity$3(f,ch,null);
});

cljs.core.async.partition_by.cljs$core$IFn$_invoke$arity$3 = (function (f,ch,buf_or_n){
var out = cljs.core.async.chan.cljs$core$IFn$_invoke$arity$1(buf_or_n);
var c__7992__auto___21646 = cljs.core.async.chan.cljs$core$IFn$_invoke$arity$1((1));
cljs.core.async.impl.dispatch.run(((function (c__7992__auto___21646,out){
return (function (){
var f__7993__auto__ = (function (){var switch__7885__auto__ = ((function (c__7992__auto___21646,out){
return (function (state_21618){
var state_val_21619 = (state_21618[(1)]);
if((state_val_21619 === (7))){
var inst_21614 = (state_21618[(2)]);
var state_21618__$1 = state_21618;
var statearr_21620_21647 = state_21618__$1;
(statearr_21620_21647[(2)] = inst_21614);

(statearr_21620_21647[(1)] = (3));


return cljs.core.cst$kw$recur;
} else {
if((state_val_21619 === (1))){
var inst_21577 = [];
var inst_21578 = inst_21577;
var inst_21579 = cljs.core.cst$kw$cljs$core$async_SLASH_nothing;
var state_21618__$1 = (function (){var statearr_21621 = state_21618;
(statearr_21621[(7)] = inst_21578);

(statearr_21621[(8)] = inst_21579);

return statearr_21621;
})();
var statearr_21622_21648 = state_21618__$1;
(statearr_21622_21648[(2)] = null);

(statearr_21622_21648[(1)] = (2));


return cljs.core.cst$kw$recur;
} else {
if((state_val_21619 === (4))){
var inst_21582 = (state_21618[(9)]);
var inst_21582__$1 = (state_21618[(2)]);
var inst_21583 = (inst_21582__$1 == null);
var inst_21584 = cljs.core.not(inst_21583);
var state_21618__$1 = (function (){var statearr_21623 = state_21618;
(statearr_21623[(9)] = inst_21582__$1);

return statearr_21623;
})();
if(inst_21584){
var statearr_21624_21649 = state_21618__$1;
(statearr_21624_21649[(1)] = (5));

} else {
var statearr_21625_21650 = state_21618__$1;
(statearr_21625_21650[(1)] = (6));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_21619 === (15))){
var inst_21608 = (state_21618[(2)]);
var state_21618__$1 = state_21618;
var statearr_21626_21651 = state_21618__$1;
(statearr_21626_21651[(2)] = inst_21608);

(statearr_21626_21651[(1)] = (14));


return cljs.core.cst$kw$recur;
} else {
if((state_val_21619 === (13))){
var state_21618__$1 = state_21618;
var statearr_21627_21652 = state_21618__$1;
(statearr_21627_21652[(2)] = null);

(statearr_21627_21652[(1)] = (14));


return cljs.core.cst$kw$recur;
} else {
if((state_val_21619 === (6))){
var inst_21578 = (state_21618[(7)]);
var inst_21603 = inst_21578.length;
var inst_21604 = (inst_21603 > (0));
var state_21618__$1 = state_21618;
if(cljs.core.truth_(inst_21604)){
var statearr_21628_21653 = state_21618__$1;
(statearr_21628_21653[(1)] = (12));

} else {
var statearr_21629_21654 = state_21618__$1;
(statearr_21629_21654[(1)] = (13));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_21619 === (3))){
var inst_21616 = (state_21618[(2)]);
var state_21618__$1 = state_21618;
return cljs.core.async.impl.ioc_helpers.return_chan(state_21618__$1,inst_21616);
} else {
if((state_val_21619 === (12))){
var inst_21578 = (state_21618[(7)]);
var inst_21606 = cljs.core.vec(inst_21578);
var state_21618__$1 = state_21618;
return cljs.core.async.impl.ioc_helpers.put_BANG_(state_21618__$1,(15),out,inst_21606);
} else {
if((state_val_21619 === (2))){
var state_21618__$1 = state_21618;
return cljs.core.async.impl.ioc_helpers.take_BANG_(state_21618__$1,(4),ch);
} else {
if((state_val_21619 === (11))){
var inst_21582 = (state_21618[(9)]);
var inst_21586 = (state_21618[(10)]);
var inst_21596 = (state_21618[(2)]);
var inst_21597 = [];
var inst_21598 = inst_21597.push(inst_21582);
var inst_21578 = inst_21597;
var inst_21579 = inst_21586;
var state_21618__$1 = (function (){var statearr_21630 = state_21618;
(statearr_21630[(7)] = inst_21578);

(statearr_21630[(11)] = inst_21596);

(statearr_21630[(8)] = inst_21579);

(statearr_21630[(12)] = inst_21598);

return statearr_21630;
})();
var statearr_21631_21655 = state_21618__$1;
(statearr_21631_21655[(2)] = null);

(statearr_21631_21655[(1)] = (2));


return cljs.core.cst$kw$recur;
} else {
if((state_val_21619 === (9))){
var inst_21578 = (state_21618[(7)]);
var inst_21594 = cljs.core.vec(inst_21578);
var state_21618__$1 = state_21618;
return cljs.core.async.impl.ioc_helpers.put_BANG_(state_21618__$1,(11),out,inst_21594);
} else {
if((state_val_21619 === (5))){
var inst_21579 = (state_21618[(8)]);
var inst_21582 = (state_21618[(9)]);
var inst_21586 = (state_21618[(10)]);
var inst_21586__$1 = (f.cljs$core$IFn$_invoke$arity$1 ? f.cljs$core$IFn$_invoke$arity$1(inst_21582) : f.call(null,inst_21582));
var inst_21587 = cljs.core._EQ_.cljs$core$IFn$_invoke$arity$2(inst_21586__$1,inst_21579);
var inst_21588 = cljs.core.keyword_identical_QMARK_(inst_21579,cljs.core.cst$kw$cljs$core$async_SLASH_nothing);
var inst_21589 = ((inst_21587) || (inst_21588));
var state_21618__$1 = (function (){var statearr_21632 = state_21618;
(statearr_21632[(10)] = inst_21586__$1);

return statearr_21632;
})();
if(cljs.core.truth_(inst_21589)){
var statearr_21633_21656 = state_21618__$1;
(statearr_21633_21656[(1)] = (8));

} else {
var statearr_21634_21657 = state_21618__$1;
(statearr_21634_21657[(1)] = (9));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_21619 === (14))){
var inst_21611 = (state_21618[(2)]);
var inst_21612 = cljs.core.async.close_BANG_(out);
var state_21618__$1 = (function (){var statearr_21636 = state_21618;
(statearr_21636[(13)] = inst_21611);

return statearr_21636;
})();
var statearr_21637_21658 = state_21618__$1;
(statearr_21637_21658[(2)] = inst_21612);

(statearr_21637_21658[(1)] = (7));


return cljs.core.cst$kw$recur;
} else {
if((state_val_21619 === (10))){
var inst_21601 = (state_21618[(2)]);
var state_21618__$1 = state_21618;
var statearr_21638_21659 = state_21618__$1;
(statearr_21638_21659[(2)] = inst_21601);

(statearr_21638_21659[(1)] = (7));


return cljs.core.cst$kw$recur;
} else {
if((state_val_21619 === (8))){
var inst_21578 = (state_21618[(7)]);
var inst_21582 = (state_21618[(9)]);
var inst_21586 = (state_21618[(10)]);
var inst_21591 = inst_21578.push(inst_21582);
var tmp21635 = inst_21578;
var inst_21578__$1 = tmp21635;
var inst_21579 = inst_21586;
var state_21618__$1 = (function (){var statearr_21639 = state_21618;
(statearr_21639[(7)] = inst_21578__$1);

(statearr_21639[(8)] = inst_21579);

(statearr_21639[(14)] = inst_21591);

return statearr_21639;
})();
var statearr_21640_21660 = state_21618__$1;
(statearr_21640_21660[(2)] = null);

(statearr_21640_21660[(1)] = (2));


return cljs.core.cst$kw$recur;
} else {
return null;
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
});})(c__7992__auto___21646,out))
;
return ((function (switch__7885__auto__,c__7992__auto___21646,out){
return (function() {
var cljs$core$async$state_machine__7886__auto__ = null;
var cljs$core$async$state_machine__7886__auto____0 = (function (){
var statearr_21641 = [null,null,null,null,null,null,null,null,null,null,null,null,null,null,null];
(statearr_21641[(0)] = cljs$core$async$state_machine__7886__auto__);

(statearr_21641[(1)] = (1));

return statearr_21641;
});
var cljs$core$async$state_machine__7886__auto____1 = (function (state_21618){
while(true){
var ret_value__7887__auto__ = (function (){try{while(true){
var result__7888__auto__ = switch__7885__auto__(state_21618);
if(cljs.core.keyword_identical_QMARK_(result__7888__auto__,cljs.core.cst$kw$recur)){
continue;
} else {
return result__7888__auto__;
}
break;
}
}catch (e21642){if((e21642 instanceof Object)){
var ex__7889__auto__ = e21642;
var statearr_21643_21661 = state_21618;
(statearr_21643_21661[(5)] = ex__7889__auto__);


cljs.core.async.impl.ioc_helpers.process_exception(state_21618);

return cljs.core.cst$kw$recur;
} else {
throw e21642;

}
}})();
if(cljs.core.keyword_identical_QMARK_(ret_value__7887__auto__,cljs.core.cst$kw$recur)){
var G__21662 = state_21618;
state_21618 = G__21662;
continue;
} else {
return ret_value__7887__auto__;
}
break;
}
});
cljs$core$async$state_machine__7886__auto__ = function(state_21618){
switch(arguments.length){
case 0:
return cljs$core$async$state_machine__7886__auto____0.call(this);
case 1:
return cljs$core$async$state_machine__7886__auto____1.call(this,state_21618);
}
throw(new Error('Invalid arity: ' + arguments.length));
};
cljs$core$async$state_machine__7886__auto__.cljs$core$IFn$_invoke$arity$0 = cljs$core$async$state_machine__7886__auto____0;
cljs$core$async$state_machine__7886__auto__.cljs$core$IFn$_invoke$arity$1 = cljs$core$async$state_machine__7886__auto____1;
return cljs$core$async$state_machine__7886__auto__;
})()
;})(switch__7885__auto__,c__7992__auto___21646,out))
})();
var state__7994__auto__ = (function (){var statearr_21644 = (f__7993__auto__.cljs$core$IFn$_invoke$arity$0 ? f__7993__auto__.cljs$core$IFn$_invoke$arity$0() : f__7993__auto__.call(null));
(statearr_21644[(6)] = c__7992__auto___21646);

return statearr_21644;
})();
return cljs.core.async.impl.ioc_helpers.run_state_machine_wrapped(state__7994__auto__);
});})(c__7992__auto___21646,out))
);


return out;
});

cljs.core.async.partition_by.cljs$lang$maxFixedArity = 3;

