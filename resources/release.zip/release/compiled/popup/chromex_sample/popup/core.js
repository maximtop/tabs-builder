// Compiled by ClojureScript 1.10.439 {:static-fns true, :optimize-constants true, :elide-asserts true}
goog.provide('chromex_sample.popup.core');
goog.require('cljs.core');
goog.require('cljs.core.constants');
goog.require('cljs.core.async');
goog.require('chromex.logging');
goog.require('chromex.protocols.chrome_port');
goog.require('chromex.ext.runtime');
chromex_sample.popup.core.process_message_BANG_ = (function chromex_sample$popup$core$process_message_BANG_(message){
console.log("POPUP: got message:",message);

return null;
});
chromex_sample.popup.core.run_message_loop_BANG_ = (function chromex_sample$popup$core$run_message_loop_BANG_(message_channel){
console.log("POPUP: starting message loop...");


var c__7992__auto__ = cljs.core.async.chan.cljs$core$IFn$_invoke$arity$1((1));
cljs.core.async.impl.dispatch.run(((function (c__7992__auto__){
return (function (){
var f__7993__auto__ = (function (){var switch__7885__auto__ = ((function (c__7992__auto__){
return (function (state_23549){
var state_val_23550 = (state_23549[(1)]);
if((state_val_23550 === (1))){
var state_23549__$1 = state_23549;
var statearr_23551_23564 = state_23549__$1;
(statearr_23551_23564[(2)] = null);

(statearr_23551_23564[(1)] = (2));


return cljs.core.cst$kw$recur;
} else {
if((state_val_23550 === (2))){
var state_23549__$1 = state_23549;
return cljs.core.async.impl.ioc_helpers.take_BANG_(state_23549__$1,(4),message_channel);
} else {
if((state_val_23550 === (3))){
var inst_23547 = (state_23549[(2)]);
var state_23549__$1 = state_23549;
return cljs.core.async.impl.ioc_helpers.return_chan(state_23549__$1,inst_23547);
} else {
if((state_val_23550 === (4))){
var inst_23537 = (state_23549[(7)]);
var inst_23537__$1 = (state_23549[(2)]);
var inst_23538 = (inst_23537__$1 == null);
var state_23549__$1 = (function (){var statearr_23552 = state_23549;
(statearr_23552[(7)] = inst_23537__$1);

return statearr_23552;
})();
if(cljs.core.truth_(inst_23538)){
var statearr_23553_23565 = state_23549__$1;
(statearr_23553_23565[(1)] = (5));

} else {
var statearr_23554_23566 = state_23549__$1;
(statearr_23554_23566[(1)] = (6));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_23550 === (5))){
var state_23549__$1 = state_23549;
var statearr_23555_23567 = state_23549__$1;
(statearr_23555_23567[(2)] = null);

(statearr_23555_23567[(1)] = (7));


return cljs.core.cst$kw$recur;
} else {
if((state_val_23550 === (6))){
var inst_23537 = (state_23549[(7)]);
var inst_23541 = chromex_sample.popup.core.process_message_BANG_(inst_23537);
var state_23549__$1 = (function (){var statearr_23556 = state_23549;
(statearr_23556[(8)] = inst_23541);

return statearr_23556;
})();
var statearr_23557_23568 = state_23549__$1;
(statearr_23557_23568[(2)] = null);

(statearr_23557_23568[(1)] = (2));


return cljs.core.cst$kw$recur;
} else {
if((state_val_23550 === (7))){
var inst_23544 = (state_23549[(2)]);
var inst_23545 = console.log("POPUP: leaving message loop");
var state_23549__$1 = (function (){var statearr_23558 = state_23549;
(statearr_23558[(9)] = inst_23544);

(statearr_23558[(10)] = inst_23545);

return statearr_23558;
})();
var statearr_23559_23569 = state_23549__$1;
(statearr_23559_23569[(2)] = null);

(statearr_23559_23569[(1)] = (3));


return cljs.core.cst$kw$recur;
} else {
return null;
}
}
}
}
}
}
}
});})(c__7992__auto__))
;
return ((function (switch__7885__auto__,c__7992__auto__){
return (function() {
var chromex_sample$popup$core$run_message_loop_BANG__$_state_machine__7886__auto__ = null;
var chromex_sample$popup$core$run_message_loop_BANG__$_state_machine__7886__auto____0 = (function (){
var statearr_23560 = [null,null,null,null,null,null,null,null,null,null,null];
(statearr_23560[(0)] = chromex_sample$popup$core$run_message_loop_BANG__$_state_machine__7886__auto__);

(statearr_23560[(1)] = (1));

return statearr_23560;
});
var chromex_sample$popup$core$run_message_loop_BANG__$_state_machine__7886__auto____1 = (function (state_23549){
while(true){
var ret_value__7887__auto__ = (function (){try{while(true){
var result__7888__auto__ = switch__7885__auto__(state_23549);
if(cljs.core.keyword_identical_QMARK_(result__7888__auto__,cljs.core.cst$kw$recur)){
continue;
} else {
return result__7888__auto__;
}
break;
}
}catch (e23561){if((e23561 instanceof Object)){
var ex__7889__auto__ = e23561;
var statearr_23562_23570 = state_23549;
(statearr_23562_23570[(5)] = ex__7889__auto__);


cljs.core.async.impl.ioc_helpers.process_exception(state_23549);

return cljs.core.cst$kw$recur;
} else {
throw e23561;

}
}})();
if(cljs.core.keyword_identical_QMARK_(ret_value__7887__auto__,cljs.core.cst$kw$recur)){
var G__23571 = state_23549;
state_23549 = G__23571;
continue;
} else {
return ret_value__7887__auto__;
}
break;
}
});
chromex_sample$popup$core$run_message_loop_BANG__$_state_machine__7886__auto__ = function(state_23549){
switch(arguments.length){
case 0:
return chromex_sample$popup$core$run_message_loop_BANG__$_state_machine__7886__auto____0.call(this);
case 1:
return chromex_sample$popup$core$run_message_loop_BANG__$_state_machine__7886__auto____1.call(this,state_23549);
}
throw(new Error('Invalid arity: ' + arguments.length));
};
chromex_sample$popup$core$run_message_loop_BANG__$_state_machine__7886__auto__.cljs$core$IFn$_invoke$arity$0 = chromex_sample$popup$core$run_message_loop_BANG__$_state_machine__7886__auto____0;
chromex_sample$popup$core$run_message_loop_BANG__$_state_machine__7886__auto__.cljs$core$IFn$_invoke$arity$1 = chromex_sample$popup$core$run_message_loop_BANG__$_state_machine__7886__auto____1;
return chromex_sample$popup$core$run_message_loop_BANG__$_state_machine__7886__auto__;
})()
;})(switch__7885__auto__,c__7992__auto__))
})();
var state__7994__auto__ = (function (){var statearr_23563 = (f__7993__auto__.cljs$core$IFn$_invoke$arity$0 ? f__7993__auto__.cljs$core$IFn$_invoke$arity$0() : f__7993__auto__.call(null));
(statearr_23563[(6)] = c__7992__auto__);

return statearr_23563;
})();
return cljs.core.async.impl.ioc_helpers.run_state_machine_wrapped(state__7994__auto__);
});})(c__7992__auto__))
);

return c__7992__auto__;
});
chromex_sample.popup.core.connect_to_background_page_BANG_ = (function chromex_sample$popup$core$connect_to_background_page_BANG_(){
var background_port = chromex.ext.runtime.connect_STAR_(chromex.config.get_active_config(),cljs.core.cst$kw$omit,cljs.core.cst$kw$omit);
chromex.protocols.chrome_port.post_message_BANG_(background_port,"hello from POPUP!");

return chromex_sample.popup.core.run_message_loop_BANG_(background_port);
});
chromex_sample.popup.core.init_BANG_ = (function chromex_sample$popup$core$init_BANG_(){
console.log("POPUP: init");


return chromex_sample.popup.core.connect_to_background_page_BANG_();
});
