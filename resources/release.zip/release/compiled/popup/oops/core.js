// Compiled by ClojureScript 1.10.439 {:static-fns true, :optimize-constants true, :elide-asserts true}
goog.provide('oops.core');
goog.require('cljs.core');
goog.require('cljs.core.constants');
goog.require('cljs.spec.alpha');
goog.require('goog.object');
goog.require('oops.sdefs');
goog.require('oops.state');
goog.require('oops.config');
goog.require('oops.messages');
goog.require('oops.helpers');
goog.require('oops.schema');
oops.core.report_error_dynamically = (function oops$core$report_error_dynamically(msg,data){
if(oops.state.was_error_reported_QMARK_()){
return null;
} else {
oops.state.mark_error_reported_BANG_();

var G__22626 = oops.config.get_error_reporting();
if(cljs.core._EQ_.cljs$core$IFn$_invoke$arity$2(cljs.core.cst$kw$throw,G__22626)){
throw oops.state.prepare_error_from_call_site(msg,oops.helpers.wrap_data_in_enveloper_if_possible(oops.config.use_envelope_QMARK_(),data));
} else {
if(cljs.core._EQ_.cljs$core$IFn$_invoke$arity$2(cljs.core.cst$kw$console,G__22626)){
var G__22628 = (console["error"]);
var G__22629 = msg;
var G__22630 = oops.helpers.wrap_data_in_enveloper_if_possible(oops.config.use_envelope_QMARK_(),data);
var fexpr__22627 = oops.state.get_console_reporter();
return (fexpr__22627.cljs$core$IFn$_invoke$arity$3 ? fexpr__22627.cljs$core$IFn$_invoke$arity$3(G__22628,G__22629,G__22630) : fexpr__22627.call(null,G__22628,G__22629,G__22630));
} else {
if(cljs.core._EQ_.cljs$core$IFn$_invoke$arity$2(false,G__22626)){
return null;
} else {
throw (new Error(["No matching clause: ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(G__22626)].join('')));

}
}
}
}
});
oops.core.report_warning_dynamically = (function oops$core$report_warning_dynamically(msg,data){
var G__22631 = oops.config.get_warning_reporting();
if(cljs.core._EQ_.cljs$core$IFn$_invoke$arity$2(cljs.core.cst$kw$throw,G__22631)){
throw oops.state.prepare_error_from_call_site(msg,oops.helpers.wrap_data_in_enveloper_if_possible(oops.config.use_envelope_QMARK_(),data));
} else {
if(cljs.core._EQ_.cljs$core$IFn$_invoke$arity$2(cljs.core.cst$kw$console,G__22631)){
var G__22633 = (console["warn"]);
var G__22634 = msg;
var G__22635 = oops.helpers.wrap_data_in_enveloper_if_possible(oops.config.use_envelope_QMARK_(),data);
var fexpr__22632 = oops.state.get_console_reporter();
return (fexpr__22632.cljs$core$IFn$_invoke$arity$3 ? fexpr__22632.cljs$core$IFn$_invoke$arity$3(G__22633,G__22634,G__22635) : fexpr__22632.call(null,G__22633,G__22634,G__22635));
} else {
if(cljs.core._EQ_.cljs$core$IFn$_invoke$arity$2(false,G__22631)){
return null;
} else {
throw (new Error(["No matching clause: ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(G__22631)].join('')));

}
}
}
});
oops.core.report_if_needed_dynamically = (function oops$core$report_if_needed_dynamically(var_args){
var args__4647__auto__ = [];
var len__4641__auto___22642 = arguments.length;
var i__4642__auto___22643 = (0);
while(true){
if((i__4642__auto___22643 < len__4641__auto___22642)){
args__4647__auto__.push((arguments[i__4642__auto___22643]));

var G__22644 = (i__4642__auto___22643 + (1));
i__4642__auto___22643 = G__22644;
continue;
} else {
}
break;
}

var argseq__4648__auto__ = ((((1) < args__4647__auto__.length))?(new cljs.core.IndexedSeq(args__4647__auto__.slice((1)),(0),null)):null);
return oops.core.report_if_needed_dynamically.cljs$core$IFn$_invoke$arity$variadic((arguments[(0)]),argseq__4648__auto__);
});

oops.core.report_if_needed_dynamically.cljs$core$IFn$_invoke$arity$variadic = (function (msg_id,p__22638){
var vec__22639 = p__22638;
var info = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(vec__22639,(0),null);
return null;
});

oops.core.report_if_needed_dynamically.cljs$lang$maxFixedArity = (1);

/** @this {Function} */
oops.core.report_if_needed_dynamically.cljs$lang$applyTo = (function (seq22636){
var G__22637 = cljs.core.first(seq22636);
var seq22636__$1 = cljs.core.next(seq22636);
var self__4628__auto__ = this;
return self__4628__auto__.cljs$core$IFn$_invoke$arity$variadic(G__22637,seq22636__$1);
});

oops.core.validate_object_access_dynamically = (function oops$core$validate_object_access_dynamically(obj,mode,key,push_QMARK_,check_key_read_QMARK_,check_key_write_QMARK_){
if(((((cljs.core._EQ_.cljs$core$IFn$_invoke$arity$2(mode,(0))) && ((void 0 === obj))))?((cljs.core.contains_QMARK_(oops.config.get_suppress_reporting(),cljs.core.cst$kw$unexpected_DASH_object_DASH_value))?true:(function (){
(oops.core.report_if_needed_dynamically.cljs$core$IFn$_invoke$arity$2 ? oops.core.report_if_needed_dynamically.cljs$core$IFn$_invoke$arity$2(cljs.core.cst$kw$unexpected_DASH_object_DASH_value,new cljs.core.PersistentArrayMap(null, 3, [cljs.core.cst$kw$path,oops.state.get_key_path_str(),cljs.core.cst$kw$flavor,"undefined",cljs.core.cst$kw$obj,oops.state.get_target_object()], null)) : oops.core.report_if_needed_dynamically.call(null,cljs.core.cst$kw$unexpected_DASH_object_DASH_value,new cljs.core.PersistentArrayMap(null, 3, [cljs.core.cst$kw$path,oops.state.get_key_path_str(),cljs.core.cst$kw$flavor,"undefined",cljs.core.cst$kw$obj,oops.state.get_target_object()], null)));

return false;
})()
):((((cljs.core._EQ_.cljs$core$IFn$_invoke$arity$2(mode,(0))) && ((obj == null))))?((cljs.core.contains_QMARK_(oops.config.get_suppress_reporting(),cljs.core.cst$kw$unexpected_DASH_object_DASH_value))?true:(function (){
(oops.core.report_if_needed_dynamically.cljs$core$IFn$_invoke$arity$2 ? oops.core.report_if_needed_dynamically.cljs$core$IFn$_invoke$arity$2(cljs.core.cst$kw$unexpected_DASH_object_DASH_value,new cljs.core.PersistentArrayMap(null, 3, [cljs.core.cst$kw$path,oops.state.get_key_path_str(),cljs.core.cst$kw$flavor,"nil",cljs.core.cst$kw$obj,oops.state.get_target_object()], null)) : oops.core.report_if_needed_dynamically.call(null,cljs.core.cst$kw$unexpected_DASH_object_DASH_value,new cljs.core.PersistentArrayMap(null, 3, [cljs.core.cst$kw$path,oops.state.get_key_path_str(),cljs.core.cst$kw$flavor,"nil",cljs.core.cst$kw$obj,oops.state.get_target_object()], null)));

return false;
})()
):(cljs.core.truth_(goog.isBoolean(obj))?((cljs.core.contains_QMARK_(oops.config.get_suppress_reporting(),cljs.core.cst$kw$unexpected_DASH_object_DASH_value))?true:(function (){
(oops.core.report_if_needed_dynamically.cljs$core$IFn$_invoke$arity$2 ? oops.core.report_if_needed_dynamically.cljs$core$IFn$_invoke$arity$2(cljs.core.cst$kw$unexpected_DASH_object_DASH_value,new cljs.core.PersistentArrayMap(null, 3, [cljs.core.cst$kw$path,oops.state.get_key_path_str(),cljs.core.cst$kw$flavor,"boolean",cljs.core.cst$kw$obj,oops.state.get_target_object()], null)) : oops.core.report_if_needed_dynamically.call(null,cljs.core.cst$kw$unexpected_DASH_object_DASH_value,new cljs.core.PersistentArrayMap(null, 3, [cljs.core.cst$kw$path,oops.state.get_key_path_str(),cljs.core.cst$kw$flavor,"boolean",cljs.core.cst$kw$obj,oops.state.get_target_object()], null)));

return false;
})()
):(cljs.core.truth_(goog.isNumber(obj))?((cljs.core.contains_QMARK_(oops.config.get_suppress_reporting(),cljs.core.cst$kw$unexpected_DASH_object_DASH_value))?true:(function (){
(oops.core.report_if_needed_dynamically.cljs$core$IFn$_invoke$arity$2 ? oops.core.report_if_needed_dynamically.cljs$core$IFn$_invoke$arity$2(cljs.core.cst$kw$unexpected_DASH_object_DASH_value,new cljs.core.PersistentArrayMap(null, 3, [cljs.core.cst$kw$path,oops.state.get_key_path_str(),cljs.core.cst$kw$flavor,"number",cljs.core.cst$kw$obj,oops.state.get_target_object()], null)) : oops.core.report_if_needed_dynamically.call(null,cljs.core.cst$kw$unexpected_DASH_object_DASH_value,new cljs.core.PersistentArrayMap(null, 3, [cljs.core.cst$kw$path,oops.state.get_key_path_str(),cljs.core.cst$kw$flavor,"number",cljs.core.cst$kw$obj,oops.state.get_target_object()], null)));

return false;
})()
):(cljs.core.truth_(goog.isString(obj))?((cljs.core.contains_QMARK_(oops.config.get_suppress_reporting(),cljs.core.cst$kw$unexpected_DASH_object_DASH_value))?true:(function (){
(oops.core.report_if_needed_dynamically.cljs$core$IFn$_invoke$arity$2 ? oops.core.report_if_needed_dynamically.cljs$core$IFn$_invoke$arity$2(cljs.core.cst$kw$unexpected_DASH_object_DASH_value,new cljs.core.PersistentArrayMap(null, 3, [cljs.core.cst$kw$path,oops.state.get_key_path_str(),cljs.core.cst$kw$flavor,"string",cljs.core.cst$kw$obj,oops.state.get_target_object()], null)) : oops.core.report_if_needed_dynamically.call(null,cljs.core.cst$kw$unexpected_DASH_object_DASH_value,new cljs.core.PersistentArrayMap(null, 3, [cljs.core.cst$kw$path,oops.state.get_key_path_str(),cljs.core.cst$kw$flavor,"string",cljs.core.cst$kw$obj,oops.state.get_target_object()], null)));

return false;
})()
):((cljs.core.not(goog.isObject(obj)))?((cljs.core.contains_QMARK_(oops.config.get_suppress_reporting(),cljs.core.cst$kw$unexpected_DASH_object_DASH_value))?true:(function (){
(oops.core.report_if_needed_dynamically.cljs$core$IFn$_invoke$arity$2 ? oops.core.report_if_needed_dynamically.cljs$core$IFn$_invoke$arity$2(cljs.core.cst$kw$unexpected_DASH_object_DASH_value,new cljs.core.PersistentArrayMap(null, 3, [cljs.core.cst$kw$path,oops.state.get_key_path_str(),cljs.core.cst$kw$flavor,"non-object",cljs.core.cst$kw$obj,oops.state.get_target_object()], null)) : oops.core.report_if_needed_dynamically.call(null,cljs.core.cst$kw$unexpected_DASH_object_DASH_value,new cljs.core.PersistentArrayMap(null, 3, [cljs.core.cst$kw$path,oops.state.get_key_path_str(),cljs.core.cst$kw$flavor,"non-object",cljs.core.cst$kw$obj,oops.state.get_target_object()], null)));

return false;
})()
):(cljs.core.truth_(goog.isDateLike(obj))?((cljs.core.contains_QMARK_(oops.config.get_suppress_reporting(),cljs.core.cst$kw$unexpected_DASH_object_DASH_value))?true:(function (){
(oops.core.report_if_needed_dynamically.cljs$core$IFn$_invoke$arity$2 ? oops.core.report_if_needed_dynamically.cljs$core$IFn$_invoke$arity$2(cljs.core.cst$kw$unexpected_DASH_object_DASH_value,new cljs.core.PersistentArrayMap(null, 3, [cljs.core.cst$kw$path,oops.state.get_key_path_str(),cljs.core.cst$kw$flavor,"date-like",cljs.core.cst$kw$obj,oops.state.get_target_object()], null)) : oops.core.report_if_needed_dynamically.call(null,cljs.core.cst$kw$unexpected_DASH_object_DASH_value,new cljs.core.PersistentArrayMap(null, 3, [cljs.core.cst$kw$path,oops.state.get_key_path_str(),cljs.core.cst$kw$flavor,"date-like",cljs.core.cst$kw$obj,oops.state.get_target_object()], null)));

return true;
})()
):(cljs.core.truth_(oops.helpers.cljs_type_QMARK_(obj))?((cljs.core.contains_QMARK_(oops.config.get_suppress_reporting(),cljs.core.cst$kw$unexpected_DASH_object_DASH_value))?true:(function (){
(oops.core.report_if_needed_dynamically.cljs$core$IFn$_invoke$arity$2 ? oops.core.report_if_needed_dynamically.cljs$core$IFn$_invoke$arity$2(cljs.core.cst$kw$unexpected_DASH_object_DASH_value,new cljs.core.PersistentArrayMap(null, 3, [cljs.core.cst$kw$path,oops.state.get_key_path_str(),cljs.core.cst$kw$flavor,"cljs type",cljs.core.cst$kw$obj,oops.state.get_target_object()], null)) : oops.core.report_if_needed_dynamically.call(null,cljs.core.cst$kw$unexpected_DASH_object_DASH_value,new cljs.core.PersistentArrayMap(null, 3, [cljs.core.cst$kw$path,oops.state.get_key_path_str(),cljs.core.cst$kw$flavor,"cljs type",cljs.core.cst$kw$obj,oops.state.get_target_object()], null)));

return true;
})()
):(cljs.core.truth_(oops.helpers.cljs_instance_QMARK_(obj))?((cljs.core.contains_QMARK_(oops.config.get_suppress_reporting(),cljs.core.cst$kw$unexpected_DASH_object_DASH_value))?true:(function (){
(oops.core.report_if_needed_dynamically.cljs$core$IFn$_invoke$arity$2 ? oops.core.report_if_needed_dynamically.cljs$core$IFn$_invoke$arity$2(cljs.core.cst$kw$unexpected_DASH_object_DASH_value,new cljs.core.PersistentArrayMap(null, 3, [cljs.core.cst$kw$path,oops.state.get_key_path_str(),cljs.core.cst$kw$flavor,"cljs instance",cljs.core.cst$kw$obj,oops.state.get_target_object()], null)) : oops.core.report_if_needed_dynamically.call(null,cljs.core.cst$kw$unexpected_DASH_object_DASH_value,new cljs.core.PersistentArrayMap(null, 3, [cljs.core.cst$kw$path,oops.state.get_key_path_str(),cljs.core.cst$kw$flavor,"cljs instance",cljs.core.cst$kw$obj,oops.state.get_target_object()], null)));

return true;
})()
):true
)))))))))){
if(cljs.core.truth_(push_QMARK_)){
oops.state.add_key_to_current_path_BANG_(key);

oops.state.set_last_access_modifier_BANG_(mode);
} else {
}

var and__4036__auto__ = (cljs.core.truth_(check_key_read_QMARK_)?((((cljs.core._EQ_.cljs$core$IFn$_invoke$arity$2(mode,(0))) && (cljs.core.not(goog.object.containsKey(obj,key)))))?(oops.core.report_if_needed_dynamically.cljs$core$IFn$_invoke$arity$2 ? oops.core.report_if_needed_dynamically.cljs$core$IFn$_invoke$arity$2(cljs.core.cst$kw$missing_DASH_object_DASH_key,new cljs.core.PersistentArrayMap(null, 3, [cljs.core.cst$kw$path,oops.state.get_key_path_str(),cljs.core.cst$kw$key,key,cljs.core.cst$kw$obj,oops.state.get_target_object()], null)) : oops.core.report_if_needed_dynamically.call(null,cljs.core.cst$kw$missing_DASH_object_DASH_key,new cljs.core.PersistentArrayMap(null, 3, [cljs.core.cst$kw$path,oops.state.get_key_path_str(),cljs.core.cst$kw$key,key,cljs.core.cst$kw$obj,oops.state.get_target_object()], null))):true):true);
if(cljs.core.truth_(and__4036__auto__)){
if(cljs.core.truth_(check_key_write_QMARK_)){
var temp__5459__auto__ = oops.helpers.get_property_descriptor(obj,key);
if((temp__5459__auto__ == null)){
if(cljs.core.truth_(oops.helpers.is_object_frozen_QMARK_(obj))){
return (oops.core.report_if_needed_dynamically.cljs$core$IFn$_invoke$arity$2 ? oops.core.report_if_needed_dynamically.cljs$core$IFn$_invoke$arity$2(cljs.core.cst$kw$object_DASH_is_DASH_frozen,new cljs.core.PersistentArrayMap(null, 3, [cljs.core.cst$kw$path,oops.state.get_key_path_str(),cljs.core.cst$kw$key,key,cljs.core.cst$kw$obj,oops.state.get_target_object()], null)) : oops.core.report_if_needed_dynamically.call(null,cljs.core.cst$kw$object_DASH_is_DASH_frozen,new cljs.core.PersistentArrayMap(null, 3, [cljs.core.cst$kw$path,oops.state.get_key_path_str(),cljs.core.cst$kw$key,key,cljs.core.cst$kw$obj,oops.state.get_target_object()], null)));
} else {
if(cljs.core.truth_(oops.helpers.is_object_sealed_QMARK_(obj))){
return (oops.core.report_if_needed_dynamically.cljs$core$IFn$_invoke$arity$2 ? oops.core.report_if_needed_dynamically.cljs$core$IFn$_invoke$arity$2(cljs.core.cst$kw$object_DASH_is_DASH_sealed,new cljs.core.PersistentArrayMap(null, 3, [cljs.core.cst$kw$path,oops.state.get_key_path_str(),cljs.core.cst$kw$key,key,cljs.core.cst$kw$obj,oops.state.get_target_object()], null)) : oops.core.report_if_needed_dynamically.call(null,cljs.core.cst$kw$object_DASH_is_DASH_sealed,new cljs.core.PersistentArrayMap(null, 3, [cljs.core.cst$kw$path,oops.state.get_key_path_str(),cljs.core.cst$kw$key,key,cljs.core.cst$kw$obj,oops.state.get_target_object()], null)));
} else {
return true;

}
}
} else {
var descriptor_22645 = temp__5459__auto__;
var temp__5459__auto____$1 = oops.helpers.determine_property_non_writable_reason(descriptor_22645);
if((temp__5459__auto____$1 == null)){
return true;
} else {
var reason_22646 = temp__5459__auto____$1;
return (oops.core.report_if_needed_dynamically.cljs$core$IFn$_invoke$arity$2 ? oops.core.report_if_needed_dynamically.cljs$core$IFn$_invoke$arity$2(cljs.core.cst$kw$object_DASH_key_DASH_not_DASH_writable,new cljs.core.PersistentArrayMap(null, 5, [cljs.core.cst$kw$path,oops.state.get_key_path_str(),cljs.core.cst$kw$key,key,cljs.core.cst$kw$frozen_QMARK_,oops.helpers.is_object_frozen_QMARK_(obj),cljs.core.cst$kw$reason,reason_22646,cljs.core.cst$kw$obj,oops.state.get_target_object()], null)) : oops.core.report_if_needed_dynamically.call(null,cljs.core.cst$kw$object_DASH_key_DASH_not_DASH_writable,new cljs.core.PersistentArrayMap(null, 5, [cljs.core.cst$kw$path,oops.state.get_key_path_str(),cljs.core.cst$kw$key,key,cljs.core.cst$kw$frozen_QMARK_,oops.helpers.is_object_frozen_QMARK_(obj),cljs.core.cst$kw$reason,reason_22646,cljs.core.cst$kw$obj,oops.state.get_target_object()], null)));
}
}
} else {
return true;
}
} else {
return and__4036__auto__;
}
} else {
return null;
}
});
oops.core.validate_fn_call_dynamically = (function oops$core$validate_fn_call_dynamically(fn,mode){
if(((cljs.core._EQ_.cljs$core$IFn$_invoke$arity$2(mode,(1))) && ((fn == null)))){
return true;
} else {
if(cljs.core.truth_(goog.isFunction(fn))){
return true;
} else {
return (oops.core.report_if_needed_dynamically.cljs$core$IFn$_invoke$arity$2 ? oops.core.report_if_needed_dynamically.cljs$core$IFn$_invoke$arity$2(cljs.core.cst$kw$expected_DASH_function_DASH_value,new cljs.core.PersistentArrayMap(null, 4, [cljs.core.cst$kw$path,oops.state.get_key_path_str(),cljs.core.cst$kw$soft_QMARK_,cljs.core._EQ_.cljs$core$IFn$_invoke$arity$2(mode,(1)),cljs.core.cst$kw$fn,fn,cljs.core.cst$kw$obj,oops.state.get_target_object()], null)) : oops.core.report_if_needed_dynamically.call(null,cljs.core.cst$kw$expected_DASH_function_DASH_value,new cljs.core.PersistentArrayMap(null, 4, [cljs.core.cst$kw$path,oops.state.get_key_path_str(),cljs.core.cst$kw$soft_QMARK_,cljs.core._EQ_.cljs$core$IFn$_invoke$arity$2(mode,(1)),cljs.core.cst$kw$fn,fn,cljs.core.cst$kw$obj,oops.state.get_target_object()], null)));

}
}
});
oops.core.punch_key_dynamically_BANG_ = (function oops$core$punch_key_dynamically_BANG_(obj,key){
var child_factory_22648 = oops.config.get_child_factory();
var child_factory_22648__$1 = (function (){var G__22649 = child_factory_22648;
var G__22649__$1 = (((G__22649 instanceof cljs.core.Keyword))?G__22649.fqn:null);
switch (G__22649__$1) {
case "js-obj":
return ((function (G__22649,G__22649__$1,child_factory_22648){
return (function (){
return {};
});
;})(G__22649,G__22649__$1,child_factory_22648))

break;
case "js-array":
return ((function (G__22649,G__22649__$1,child_factory_22648){
return (function (){
return [];
});
;})(G__22649,G__22649__$1,child_factory_22648))

break;
default:
return child_factory_22648;

}
})();

var child_obj_22647 = (child_factory_22648__$1.cljs$core$IFn$_invoke$arity$2 ? child_factory_22648__$1.cljs$core$IFn$_invoke$arity$2(obj,key) : child_factory_22648__$1.call(null,obj,key));
(obj[key] = child_obj_22647);

return child_obj_22647;
});
oops.core.build_path_dynamically = (function oops$core$build_path_dynamically(selector){
if(((typeof selector === 'string') || ((selector instanceof cljs.core.Keyword)))){
var selector_path_22653 = [];
oops.schema.prepare_simple_path_BANG_(selector,selector_path_22653);

return selector_path_22653;
} else {
var selector_path_22654 = [];
oops.schema.prepare_path_BANG_(selector,selector_path_22654);

return selector_path_22654;

}
});
oops.core.check_path_dynamically = (function oops$core$check_path_dynamically(path,op){
var temp__5461__auto__ = oops.schema.check_dynamic_path_BANG_(path,op);
if((temp__5461__auto__ == null)){
return null;
} else {
var issue_22655 = temp__5461__auto__;
return cljs.core.apply.cljs$core$IFn$_invoke$arity$2(oops.core.report_if_needed_dynamically,issue_22655);
}
});
oops.core.get_key_dynamically = (function oops$core$get_key_dynamically(obj,key,mode){
return (obj[key]);
});
oops.core.set_key_dynamically = (function oops$core$set_key_dynamically(obj,key,val,mode){
return (obj[key] = val);
});
oops.core.get_selector_dynamically = (function oops$core$get_selector_dynamically(obj,selector){
var path_22657 = (function (){var path_22656 = oops.core.build_path_dynamically(selector);

return path_22656;
})();
var len_22658 = path_22657.length;
var i_22659 = (0);
var obj_22660 = obj;
while(true){
if((i_22659 < len_22658)){
var mode_22661 = (path_22657[i_22659]);
var key_22662 = (path_22657[(i_22659 + (1))]);
var next_obj_22663 = oops.core.get_key_dynamically(obj_22660,key_22662,mode_22661);
var G__22664 = mode_22661;
switch (G__22664) {
case (0):
var G__22666 = (i_22659 + (2));
var G__22667 = next_obj_22663;
i_22659 = G__22666;
obj_22660 = G__22667;
continue;

break;
case (1):
if((!((next_obj_22663 == null)))){
var G__22668 = (i_22659 + (2));
var G__22669 = next_obj_22663;
i_22659 = G__22668;
obj_22660 = G__22669;
continue;
} else {
return null;
}

break;
case (2):
if((!((next_obj_22663 == null)))){
var G__22670 = (i_22659 + (2));
var G__22671 = next_obj_22663;
i_22659 = G__22670;
obj_22660 = G__22671;
continue;
} else {
var G__22672 = (i_22659 + (2));
var G__22673 = (oops.core.punch_key_dynamically_BANG_.cljs$core$IFn$_invoke$arity$2 ? oops.core.punch_key_dynamically_BANG_.cljs$core$IFn$_invoke$arity$2(obj_22660,key_22662) : oops.core.punch_key_dynamically_BANG_.call(null,obj_22660,key_22662));
i_22659 = G__22672;
obj_22660 = G__22673;
continue;
}

break;
default:
throw (new Error(["No matching clause: ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(G__22664)].join('')));

}
} else {
return obj_22660;
}
break;
}
});
oops.core.get_selector_call_info_dynamically = (function oops$core$get_selector_call_info_dynamically(obj,selector){
var path_22675 = (function (){var path_22674 = oops.core.build_path_dynamically(selector);

return path_22674;
})();
var len_22676 = path_22675.length;
if((len_22676 < (4))){
return [obj,(function (){var path_22678 = path_22675;
var len_22679 = path_22678.length;
var i_22680 = (0);
var obj_22681 = obj;
while(true){
if((i_22680 < len_22679)){
var mode_22682 = (path_22678[i_22680]);
var key_22683 = (path_22678[(i_22680 + (1))]);
var next_obj_22684 = oops.core.get_key_dynamically(obj_22681,key_22683,mode_22682);
var G__22699 = mode_22682;
switch (G__22699) {
case (0):
var G__22703 = (i_22680 + (2));
var G__22704 = next_obj_22684;
i_22680 = G__22703;
obj_22681 = G__22704;
continue;

break;
case (1):
if((!((next_obj_22684 == null)))){
var G__22705 = (i_22680 + (2));
var G__22706 = next_obj_22684;
i_22680 = G__22705;
obj_22681 = G__22706;
continue;
} else {
return null;
}

break;
case (2):
if((!((next_obj_22684 == null)))){
var G__22707 = (i_22680 + (2));
var G__22708 = next_obj_22684;
i_22680 = G__22707;
obj_22681 = G__22708;
continue;
} else {
var G__22709 = (i_22680 + (2));
var G__22710 = (oops.core.punch_key_dynamically_BANG_.cljs$core$IFn$_invoke$arity$2 ? oops.core.punch_key_dynamically_BANG_.cljs$core$IFn$_invoke$arity$2(obj_22681,key_22683) : oops.core.punch_key_dynamically_BANG_.call(null,obj_22681,key_22683));
i_22680 = G__22709;
obj_22681 = G__22710;
continue;
}

break;
default:
throw (new Error(["No matching clause: ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(G__22699)].join('')));

}
} else {
return obj_22681;
}
break;
}
})()];
} else {
var target_obj_22677 = (function (){var path_22685 = path_22675.slice((0),(len_22676 - (2)));
var len_22686 = path_22685.length;
var i_22687 = (0);
var obj_22688 = obj;
while(true){
if((i_22687 < len_22686)){
var mode_22689 = (path_22685[i_22687]);
var key_22690 = (path_22685[(i_22687 + (1))]);
var next_obj_22691 = oops.core.get_key_dynamically(obj_22688,key_22690,mode_22689);
var G__22700 = mode_22689;
switch (G__22700) {
case (0):
var G__22712 = (i_22687 + (2));
var G__22713 = next_obj_22691;
i_22687 = G__22712;
obj_22688 = G__22713;
continue;

break;
case (1):
if((!((next_obj_22691 == null)))){
var G__22714 = (i_22687 + (2));
var G__22715 = next_obj_22691;
i_22687 = G__22714;
obj_22688 = G__22715;
continue;
} else {
return null;
}

break;
case (2):
if((!((next_obj_22691 == null)))){
var G__22716 = (i_22687 + (2));
var G__22717 = next_obj_22691;
i_22687 = G__22716;
obj_22688 = G__22717;
continue;
} else {
var G__22718 = (i_22687 + (2));
var G__22719 = (oops.core.punch_key_dynamically_BANG_.cljs$core$IFn$_invoke$arity$2 ? oops.core.punch_key_dynamically_BANG_.cljs$core$IFn$_invoke$arity$2(obj_22688,key_22690) : oops.core.punch_key_dynamically_BANG_.call(null,obj_22688,key_22690));
i_22687 = G__22718;
obj_22688 = G__22719;
continue;
}

break;
default:
throw (new Error(["No matching clause: ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(G__22700)].join('')));

}
} else {
return obj_22688;
}
break;
}
})();
return [target_obj_22677,(function (){var path_22692 = [(path_22675[(len_22676 - (2))]),(path_22675[(len_22676 - (1))])];
var len_22693 = path_22692.length;
var i_22694 = (0);
var obj_22695 = target_obj_22677;
while(true){
if((i_22694 < len_22693)){
var mode_22696 = (path_22692[i_22694]);
var key_22697 = (path_22692[(i_22694 + (1))]);
var next_obj_22698 = oops.core.get_key_dynamically(obj_22695,key_22697,mode_22696);
var G__22701 = mode_22696;
switch (G__22701) {
case (0):
var G__22721 = (i_22694 + (2));
var G__22722 = next_obj_22698;
i_22694 = G__22721;
obj_22695 = G__22722;
continue;

break;
case (1):
if((!((next_obj_22698 == null)))){
var G__22723 = (i_22694 + (2));
var G__22724 = next_obj_22698;
i_22694 = G__22723;
obj_22695 = G__22724;
continue;
} else {
return null;
}

break;
case (2):
if((!((next_obj_22698 == null)))){
var G__22725 = (i_22694 + (2));
var G__22726 = next_obj_22698;
i_22694 = G__22725;
obj_22695 = G__22726;
continue;
} else {
var G__22727 = (i_22694 + (2));
var G__22728 = (oops.core.punch_key_dynamically_BANG_.cljs$core$IFn$_invoke$arity$2 ? oops.core.punch_key_dynamically_BANG_.cljs$core$IFn$_invoke$arity$2(obj_22695,key_22697) : oops.core.punch_key_dynamically_BANG_.call(null,obj_22695,key_22697));
i_22694 = G__22727;
obj_22695 = G__22728;
continue;
}

break;
default:
throw (new Error(["No matching clause: ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(G__22701)].join('')));

}
} else {
return obj_22695;
}
break;
}
})()];
}
});
oops.core.set_selector_dynamically = (function oops$core$set_selector_dynamically(obj,selector,val){
var path_22730 = (function (){var path_22729 = oops.core.build_path_dynamically(selector);

return path_22729;
})();
var len_22733 = path_22730.length;
var parent_obj_path_22734 = path_22730.slice((0),(len_22733 - (2)));
var key_22731 = (path_22730[(len_22733 - (1))]);
var mode_22732 = (path_22730[(len_22733 - (2))]);
var parent_obj_22735 = (function (){var path_22736 = parent_obj_path_22734;
var len_22737 = path_22736.length;
var i_22738 = (0);
var obj_22739 = obj;
while(true){
if((i_22738 < len_22737)){
var mode_22740 = (path_22736[i_22738]);
var key_22741 = (path_22736[(i_22738 + (1))]);
var next_obj_22742 = oops.core.get_key_dynamically(obj_22739,key_22741,mode_22740);
var G__22743 = mode_22740;
switch (G__22743) {
case (0):
var G__22745 = (i_22738 + (2));
var G__22746 = next_obj_22742;
i_22738 = G__22745;
obj_22739 = G__22746;
continue;

break;
case (1):
if((!((next_obj_22742 == null)))){
var G__22747 = (i_22738 + (2));
var G__22748 = next_obj_22742;
i_22738 = G__22747;
obj_22739 = G__22748;
continue;
} else {
return null;
}

break;
case (2):
if((!((next_obj_22742 == null)))){
var G__22749 = (i_22738 + (2));
var G__22750 = next_obj_22742;
i_22738 = G__22749;
obj_22739 = G__22750;
continue;
} else {
var G__22751 = (i_22738 + (2));
var G__22752 = (oops.core.punch_key_dynamically_BANG_.cljs$core$IFn$_invoke$arity$2 ? oops.core.punch_key_dynamically_BANG_.cljs$core$IFn$_invoke$arity$2(obj_22739,key_22741) : oops.core.punch_key_dynamically_BANG_.call(null,obj_22739,key_22741));
i_22738 = G__22751;
obj_22739 = G__22752;
continue;
}

break;
default:
throw (new Error(["No matching clause: ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(G__22743)].join('')));

}
} else {
return obj_22739;
}
break;
}
})();
return oops.core.set_key_dynamically(parent_obj_22735,key_22731,val,mode_22732);
});
